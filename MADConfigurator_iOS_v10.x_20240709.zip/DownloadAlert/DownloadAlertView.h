//
//  ExistingSurveyDeleteConfirmView.h
//  MADSurvey
//
//  Created by Alex on 6/1/17.
//  Copyright © 2017 MAD Elevator Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^stop_survey_yes_block)(void);
typedef void (^stop_survey_no_block)(void);

@interface DownloadAlertView : UIView
{
    IBOutlet UIView * confirmView;
    IBOutlet UILabel *textLabel;
}

@property (nonatomic) stop_survey_yes_block yesBlock;
@property (nonatomic) stop_survey_no_block noBlock;

- (IBAction)yes:(id)sender;
- (IBAction)no:(id)sender;

+ (DownloadAlertView*) showOnView:(UIView*) view;

@end
