//
//  DownloadAlertView.m
//  MADSurvey
//
//  Created by Alex on 6/1/17.
//  Copyright © 2017 MAD Elevator Inc. All rights reserved.
//

#import "DownloadAlertView.h"

@implementation DownloadAlertView

+ (DownloadAlertView *) showOnView:(UIView*) view_ {
    if (view_ == nil) return nil;
    
    DownloadAlertView * opView = (DownloadAlertView*) [[[NSBundle mainBundle] loadNibNamed:@"DownloadAlertView" owner:nil options:nil] firstObject];
    opView.translatesAutoresizingMaskIntoConstraints = NO;
    
    [view_ addSubview:opView];
    
    NSMutableArray * constraints = [[NSMutableArray alloc] init];
    [constraints addObjectsFromArray:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[opView]|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(opView)]];
    [constraints addObjectsFromArray:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[opView]|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(opView)]];
    [view_ addConstraints:constraints];
    
    return opView;
}

- (IBAction)yes:(id)sender {
    [self removeFromSuperview];

    if (self.yesBlock) {
        self.yesBlock();
        self.yesBlock = nil;
    }
}

- (IBAction)no:(id)sender {
    [self removeFromSuperview];

    if (self.noBlock) {
        self.noBlock();
        self.noBlock = nil;
    }
}

- (void)awakeFromNib {
    [super awakeFromNib];
    
    confirmView.layer.cornerRadius = 8;
}

- (IBAction)didButtonHighlighted:(id)sender {
    [(UIButton *)sender setBackgroundColor:[UIColor colorWithRed:237.0/255.0 green:48.0/255.0 blue:56.0/255.0 alpha:1.0]];
}

- (IBAction)didButtonNotHighlighted:(id)sender {
    [(UIButton *)sender setBackgroundColor:[UIColor whiteColor]];
}

@end
