//
//  Utils.h
//  MadCabConfigurator
//
//  Created by Alex on 1/15/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Utils : NSObject

+(BOOL) containsString:(NSString*)string inArray:(NSArray<NSString*>*) array;
+(NSArray<NSString*>*) mergeStringArray:(NSArray<NSString*>*) array1 Array2:(NSArray<NSString*>*) array2;
@end
