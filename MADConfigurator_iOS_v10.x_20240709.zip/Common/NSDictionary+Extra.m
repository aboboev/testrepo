//
//  NSDictionary+Extra.m
//  MadCabConfigurator
//
//  Created by Alex on 1/15/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import "NSDictionary+Extra.h"

@implementation NSDictionary (Extra)

- (NSString*) stringValueForKey:(NSString*) key {
    NSString * string = [self objectForKey:key] ? [self objectForKey:key] : @"";
    if ([string isKindOfClass:[NSString class]] == NO)
        return @"";
    return string;
}
- (BOOL) hasKey:(NSString*) key {
    for (NSString * k in self.allKeys) {
        if ([k isEqualToString:@"key"]) {
            return YES;
        }
    }
    return NO;
}
@end
