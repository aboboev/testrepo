//
//  Constants.h
//  MadCabConfigurator
//
//  Created by Alex on 1/15/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#ifndef Constants_h
#define Constants_h

#define  LAYOUT_TYPE_TUCANA   0
#define   LAYOUT_TYPE_CARINA   1
#define   LAYOUT_TYPE_ASHBURY   2
#define   LAYOUT_TYPE_STLOUIS   3

#define   MENU_THUMB_IMG_URL    @"images/menu/"
#define   INTERIOR_IMG_URL      @"images/interior/"
#define   POPULAR_IMG_URL       @"images/predefined/"

#define  ACR             @[@"L",@"M",@"N",@"O",@"P", @"Q", @"R", @"S", @"T", @"U", @"1", @"2", @"3", @"4"]
//#define  CHECK_ARR       @[@"B", @"L",@"M",@"N",@"O"]
#define  SIDE_ARR        @[@"B", @"K", @"L", @"M", @"N", @"O", @"T", @"P", @"2", @"3", @"4"]
#define  CMEXCEPW_ARR    @[@"L", @"M", @"N", @"O", @"P", @"Q", @"R", @"S"]

#define GLASS_MIRRORS    @[@"05", @"06", @"07", @"08", @"09", @"10", @"11", @"12", @"13", @"", @"W", @"V"]

#define NONE_THUMB       @"NA.png"
#define FAKE_SUBMENU_ID     @"-"

#define   IMAGE_LAYER_CNT   39
#define IMAGE_MAX_SIZE   1024
#define IMAGE_MIN_SIZE   256
#define THUMB_IMAGE_SIZE   200
#define MENU_ROW_HEIGHT     100 // unused
#define MENU_ITEM_HORIZONTAL_GAP        4

#define MSG_LOADING_NOW  @"The image is loading now!"

#define STR_PRE_DEFINED     @"predefined"
#define STR_POPULAR_LAYOUTS  @"Quick Start"
#define LIST_OTHER_ITEM_TITLE  @"Other"

#define PRIMARY_COLOR        [UIColor colorWithRed:237.0/255.0 green:47.0/255.0 blue:59.0/255.0 alpha:1.0]

#define USER_NAME_KEY       @"cabconfig_username"
#define USER_EMAIL_KEY       @"cabconfig_email"
#define USER_COMPANY_KEY       @"cabconfig_company"
#define USER_PHONE_KEY       @"cabconfig_phone"
#define USER_LAST_EMAIL_KEY       @"cabconfig_last_email"
#define PDF_FILE_NAME           @"ElevatorInteriorSelection.pdf"

#define LAYOUT_TYPE_BACK    @"back"
#define LAYOUT_TYPE_SIDE    @"side"
#define LAYOUT_TYPE_ALL     @"all"

//public static final String[] LST_INTERIOR   {"Cab Interior Only","Cab Interior & Fronts"};
//public static final String[] LST_SHELL   {"Existing Shell","Supply Shell"};
//public static final String[] LST_CAPACITY   {"2000","2500","3000","3500","4000","4500","5000",LIST_OTHER_ITEM_TITLE};
//public static final String[] LST_INSTALLATION   {"By Others","By MAD (subject to location)"};
//
#define STR_INDICATOR  @","
#define STR_SEPARATOR  @"separator"
//public static final String[] SORT_TYPES   {"Date (New-Old)","Date (Old-New)",@"Project Name (A-Z)",@"Project Name (Z-A)","Customer Name (A-Z)","Customer Name (Z-A)"};
//
//public static int NOT_SCROLLING   -100000;

#define GRAPHIC_SIZE_FULL   @"f"
#define GRAPHIC_SIZE_MEDIUM @"m"
#define GRAPHIC_SIZE_SMALL  @"s"

#define GRAPHIC_HALIGN_LEFT   @"l"
#define GRAPHIC_HALIGN_CENTER @"c"
#define GRAPHIC_HALIGN_RIGHT  @"r"

#define GRAPHIC_VALIGN_TOP    @"t"
#define GRAPHIC_VALIGN_CENTER @"c"
#define GRAPHIC_VALIGN_BOTTOM @"b"

#define GRAPHIC_LAYOUT_FULL @"f"
#define GRAPHIC_LAYOUT_VLONG @"v"
#define GRAPHIC_LAYOUT_HLONG @"h"
#define GRAPHIC_LAYOUT_SMALL @"s"

#endif /* Constants_h */
