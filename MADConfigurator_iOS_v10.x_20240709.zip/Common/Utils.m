//
//  Utils.m
//  MadCabConfigurator
//
//  Created by Alex on 1/15/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import "Utils.h"

@implementation Utils

+(BOOL) containsString:(NSString*)string inArray:(NSArray<NSString*>*) array {
    if (string == nil)
        return NO;
    for (NSString * element in array) {
        if ([element isEqualToString:string]) {
            return YES;
        }
    }
    return NO;
}

+(NSArray<NSString*>*) mergeStringArray:(NSArray<NSString*>*) array1 Array2:(NSArray<NSString*>*) array2{
    NSMutableArray<NSString*> *retArray = [[NSMutableArray alloc] initWithArray:array1];
    [retArray addObjectsFromArray:array2];
    return retArray;
}

@end
