//
//  NSDictionary+Extra.h
//  MadCabConfigurator
//
//  Created by Alex on 1/15/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (Extra)

- (NSString*) stringValueForKey:(NSString*) key;
- (BOOL) hasKey:(NSString*) key;

@end
