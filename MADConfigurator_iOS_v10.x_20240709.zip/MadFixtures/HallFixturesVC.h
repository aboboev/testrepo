//
//  HallFixturesVC.h
//  MadFixtures
//
//  Created by Antonio Pena on 2012-12-29.
//  Copyright (c) 2012 Kioaxis. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "V8HorizontalPickerView.h"
#import <MessageUI/MFMailComposeViewController.h>


#import "HallLantern.h"
#import "HallStation.h"


static const CGFloat itemActive    = 1.0;
static const CGFloat itemNotActive = 0.3;


typedef enum {
    hpv_LANTERN_Type,
    hpv_LANTERN_Style,
    hpv_LANTERN_Finish,
    hpv_LANTERN_Width,
    hpv_LANTERN_Height,
    hpv_LANTERN_Orientation,
    hpv_LANTERN_ArrowStyle,
    hpv_LANTERN_PositionIndicator,
    hpv_LANTERN_COUNT
} hpvOptionsLanternType;


typedef enum {
    hpv_HALL_Type,
    hpv_HALL_Style,
    hpv_HALL_Finish,
    hpv_HALL_Width,
    hpv_HALL_Height,
    hpv_HALL_FireService,
    hpv_HALL_ApendixOH,
    hpv_HALL_COUNT

} hpvOptionsHallType;



typedef enum {
     hpv_OPTIONS_Lantern,
     hpv_OPTIONS_Hall,
     hpv_OPTIONS_COUNT
} hpvOptionsType;


typedef enum {
    OPTIONS_Gen,
    OPTIONS_Lantern,
    OPTIONS_Hall,
    OPTIONS_COUNT
} OptionsType;


typedef enum {
    GEN_Type,
    GEN_Style,
    GEN_Finish,
    GEN_COUNT
} OptionsGenType;


typedef enum {
    LANTERN_Width,
    LANTERN_Height,
    LANTERN_Orientation,
    LANTERN_ArrowStyle,
    LANTERN_PositionIndicator,
    LANTERN_COUNT
} OptionsLanternType;


typedef enum {
    HALL_Width,
    HALL_Height,
    HALL_FireService,
    HALL_ApendixOH,
    HALL_COUNT
} OptionsHallType;


typedef enum {
    TYPE_Terminal,
    TYPE_Intermediate,
    TYPE_COUNT
} SettingsTypeType;


typedef enum {
    STYLE_FlushMount,
    STYLE_GildaSurfaceMount,
    STYLE_GildaCurveSurfaceMount,
    STYLE_GildaCornerSurfaceMount,
    STYLE_COUNT
} SettingsStyleType;

typedef enum {
    FINISH_ss4,
    FINISH_ss8,
    FINISH_b4,
    FINISH_b8,
    FINISH_orb,
    FINISH_COUNT
} SettingsFinishType;

typedef enum {
    LWIDTH_12,
    LWIDTH_16,
    LWIDTH_20,
    LWIDTH_COUNT
} SettingsLWidthType;

typedef enum {
    LHEIGHT_4_45,
    LHEIGHT_6,
    LHEIGHT_8,
    LHEIGHT_COUNT
} SettingsLHeightType;

typedef enum {
    LORIENT_Vertial,
    LORIENT_Horizontal,
    LORIENT_COUNT
} SettingsLOrientationType;

typedef enum {
    LARROW_TraditionalADA,
    LARROW_Vandal,
    LARROW_PIonly,
    LARROW_VisionSeries,
    LARROW_COUNT
} SettingsLArrowStyleType;

typedef enum {
    LPI_16segment,
    LPI_None,
    LPI_43Giotto,
    LPI_7Giotto,
    LPI_COUNT
} SettingsLPIType;


typedef enum {
    HWIDTH_4,
    HWIDTH_6,
    HWIDTH_8,
    HWIDTH_COUNT
} SettingsHWidthType;

typedef enum {
    HHEIGHT_12,
    HHEIGHT_20,
    HHEIGHT_24,
    HHEIGHT_COUNT
} SettingsHHeightType;

typedef enum {
    FS_YES,
    FS_NO,
    FS_COUNT
} SettingsHFireServiceType;


typedef enum {
    APPENDIX_YES,
    APPENDIX_NO,
    APPENDIX_COUNT
} SettingsHAppendixType;






extern const int ZOOM_NONE;
extern const int ZOOM_LANTERN;
extern const int ZOOM_STATION;




@interface HallFixturesVC : UIViewController  <MFMailComposeViewControllerDelegate, UITableViewDelegate, V8HorizontalPickerViewDelegate, V8HorizontalPickerViewDataSource,  UIScrollViewDelegate>
{

    IBOutlet UIImageView *imgBackground;
    IBOutlet UIImageView *imgTop;
    IBOutlet UIImageView *imgTopCenter;
    IBOutlet UIImageView *imgBottom;
    
    IBOutlet UIView *viewConfig;
    IBOutlet UIImageView *imgConfigBg;
    
    IBOutlet UIView *viewZoom;
    
    IBOutlet UIImageView *imglogoBg;
    
    
    IBOutlet UIImageView *imgZoomBg;
    
    IBOutlet UIImageView *imgZoom;
    
    IBOutlet UIImageView *imgHelp;
    
    NSInteger zoomMode;
    
   IBOutlet UIButton *btnZoomIn1;
    IBOutlet UIButton *btnZoomIn2;
    IBOutlet UIButton *btnZoomIn3;
    IBOutlet UIButton *btnZoomIn4;
    
    IBOutlet UIButton *btnZoomOut;
    IBOutlet UIButton *btnBigZoomOut;
    
    
    IBOutlet UIButton *btnHallStation;
    IBOutlet UIButton *btnHallLantern;
    
    IBOutlet UIButton *btnSendMail;
    
    
    IBOutlet UIView *viewHelp;
    
    IBOutlet UIButton *btnHelp;
    
    HallLantern *myLantern;
    HallStation *myStation;

    // the table view stuff
    IBOutlet UITableView *tblHallFixtures;
    IBOutlet UITableView *tblLanternFixtures;
    
    

    /// DEBUGGING
    IBOutlet UILabel  *debugFileName;
    IBOutlet UILabel  *debugsFileName;
    
}

- (void) checkRules;
- (void) updateImagesToBeDispalyed;

@property (nonatomic, strong) IBOutlet V8HorizontalPickerView *hPickerView;

@property(nonatomic, retain)IBOutlet UIImageView *imgBackground;
@property(nonatomic, retain)IBOutlet UIImageView *imgTop;
@property(nonatomic, retain)IBOutlet UIImageView *imgTopCenter;
@property(nonatomic, retain)IBOutlet UIImageView *imgBottom;

@property(nonatomic, retain)IBOutlet UIView *viewConfig;
@property(nonatomic, retain)IBOutlet UIImageView *imgConfigBg;

@property(nonatomic, retain)IBOutlet UIView *viewZoom;

@property(nonatomic, retain)IBOutlet UIImageView *imglogoBg;

@property(nonatomic, retain)IBOutlet UIImageView *imgZoomBg;
@property(nonatomic, retain)IBOutlet UIImageView *imgZoom;

@property(nonatomic, retain)IBOutlet UIView *viewHelp;
@property(nonatomic, retain)IBOutlet UIImageView *imgHelp;
@property(nonatomic, retain)IBOutlet UIButton *btnHelp;

@property(nonatomic, retain)IBOutlet UIButton *btnZoomIn1;
@property(nonatomic, retain)IBOutlet UIButton *btnZoomIn2;
@property(nonatomic, retain)IBOutlet UIButton *btnZoomIn3;
@property(nonatomic, retain)IBOutlet UIButton *btnZoomIn4;

@property(nonatomic, retain)IBOutlet UIButton *btnZoomOut;
@property(nonatomic, retain)IBOutlet UIButton *btnBigZoomOut;

@property(nonatomic, retain)IBOutlet UITableView *tblHallFixtures;
@property(nonatomic, retain)IBOutlet UITableView *tblLanternFixtures;


@property(nonatomic, retain)IBOutlet UIButton *btnHallStation;
@property(nonatomic, retain)IBOutlet UIButton *btnHallLantern;

@property(nonatomic, retain)IBOutlet UIButton *btnSendMail;

@property (nonatomic, strong) IBOutlet UIScrollView *scrollView;
@property (nonatomic, strong) IBOutlet UIView *containerView;


// DEBUGGING
@property(nonatomic, retain)IBOutlet UILabel  *debugFileName;
@property(nonatomic, retain)IBOutlet UILabel  *debugsFileName;

@property (nonatomic, weak) IBOutlet NSLayoutConstraint *varCon;
@property (nonatomic, weak) IBOutlet NSLayoutConstraint *portraitCon;
@property (nonatomic, weak) IBOutlet NSLayoutConstraint *landscapeCon;


-(IBAction)ZoomIn:(UIButton*)sender;
-(IBAction)ZoomOut:(UIButton*)sender;

-(IBAction)Help:(UIButton*)sender;


-(IBAction)sendEmail;

@end
