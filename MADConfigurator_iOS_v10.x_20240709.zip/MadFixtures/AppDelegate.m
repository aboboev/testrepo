//
//  AppDelegate.m
//  MadFixtures
//
//  Created by Antonio Pena on 12-01-14.
//  Copyright (c) 2012 Kioaxis. All rights reserved.
//

#import "AppDelegate.h"

@implementation AppDelegate

@synthesize window = _window;

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{    
    [[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];
    
    if (@available(iOS 13.0, *)) {
        self.window.overrideUserInterfaceStyle = UIUserInterfaceStyleLight;
    }
    
    // Override point for customization after application launch.
	sleep(1);
    
    return YES;
}
							
- (void)applicationWillResignActive:(UIApplication *)application
{
    /*
     Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
     Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
     */
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    /*
     Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
     If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
     */
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    /*
     Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
     */
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    /*
     Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
     */
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    /*
     Called when the application is about to terminate.
     Save data if appropriate.
     See also applicationDidEnterBackground:.
     */
}

+ (AppDelegate *)sharedDelegate {
    return (AppDelegate *)[[UIApplication sharedApplication] delegate];
}

#pragma mark - Core Data stack

@synthesize managedObjectContext = _managedObjectContext;
@synthesize managedObjectModel = _managedObjectModel;
@synthesize persistentStoreCoordinator = _persistentStoreCoordinator;

#pragma mark - Core Data Saving support

- (BOOL)saveContext {
    NSError *error = nil;
    NSManagedObjectContext *managedObjectContext = self.managedObjectContext;
    if (managedObjectContext != nil) {
        if ([managedObjectContext hasChanges] && ![managedObjectContext save:&error]) {
            NSLog(@"Save Failed Unresolved error %@, %@", error, [error userInfo]);
            return NO;
        }
    }
    return YES;
}

#pragma mark - Core Data stack

- (NSManagedObjectContext *)managedObjectContext {
    if (_managedObjectContext != nil)
        return _managedObjectContext;
    
    NSPersistentStoreCoordinator *coordinator = [self persistentStoreCoordinator];
    if (coordinator != nil) {
        _managedObjectContext = [[NSManagedObjectContext alloc] initWithConcurrencyType:NSMainQueueConcurrencyType];
        [_managedObjectContext setPersistentStoreCoordinator:coordinator];
    }
    return _managedObjectContext;
}

- (NSManagedObjectModel *)managedObjectModel {
    if (_managedObjectModel != nil)
        return _managedObjectModel;

    NSURL *modelURL = [[NSBundle mainBundle] URLForResource:@"MadCabConfigurator" withExtension:@"momd"];
    _managedObjectModel = [[NSManagedObjectModel alloc] initWithContentsOfURL:modelURL];
    return _managedObjectModel;
}

- (NSPersistentStoreCoordinator *)persistentStoreCoordinator {
    
    if (_persistentStoreCoordinator != nil)
        return _persistentStoreCoordinator;
    
    _persistentStoreCoordinator = [[NSPersistentStoreCoordinator alloc] initWithManagedObjectModel:[self managedObjectModel]];
    
    NSError *error = nil;
    if (![_persistentStoreCoordinator addPersistentStoreWithType:NSSQLiteStoreType
                                                   configuration:nil
                                                             URL:[self sourceStoreURL]
                                                         options:@{NSInferMappingModelAutomaticallyOption: @YES}
                                                           error:&error]) {
        NSLog(@"Persistent Store Error: %@", error);
        abort();
    }
    
    return _persistentStoreCoordinator;
}


- (NSURL *)sourceStoreURL {
    NSURL *dir = [[[NSFileManager defaultManager] URLsForDirectory:NSApplicationSupportDirectory inDomains:NSUserDomainMask] lastObject];
    [[NSFileManager defaultManager] createDirectoryAtURL:dir withIntermediateDirectories:YES attributes:nil error:nil];
    
    NSURL *oldFile = [dir URLByAppendingPathComponent:@"MadCabConfigurator.sqlite"];
    return oldFile;
}


- (BOOL)isMigrationNeeded {
    
    NSError *error = nil;
    NSDictionary *sourceMetadata = [NSPersistentStoreCoordinator metadataForPersistentStoreOfType:NSSQLiteStoreType URL:[self sourceStoreURL] options:@{NSInferMappingModelAutomaticallyOption: @YES} error:&error];
    BOOL isMigrationNeeded = NO;
    if (sourceMetadata != nil) {
        
        NSManagedObjectModel *destinationModel = [self managedObjectModel];
        // Migration is needed if destinationModel is NOT compatible
        isMigrationNeeded = ![destinationModel isConfiguration:nil compatibleWithStoreMetadata:sourceMetadata];
    }
    
    NSLog(@"isMigrationNeeded: %@", (isMigrationNeeded == YES) ? @"YES" : @"NO");
    return isMigrationNeeded;
}


- (BOOL)migrate:(NSError *__autoreleasing *)error {
    
    NSURL *sourceUrl = [self sourceStoreURL];
    
    // - Get metadata for source store from its URL with given type.
    NSDictionary *sourceMetadata = [NSPersistentStoreCoordinator metadataForPersistentStoreOfType:NSSQLiteStoreType URL:sourceUrl options:@{NSInferMappingModelAutomaticallyOption: @YES} error:error];
    if (sourceMetadata == NO) {
        NSLog(@"FAILED to create source meta data");
        return NO;
    }
    
    
    // - Create model from source store meta deta,
    NSManagedObjectModel *sourceModel = [NSManagedObjectModel mergedModelFromBundles:@[[NSBundle mainBundle]] forStoreMetadata:sourceMetadata];
    if (sourceModel == nil) {
        NSLog(@"FAILED to create source model, something wrong with source xcdatamodel.");
        return NO;
    }
    
    
    NSManagedObjectModel *destinationModel = [self managedObjectModel];
    NSMappingModel *mappingModel = [NSMappingModel mappingModelFromBundles:@[[NSBundle mainBundle]]
                                       forSourceModel:sourceModel
                                     destinationModel:destinationModel];
    
    
    // - Create the destination store url
    NSString *fileName = @"MadCabConfigurator_V2.sqlite";
    NSURL *destinationStoreURL = [[[[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] lastObject] URLByAppendingPathComponent:fileName];
    
    
    // - Migrate from source to latest matched destination model,
    NSMigrationManager *manager = [[NSMigrationManager alloc] initWithSourceModel:sourceModel destinationModel:destinationModel];
    BOOL didMigrate = [manager migrateStoreFromURL:sourceUrl
                                              type:NSSQLiteStoreType
                                           options:nil
                                  withMappingModel:mappingModel
                                  toDestinationURL:destinationStoreURL
                                   destinationType:NSSQLiteStoreType
                                destinationOptions:nil
                                             error:error];
    if (!didMigrate) {
        return NO;
    }
    
    NSLog(@"Migrating from source: %@ ===To=== %@", sourceUrl.path, destinationStoreURL.path);
    
    // Delete old sqlite file
    NSError *err = nil;
    NSFileManager *fm = [NSFileManager defaultManager];
    if (![fm removeItemAtURL:sourceUrl error:&err]) {
        NSLog(@"File delete failed.");
        return NO;
    }

    NSString *str1 = [NSString stringWithFormat:@"%@-shm",sourceUrl.path];
    [fm removeItemAtURL:[NSURL fileURLWithPath:str1] error:&err];
    str1 = [NSString stringWithFormat:@"%@-wal",sourceUrl.path];
    [fm removeItemAtURL:[NSURL fileURLWithPath:str1] error:&err];
    
    // Copy into new location
    if (![fm moveItemAtURL:destinationStoreURL toURL:sourceUrl error:&err]) {
        NSLog(@"File move failed.");
        return NO;
    }

    NSLog(@"Migration successful");
    
    return didMigrate;
}

@end
