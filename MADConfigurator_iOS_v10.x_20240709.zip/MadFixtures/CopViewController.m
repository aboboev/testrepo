//
//  CopViewController.m
//  MadFixtures
//
//  Created by Antonio Pena on 2014-04-23.
//  Copyright (c) 2014 Kioaxis. All rights reserved.
//

#import "CopViewController.h"

#import "JTTransformableTableViewCell.h"



#define IDIOM    [UIDevice currentDevice].userInterfaceIdiom
#define IPAD     UIUserInterfaceIdiomPad

#define IS_IPHONE ([UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPhone)
#define IS_IPHONE_4 (IS_IPHONE && [[UIScreen mainScreen] bounds].size.height == 480.0f)

#define Rgb2UIColor(r, g, b)  [UIColor colorWithRed:((r) / 255.0) green:((g) / 255.0) blue:((b) / 255.0) alpha:1.0]


#define COMMITING_CREATE_CELL_HEIGHT 50
#define NORMAL_CELL_FINISHING_HEIGHT 50



@interface CopViewController ()

@end

@implementation CopViewController
{
    NSMutableArray *optionsCOP;
    NSMutableArray *optionsCOPExtra;
    
    NSMutableArray *valuesCOP;
    NSMutableArray *valuesCOPExtra;
    
    
    
    // Selection results
    DoorType   doorType;
    CopType    copType;
    FinishType finishType;
    
    // img 2
    EngravingsType engravingType;
    LocationType   engravingLoc;

    // img 3
    PositionIndicatorType posIndicatorType;
    LocationType posIndicatorLoc;

    // img 4
    BOOL emergLightType;
    LocationType emergLightLoc;

    // img 5
    BOOL autodialerType;
    LocationType autodialerLoc;

    // img 6
    FireServiceType fireServiceType;
    LocationType fireServiceLoc;
    SpecialServiceType specialService;

    // img 7
    PushButtonType pushButtonType;
    unsigned int pushButtonNumOpenings;  // values 02 - 24
    LocationType pushButtonLoc;  // no selction just rule
    
    // img 8
    OpeningType openingType;
    LocationType openingLoc;
    
    
    // img 9
    AccessControlType accessControl;
    LocationType accessControlLoc;
    
    // img 10
    ServiceCabinetType serviceCabinetType;
    LocationType serviceCabinetLoc;

    // img 11
    TouchscreenType touchscreenType;
    LocationType touchscreenLoc;
    
    
    NSMutableArray *p1;
    NSMutableArray *pa2;
    NSMutableArray *pb2;
    NSMutableArray *p3;
    
    
    NSMutableArray *img2p5;
    NSMutableArray *img3p5;
    
    NSMutableArray *img4p5;
    
    NSMutableArray *img5p5;
    
    NSMutableArray *img6ap5;
    NSMutableArray *img6bp5;
    
    NSMutableArray *img7ap5;
    NSMutableArray *img7bp5;
    
    NSMutableArray *img7ap5t;
    NSMutableArray *img7bp5t;
    
    
    NSMutableArray *img7bp9;
    
    NSMutableArray *img8ap5;
    NSMutableArray *img8bp5;
    
    NSMutableArray *img8p8;
    
    NSMutableArray *img9p5;
    
    NSMutableArray *img10p5;
    
    NSMutableArray *img11p5;
    
    
    
    // menus
    NSMutableArray *menuDoor, *menuCop, *menuFinish;
    
    NSMutableArray *menuEngraving, *menuEngravingLoc;
    NSMutableArray *menuPosIndicator, *menuPosIndicatorLoc;
    NSMutableArray *menuEmergLight, *menuEmergLightLoc;
    NSMutableArray *menuAutodialer, *menuAutodialerLoc;
    NSMutableArray *menuFireService, *menuFireServiceLoc;
    NSMutableArray *menuOtherService;
    NSMutableArray *menuTouchscreen, *menuTouchscreenLoc;
    NSMutableArray *menuPushbutton, *menuPushbuttonOpenings;
    NSMutableArray *menuRearOpening;
    NSMutableArray *menuAccessControl, *menuAccessControlLoc;
    NSMutableArray *menuServiceCabinet, *menuServiceCabinetLoc;
    
    
    // coordinates
    CoordType currentCoords;
    
    
    
    // selection stuff
    NSMutableArray *activeMenuA;
    NSMutableArray *activeMenuB;
    
    ConfigButtonType activeConfig;
    
    unsigned int userSelectionA;
    unsigned int userSelectionB;
    
    unsigned int numPickComponents;
    
    // used to animate to auxilatiy views
    BOOL configViewHidden;

    
    // rotation position factor
    float rotationFactor;
    float rotationFactor2;
    BOOL orientationPortrait;
    
    
    
    int currentTableRow;
    
    
    // horizontal picker
    NSMutableArray *hvPickerActive;
    NSMutableArray *hvPickerActiveExtra;
    
    
    int activeHvPicker;
    int activeHvSelection;
    
    int activeHvSelectionExtra;
    
    
    //  to manage table section collaps
    NSMutableSet* _collapsedSections;
    
    int currentSection;
    
    
    
}

@synthesize hPickerView, hPickerViewExtra;

@synthesize imgBg, imgUiBg;

@synthesize imgM2,imgM3,imgM4,imgM5,imgM6,imgM7,imgM8,imgM9,imgM10,imgM11;
@synthesize imgA2,imgA3,imgA4,imgA5,imgA6,imgA7,imgA8,imgA9,imgA10,imgA11;

@synthesize viewConfiguration;

@synthesize viewUserInterface;

@synthesize btnConfirguration, btnEmail, btnHome;

@synthesize tblOptionsCOP;


@synthesize scrollView, containerView;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    
    optionsCOP = [[NSMutableArray alloc] initWithObjects:   @"Door Type", @"COP Type", @"Finish",@"Engraving", @"Position Indicator", @"Emergency Light", @"Autodialer", @"Fire Service", @"Other Service", @"Touchscreen",@"Pushbutton",   @"Rear Opening",@"Access Control",@"Service Cabinet", nil];
    
    optionsCOPExtra= [[NSMutableArray alloc] initWithObjects:@"",         @"",         @"",      @"Location",  @"Location",           @"Location",        @"Location",   @"Location",     @"",              @"Location",   @"# of openings",@"",             @"Location",     @"Location", nil];
    
    valuesCOP = [[NSMutableArray alloc] initWithObjects:@"blablabla", @"blablabla", @"blablabla",@"blablabla", @"blablabla", @"blablabla", @"blablabla", @"blablabla", @"blablabla", @"blablabla",@"blablabla",@"blablabla",@"blablabla",@"blablabla", nil];
    
    valuesCOPExtra= [[NSMutableArray alloc] initWithObjects:@"", @"", @"",@"bla", @"bla", @"bla", @"bla", @"bla", @"", @"bla",@"bla",@"",@"bla",@"bla", nil];
    
    
    
    
    
    // define some static arrays used for image file names
    p1  = [[NSMutableArray alloc] initWithObjects:@"S", @"B",nil];
    
    pa2 = [[NSMutableArray alloc] initWithObjects:@"1", @"2",nil];
    pb2 = [[NSMutableArray alloc] initWithObjects:@"3", @"4",nil];
    
    p3  = [[NSMutableArray alloc] initWithObjects:@"S", @"A",nil];
    
    
    img2p5  = [[NSMutableArray alloc] initWithObjects:@"", @"TE001",@"TE002",@"TE003",nil];
    
    img3p5  = [[NSMutableArray alloc] initWithObjects:@"", @"PI000",@"PI001",@"PI002",@"PI005",@"PI003",@"PI004",nil];  // new option PI005

    img4p5  = [[NSMutableArray alloc] initWithObjects:@"", @"EM001",nil];
    
    img5p5  = [[NSMutableArray alloc] initWithObjects:@"PH001",@"PH002",nil]; // depend on img 10 and 11
    
    img6ap5  = [[NSMutableArray alloc] initWithObjects:@"", @"FS001",@"FS003",nil];  // depends on speciaService
    img6bp5  = [[NSMutableArray alloc] initWithObjects:@"", @"FS002",@"FS004",nil];  // depends on speciaService

    img7ap5  = [[NSMutableArray alloc] initWithObjects:@"PBQ",@"PBJ",@"PBC",@"PBD",@"PBP",@"PBS",@"PBF",@"PBR",@"PBQ",@"PBB",nil];  // depends on im 11
    img7bp5  = [[NSMutableArray alloc] initWithObjects:@"PBQ",@"PBJ",@"PBC",@"PBD",@"PBP",@"PBD",@"PBF",@"PBR",@"PBQ",@"PBB",nil];  // depends on im 11

    img7ap5t  = [[NSMutableArray alloc] initWithObjects:@"PTQ",@"PTJ",@"PTC",@"PTD",@"PTP",@"PTS",@"PTF",@"PTR",@"PTQ",@"PTB",nil];  // depends on im 11
    img7bp5t  = [[NSMutableArray alloc] initWithObjects:@"PTQ",@"PTJ",@"PTC",@"PTD",@"PTP",@"PTS",@"PTF",@"PTR",@"PTQ",@"PTB",nil];  // depends on im 11

    
    img7bp9  = [[NSMutableArray alloc] initWithObjects:@"0",@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",nil];
    
    
    img8ap5  = [[NSMutableArray alloc] initWithObjects:@"UBQ",@"UBJ",@"UBC",@"UBD",@"UBP",@"UBS",@"UBF",@"UBR",@"UBQ",@"UBB",nil];  // depends on im 11
    img8bp5  = [[NSMutableArray alloc] initWithObjects:@"UBQ",@"UBJ",@"UBC",@"UBD",@"UBP",@"UBD",@"UBF",@"UBR",@"UBQ",@"UBB",nil];  // depends on im 11

    img8p8  = [[NSMutableArray alloc] initWithObjects:@"00",@"01",nil];
    
    img9p5 = [[NSMutableArray alloc] initWithObjects:@"", @"AC001",nil];
    
    img10p5  = [[NSMutableArray alloc] initWithObjects:@"", @"SC003",@"SC002",@"SC001",nil];
    
    img11p5  = [[NSMutableArray alloc] initWithObjects:@"", @"TS001",@"TS002",@"TS003",@"TS004",nil];
    
    
    
    // static arrays for menu selections
    
    menuDoor  = [[NSMutableArray alloc] initWithObjects:@"Single Side Opening", @"Center Opening",nil];
    
    menuCop   = [[NSMutableArray alloc] initWithObjects:@"Swing", @"Applied",nil];
    
    menuFinish = [[NSMutableArray alloc] initWithObjects:@"Stainless", @"Brass",nil];
    
    
    menuEngraving = [[NSMutableArray alloc] initWithObjects:@"None", @"No Smoking", @"No Smoking Capacity", @"Capacity",nil];
    menuEngravingLoc = [[NSMutableArray alloc] initWithObjects:@"Main COP", @"AUX COP", @"Main & AUX COP",nil];
    
    
    // Jyly 201 2016
    // On COP configurator, please change COP PI to say Red 16 Segment or Blue 16 Segment opposed to Red MH222 and Blue MH222
   // menuPosIndicator  = [[NSMutableArray alloc] initWithObjects:@"None", @"Red MH 222", @"Blue MH 222",  @"Giotto 4.3\"",  @"Giotto 7\"", @"Matisse 7\"", @"Matisse 10\"",  nil];
    menuPosIndicator  = [[NSMutableArray alloc] initWithObjects:@"None", @"Red 16 Segment", @"Blue 16 Segment",  @"Giotto 4.3\"",  @"Giotto 7\"", @"Matisse 7\"", @"Matisse 10\"",  nil];
    
    menuPosIndicatorLoc  = [[NSMutableArray alloc] initWithObjects:@"Main COP", @"AUX COP", @"Main & AUX COP",nil];
    
    menuEmergLight  = [[NSMutableArray alloc] initWithObjects:@"NO", @"YES",nil];
    menuEmergLightLoc = [[NSMutableArray alloc] initWithObjects:@"Main COP", @"AUX COP", @"Main & AUX COP",nil];
    
    menuAutodialer  = [[NSMutableArray alloc] initWithObjects:@"NO", @"YES",nil];
    menuAutodialerLoc = [[NSMutableArray alloc] initWithObjects:@"Main COP", @"AUX COP",nil];
    
    menuFireService  = [[NSMutableArray alloc] initWithObjects:@"NONE", @"Cabinet", @"2000 code",nil];
    menuFireServiceLoc  = [[NSMutableArray alloc] initWithObjects:@"Main COP", @"AUX COP", nil];
    
    menuOtherService  = [[NSMutableArray alloc] initWithObjects:@"NONE", @"Code Blue",nil];
    
    menuTouchscreen  = [[NSMutableArray alloc] initWithObjects:@"NONE",@"21\"", @"19\"W", @"19\"S", @"17",nil];
    menuTouchscreenLoc  = [[NSMutableArray alloc] initWithObjects:@"Main COP", @"AUX COP", @"Main & AUX COP",nil];
    
    menuPushbutton  = [[NSMutableArray alloc] initWithObjects:@"Surface Mount Square", @"Julius Surround", @"Caeser", @"Dune", @"Pin Brail", @"Slimline", @"Flush Mount Julius", @"Flush Mount Round", @"Flush Mount Square", @"Black Caesar", nil];
    menuPushbuttonOpenings  = [[NSMutableArray alloc] initWithObjects:@"02", @"03", @"04", @"05", @"06", @"07", @"08", @"09", @"10", @"11", @"12", @"13", @"14", @"15", @"16", @"17", @"18", @"19", @"20", @"21", @"22", @"23", @"24",nil];
    

    
    menuRearOpening  = [[NSMutableArray alloc] initWithObjects:@"Front Only", @" Front and Rear",nil];
    
    menuAccessControl  = [[NSMutableArray alloc] initWithObjects:@"NONE", @"Card Reader Provision",nil];
    menuAccessControlLoc  = [[NSMutableArray alloc] initWithObjects:@"Main COP", @"AUX COP", @"Main & AUX COP",nil];
    
    menuServiceCabinet  = [[NSMutableArray alloc] initWithObjects:@"NONE", @"Blank", @"Certificate Window", @"Engravings", nil];
    menuServiceCabinetLoc  = [[NSMutableArray alloc] initWithObjects:@"Main COP", @"AUX COP",nil];
    
    
    orientationPortrait = YES;
    if ( IDIOM == IPAD )
    {
        // July 25
        // resize images to 1/2 of original
        //

        
        // rotationFactor = 0.5;  // ipad
        rotationFactor = self.view.frame.size.width / 768;
        rotationFactor2 = self.view.frame.size.height / 1024;  // ipad
    }
    else
    {
        // July 25
        // resize images to 1/2 of original
        //
        rotationFactor = 0.4166666 * self.view.frame.size.width / 320;  // for iPhone
        rotationFactor2 = rotationFactor;
    }

    // this should resolve the image size for iphone 5 vs 4
    [self adjustPosition:imgBg newX:0 newY:0];
    
    
    //  iphone 4 vs 5
 
    
    [self setDefautls];
    
    [self startConfigHidden];
    
    // table view stuff
    currentTableRow = -1;
    
    currentSection = -1;
    _collapsedSections = [NSMutableSet new];
    
    
    UITapGestureRecognizer *doubleTapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(scrollViewDoubleTapped:)];
    doubleTapRecognizer.numberOfTapsRequired = 2;
    doubleTapRecognizer.numberOfTouchesRequired = 1;
    [self.scrollView addGestureRecognizer:doubleTapRecognizer];
    
    UITapGestureRecognizer *twoFingerTapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(scrollViewTwoFingerTapped:)];
    twoFingerTapRecognizer.numberOfTapsRequired = 1;
    twoFingerTapRecognizer.numberOfTouchesRequired = 2;
    [self.scrollView addGestureRecognizer:twoFingerTapRecognizer];
    
    
    
}



#pragma mark ---- View Appearing ----


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    // set rotation factor
    UIInterfaceOrientation iOrientation = [UIApplication sharedApplication].windows.firstObject.windowScene.interfaceOrientation;
	UIDeviceOrientation dOrientation = [UIDevice currentDevice].orientation;
    
    
    // if (dOrientation == UIInterfaceOrientationPortraitUpsideDown)
    //     return (NO);
    
    
    bool landscape;
	
    if( IDIOM == IPAD)
    {
        if (dOrientation == UIDeviceOrientationUnknown || dOrientation == UIDeviceOrientationFaceUp || dOrientation == UIDeviceOrientationFaceDown) {
            // If the device is laying down, use the UIInterfaceOrientation based on the status bar.
            landscape = UIInterfaceOrientationIsLandscape(iOrientation);
        } else {
            // If the device is not laying down, use UIDeviceOrientation.
            landscape = UIDeviceOrientationIsLandscape(dOrientation);
        }
    }
    else
    {
        // portrit only for iPhone
        landscape = NO;
    }
    
    
    [self adjustForRotation:landscape];
    [self.view layoutIfNeeded];
    
    //[self shouldAutorotate];
    
    
    [self setDefautls];
    [self updateImages];
    [self updateCoords];
    
    // PINCH ZOOM SCROLL VIEW STUFF
    
    // Set up the minimum & maximum zoom scales
    
    
    self.scrollView.minimumZoomScale = 1.0f;//minScale;
    self.scrollView.maximumZoomScale = 4.0f;
    
    [self scrollviewZoomToFullSize];
}



- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}





- (void) setDefautls
{
    
    imgM2.hidden = NO;
    imgM3.hidden = NO;
    imgM4.hidden = NO;
    imgM5.hidden = NO;
    imgM6.hidden = NO;
    imgM7.hidden = NO;
    imgM8.hidden = NO;
    imgM9.hidden = NO;
    imgM10.hidden = NO;
    imgM11.hidden = NO;
    
    imgA2.hidden = NO;
    imgA3.hidden = NO;
    imgA4.hidden = NO;
    imgA5.hidden = NO;
    imgA6.hidden = NO;
    imgA7.hidden = NO;
    imgA8.hidden = NO;
    imgA9.hidden = NO;
    imgA10.hidden = NO;
    imgA11.hidden = NO;
    
    
    
    
    // Set The Defaults:
    
    // Selection results
    doorType = DOOR_CenterOpening;
    copType = COP_Swing;
    finishType = F_Stainless;
    
    
    // img 2
    engravingType = E_Capacity;
    engravingLoc = L_MainAuxCop;
    
    // img 3
    posIndicatorType = PI_Matisse7;
    posIndicatorLoc = L_MainAuxCop;
    
    // img 4
    emergLightType = YES;
    emergLightLoc=L_MainAuxCop;
    
    // img 5
    autodialerType=YES;
    autodialerLoc=L_AuxCop;
    
    // img 6
    fireServiceType=FS_Cabinet;
    fireServiceLoc=L_MainCop;
    specialService=SS_None;
    
    // img 7
    pushButtonType=PB_JuliusSurround;
    pushButtonNumOpenings=12;  // values 02 - 24
    pushButtonLoc=L_MainAuxCop;  // no selction just rule
    
    // img 8
    openingType=O_FrontOnly;
    // location based in rule
    
    // img 9
    accessControl=AC_CardReaderProvision;
    accessControlLoc = L_MainAuxCop;
    
    // img 10
    serviceCabinetType=SC_Engravings;
    serviceCabinetLoc=L_MainCop;
    
    // img 11
    touchscreenType=TS_None;
    touchscreenLoc=L_MainAuxCop; // N/A given none above
    
    
    
    [valuesCOP replaceObjectAtIndex:CB_DoorType withObject:[menuDoor objectAtIndex:(unsigned int)doorType]];
    [valuesCOP replaceObjectAtIndex:CB_Coptype withObject:[menuCop objectAtIndex:(unsigned int)copType]];
    [valuesCOP replaceObjectAtIndex:CB_Finish withObject:[menuFinish objectAtIndex:(unsigned int)finishType]];
    [valuesCOP replaceObjectAtIndex:CB_Engraving withObject:[menuEngraving objectAtIndex:(unsigned int)engravingType]];
    [valuesCOP replaceObjectAtIndex:CB_PositionIndicator withObject:[menuPosIndicator objectAtIndex:(unsigned int)posIndicatorType]];
    [valuesCOP replaceObjectAtIndex:CB_EmergencyLight withObject:[menuEmergLight objectAtIndex:(unsigned int)emergLightType]];
    [valuesCOP replaceObjectAtIndex:CB_Autodialer withObject:[menuAutodialer objectAtIndex:(unsigned int)autodialerType]];
    [valuesCOP replaceObjectAtIndex:CB_FireService withObject:[menuFireService objectAtIndex:(unsigned int)fireServiceType]];
    [valuesCOP replaceObjectAtIndex:CB_OtherService withObject:[menuOtherService objectAtIndex:(unsigned int)specialService]];
    [valuesCOP replaceObjectAtIndex:CB_Touchscreen withObject:[menuTouchscreen objectAtIndex:(unsigned int)touchscreenType]];
    [valuesCOP replaceObjectAtIndex:CB_Pushbutton withObject:[menuPushbutton objectAtIndex:(unsigned int)pushButtonType]];
    [valuesCOP replaceObjectAtIndex:CB_RearOpening withObject:[menuRearOpening objectAtIndex:(unsigned int)openingType]];
    [valuesCOP replaceObjectAtIndex:CB_AccessControl withObject:[menuAccessControl objectAtIndex:(unsigned int)accessControl]];
    [valuesCOP replaceObjectAtIndex:CB_ServiceCabinet withObject:[menuServiceCabinet objectAtIndex:(unsigned int)serviceCabinetType]];

    
    
    //[valuesCOPExtra replaceObjectAtIndex:CB_DoorType withObject:[menuDoor objectAtIndex:(unsigned int)doorType]];
    //[valuesCOPExtra replaceObjectAtIndex:CB_Coptype withObject:[menuCop objectAtIndex:(unsigned int)copType]];
    //[valuesCOPExtra replaceObjectAtIndex:CB_Finish withObject:[menuFinish objectAtIndex:(unsigned int)finishType]];
    [valuesCOPExtra replaceObjectAtIndex:CB_Engraving withObject:[menuEngravingLoc objectAtIndex:(unsigned int)engravingLoc]];
    [valuesCOPExtra replaceObjectAtIndex:CB_PositionIndicator withObject:[menuPosIndicatorLoc objectAtIndex:(unsigned int)posIndicatorLoc]];
    [valuesCOPExtra replaceObjectAtIndex:CB_EmergencyLight withObject:[menuEmergLightLoc objectAtIndex:(unsigned int)emergLightLoc]];
    [valuesCOPExtra replaceObjectAtIndex:CB_Autodialer withObject:[menuAutodialerLoc objectAtIndex:(unsigned int)autodialerLoc]];
    [valuesCOPExtra replaceObjectAtIndex:CB_FireService withObject:[menuFireServiceLoc objectAtIndex:(unsigned int)fireServiceLoc]];
    //[valuesCOPExtra replaceObjectAtIndex:CB_OtherService withObject:[menuOtherService objectAtIndex:(unsigned int)specialService]];
    [valuesCOPExtra replaceObjectAtIndex:CB_Touchscreen withObject:[menuTouchscreenLoc objectAtIndex:(unsigned int)touchscreenLoc]];
    [valuesCOPExtra replaceObjectAtIndex:CB_Pushbutton withObject:[menuPushbuttonOpenings objectAtIndex:(unsigned int)pushButtonNumOpenings-2]];
    //[valuesCOPExtra replaceObjectAtIndex:CB_RearOpening withObject:[menuRearOpening objectAtIndex:(unsigned int)openingType]];
    [valuesCOPExtra replaceObjectAtIndex:CB_AccessControl withObject:[menuAccessControlLoc objectAtIndex:(unsigned int)accessControlLoc]];
    [valuesCOPExtra replaceObjectAtIndex:CB_ServiceCabinet withObject:[menuServiceCabinetLoc objectAtIndex:(unsigned int)serviceCabinetLoc]];
 
    
}






// update images based on rules

- (void) updateImages
{
    // Filenaming Convetion     P  123456789.jpg
    
    
    // Set the Global settings this is true for all image names
    
    
    NSString *globalSettings;
    
    if(touchscreenType == TS_None )
        globalSettings = [NSString stringWithFormat:@"%@%@%@",[p1 objectAtIndex:finishType],[pa2 objectAtIndex:doorType],[p3 objectAtIndex:copType]];
    else
        globalSettings = [NSString stringWithFormat:@"%@%@%@",[p1 objectAtIndex:finishType],[pb2 objectAtIndex:doorType],[p3 objectAtIndex:copType]];
        
    
    
    // Background image
    NSString *bgImageName = [NSString stringWithFormat:@"%@000000.jpg",globalSettings];
    [imgBg  setImage:[UIImage imageNamed:bgImageName]];
    
    
    // img 2
    if( engravingType == E_None)
    {
        imgM2.hidden = YES;
        imgA2.hidden = YES;
    }
    else
    {
        NSString *img2mName = [NSString stringWithFormat:@"%@M%@.jpg",globalSettings,[img2p5 objectAtIndex:engravingType]];
        NSString *img2aName = [NSString stringWithFormat:@"%@A%@.jpg",globalSettings,[img2p5 objectAtIndex:engravingType]];
        
        switch (engravingLoc) {
            case L_MainCop:
            {
                [imgM2  setImage:[UIImage imageNamed:img2mName]];
                
                imgM2.hidden = NO;
                imgA2.hidden = YES;
            }
                break;
            case L_AuxCop:
            {
                [imgA2  setImage:[UIImage imageNamed:img2aName]];
                
                imgM2.hidden = YES;
                imgA2.hidden = NO;
            }
                break;
            case L_MainAuxCop:
            {
                [imgM2  setImage:[UIImage imageNamed:img2mName]];
                [imgA2  setImage:[UIImage imageNamed:img2aName]];
                
                imgM2.hidden = NO;
                imgA2.hidden = NO;
            }
                break;
                
                
            default:
            {
                imgM2.hidden = YES;
                imgA2.hidden = YES;
            }
                break;
        }
    }
    
    
    
    // img 3
    if( posIndicatorType == PI_None)
    {
        imgM3.hidden = YES;
        imgA3.hidden = YES;
    }
    else
    {
        
        NSString *img3mName = [NSString stringWithFormat:@"%@M%@.jpg",globalSettings,[img3p5 objectAtIndex:posIndicatorType]];
        NSString *img3aName = [NSString stringWithFormat:@"%@A%@.jpg",globalSettings,[img3p5 objectAtIndex:posIndicatorType]];
        
        switch (posIndicatorLoc) {
            case L_MainCop:
            {
                [imgM3  setImage:[UIImage imageNamed:img3mName]];
                
                imgM3.hidden = NO;
                imgA3.hidden = YES;
            }
                break;
            case L_AuxCop:
            {
                [imgA3  setImage:[UIImage imageNamed:img3aName]];
                
                imgM3.hidden = YES;
                imgA3.hidden = NO;
            }
                break;
            case L_MainAuxCop:
            {
                [imgM3  setImage:[UIImage imageNamed:img3mName]];
                [imgA3  setImage:[UIImage imageNamed:img3aName]];
                
                imgM3.hidden = NO;
                imgA3.hidden = NO;
            }
                break;
                
                
            default:
            {
                imgM3.hidden = YES;
                imgA3.hidden = YES;
            }
                break;
        }
    }
    
    // img 4
    if ( ! emergLightType )  // IF emergLightType YES
    {
        imgM4.hidden = YES;
        imgA4.hidden = YES;
    }
    else
    {
        NSString *img4mName = [NSString stringWithFormat:@"%@M%@.jpg",globalSettings,[img4p5 objectAtIndex:1]];
        NSString *img4aName = [NSString stringWithFormat:@"%@A%@.jpg",globalSettings,[img4p5 objectAtIndex:1]];
        
        
        switch (emergLightLoc) {
            case L_MainCop:
            {
                [imgM4  setImage:[UIImage imageNamed:img4mName]];
                
                imgM4.hidden = NO;
                imgA4.hidden = YES;
            }
                break;
            case L_AuxCop:
            {
                [imgA4  setImage:[UIImage imageNamed:img4aName]];
                
                imgM4.hidden = YES;
                imgA4.hidden = NO;
            }
                break;
            case L_MainAuxCop:
            {
                [imgM4  setImage:[UIImage imageNamed:img4mName]];
                [imgA4  setImage:[UIImage imageNamed:img4aName]];
                
                imgM4.hidden = NO;
                imgA4.hidden = NO;
            }
                break;
                
                
            default:
            {
                imgM4.hidden = YES;
                imgA4.hidden = YES;
            }
                break;
        }
        
    }

    
    // img 5
    if ( ! autodialerType )  // IF emergLightType YES
    {
        imgM5.hidden = YES;
        imgA5.hidden = YES;
    }
    else
    {
        
        int index=1;
        
        if ( (touchscreenType != TS_None ) || (serviceCabinetType == SC_Engravings))
        {
            index = 0;
        }
   
        
        
        NSString *img5mName = [NSString stringWithFormat:@"%@M%@.jpg",globalSettings,[img5p5 objectAtIndex:index]];
        NSString *img5aName = [NSString stringWithFormat:@"%@A%@.jpg",globalSettings,[img5p5 objectAtIndex:index]];
        
        
        switch (autodialerLoc) {
            case L_MainCop:
            {
                [imgM5  setImage:[UIImage imageNamed:img5mName]];
                
                imgM5.hidden = NO;
                imgA5.hidden = YES;
            }
                break;
            case L_AuxCop:
            {
                [imgA5  setImage:[UIImage imageNamed:img5aName]];
                
                imgM5.hidden = YES;
                imgA5.hidden = NO;
            }
                break;
            case L_MainAuxCop:
            {
                [imgM5  setImage:[UIImage imageNamed:img5mName]];
                [imgA5  setImage:[UIImage imageNamed:img5aName]];
                
                imgM5.hidden = NO;
                imgA5.hidden = NO;
            }
                break;
                
                
            default:
            {
                imgM5.hidden = YES;
                imgA5.hidden = YES;
            }
                break;
        }
        
    }

    
    // img 6
    if ( fireServiceType == FS_None )  // IF emergLightType YES
    {
        imgM6.hidden = YES;
        imgA6.hidden = YES;
    }
    else
    {
        
        NSString *img6mName;
        NSString *img6aName;
        
        if(specialService==SS_None)
        {
            img6mName = [NSString stringWithFormat:@"%@M%@.jpg",globalSettings,[img6ap5 objectAtIndex:fireServiceType]];
            img6aName = [NSString stringWithFormat:@"%@A%@.jpg",globalSettings,[img6ap5 objectAtIndex:fireServiceType]];
        }
        else
        {
            img6mName = [NSString stringWithFormat:@"%@M%@.jpg",globalSettings,[img6bp5 objectAtIndex:fireServiceType]];
            img6aName = [NSString stringWithFormat:@"%@A%@.jpg",globalSettings,[img6bp5 objectAtIndex:fireServiceType]];
        }
        
        switch (fireServiceLoc) {
            case L_MainCop:
            {
                [imgM6  setImage:[UIImage imageNamed:img6mName]];
                
                imgM6.hidden = NO;
                imgA6.hidden = YES;
            }
                break;
            case L_AuxCop:
            {
                [imgA6  setImage:[UIImage imageNamed:img6aName]];
                
                imgM6.hidden = YES;
                imgA6.hidden = NO;
            }
                break;
            case L_MainAuxCop:
            {
                [imgM6  setImage:[UIImage imageNamed:img6mName]];
                [imgA6  setImage:[UIImage imageNamed:img6aName]];
                
                imgM6.hidden = NO;
                imgA6.hidden = NO;
            }
                break;
                
                
            default:
            {
                imgM6.hidden = YES;
                imgA6.hidden = YES;
            }
                break;
        }
        
    }

    
    
    // img 7
    
    if( doorType == DOOR_SingleSideOpening)
        pushButtonLoc = L_MainCop;
    else
        pushButtonLoc = L_MainAuxCop;
    

    NSString *img7mName;
    NSString *img7aName;
    
    NSString *img7p8=@"8";
    unsigned int img7mp9=0;
    unsigned int img7ap9=0;
    
    if (touchscreenType ==TS_None )
    {
        img7mName = [NSString stringWithFormat:@"%@M%@%02d.jpg",globalSettings,[img7ap5 objectAtIndex:pushButtonType],pushButtonNumOpenings];
        img7aName = [NSString stringWithFormat:@"%@A%@%02d.jpg",globalSettings,[img7ap5 objectAtIndex:pushButtonType],pushButtonNumOpenings];
    }
    else
    {
        // id img 11 != NONE
        
        if( touchscreenType != TS_None )
        {
            if( serviceCabinetLoc == L_MainCop)
            {
                if ( openingType == O_FrontOnly )
                {
                    img7p8=@"8";
                    img7mp9 = pushButtonNumOpenings;
                    if( img7mp9 >= 9 )
                    {
                        img7mp9 = 9;
                    }

                    
                    img7ap9 = pushButtonNumOpenings;
                    if( img7ap9 >= 9 )
                    {
                        img7ap9 = 0;
                    }
                    else
                    {
                        img7ap9 = 1;
                    }
                }
                else
                {
                    img7p8=@"9";
                    img7mp9 = pushButtonNumOpenings;
                    if( img7mp9 >= 5 )
                    {
                        img7mp9 = 9;
                    }
                    
                    img7ap9 = pushButtonNumOpenings;
                    if( img7ap9 >= 5 )
                    {
                        img7ap9 = 0;
                    }
                    else
                    {
                        img7ap9 = 1;
                    }
                    
                }
                
            }
            else /// Service cabinet AUX
            {
                if ( openingType == O_FrontOnly )
                {
                    img7p8=@"8";
                    img7mp9 = pushButtonNumOpenings;
                    if( img7mp9 >= 9 )
                    {
                        img7mp9 = 0;
                    }
                    else
                    {
                        img7mp9 = 1;
                    }
                    
                    img7ap9 = pushButtonNumOpenings;
                    if( img7ap9 >= 9 )
                    {
                        img7ap9 = 9;
                    }
                }
                else
                {
                    img7p8=@"9";
                    img7mp9 = pushButtonNumOpenings;
                    if( img7mp9 >= 5 )
                    {
                        img7mp9 = 0;
                    }
                    else
                    {
                        img7mp9 = 1;
                    }
                    
                    img7ap9 = pushButtonNumOpenings;
                    if( img7ap9 >= 5 )
                    {
                        img7ap9 = 9;
                    }
                }
            }
            
            img7mName = [NSString stringWithFormat:@"%@M%@%@%@.jpg",globalSettings,[img7bp5t objectAtIndex:pushButtonType],img7p8, [img7bp9 objectAtIndex:img7mp9]];
            img7aName = [NSString stringWithFormat:@"%@A%@%@%@.jpg",globalSettings,[img7bp5t objectAtIndex:pushButtonType],img7p8, [img7bp9 objectAtIndex:img7ap9]];
        }
        else
        {
            img7mName = [NSString stringWithFormat:@"%@M%@%02d.jpg",globalSettings,[img7bp5 objectAtIndex:pushButtonType],pushButtonNumOpenings];
            img7aName = [NSString stringWithFormat:@"%@A%@%02d.jpg",globalSettings,[img7bp5 objectAtIndex:pushButtonType],pushButtonNumOpenings];
        }
    }
    
    
    
    switch (pushButtonLoc) {
        case L_MainCop:
        {
            [imgM7  setImage:[UIImage imageNamed:img7mName]];
            
            imgM7.hidden = NO;
            imgA7.hidden = YES;
        }
            break;
        case L_AuxCop:
        {
            [imgA7  setImage:[UIImage imageNamed:img7aName]];
            
            imgM7.hidden = YES;
            imgA7.hidden = NO;
        }
            break;
        case L_MainAuxCop:
        {
            [imgM7  setImage:[UIImage imageNamed:img7mName]];
            [imgA7  setImage:[UIImage imageNamed:img7aName]];
            
            imgM7.hidden = NO;
            imgA7.hidden = NO;
        }
            break;
            
            
        default:
        {
            imgM7.hidden = YES;
            imgA7.hidden = YES;
        }
            break;
    }
    
    
    
    // img 8
    if( doorType == DOOR_SingleSideOpening)
        openingLoc = L_MainCop;
    else
        openingLoc = L_MainAuxCop;

    
    NSString *img8mName;
    NSString *img8aName;
    
    if (touchscreenType ==TS_None )
    {
        img8mName = [NSString stringWithFormat:@"%@M%@%@.jpg",globalSettings,[img8ap5 objectAtIndex:pushButtonType],[img8p8 objectAtIndex:openingType]];
        img8aName = [NSString stringWithFormat:@"%@A%@%@.jpg",globalSettings,[img8ap5 objectAtIndex:pushButtonType],[img8p8 objectAtIndex:openingType]];
    }
    else
    {
        img8mName = [NSString stringWithFormat:@"%@M%@%@.jpg",globalSettings,[img8bp5 objectAtIndex:pushButtonType],[img8p8 objectAtIndex:openingType]];
        img8aName = [NSString stringWithFormat:@"%@A%@%@.jpg",globalSettings,[img8bp5 objectAtIndex:pushButtonType],[img8p8 objectAtIndex:openingType]];
        
    }

    switch (openingLoc) {
        case L_MainCop:
        {
            [imgM8  setImage:[UIImage imageNamed:img8mName]];
            
            imgM8.hidden = NO;
            imgA8.hidden = YES;
        }
            break;
        case L_AuxCop:
        {
            [imgA8  setImage:[UIImage imageNamed:img8aName]];
            
            imgM8.hidden = YES;
            imgA8.hidden = NO;
        }
            break;
        case L_MainAuxCop:
        {
            [imgM8  setImage:[UIImage imageNamed:img8mName]];
            [imgA8  setImage:[UIImage imageNamed:img8aName]];
            
            imgM8.hidden = NO;
            imgA8.hidden = NO;
        }
            break;
            
            
        default:
        {
            imgM8.hidden = YES;
            imgA8.hidden = YES;
        }
            break;
    }

    
    
    
    
    
    // img 9
    
    if( accessControl == AC_None)
    {
        imgM9.hidden = YES;
        imgA9.hidden = YES;
    }
    else
    {
        NSString *img9mName = [NSString stringWithFormat:@"%@M%@.jpg",globalSettings,[img9p5 objectAtIndex:accessControl]];
        NSString *img9aName = [NSString stringWithFormat:@"%@A%@.jpg",globalSettings,[img9p5 objectAtIndex:accessControl]];
        
        switch (accessControlLoc) {
            case L_MainCop:
            {
                [imgM9  setImage:[UIImage imageNamed:img9mName]];
                
                imgM9.hidden = NO;
                imgA9.hidden = YES;
            }
                break;
            case L_AuxCop:
            {
                [imgA9  setImage:[UIImage imageNamed:img9aName]];
                
                imgM9.hidden = YES;
                imgA9.hidden = NO;
            }
                break;
            case L_MainAuxCop:
            {
                [imgM9  setImage:[UIImage imageNamed:img9mName]];
                [imgA9  setImage:[UIImage imageNamed:img9aName]];
                
                imgM9.hidden = NO;
                imgA9.hidden = NO;
            }
                break;
                
                
            default:
            {
                imgM9.hidden = YES;
                imgA9.hidden = YES;
            }
                break;
        }

    }
    

    
    
    // img 10
    if ( serviceCabinetType == SC_None )  // IF emergLightType YES
    {
        imgM10.hidden = YES;
        imgA10.hidden = YES;
    }
    else
    {
        
        NSString *img10mName =[NSString stringWithFormat:@"%@M%@.jpg",globalSettings,[img10p5 objectAtIndex:serviceCabinetType]];
        NSString *img10aName =[NSString stringWithFormat:@"%@A%@.jpg",globalSettings,[img10p5 objectAtIndex:serviceCabinetType]];

        switch (serviceCabinetLoc) {
            case L_MainCop:
            {
                [imgM10  setImage:[UIImage imageNamed:img10mName]];
                
                imgM10.hidden = NO;
                imgA10.hidden = YES;
            }
                break;
            case L_AuxCop:
            {
                [imgA10  setImage:[UIImage imageNamed:img10aName]];
                
                imgM10.hidden = YES;
                imgA10.hidden = NO;
            }
                break;
            case L_MainAuxCop:
            {
                [imgM10  setImage:[UIImage imageNamed:img10mName]];
                [imgA10  setImage:[UIImage imageNamed:img10aName]];
                
                imgM10.hidden = NO;
                imgA10.hidden = NO;
            }
                break;
                
                
            default:
            {
                imgM10.hidden = YES;
                imgA10.hidden = YES;
            }
                break;
        }
        
    }

    // img 11
    if ( touchscreenType == TS_None )  // IF emergLightType YES
    {
        imgM11.hidden = YES;
        imgA11.hidden = YES;
    }
    else
    {
        
        NSString *img11mName =[NSString stringWithFormat:@"%@M%@.jpg",globalSettings,[img11p5 objectAtIndex:touchscreenType]];
        NSString *img11aName =[NSString stringWithFormat:@"%@A%@.jpg",globalSettings,[img11p5 objectAtIndex:touchscreenType]];
        
        switch (touchscreenLoc) {
            case L_MainCop:
            {
                [imgM11  setImage:[UIImage imageNamed:img11mName]];
                
                imgM11.hidden = NO;
                imgA11.hidden = YES;
            }
                break;
            case L_AuxCop:
            {
                [imgA11  setImage:[UIImage imageNamed:img11aName]];
                
                imgM11.hidden = YES;
                imgA11.hidden = NO;
            }
                break;
            case L_MainAuxCop:
            {
                [imgM11  setImage:[UIImage imageNamed:img11mName]];
                [imgA11  setImage:[UIImage imageNamed:img11aName]];
                
                imgM11.hidden = NO;
                imgA11.hidden = NO;
            }
                break;
                
                
            default:
            {
                imgM11.hidden = YES;
                imgA11.hidden = YES;
            }
                break;
        }
        
    }
    
}


// update coordinates based on rules

#pragma mark ---- adjust coordinates ----


- (void) updateCoords
{
   
    if ( doorType == DOOR_SingleSideOpening )
    {
        if(touchscreenType == TS_None )
            currentCoords = COORD_A_SINGLE;
        else
            currentCoords = COORD_B_SINGLE;
        
        // in this case the A images are all hidden
        imgA2.hidden = YES;
        imgA3.hidden = YES;
        imgA4.hidden = YES;
        imgA5.hidden = YES;
        imgA6.hidden = YES;
        imgA7.hidden = YES;
        imgA8.hidden = YES;
        imgA9.hidden = YES;
        imgA10.hidden = YES;
        imgA11.hidden = YES;
        
    }
    else
    {
        if(touchscreenType == TS_None )
            currentCoords = COORD_A_CENTER;
        else
            currentCoords = COORD_B_CENTER;
    }
    
    
    switch (currentCoords) {
        case COORD_A_SINGLE:
        {
            [self adjustPosition:imgM2  newX:360.0f newY:418.0f];
            [self adjustPosition:imgM3  newX:360.0f newY:468.0f];
            [self adjustPosition:imgM4  newX:360.0f newY:578.0f];
            [self adjustPosition:imgM5  newX:360.0f newY:636.0f];
            [self adjustPosition:imgM6  newX:360.0f newY:748.0f];
            [self adjustPosition:imgM7  newX:360.0f newY:918.0f];
            [self adjustPosition:imgM8  newX:360.0f newY:1168.0f];
            [self adjustPosition:imgM9  newX:360.0f newY:1268.0f];
            [self adjustPosition:imgM10 newX:360.0f newY:1358.0f];
            [self adjustPosition:imgM11 newX:360.0f newY:1168.0f];      // NA
        
        }
        break;
        case COORD_B_SINGLE:
        {
            [self adjustPosition:imgM2  newX:340.0f newY:396.0f];
            [self adjustPosition:imgM3  newX:340.0f newY:454.0f];
            [self adjustPosition:imgM4  newX:340.0f newY:562.0f];
            [self adjustPosition:imgM5  newX:340.0f newY:632.0f];
            [self adjustPosition:imgM6  newX:340.0f newY:700.0f];
            [self adjustPosition:imgM7  newX:340.0f newY:1164.0f];
            [self adjustPosition:imgM8  newX:340.0f newY:832.0f];   // NA
            [self adjustPosition:imgM9  newX:340.0f newY:1272.0f];
            [self adjustPosition:imgM10 newX:340.0f newY:1350.0f];
            [self adjustPosition:imgM11 newX:340.0f newY:832.0f];
            
        }
        break;
        
        
        case COORD_A_CENTER:
        {
            
            float newCoord;
            
            if ( finishType == F_Stainless )
                newCoord = 184.0f;
            else
                newCoord = 190.0f;
            
            
            [self adjustPosition:imgM2  newX:newCoord newY:418.0f];
            [self adjustPosition:imgM3  newX:newCoord newY:468.0f];
            [self adjustPosition:imgM4  newX:newCoord newY:578.0f];
            [self adjustPosition:imgM5  newX:newCoord newY:636.0f];
            [self adjustPosition:imgM6  newX:newCoord newY:748.0f];
            [self adjustPosition:imgM7  newX:newCoord newY:919.0f];
            [self adjustPosition:imgM8  newX:newCoord newY:1168.0f];
            [self adjustPosition:imgM9  newX:newCoord newY:1268.0f];
            [self adjustPosition:imgM10 newX:newCoord newY:1358.0f];
            [self adjustPosition:imgM11 newX:newCoord newY:1168.0f];   // NA
            
            [self adjustPosition:imgA2  newX:1170.0f newY:468.0f];
            [self adjustPosition:imgA3  newX:1170.0f newY:524.0f];
            [self adjustPosition:imgA4  newX:1170.0f newY:618.0f];
            [self adjustPosition:imgA5  newX:1170.0f newY:678.0f];
            [self adjustPosition:imgA6  newX:1170.0f newY:778.0f];
            [self adjustPosition:imgA7  newX:1170.0f newY:928.0f];
            [self adjustPosition:imgA8  newX:1170.0f newY:1148.0f];
            [self adjustPosition:imgA9  newX:1170.0f newY:1248.0f];
            [self adjustPosition:imgA10 newX:1170.0f newY:1318.0f];
            [self adjustPosition:imgA11 newX:1170.0f newY:928.0f];     // NA
            
            
            
            
        }
        break;
        case COORD_B_CENTER:
        {
            [self adjustPosition:imgM2  newX:170.0f newY:396.0f];
            [self adjustPosition:imgM3  newX:170.0f newY:454.0f];
            [self adjustPosition:imgM4  newX:170.0f newY:562.0f];
            [self adjustPosition:imgM5  newX:170.0f newY:632.0f];
            [self adjustPosition:imgM6  newX:170.0f newY:700.0f];
            [self adjustPosition:imgM7  newX:170.0f newY:1164.0f];
            [self adjustPosition:imgM8  newX:170.0f newY:832.0f];      // NA
            [self adjustPosition:imgM9  newX:170.0f newY:1272.0f];
            [self adjustPosition:imgM10 newX:170.0f newY:1350.0f];
            [self adjustPosition:imgM11 newX:170.0f newY:832.0f];
            
            
            [self adjustPosition:imgA2  newX:1182.0f newY:472.0f];
            [self adjustPosition:imgA3  newX:1182.0f newY:516.0f];
            [self adjustPosition:imgA4  newX:1182.0f newY:606.0f];
            [self adjustPosition:imgA5  newX:1182.0f newY:668.0f];
            [self adjustPosition:imgA6  newX:1182.0f newY:732.0f];
            [self adjustPosition:imgA7  newX:1182.0f newY:1146.0f];
            [self adjustPosition:imgA8  newX:1182.0f newY:852.0f];      // NA
            [self adjustPosition:imgA9  newX:1182.0f newY:1246.0f];
            [self adjustPosition:imgA10 newX:1182.0f newY:1316.0f];
            [self adjustPosition:imgA11 newX:1182.0f newY:852.0f];
            
        }
        break;
            
        default:
            break;
    }
    
    
    
    
}

- (void)adjustPosition:(UIImageView *)imgView newX:(CGFloat)newX  newY:(CGFloat)newY{
    
    //[image1 setCenter: CGPointMake(634, 126)];
    CGRect myFrame = imgView.frame;
    
    // July 25
    // resize images to 1/2 of original
    //

    //myFrame.origin.x = newX * rotationFactor;
    //myFrame.origin.y = newY * rotationFactor;
    
    myFrame.origin.x = newX * rotationFactor/2.0;
    myFrame.origin.y = newY * rotationFactor2/2.0;
    
    
    myFrame.size.width = imgView.image.size.width * rotationFactor;
    myFrame.size.height = imgView.image.size.height * rotationFactor2;
    imgView.frame = myFrame;
}




#pragma mark ---- Button Actions ----





- (void)startConfigHidden
{
    configViewHidden = YES;
}



-(IBAction)btnShowHideConfig :(UIButton *)sender
{
    if ( IDIOM == IPAD )
    {
        if( orientationPortrait )
        {
            self.varConstraint.constant = 0;
            self.rotateLabel.alpha = 1;
        }
        else // landsape now
        {
            self.varConstraint.constant = MAX([UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height) - MIN([UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height) / 1024 * 768;
            self.rotateLabel.alpha = 0;
        }
    }
    else  // IPHONE
    {
        if (configViewHidden)
        {
            // show it
            [UIView animateWithDuration:0.2 animations:^{
                self.varConstraint.constant = - self.view.frame.size.width;
                [self.view layoutIfNeeded];
            }];
            
            configViewHidden = NO;
        }
        else
        {
            // hide it
            [UIView animateWithDuration:0.2 animations:^{
                self.varConstraint.constant = 0;
                [self.view layoutIfNeeded];
            }];
            
            configViewHidden = YES;
        }
      
    }
}


#pragma mark ---- Send Mail methods ----

-(IBAction)sendEmail {
    
    MFMailComposeViewController *composer = [[MFMailComposeViewController alloc] init];
    
    [composer setMailComposeDelegate:self];
    
    if ([MFMailComposeViewController canSendMail]) {
        
        NSString *TheMsg;
        
        //[composer setToRecipients:[NSArray arrayWithObjects:@"info@madelevator.com", nil]];
        
        [composer setCcRecipients:[NSArray arrayWithObjects:@"info@madelevator.com", nil]];
        
        
        [composer setSubject:@"MAD Elevator - COP Selection"];
        
        
        TheMsg = [NSString stringWithFormat:@"\nPlease find attached your COP Selection.\n%@: %@\n\%@: %@\n%@: %@\n%@: %@   %@: %@\n%@: %@   %@: %@\n%@: %@   %@: %@\n%@: %@   %@: %@\n%@: %@\n\%@: %@\n%@: %@   %@: %@\n%@: %@   %@: %@\n\%@: %@\n%@: %@   %@: %@\n%@: %@   %@: %@\n\n\nPlease let your MAD Sales Rep know if you have any questions.\n\n\nThe MAD Elevator Team\n1-866-967-8500\ninfo@madelevator.com\n\n Sent from MAD Fixtures App",
                  [optionsCOP objectAtIndex:CB_DoorType],[valuesCOP objectAtIndex:CB_DoorType],
                  [optionsCOP objectAtIndex:CB_Coptype],[valuesCOP objectAtIndex:CB_Coptype],
                  [optionsCOP objectAtIndex:CB_Finish],[valuesCOP objectAtIndex:CB_Finish],
                  
                  [optionsCOP objectAtIndex:CB_Engraving],[valuesCOP objectAtIndex:CB_Engraving],
                  [optionsCOPExtra objectAtIndex:CB_Engraving],[valuesCOPExtra objectAtIndex:CB_Engraving],
                  
                  [optionsCOP objectAtIndex:CB_PositionIndicator],[valuesCOP objectAtIndex:CB_PositionIndicator],
                  [optionsCOPExtra objectAtIndex:CB_PositionIndicator],[valuesCOPExtra objectAtIndex:CB_PositionIndicator],
                  
                  [optionsCOP objectAtIndex:CB_EmergencyLight],[valuesCOP objectAtIndex:CB_EmergencyLight],
                  [optionsCOPExtra objectAtIndex:CB_EmergencyLight],[valuesCOPExtra objectAtIndex:CB_EmergencyLight],
                  
                  [optionsCOP objectAtIndex:CB_Autodialer],[valuesCOP objectAtIndex:CB_Autodialer],
                  [optionsCOPExtra objectAtIndex:CB_Autodialer],[valuesCOPExtra objectAtIndex:CB_Autodialer],
                  
                  [optionsCOP objectAtIndex:CB_FireService],[valuesCOP objectAtIndex:CB_FireService],
                  
                  [optionsCOP objectAtIndex:CB_OtherService],[valuesCOP objectAtIndex:CB_OtherService],
                  
                  [optionsCOP objectAtIndex:CB_Touchscreen],[valuesCOP objectAtIndex:CB_Touchscreen],
                  [optionsCOPExtra objectAtIndex:CB_Touchscreen],[valuesCOPExtra objectAtIndex:CB_Touchscreen],
                  
                  [optionsCOP objectAtIndex:CB_Pushbutton],[valuesCOP objectAtIndex:CB_Pushbutton],
                  [optionsCOPExtra objectAtIndex:CB_Pushbutton],[valuesCOPExtra objectAtIndex:CB_Pushbutton],
                  
                  [optionsCOP objectAtIndex:CB_RearOpening],[valuesCOP objectAtIndex:CB_RearOpening],
                  
                  [optionsCOP objectAtIndex:CB_AccessControl],[valuesCOP objectAtIndex:CB_AccessControl],
                  [optionsCOPExtra objectAtIndex:CB_AccessControl],[valuesCOPExtra objectAtIndex:CB_AccessControl],
                  
                  [optionsCOP objectAtIndex:CB_ServiceCabinet],[valuesCOP objectAtIndex:CB_ServiceCabinet],
                  [optionsCOPExtra objectAtIndex:CB_ServiceCabinet],[valuesCOPExtra objectAtIndex:CB_ServiceCabinet]
                  ];
        
        [composer setMessageBody:TheMsg isHTML:NO];
        
        // build the composed image
        
        
        CGSize newSize = CGSizeMake(768, 1024);
        UIGraphicsBeginImageContext( newSize );
        
        // draw the images
            
        // BG and image 2 to 11 depending on options
        
        // top or top center
        // bottom
        
        float currentFactor = rotationFactor;
        float currentFactor2 = rotationFactor2;

// July 25
// resize images to 1/2 of original
//
//        rotationFactor = 0.5;
        rotationFactor = 1.0;
        rotationFactor2 = 1.0;
        
        
        [self updateCoords];
        rotationFactor = currentFactor;
        rotationFactor2 = currentFactor2;
            
        [imgBg.image drawInRect:CGRectMake(0,0,newSize.width,newSize.height) blendMode:kCGBlendModeNormal alpha:1];
       
        
        if (! imgM2.hidden) [imgM2.image drawInRect:imgM2.frame blendMode:kCGBlendModeNormal alpha:1];
        if (! imgM3.hidden) [imgM3.image drawInRect:imgM3.frame blendMode:kCGBlendModeNormal alpha:1];
        if (! imgM4.hidden) [imgM4.image drawInRect:imgM4.frame blendMode:kCGBlendModeNormal alpha:1];
        if (! imgM5.hidden) [imgM5.image drawInRect:imgM5.frame blendMode:kCGBlendModeNormal alpha:1];
        if (! imgM6.hidden) [imgM6.image drawInRect:imgM6.frame blendMode:kCGBlendModeNormal alpha:1];
        if (! imgM7.hidden) [imgM7.image drawInRect:imgM7.frame blendMode:kCGBlendModeNormal alpha:1];
        if (! imgM8.hidden) [imgM8.image drawInRect:imgM8.frame blendMode:kCGBlendModeNormal alpha:1];
        if (! imgM9.hidden) [imgM9.image drawInRect:imgM9.frame blendMode:kCGBlendModeNormal alpha:1];
        if (! imgM10.hidden) [imgM10.image drawInRect:imgM10.frame blendMode:kCGBlendModeNormal alpha:1];
        if (! imgM11.hidden) [imgM11.image drawInRect:imgM11.frame blendMode:kCGBlendModeNormal alpha:1];
        
        
        if ( doorType == DOOR_CenterOpening )
        {
            // draw aux images as well
            if (! imgA2.hidden) [imgA2.image drawInRect:imgA2.frame blendMode:kCGBlendModeNormal alpha:1];
            if (! imgA3.hidden) [imgA3.image drawInRect:imgA3.frame blendMode:kCGBlendModeNormal alpha:1];
            if (! imgA4.hidden) [imgA4.image drawInRect:imgA4.frame blendMode:kCGBlendModeNormal alpha:1];
            if (! imgA5.hidden) [imgA5.image drawInRect:imgA5.frame blendMode:kCGBlendModeNormal alpha:1];
            if (! imgA6.hidden) [imgA6.image drawInRect:imgA6.frame blendMode:kCGBlendModeNormal alpha:1];
            if (! imgA7.hidden) [imgA7.image drawInRect:imgA7.frame blendMode:kCGBlendModeNormal alpha:1];
            if (! imgA8.hidden) [imgA8.image drawInRect:imgA8.frame blendMode:kCGBlendModeNormal alpha:1];
            if (! imgA9.hidden) [imgA9.image drawInRect:imgA9.frame blendMode:kCGBlendModeNormal alpha:1];
            if (! imgA10.hidden) [imgA10.image drawInRect:imgA10.frame blendMode:kCGBlendModeNormal alpha:1];
            if (! imgA11.hidden) [imgA11.image drawInRect:imgA11.frame blendMode:kCGBlendModeNormal alpha:1];
            
        }
       
        [self updateCoords];
        
        // add the copyright
        
        [[UIImage imageNamed:@"copyright.png"] drawInRect:CGRectMake(368,924,400,100) blendMode:kCGBlendModeNormal alpha:1];
        
        
        UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
        
        UIGraphicsEndImageContext();
        
        
        NSData *photoData = UIImageJPEGRepresentation(newImage, 1);
        [composer addAttachmentData:photoData mimeType:@"image/jpeg" fileName:@"COP.jpg"];
        
        [composer setModalTransitionStyle:UIModalTransitionStyleCrossDissolve];
        
        //[self presentModalViewController:composer animated:YES];
        [self presentViewController:composer animated:YES completion:nil];
    }
}

-(void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error {
    
    
    // restore the screen image sizes after attachemnt is created

    
    if (error) {
        UIAlertController * alert = [UIAlertController
                                     alertControllerWithTitle:@"Error Occured"
                                     message:[NSString stringWithFormat:@"error - %@", [error description]]
                                     preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction* dismissButton = [UIAlertAction
                                        actionWithTitle:@"dismiss"
                                        style:UIAlertActionStyleDefault
                                        handler:^(UIAlertAction * action) {
                                            //Handle your yes please button action here
                                            [alert dismissViewControllerAnimated:YES completion:nil];
                                        }];
        [alert addAction:dismissButton];
        [self presentViewController:alert animated:YES completion:nil];
        
       // [self dismissModalViewControllerAnimated:YES];
        [self dismissViewControllerAnimated:YES completion:nil];
        
    }
    
    else {
        
        //[self dismissModalViewControllerAnimated:YES];
        [self dismissViewControllerAnimated:YES completion:nil];
        
    }
    
}



#pragma mark ---- UIPickerViewDataSource delegate methods ----

// returns the number of columns to display.
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
	return numPickComponents;
}

// returns the number of rows
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    if ( component == 0 )
        return [activeMenuA count];
    else
        return [activeMenuB count];
}


#pragma mark ---- UIPickerViewDelegate delegate methods ----

// returns the title of each row
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
	
    if ( component == 0 )
        return [activeMenuA objectAtIndex:row];
    else
        return [activeMenuB objectAtIndex:row];
    
    
}

// gets called when the user settles on a row
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
	if ( component == 0 )
        userSelectionA = (unsigned int)row;
    else
        userSelectionB = (unsigned int)row;

}



#pragma mark ---- Memory ----

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


// update the config based on selection
-(void)updateConfig :(int)index :(bool)extraPicker {
    
   
    
    // set the current selection for the activeConfig;
    
    // base on the active menu
    switch (activeHvPicker) {
            
        case CB_DoorType:
        {
            doorType = index;
            [valuesCOP replaceObjectAtIndex:CB_DoorType withObject:[menuDoor objectAtIndex:(unsigned int)doorType]];
            
            [self updateCoords];
        }
            break;
            
        case CB_Coptype:
        {
            copType = index;
            [valuesCOP replaceObjectAtIndex:CB_Coptype withObject:[menuCop objectAtIndex:(unsigned int)copType]];
        }
            break;
            
        case CB_Finish:
        {
            finishType  = index;
            [valuesCOP replaceObjectAtIndex:CB_Finish withObject:[menuFinish objectAtIndex:(unsigned int)finishType]];
            
            [self updateCoords];
            
        }
            break;
            
        case CB_Engraving:
        {
            if ( ! extraPicker )
            {
                engravingType  = index;
                [valuesCOP replaceObjectAtIndex:CB_Engraving withObject:[menuEngraving objectAtIndex:(unsigned int)engravingType]];
            }
            else
            {
                engravingLoc  = index;
                [valuesCOPExtra replaceObjectAtIndex:CB_Engraving withObject:[menuEngravingLoc objectAtIndex:(unsigned int)engravingLoc]];

            }
        }
            break;
            
            
        case CB_PositionIndicator:
        {
            if ( ! extraPicker )
            {
                posIndicatorType  = index;
                [valuesCOP replaceObjectAtIndex:CB_PositionIndicator withObject:[menuPosIndicator objectAtIndex:(unsigned int)posIndicatorType]];
            }
            else
            {
                posIndicatorLoc = index;
                [valuesCOPExtra replaceObjectAtIndex:CB_PositionIndicator withObject:[menuPosIndicatorLoc objectAtIndex:(unsigned int)posIndicatorLoc]];
            }
        }
            break;
            
        case CB_EmergencyLight:
        {
            if ( ! extraPicker )
            {
                if( index == 0)
                    emergLightType = NO;
                else
                    emergLightType = YES;
                
                [valuesCOP replaceObjectAtIndex:CB_EmergencyLight withObject:[menuEmergLight objectAtIndex:(unsigned int)emergLightType]];
            }
            else
            {
                emergLightLoc = index;
                 [valuesCOPExtra replaceObjectAtIndex:CB_EmergencyLight withObject:[menuEmergLightLoc objectAtIndex:(unsigned int)emergLightLoc]];
            }

        }
            break;
            
        case CB_Autodialer:
        {
            if ( ! extraPicker )
            {

                if( index == 0)
                    autodialerType = NO;
                else
                    autodialerType = YES;
                
                [valuesCOP replaceObjectAtIndex:CB_Autodialer withObject:[menuAutodialer objectAtIndex:(unsigned int)autodialerType]];

            }
            else
            {
                autodialerLoc = index;
                [valuesCOPExtra replaceObjectAtIndex:CB_Autodialer withObject:[menuAutodialerLoc objectAtIndex:(unsigned int)autodialerLoc]];
            }
            
        }
            break;
            
        case CB_FireService:
        {
            if ( ! extraPicker )
            {
                fireServiceType = index;
                [valuesCOP replaceObjectAtIndex:CB_FireService withObject:[menuFireService objectAtIndex:(unsigned int)fireServiceType]];
            }
            else
            {
                fireServiceLoc = index;
                [valuesCOPExtra replaceObjectAtIndex:CB_FireService withObject:[menuFireServiceLoc objectAtIndex:(unsigned int)fireServiceLoc]];
            }
            
        }
            break;
            
        case CB_OtherService:
        {
            specialService = index;
            [valuesCOP replaceObjectAtIndex:CB_OtherService withObject:[menuOtherService objectAtIndex:(unsigned int)specialService]];
        }
            break;
            
        case CB_Touchscreen:
        {
            if ( ! extraPicker )
            {
                touchscreenType = index;
                [valuesCOP replaceObjectAtIndex:CB_Touchscreen withObject:[menuTouchscreen objectAtIndex:(unsigned int)touchscreenType]];
                [self updateCoords];
            }
            else
            {
                touchscreenLoc = index;
                [valuesCOPExtra replaceObjectAtIndex:CB_Touchscreen withObject:[menuTouchscreenLoc objectAtIndex:(unsigned int)touchscreenLoc]];
            }

        }
            break;
            
        case CB_Pushbutton:
        {
            if ( ! extraPicker )
            {
                pushButtonType = index;
                [valuesCOP replaceObjectAtIndex:CB_Pushbutton withObject:[menuPushbutton objectAtIndex:(unsigned int)pushButtonType]];
            }
            else
            {
                pushButtonNumOpenings = index +2;
                [valuesCOPExtra replaceObjectAtIndex:CB_Pushbutton withObject:[menuPushbuttonOpenings objectAtIndex:(unsigned int)pushButtonNumOpenings-2]];
            }

        }
            break;
            
        case CB_RearOpening:
        {
            openingType = index;
            [valuesCOP replaceObjectAtIndex:CB_RearOpening withObject:[menuRearOpening objectAtIndex:(unsigned int)openingType]];
        }
            break;
            
        case CB_AccessControl:
        {
            if ( ! extraPicker )
            {
                accessControl = index;
                [valuesCOP replaceObjectAtIndex:CB_AccessControl withObject:[menuAccessControl objectAtIndex:(unsigned int)accessControl]];
            }
            else
            {
                accessControlLoc = index;
                 [valuesCOPExtra replaceObjectAtIndex:CB_AccessControl withObject:[menuAccessControlLoc objectAtIndex:(unsigned int)accessControlLoc]];
            }

        }
            break;
            
        case CB_ServiceCabinet:
        {
            if ( ! extraPicker )
            {
                serviceCabinetType = index;
                [valuesCOP replaceObjectAtIndex:CB_ServiceCabinet withObject:[menuServiceCabinet objectAtIndex:(unsigned int)serviceCabinetType]];
            }
            else
            {
                serviceCabinetLoc = index;
                [valuesCOPExtra replaceObjectAtIndex:CB_ServiceCabinet withObject:[menuServiceCabinetLoc objectAtIndex:(unsigned int)serviceCabinetLoc]];
            }

        }
            break;
            
        default:
            break;
    }
    
    
    [self updateImages];
    [self updateCoords];
}









#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [optionsCOP count];
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (IDIOM == IPAD) {
        return NORMAL_CELL_FINISHING_HEIGHT;
    } else {
        return 40;
    }
}


- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section;
{
    if (IDIOM == IPAD) {
        return 45;
    } else {
        return 40;
    }
}



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    if( [_collapsedSections containsObject:@(section)] )
    {
        if ( [[optionsCOPExtra objectAtIndex:section] isEqual: @""] )
            return 1;
        else
            return 2;
    }
    else
        return 0;
        
}

- (NSString *)titleForSection:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    if( section == currentSection )
        return [NSString stringWithFormat:@"  %@:", [optionsCOP objectAtIndex:section]];
    else
    {
        if ([[optionsCOPExtra objectAtIndex:section] isEqual: @""] )
            return [NSString stringWithFormat:@"  %@: %@", [optionsCOP objectAtIndex:section],  [valuesCOP objectAtIndex:section]];
        else
        {
            if( section == CB_Pushbutton )
                return [NSString stringWithFormat:@"  %@: %@  - %@ openings", [optionsCOP objectAtIndex:section],  [valuesCOP objectAtIndex:section],  [valuesCOPExtra objectAtIndex:section]];
            else
                return [NSString stringWithFormat:@"  %@: %@  - %@ ", [optionsCOP objectAtIndex:section],  [valuesCOP objectAtIndex:section],  [valuesCOPExtra objectAtIndex:section]];
        }
    }
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    
    //int sectionReference = section;
    //if ( sectionReference >= LANTERNTAG_START)
    //    sectionReference = sectionReference - LANTERNTAG_START;
    
    UIButton* result = [UIButton buttonWithType:UIButtonTypeCustom];
    
    [result addTarget:self action:@selector(sectionButtonTouchUpInside:) forControlEvents:UIControlEventTouchUpInside];
    
    //NSLog(@"VIEW FOR HEADER currentSection %d ",currentSection);
    
    if( currentSection == section)
    {
        result.backgroundColor =  [UIColor blackColor];//Rgb2UIColor(236, 28, 36);//[UIColor blueColor];
        [result setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [result setTitleColor:[UIColor whiteColor] forState:UIControlStateHighlighted];
    }
    else
    {
        result.backgroundColor =  Rgb2UIColor(229, 229, 229);//[UIColor lightGrayColor];
        [result setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [result setTitleColor:[UIColor blackColor] forState:UIControlStateHighlighted];
    }
    
    [result setTitle:[self titleForSection:tableView titleForHeaderInSection:section ] forState:UIControlStateNormal];
    //result.titleLabel.font = [UIFont fontWithName: @"Helvetica" size: 12];
    result.titleLabel.adjustsFontSizeToFitWidth = YES;
    
    // [result.titleLabel setTextAlignment: NSTextAlignmentLeft];
    //result.titleLabel.textAlignment=NSTextAlignmentLeft;
    
    result.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    result.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    
    if (IDIOM != IPAD) {
        [result.titleLabel setFont:[UIFont systemFontOfSize:12]];
    }
    
    result.tag = section;
    
    return result;
    
}

-(NSArray*) indexPathsForSection:(int)section withNumberOfRows:(int)numberOfRows {
    
    NSMutableArray* indexPaths = [NSMutableArray new];
    
    for (int i = 0; i < numberOfRows; i++) {
        NSIndexPath* indexPath = [NSIndexPath indexPathForRow:i inSection:section];
        [indexPaths addObject:indexPath];
    }
    
    return indexPaths;
}

-(void)sectionButtonTouchUpInside:(UIButton*)sender {
    
    //NSLog(@"currentSection %d  ButtonTag %d",currentSection, (int)sender.tag);
    
    int previousSection = currentSection;
    
    
    int sectionCollapsed = -1;
    
    
    [tblOptionsCOP beginUpdates];
    
    if ( currentSection != -1 )
    {
        bool shouldCollapsePrevious;
        
        shouldCollapsePrevious= [_collapsedSections containsObject:@(currentSection)];
        
        if (shouldCollapsePrevious)
        {
            
            sectionCollapsed = currentSection;
            
            int numOfRows;
            
            numOfRows = (int)[tblOptionsCOP numberOfRowsInSection:currentSection];
            
            [_collapsedSections removeObject:@(currentSection)];
            
            NSArray* indexPaths = [self indexPathsForSection:currentSection withNumberOfRows:numOfRows];
            [tblOptionsCOP deleteRowsAtIndexPaths:indexPaths withRowAnimation:UITableViewRowAnimationTop];
            
        }
        
        currentSection = -1;
        
        [tblOptionsCOP reloadSections: [NSIndexSet indexSetWithIndex:previousSection] withRowAnimation:UITableViewRowAnimationNone];
        
    }
    
    [tblOptionsCOP endUpdates];
    //[NSThread sleepForTimeInterval:0.6];  //wait a bit for the animation
    
    // [myTableView reloadData];  // make sure that the last header turned grey ( not selected )
    int section = (int)sender.tag;
    bool shouldExpand;
    
    shouldExpand = ![_collapsedSections containsObject:@(section)];
    
    
    
    //NSLog(@"currentSection %d  ButtonTag %d",currentSection, (int)sender.tag);
    
    
    [tblOptionsCOP beginUpdates];
    
    if ( shouldExpand && sectionCollapsed != section ) // should expand oly if it was not just collpased
    {
        currentSection = section;
       
        [self setupHorizontalPickerView:currentSection];  // set up Horizontal picker here to be added to each cell as they are displayed
        
        sender.backgroundColor = Rgb2UIColor(236, 28, 36);//[UIColor blueColor];
        
        [_collapsedSections addObject:@(currentSection)];
   
        int numOfRows;
        
        numOfRows = (int)[tblOptionsCOP numberOfRowsInSection:currentSection];
        
        
        NSArray* indexPaths = [self indexPathsForSection:currentSection withNumberOfRows:numOfRows];
        
        [tblOptionsCOP insertRowsAtIndexPaths:indexPaths withRowAnimation:UITableViewRowAnimationTop];
        
        [tblOptionsCOP reloadSections: [NSIndexSet indexSetWithIndex:currentSection] withRowAnimation:UITableViewRowAnimationNone];
        
        //NSLog(@"SET currentSection %d ",currentSection);
        
    }
    else
    {
        currentSection = -1;
    }
    
    [tblOptionsCOP endUpdates];
    
    
    if (  currentSection != -1 )
    {
        if ([[optionsCOPExtra objectAtIndex:section] isEqual: @""] )
            [tblOptionsCOP scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:currentSection] atScrollPosition:UITableViewScrollPositionNone  animated:YES];
        else
            [tblOptionsCOP scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:1 inSection:currentSection] atScrollPosition:UITableViewScrollPositionNone  animated:YES];
        
    }
    
}





- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
   
    NSString *cellIdentifier = nil;
    JTTransformableTableViewCell *cell = nil;
    cellIdentifier = @"UnfoldingTableViewCell";
    
    
    if (cell == nil) {
        cell = [JTTransformableTableViewCell transformableTableViewCellWithStyle:JTTransformableTableViewCellStyleUnfolding
                                                                 reuseIdentifier:cellIdentifier];
        cell.textLabel.adjustsFontSizeToFitWidth = YES;
        cell.textLabel.textColor = [UIColor whiteColor];
    }
    cell.tintColor =  Rgb2UIColor(236, 28, 36); //[UIColor blueColor];
    
    cell.finishedHeight = COMMITING_CREATE_CELL_HEIGHT;
    
    
    // Configure the cell...
   // NSLog(@"CELL FOR ROW %d ",(int)indexPath.row );
    
    [cell setBackgroundColor:[UIColor clearColor]];
    //UILabel *textLable = [[UILabel alloc] initWithFrame:CGRectZero];
    
    cell.accessoryView = nil;
    cell.accessoryType = UITableViewCellAccessoryNone;
    
    // cell.backgroundColor =  Rgb2UIColor(229, 229, 229);
    
    cell.contentView.backgroundColor = [UIColor clearColor];
    
    
    if(indexPath.row == 0 )
        cell.textLabel.text = @"Options:";
    else
        cell.textLabel.text = [NSString stringWithFormat:@"%@:", [optionsCOPExtra objectAtIndex:currentSection]];
    
    if (IDIOM == IPAD) {
        if (currentSection == CB_Pushbutton && indexPath.row == 1) {
            cell.textLabel.font = [UIFont fontWithName: @"Helvetica" size: 15];
        } else {
            cell.textLabel.font = [UIFont fontWithName: @"Helvetica" size: 16];
        }
    } else {
        cell.textLabel.font = [UIFont fontWithName: @"Helvetica" size: 12];
    }
    
    return cell;
}

-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    // change the height of cell over .6 of a second
    cell.layer.opacity = 1;
    
    CGRect myFrame = cell.frame;
    
    myFrame.size.height = 0;
    
    cell.frame= myFrame;
    
    if ( indexPath.row == 0)
        [self.hPickerView removeFromSuperview]; // since will get re added after animation;
    else
        [self.hPickerViewExtra removeFromSuperview];
    
        
    [UIView animateWithDuration:0.6
                     animations:^{
                         
                         CGRect myFrame = cell.frame;
                         myFrame.size.height = 50;
                         cell.frame= myFrame;
                         cell.layer.opacity = 1;
                         
                     }
                     completion:^(BOOL finished){
                         if ( indexPath.row == 0)
                            [cell addSubview:self.hPickerView];
                         else
                            [cell addSubview:self.hPickerViewExtra];
                             
                     }];
}




#pragma mark - Table view delegate



#pragma mark - HorizontalPickerView Inintialization
- (void)setupHorizontalPickerView:(int)thePickerOptions {
    
    self.hPickerView = nil;
    self.hPickerViewExtra = nil;
    
    activeHvPicker = thePickerOptions;
    
    switch(activeHvPicker)
    {
        case CB_DoorType:
        {
            hvPickerActive = menuDoor;
            activeHvSelection = (int)doorType;
        }
            break;
        case CB_Coptype:
        {
            hvPickerActive = menuCop;
            activeHvSelection = (int)copType;
        }
            break;
        case CB_Finish:
        {
            hvPickerActive = menuFinish;
            activeHvSelection = (int)finishType;
        }
            break;
        case CB_Engraving:
        {
            hvPickerActive = menuEngraving;
            activeHvSelection = (int)engravingType;
            
            hvPickerActiveExtra = menuEngravingLoc;
            activeHvSelectionExtra = (int)engravingLoc;

        }
            break;
        case CB_PositionIndicator:
        {
            hvPickerActive = menuPosIndicator;
            activeHvSelection = (int)posIndicatorType;
            
            hvPickerActiveExtra = menuPosIndicatorLoc;
            activeHvSelectionExtra = (int)posIndicatorLoc;

        }
            break;

        case CB_EmergencyLight:
        {
            hvPickerActive = menuEmergLight;
            activeHvSelection = (int)emergLightType;
            
            hvPickerActiveExtra = menuEmergLightLoc;
            activeHvSelectionExtra = (int)emergLightLoc;
            
        }
            break;
        case CB_Autodialer:
        {
            hvPickerActive = menuAutodialer;
            activeHvSelection = (int)fireServiceType;
            
            hvPickerActiveExtra = menuAutodialerLoc;
            activeHvSelectionExtra = (int)autodialerLoc;
            
            
        }
            break;
        case CB_FireService:
        {
            hvPickerActive = menuFireService;
            activeHvSelection = (int)autodialerType;
            
            hvPickerActiveExtra = menuFireServiceLoc;
            activeHvSelectionExtra = (int)fireServiceLoc;
            
        }
            break;
        case  CB_OtherService:
        {
            hvPickerActive = menuOtherService;
            activeHvSelection = (int)specialService;
            
        }
            break;
        case CB_Touchscreen:
        {
            hvPickerActive = menuTouchscreen;
            activeHvSelection = (int)touchscreenType;
            
            hvPickerActiveExtra = menuTouchscreenLoc;
            activeHvSelectionExtra = (int)touchscreenLoc;
            
        }
            break;
        case  CB_Pushbutton:
        {
            hvPickerActive = menuPushbutton;
            activeHvSelection = (int)pushButtonType;
          
            
            hvPickerActiveExtra = menuPushbuttonOpenings;
            activeHvSelectionExtra = (int)pushButtonNumOpenings-2;
            
        }
            break;
        case  CB_RearOpening:
        {
            hvPickerActive = menuRearOpening;
            activeHvSelection = (int)openingType;
            
        }
            break;
        case CB_AccessControl:
        {
            hvPickerActive = menuAccessControl;
            activeHvSelection = (int)accessControl;
            
            hvPickerActiveExtra = menuAccessControlLoc;
            activeHvSelectionExtra = (int)accessControlLoc;
        }
            break;
       
        case CB_ServiceCabinet:
        {
            hvPickerActive = menuServiceCabinet;
            activeHvSelection = (int)serviceCabinetType;
            
            hvPickerActiveExtra = menuServiceCabinetLoc;
            activeHvSelectionExtra = (int)serviceCabinetLoc;
        }
            break;

    
    }
    
    
    CGRect tmpFrame;
    if ( IDIOM != IPAD )  // IPHONE
        tmpFrame = CGRectMake(110,0,220,40);
    else
        tmpFrame = CGRectMake(110,0,310,40);
    
	self.hPickerView = [[V8HorizontalPickerView alloc] initWithFrame:tmpFrame];
    self.hPickerView.backgroundColor   = Rgb2UIColor(236, 28, 36);
	self.hPickerView.selectedTextColor = [UIColor whiteColor];
	self.hPickerView.textColor   = [UIColor whiteColor];
	self.hPickerView.delegate    = self;
	self.hPickerView.dataSource  = self;
    if ( IDIOM != IPAD )  // IPHONE
    {
        self.hPickerView.elementFont = [UIFont boldSystemFontOfSize:12.0f];
        self.hPickerView.selectionPoint = CGPointMake(110, 0);
    }
    else
    {
        self.hPickerView.elementFont = [UIFont boldSystemFontOfSize:14.0f];
        self.hPickerView.selectionPoint = CGPointMake(155, 0);
    }
    
    // add carat or other view to indicate selected element
	UIImageView *indicator = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"indicator"]];
    self.hPickerView.selectionIndicatorView = indicator;
    
    // add gradient images to left and right of view if desired
    UIImageView *leftFade = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"left_fade"]];
    self.hPickerView.leftEdgeView = leftFade;
    
    UIImageView *rightFade = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"right_fade"]];
    self.hPickerView.rightEdgeView = rightFade;

    // set the intial value of the picker
    [self.hPickerView scrollToElement:activeHvSelection animated:NO];
    
    
    
    ///////
    
    if ( ! [[optionsCOPExtra objectAtIndex:activeHvPicker] isEqual: @""] )
    {
     
        if ( IDIOM != IPAD )  // IPHONE
            tmpFrame = CGRectMake(110,0,220,40);
        else
        {
            tmpFrame = CGRectMake(110,0,310,40);
        }
        self.hPickerViewExtra = [[V8HorizontalPickerView alloc] initWithFrame:tmpFrame];
        self.hPickerViewExtra.backgroundColor   = Rgb2UIColor(236, 28, 36);
        self.hPickerViewExtra.selectedTextColor = [UIColor whiteColor];
        self.hPickerViewExtra.textColor   = [UIColor whiteColor];
        self.hPickerViewExtra.delegate    = self;
        self.hPickerViewExtra.dataSource  = self;
        
        if ( IDIOM != IPAD )  // IPHONE
        {
            self.hPickerViewExtra.elementFont = [UIFont boldSystemFontOfSize:12.0f];
            self.hPickerViewExtra.selectionPoint = CGPointMake(110, 0);
        }
        else
        {
            self.hPickerViewExtra.elementFont = [UIFont boldSystemFontOfSize:14.0f];
            self.hPickerViewExtra.selectionPoint = CGPointMake(155, 0);
        }
        // add carat or other view to indicate selected element
        UIImageView *indicator = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"indicator"]];
        self.hPickerViewExtra.selectionIndicatorView = indicator;
        
        // add gradient images to left and right of view if desired
        UIImageView *leftFade = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"left_fade"]];
        self.hPickerViewExtra.leftEdgeView = leftFade;
        
        UIImageView *rightFade = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"right_fade"]];
        self.hPickerViewExtra.rightEdgeView = rightFade;
   
        
        // set the intial value of the picker
        [self.hPickerViewExtra scrollToElement:activeHvSelectionExtra  animated:NO];

    }
    

}


#pragma mark - HorizontalPickerView DataSource Methods
- (NSInteger)numberOfElementsInHorizontalPickerView:(V8HorizontalPickerView *)picker {
    
    if ( picker == self.hPickerView )
    {
        return [hvPickerActive count];
    }
    else
    {
       return [hvPickerActiveExtra count];
    }

}

- (UIView *)horizontalPickerView:(V8HorizontalPickerView *)picker viewForElementAtIndex:(NSInteger)index;
{

    CGSize constrainedSize = CGSizeMake(MAXFLOAT, MAXFLOAT);
	NSString *text;
    
    if ( picker == self.hPickerView )
    {
        text= [hvPickerActive objectAtIndex:index];
    }
    else
    {
        text= [hvPickerActiveExtra objectAtIndex:index];
    }
    
    
    CGSize textSize;

    UIFont *font;
    
    
    if ( IDIOM != IPAD )  // IPHONE
    {
        font = [UIFont systemFontOfSize:12.0f];
    }
    else
    {
        font = [UIFont systemFontOfSize:14.0f];
    }
    
    NSAttributedString *attributedText =
    [[NSAttributedString alloc]
     initWithString:text
     attributes:@
     {
     NSFontAttributeName: font
     }];
    CGRect rect = [attributedText boundingRectWithSize:constrainedSize
                                               options:NSStringDrawingUsesLineFragmentOrigin
                                               context:nil];
    textSize = rect.size;
    

    
    
    
	float theWidth = textSize.width + 40.0f; // 20px padding on each side
    
    CGRect labelFrame     = CGRectMake(0, 0, theWidth, 40);
	UILabel *theLable = [[UILabel alloc] initWithFrame:labelFrame];
    
	theLable.textAlignment   = NSTextAlignmentCenter;
	theLable.backgroundColor = [UIColor clearColor];
	theLable.text            = text;
    
    if ( IDIOM != IPAD )  // IPHONE

        theLable.font = [UIFont systemFontOfSize:12.0f];
    else
        theLable.font = [UIFont boldSystemFontOfSize:14.0f];
    
    theLable.textColor=[UIColor whiteColor];

    
	return theLable;
}


- (NSInteger) horizontalPickerView:(V8HorizontalPickerView *)picker widthForElementAtIndex:(NSInteger)index {
    
	CGSize constrainedSize = CGSizeMake(MAXFLOAT, MAXFLOAT);
    
	NSString *text;
    
    if ( picker == self.hPickerView )
    {
        text= [hvPickerActive objectAtIndex:index];
    }
    else
    {
        text= [hvPickerActiveExtra objectAtIndex:index];
    }

    CGSize textSize;
    
    UIFont *font;
    
    
    if ( IDIOM != IPAD )  // IPHONE
    {
        font = [UIFont systemFontOfSize:12.0f];
    }
    else
    {
        font = [UIFont systemFontOfSize:14.0f];
    }
    
    NSAttributedString *attributedText =
    [[NSAttributedString alloc]
     initWithString:text
     attributes:@
     {
     NSFontAttributeName: font
     }];
    CGRect rect = [attributedText boundingRectWithSize:constrainedSize
                                               options:NSStringDrawingUsesLineFragmentOrigin
                                               context:nil];
    textSize = rect.size;
    
	return textSize.width + 40.0f; // 20px padding on each side
}


- (void)horizontalPickerView:(V8HorizontalPickerView *)picker didSelectElementAtIndex:(NSInteger)index {
    
    // handel selection here
    
    [self updateConfig:(int)index :(picker == self.hPickerViewExtra)];
    
}



#pragma mark ---- Orientation ----


- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    
    if ( IDIOM == IPAD )
        return UIInterfaceOrientationMaskPortrait|UIInterfaceOrientationMaskLandscape;
    else
        return UIInterfaceOrientationMaskPortrait;
        
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}


 
- (BOOL)shouldAutorotate
{
    if ( IDIOM != IPAD )
        return (NO);
    else
        return YES;
}

- (void)viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator {
    
    [coordinator animateAlongsideTransition:^(id<UIViewControllerTransitionCoordinatorContext> context)
     {
         UIInterfaceOrientation interfaceOrientation = (UIInterfaceOrientation)[[UIDevice currentDevice] orientation];
         
         bool landscape = UIInterfaceOrientationIsLandscape(interfaceOrientation);
         [self adjustForRotation:landscape];
         [self.view layoutIfNeeded];
         [self updateCoords];
         // do whatever
     } completion:^(id<UIViewControllerTransitionCoordinatorContext> context)
     {
         
     }];
    
    [super viewWillTransitionToSize:size withTransitionCoordinator:coordinator];
}

 - ( void )adjustForRotation:(BOOL)landscape
{
    // resize before rotation
    
    [self scrollviewZoomToFullSize];
    
    if(  !landscape )  //// PORTRAIT
    {
        orientationPortrait = YES;
        if([UIDevice currentDevice].userInterfaceIdiom == IPAD)
        {
            // July 25
            // resize images to 1/2 of original
            //

            //rotationFactor = 0.5;  // for ipad
            rotationFactor = MIN(self.view.frame.size.width, self.view.frame.size.height) / 768;
            rotationFactor2 = MAX(self.view.frame.size.width, self.view.frame.size.height) / 1024;  // ipad
        }
        else
        {
            // July 25
            // resize images to 1/2 of original
            //

            //rotationFactor = 0.2083333;  // for iPhone
            rotationFactor = 0.4166666 * self.view.frame.size.width / 320;  // for iPhone
            rotationFactor2 = rotationFactor;
        }
        
        // config button is available in portrait
        btnConfirguration.hidden = NO;
        // and hide the config and selection
        if ( !configViewHidden  ) [self btnShowHideConfig:nil];
    }
    else
    {
        orientationPortrait = NO;
        // July 25
        // resize images to 1/2 of original
        //

        //rotationFactor = 0.375;
        rotationFactor = 0.75 * MAX(self.view.frame.size.width, self.view.frame.size.height) / 1024;
        rotationFactor2 = 0.75 * MIN(self.view.frame.size.width, self.view.frame.size.height) / 768;  // ipad
        
        // allways show config
        if ( configViewHidden  ) [self btnShowHideConfig:nil];
        
        btnConfirguration.hidden = YES;
    }

    
    [self updateCoords];
    
    
    
    //NSLog(@"image Frame %d, %d, W:%d, H:%d",(int)imgBg.frame.origin.x, (int)imgBg.frame.origin.y, (int)imgBg.frame.size.width, (int)imgBg.frame.size.height);
    
    // SCROLL VIEW  / PINCH ZOOM
    if(  !landscape )  //// PORTRAIT
    {
       
        if([UIDevice currentDevice].userInterfaceIdiom == IPAD)
        {
            self.varConstraint.constant = 0;
            self.rotateLabel.alpha = 1;
        }
        else
        {

        }
    }
    else
    {
        if([UIDevice currentDevice].userInterfaceIdiom == IPAD) {
            self.varConstraint.constant = MAX([UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height) - MIN([UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height) / 1024 * 768;
            self.rotateLabel.alpha = 0;
        } else {

        }
    }
    

    // go back to full size so can be readjusted and positioned at full size at full sized
    [self scrollviewZoomToFullSize];
}


#pragma mark ---- scrollView delegate methods ----

- (void)scrollviewZoomToFullSize
{
//    CGSize scrollViewSize = self.scrollView.bounds.size;
//    
//    CGFloat w = scrollViewSize.width; // / self.scrollView.minimumZoomScale;
//    CGFloat h = scrollViewSize.height; // / self.scrollView.minimumZoomScale;
//    CGFloat x = 0;
//    CGFloat y = 0;
//    
//    CGRect rectToZoomTo = CGRectMake(x, y, w, h);
//    
//    [self.scrollView zoomToRect:rectToZoomTo animated:YES];
}

- (void)scrollViewDoubleTapped:(UITapGestureRecognizer*)recognizer {
    // Get the location within the image view where we tapped
    CGPoint pointInView = [recognizer locationInView:self.containerView];
    
    // Get a zoom scale that's zoomed in slightly, capped at the maximum zoom scale specified by the scroll view
    CGFloat newZoomScale = self.scrollView.zoomScale * 1.5f;
    newZoomScale = MIN(newZoomScale, self.scrollView.maximumZoomScale);
    
    // Figure out the rect we want to zoom to, then zoom to it
    CGSize scrollViewSize = self.scrollView.bounds.size;
    
    CGFloat w = scrollViewSize.width / newZoomScale;
    CGFloat h = scrollViewSize.height / newZoomScale;
    CGFloat x = pointInView.x - (w / 2.0f);
    CGFloat y = pointInView.y - (h / 2.0f);
    
    CGRect rectToZoomTo = CGRectMake(x, y, w, h);
    
    [self.scrollView zoomToRect:rectToZoomTo animated:YES];
}

- (void)scrollViewTwoFingerTapped:(UITapGestureRecognizer*)recognizer {
    // Zoom out slightly, capping at the minimum zoom scale specified by the scroll view
    CGFloat newZoomScale = self.scrollView.zoomScale / 1.5f;
    newZoomScale = MAX(newZoomScale, self.scrollView.minimumZoomScale);
    [self.scrollView setZoomScale:newZoomScale animated:YES];
}



-(UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView{
    return containerView;
}



- (BOOL)prefersStatusBarHidden
{
    return YES;
}


@end
