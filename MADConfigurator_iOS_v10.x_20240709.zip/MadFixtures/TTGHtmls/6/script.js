"use strict"

const animWidth = 20;
const animHeight = 20;

document.addEventListener('click', e => {
    const ptX = e.pageX - animWidth / 2;
    const ptY = e.pageY - animHeight / 2;
    const touchPoint = document.createElement('div');
    touchPoint.classList.add('cursor');
    touchPoint.setAttribute('style', `left: ${ptX}px; top: ${ptY}px;`);
    touchPoint.addEventListener('animationend', e => {
        if (e.target === touchPoint && !e.pseudoElement) {
            body.removeChild(touchPoint);
        }
    });
    const body = document.getElementsByTagName('body')[0];
    body.appendChild(touchPoint);
});
