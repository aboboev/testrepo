// ALL POP-UP BUTTONS

// Get the modal
var modalDirectory = document.getElementById("myModalDirectory");
var modalTransit = document.getElementById("myModalTransit");
var modalUpcomingEvents = document.getElementById("myModalUpcomingEvents");


// Add timers so that the popups automatically close
var myTimerDirectory = setTimeout(function(){ modalDirectory.style.display = "none" }, 10000);
var myTimerTransit = setTimeout(function(){ modalTransit.style.display = "none" }, 10000);
var myTimerUpcomingEvents = setTimeout(function(){ modalUpcomingEvents.style.display = "none" }, 10000);

// Get the button that opens the modal
var btnDirectory = document.getElementById("directoryBtn");
var btnTransit = document.getElementById("transitBtn");
var btnUpcomingEvents = document.getElementById("upcomingEventsBtn");

var contentDirectory = document.getElementsByClassName("modal-content-Directory")[0];
var contentTransit = document.getElementsByClassName("modal-content-Transit")[0];
var contentUpcomingEvents = document.getElementsByClassName("modal-content-UpcomingEvents")[0];

// Get the <span> element that closes the modal

var spanDirectory = document.getElementsByClassName("close-Directory")[0];
var spanTransit = document.getElementsByClassName("close-Transit")[0];
var spanUpcomingEvents = document.getElementsByClassName("close-UpcomingEvents")[0];

// When the user clicks the button, open the modal 


btnDirectory.onclick = function() {
  modalDirectory.style.display = "block";
  clearTimeout(myTimerDirectory);
  myTimerDirectory = setTimeout(function(){ modalDirectory.style.display = "none" }, 10000);
    
    
    modalTransit.style.display = "none";
    modalUpcomingEvents.style.display = "none";
    
}

btnTransit.onclick = function() {
  modalTransit.style.display = "block";
  clearTimeout(myTimerTransit);
  myTimerTransit = setTimeout(function(){ modalTransit.style.display = "none" }, 10000);
    
    modalDirectory.style.display = "none";
    modalUpcomingEvents.style.display = "none";
    
}

btnUpcomingEvents.onclick = function() {
  modalUpcomingEvents.style.display = "block";
  clearTimeout(myTimerUpcomingEvents);
  myTimerUpcomingEvents = setTimeout(function(){ modalUpcomingEvents.style.display = "none" }, 10000);
    
    modalDirectory.style.display = "none";
    modalTransit.style.display = "none";
    
}


// When the user clicks on <span> (x), close the modal

spanDirectory.onclick = function() {
  modalDirectory.style.display = "none";
}

spanTransit.onclick = function() {
  modalTransit.style.display = "none";
}

spanUpcomingEvents.onclick = function() {
  modalUpcomingEvents.style.display = "none";
}


// When the user clicks anywhere outside of the modal, close it

window.onclick = function(event) {
  if (event.target == modalDirectory) {
    modalDirectory.style.display = "none";
  }
}

window.onclick = function(event) {
  if (event.target == modalTransit) {
    modalTransit.style.display = "none";
  }
}

window.onclick = function(event) {
  if (event.target == modalUpcomingEvents) {
    modalUpcomingEvents.style.display = "none";
  }
}


// When the user clicks on content, close it


contentDirectory.onclick = function() {
  modalDirectory.style.display = "none";
}

contentTransit.onclick = function() {
  modalTransit.style.display = "none";
}

contentUpcomingEvents.onclick = function() {
  modalUpcomingEvents.style.display = "none";
}



"use strict"

const animWidth = 20;
const animHeight = 20;

document.addEventListener('click', e => {
    const ptX = e.pageX - animWidth / 2;
    const ptY = e.pageY - animHeight / 2;
    const touchPoint = document.createElement('div');
    touchPoint.classList.add('cursor');
    touchPoint.setAttribute('style', `left: ${ptX}px; top: ${ptY}px;`);
    touchPoint.addEventListener('animationend', e => {
        if (e.target === touchPoint && !e.pseudoElement) {
            body.removeChild(touchPoint);
        }
    });
    const body = document.getElementsByTagName('body')[0];
    body.appendChild(touchPoint);
});
