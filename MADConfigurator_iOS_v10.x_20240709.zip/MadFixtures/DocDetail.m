//
//  DocDetail.m
//  MadFixtures
//
//  Created by Antonio Pena on 12-03-19.
//  Copyright (c) 2012 Kioaxis. All rights reserved.
//

#import "DocDetail.h"

@implementation DocDetail


@synthesize title;
@synthesize subtitle;
@synthesize filename;

@end
