//
//  ProdPickerViewController.m
//  MadFixtures
//
//  Created by Antonio Pena on 12-01-04.
//  Copyright (c) 2012 Kioaxis. All rights reserved.
//

#import <sys/utsname.h>

#import "ProdPickerViewController.h"


#define IS_IPHONE ([UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPhone)
#define IS_IPHONE_4 (IS_IPHONE && [[UIScreen mainScreen] bounds].size.height == 480.0f)



static NSString *keyProduct = @"product";
static NSString *keyPhoto = @"photo";
//static NSString *keyName = @"name";
static NSString *keyDesc = @"description";
//static NSString *keyMsg = @"emailmsg";


static NSString *fileName = @"allbuttons";



@implementation ProdPickerViewController

@synthesize imageSwitchIndicator;

@synthesize pickerView,imgPickerViewBg;
@synthesize descLabel;
@synthesize productImage;
@synthesize productBackImage;


@synthesize btnColl1;
@synthesize btnColl2;
@synthesize btnColl3;
@synthesize btnColl4;
@synthesize btnColl5;

@synthesize viewControls;

@synthesize imgUiBg;


@synthesize lbl1, lbl2, lbl3, lbl4, lblback, imgBgip5,imgBackfill;


@synthesize scrollView, containerView;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle



- (NSArray *)theListOfProducts {
	
    // the list of sayings are stored in a plist in the app bundle,
	// create an array of sayings by reading this plist
	
    
    NSString *fullfilename =[NSString stringWithFormat: @"%@.plist", fileName];
    NSString *path;
	NSString *rootPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,
															  NSUserDomainMask, YES) objectAtIndex:0];
	path = [rootPath stringByAppendingPathComponent:fullfilename];
	if (![[NSFileManager defaultManager] fileExistsAtPath:path]) {
		path = [[NSBundle mainBundle] pathForResource:fileName ofType:@"plist"];
	}
    
	
    NSData *plistData = [NSData dataWithContentsOfFile:path];
    //NSString *error;
    NSError *error;
	NSPropertyListFormat format;
	
    /*
    NSArray *theListOfProducts = [NSPropertyListSerialization propertyListFromData:plistData
                                                                  mutabilityOption:NSPropertyListImmutable
                                                                            format:&format
                                                                  errorDescription:&error];
    */
    
    NSArray *theListOfProducts =  [   NSPropertyListSerialization propertyListWithData:plistData
                                                                                    options:NSPropertyListImmutable
                                                                                     format:&format
                                                                                      error:&error];
    
    
    if (!theListOfProducts) {
        NSLog(@"Failed to read button data. Error: %@", error);
    }
	
    return theListOfProducts;
}

/*
 // Implement loadView to create a view hierarchy programmatically, without using a nib.
 - (void)loadView
 {
 }
 */


-(void) updateProduct
{
    
    
    // chenck if there is a change?
    // apply the rules
    
    /*
     TTTTT fArray1 = [[NSMutableArray alloc] initWithObjects:@"L",@"A",@"B",@"C",@"D",@"E",@"N",@"F",@"G",@"H",@"M",@"I",@"J",@"K", nil];
     0    1    2    3    4    5    6    7    8    9   10   11   12   13
     MASTER:
     PPPPP fArray2 = [[NSMutableArray alloc] initWithObjects:@"E",@"F",@"J",@"G",@"A",@"B",@"C",@"D",@"H",@"K", @"I", nil];
                                                               0    1    2    3    4    5    6    7    8    9   10
     
     IIIIII fArray3 = [[NSMutableArray alloc] initWithObjects:@"A",@"B",@"C",@"D",@"E",@"F", nil];
     0    1    2    3    4    5
     
     MMMMMM fArray4 = [[NSMutableArray alloc] initWithObjects:@"A",@"B",@"C",@"D",@"E",@"F", nil];
     0    1    2    3    4    5
     */
    
    
    // check for change and re set if color is gray
    
    
    
    /*
     UIView *selectedView = [pickerView viewForRow:row forComponent:component];
    */
    
    

    
    /*
     How it works
    
     1) if a item is selected and it is gray, then do noting and return to the previous selection
     
     2) if and item is selected and it is not gray then we can display the new image and alos check the rules 
     
     3) now we check the rules and to ensure that given the new change we can ensure that only the valid options are available to the user
     
    */
    
    if(sel1 != psel1)
    {
        
        // check for selection  check alpha not backgroundColor
        
        if ( [[pickerView viewForRow:sel1 forComponent:0] alpha ] == itemNotActive )
        {
            sel1 = psel1;
            [pickerView selectRow:sel1 inComponent:1 animated:NO];
            
            // must also restore the current selection otherwise wron combinations may be attempted to be displayed
            cur1 = [fArray1 objectAtIndex:sel1];
            
            applyRules = true;
            return;
        }
        
        
    }
    else if (sel2 != psel2)
    {
        // check selection
        if ( [[pickerView viewForRow:sel2 forComponent:1] alpha ] == itemNotActive )
        {
            sel2 = psel2;
            [pickerView selectRow:sel2 inComponent:0 animated:NO];
            
            // must also restore the current selection otherwise wron combinations may be attempted to be displayed
            cur2 = [fArray2 objectAtIndex:sel2];
            
            applyRules = true;
            return;
        }
    }
    else if(sel3 != psel3)
    {
        
       // NSLog(@"Value of alpha = %f selected row = %d\n",[[pickerView viewForRow:sel3 forComponent:2] alpha], sel3);
        // check selection
        if ( [[pickerView viewForRow:sel3 forComponent:2] alpha ] == itemNotActive )
        {
         //   NSLog(@"WHAT IS IT Value of alpha = %f selected row = %d\n",[[pickerView viewForRow:sel3 forComponent:2] alpha], sel3);
            
            
            sel3 = psel3;
            [pickerView selectRow:sel3 inComponent:2 animated:NO];
            
            // must also restore the current selection otherwise wron combinations may be attempted to be displayed
            cur3 = [fArray3 objectAtIndex:sel3];
            
           applyRules = true;
            return;
        }
        /*
        else
        {
            NSLog(@"DID NOT RETURN\n");
            
            
        }
         */
        
    }
    else if (sel4 != psel4)
    {
        // check selection
        if ( [[pickerView viewForRow:sel4 forComponent:3] alpha ] == itemNotActive )
        {
            sel4 = psel4;
            [pickerView selectRow:sel4 inComponent:3 animated:NO];
            
            // must also restore the current selection otherwise wron combinations may be attempted to be displayed
            cur4 = [fArray4 objectAtIndex:sel4];
            
            applyRules = true;
            return;
        }
    }

    
    
    
    // rules here ??????
    if ( true ) //applyRules )
    {
        
        //NSLog(@"MADE IT TO THE RULES\n");
        
        // re-set all rules
        [aArray3 replaceObjectAtIndex:0 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray3 replaceObjectAtIndex:1 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray3 replaceObjectAtIndex:2 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray3 replaceObjectAtIndex:3 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray3 replaceObjectAtIndex:4 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray3 replaceObjectAtIndex:5 withObject:[NSNumber numberWithFloat:itemActive]];
        
        
        [aArray4 replaceObjectAtIndex:0 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray4 replaceObjectAtIndex:1 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray4 replaceObjectAtIndex:2 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray4 replaceObjectAtIndex:3 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray4 replaceObjectAtIndex:4 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray4 replaceObjectAtIndex:5 withObject:[NSNumber numberWithFloat:itemActive]];
        
        
        [aArray1 replaceObjectAtIndex:0 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray1 replaceObjectAtIndex:1 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray1 replaceObjectAtIndex:2 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray1 replaceObjectAtIndex:3 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray1 replaceObjectAtIndex:4 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray1 replaceObjectAtIndex:5 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray1 replaceObjectAtIndex:6 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray1 replaceObjectAtIndex:7 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray1 replaceObjectAtIndex:8 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray1 replaceObjectAtIndex:9 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray1 replaceObjectAtIndex:10 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray1 replaceObjectAtIndex:11 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray1 replaceObjectAtIndex:12 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray1 replaceObjectAtIndex:13 withObject:[NSNumber numberWithFloat:itemActive]];
        
        
        [pickerView reloadComponent:0];
        [pickerView reloadComponent:2];
        [pickerView reloadComponent:3];
        
        /*
         When P is changed to G, then change I to F
         If P-G is active, do not allow I to be A, B, C or D
         If P-G and I-F active and P is changed, change I to A
         If P does not equal G, then do not allow I-F
         
         */
        
        
        if ([cur2 isEqual:@"G"]){
            
            if( psel2 != 3 )
            {
                cur3 = @"F";
                [pickerView selectRow:5 inComponent:2 animated:NO];
                sel3 = 5;
            }
           
            [aArray3 replaceObjectAtIndex:0 withObject:[NSNumber numberWithFloat:itemNotActive]];//A
            [aArray3 replaceObjectAtIndex:1 withObject:[NSNumber numberWithFloat:itemNotActive]];//B
            [aArray3 replaceObjectAtIndex:2 withObject:[NSNumber numberWithFloat:itemNotActive]];//C
            [aArray3 replaceObjectAtIndex:3 withObject:[NSNumber numberWithFloat:itemNotActive]];//D
            [aArray3 replaceObjectAtIndex:4 withObject:[NSNumber numberWithFloat:itemActive]]; //E  ?????????
            [aArray3 replaceObjectAtIndex:5 withObject:[NSNumber numberWithFloat:itemActive]]; //F

            
            [pickerView reloadComponent:2];

            // NSLog(@"Value of alpha SET TO = %f\n",[[pickerView viewForRow:4 forComponent:2] alpha]);
            
            
        }
        else
        {
            
            // change illumination to F if previous PB was G
            if (psel2 == 3 && [cur3 isEqual:@"F"]){
                cur3 = @"A";
                [pickerView selectRow:0 inComponent:2 animated:NO];
                sel3 = 0;
            }
          
            [aArray3 replaceObjectAtIndex:0 withObject:[NSNumber numberWithFloat:itemActive]];
            [aArray3 replaceObjectAtIndex:1 withObject:[NSNumber numberWithFloat:itemActive]];
            [aArray3 replaceObjectAtIndex:2 withObject:[NSNumber numberWithFloat:itemActive]];
            [aArray3 replaceObjectAtIndex:3 withObject:[NSNumber numberWithFloat:itemActive]];
            [aArray3 replaceObjectAtIndex:4 withObject:[NSNumber numberWithFloat:itemActive]];
            [aArray3 replaceObjectAtIndex:5 withObject:[NSNumber numberWithFloat:itemNotActive]];

            [pickerView reloadComponent:2];
        }
        
        /*
         When P is changed to H, if M equals C, D, E or F, change M to A
         If P-H is active, do not allow M to be C, D, E or F
         If P = H, do not allow T = B,C,D,E,H,J,K,N
         If T = B, when P changed to H, change T to G
         If T = G, when P changed to A, B, C, D, E, F,J, change T to B
         If T = C,D,E,N,H when P changed to H, change T to F
         If T = F, when P changed to A, B, C, D, E, F,J, change T to D
         If T = J,K when P changed to H, change T to I
         
         */
        
        if ( [cur2 isEqual: @"H"] || [cur2 isEqual: @"K"]){
            
            if ( [cur4 isEqual:  @"C"]  || [cur4 isEqual: @"D"]  || [cur4 isEqual: @"E"]  || [cur4 isEqual:   @"F"] ){
                cur4 = @"A";
                [pickerView selectRow:0 inComponent:3 animated:YES];
                sel4 = 0;
            }
            
            
            [aArray4 replaceObjectAtIndex:0 withObject:[NSNumber numberWithFloat:itemActive]];
            [aArray4 replaceObjectAtIndex:1 withObject:[NSNumber numberWithFloat:itemActive]]; ///////
            [aArray4 replaceObjectAtIndex:2 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [aArray4 replaceObjectAtIndex:3 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [aArray4 replaceObjectAtIndex:4 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [aArray4 replaceObjectAtIndex:5 withObject:[NSNumber numberWithFloat:itemNotActive]];
       
            [pickerView reloadComponent:3];
            
            
            /*
             TTTTT fArray1 = [[NSMutableArray alloc] initWithObjects:@"L",@"A",@"B",@"C",@"D",@"E",@"N",@"F",@"G",@"H",@"M",@"I",@"J",@"K", nil];
                                   0    1    2    3    4    5    6    7    8    9   10   11   12   13
             */
            
            [aArray1 replaceObjectAtIndex:0 withObject:[NSNumber numberWithFloat:itemActive]];  // L
            [aArray1 replaceObjectAtIndex:1 withObject:[NSNumber numberWithFloat:itemActive]];  // A
            [aArray1 replaceObjectAtIndex:2 withObject:[NSNumber numberWithFloat:itemNotActive]]; // B
            [aArray1 replaceObjectAtIndex:3 withObject:[NSNumber numberWithFloat:itemNotActive]]; // C
            [aArray1 replaceObjectAtIndex:4 withObject:[NSNumber numberWithFloat:itemNotActive]]; // D
            [aArray1 replaceObjectAtIndex:5 withObject:[NSNumber numberWithFloat:itemNotActive]]; // E
            [aArray1 replaceObjectAtIndex:6 withObject:[NSNumber numberWithFloat:itemActive]];  // F
            [aArray1 replaceObjectAtIndex:7 withObject:[NSNumber numberWithFloat:itemActive]];  // G
            [aArray1 replaceObjectAtIndex:8 withObject:[NSNumber numberWithFloat:itemNotActive]]; //H
            [aArray1 replaceObjectAtIndex:9 withObject:[NSNumber numberWithFloat:itemActive]]; //M
            [aArray1 replaceObjectAtIndex:10 withObject:[NSNumber numberWithFloat:itemActive]]; // I
            [aArray1 replaceObjectAtIndex:11 withObject:[NSNumber numberWithFloat:itemNotActive]];  // J
            [aArray1 replaceObjectAtIndex:12 withObject:[NSNumber numberWithFloat:itemNotActive]];  // K
            [aArray1 replaceObjectAtIndex:13 withObject:[NSNumber numberWithFloat:itemNotActive]];  // P
            
            [pickerView reloadComponent:0];
           
            
            if ( [cur1 isEqual: @"B"] )
            {
                cur1 = @"G";
                [pickerView selectRow:7 inComponent:1 animated:YES];
                sel1 = 7;
                
            }
            
            
            if ( [cur1 isEqual: @"C"] || [cur1 isEqual: @"D"] || [cur1 isEqual: @"E"] || [cur1 isEqual: @"N"] || [cur1 isEqual: @"H"] )
            {
                cur1 = @"F";
                [pickerView selectRow:6 inComponent:1 animated:YES];
                sel1 = 6;
            }
            
            
            if ( [cur1 isEqual: @"J"] || [cur1 isEqual: @"K"])
            {
                cur1 = @"I";
                [pickerView selectRow:10 inComponent:1 animated:YES];
                sel1 = 10;
            }
              
            
        }
        
        
        if ( [cur2 isEqual:@"A"] || [cur2 isEqual:@"B"] || [cur2 isEqual:@"C"] || [cur2 isEqual:@"D"] || [cur2 isEqual:@"E"] || [cur2 isEqual:@"F"] || [cur2 isEqual:@"J"] || [cur2 isEqual:@"L"] || [cur2 isEqual:@"P"])
        {
            if ( [cur1 isEqual: @"G"] )
            {
                cur1 = @"B";
                [pickerView selectRow:2 inComponent:1 animated:YES];
                sel1 = 2;
                
                
            }else if ( [cur1 isEqual: @"F"] )
            {
                cur1 = @"D";
                [pickerView selectRow:4 inComponent:1 animated:YES];
                sel1 = 4;
                
                
            }
            
        }
        
        
        if ( [cur2 isEqual:@"I"] ){
           
            [aArray3 replaceObjectAtIndex:0 withObject:[NSNumber numberWithFloat:itemActive]];
            [aArray3 replaceObjectAtIndex:1 withObject:[NSNumber numberWithFloat:itemActive]];
            [aArray3 replaceObjectAtIndex:2 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [aArray3 replaceObjectAtIndex:3 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [aArray3 replaceObjectAtIndex:4 withObject:[NSNumber numberWithFloat:itemActive]];
            [aArray3 replaceObjectAtIndex:5 withObject:[NSNumber numberWithFloat:itemNotActive]];
            
            if ([cur3 isEqual:@"C"]  || [cur3 isEqual:@"D"] || [cur3 isEqual:@"F"]){
                cur3 = @"A";
                [pickerView selectRow:0 inComponent:2 animated:YES];
                sel3 = 0;
                
            }
            
            // do not allow  T = B,C,D,E,F,H,J,K,N P
        
            [aArray1 replaceObjectAtIndex:0 withObject:[NSNumber numberWithFloat:itemActive]];  // L
            [aArray1 replaceObjectAtIndex:1 withObject:[NSNumber numberWithFloat:itemActive]];  // A
            [aArray1 replaceObjectAtIndex:2 withObject:[NSNumber numberWithFloat:itemNotActive]]; // B
            [aArray1 replaceObjectAtIndex:3 withObject:[NSNumber numberWithFloat:itemNotActive]]; // C
            [aArray1 replaceObjectAtIndex:4 withObject:[NSNumber numberWithFloat:itemNotActive]]; // D
            [aArray1 replaceObjectAtIndex:5 withObject:[NSNumber numberWithFloat:itemNotActive]]; // E
            [aArray1 replaceObjectAtIndex:6 withObject:[NSNumber numberWithFloat:itemNotActive]];  // F
            [aArray1 replaceObjectAtIndex:7 withObject:[NSNumber numberWithFloat:itemNotActive]];  // G
            [aArray1 replaceObjectAtIndex:8 withObject:[NSNumber numberWithFloat:itemNotActive]]; //H
            [aArray1 replaceObjectAtIndex:9 withObject:[NSNumber numberWithFloat:itemActive]]; //M
            [aArray1 replaceObjectAtIndex:10 withObject:[NSNumber numberWithFloat:itemActive]]; // I
            [aArray1 replaceObjectAtIndex:11 withObject:[NSNumber numberWithFloat:itemNotActive]];  // J
            [aArray1 replaceObjectAtIndex:12 withObject:[NSNumber numberWithFloat:itemNotActive]];  // K
            [aArray1 replaceObjectAtIndex:13 withObject:[NSNumber numberWithFloat:itemNotActive]];  // P
            
 
            [pickerView reloadComponent:0];
            
            
            //   If T = B,C,D,E,F,G,H,J,K,N,OR P,     when P changed to I, change T to I
            
            
            if ( [cur1 isEqual: @"B"] || [cur1 isEqual: @"C"] || [cur1 isEqual: @"D"]  || [cur1 isEqual: @"E"] || [cur1 isEqual: @"N"] || [cur1 isEqual: @"F"] || [cur1 isEqual: @"G" ] || [cur1 isEqual: @"H" ] || [cur1 isEqual: @"J"]  || [cur1 isEqual: @"K"] || [cur1 isEqual: @"P"] )
            {
                cur1 = @"I";
                [pickerView selectRow:10 inComponent:1 animated:YES];
                sel1 = 10;
                
            }
            
            
        }
        
        
        /*
         If P-E is active, do not allow T=B,C,D,E,F,G,H,N
         If P-F is active, do not allow T=B,C,D,E,F,G,H,N
         If P-G is active, do not allow T=B,C,D,E,F,G,H,N
         If T=B when P changed to E, change T to K
         If T=B when P changed to F, change T to K
         If T=B when P changed to G, change T to K
         If T=C,D,E,F,G,H,N when P changed to E, change T to A
         If T=C,D,E,F,G,H,N when P changed to F, change T to A
         If T=C,D,E,F,G,H,N when P changed to G, change T to A
         
         */
        
        
        if ( [cur2 isEqual:@"E"] || [cur2 isEqual:@"F"] || [cur2 isEqual:@"G"] ){
            // do not allow  T = B,C,D,E,F,H,J,K,N
            
            /*
             TTTTT fArray1 = [[NSMutableArray alloc] 
               initWithObjects:@"L",@"A",@"B",@"C",@"D",@"E",@"N",@"F",@"G",@"H",@"M",@"I",@"J",@"K",@"P", nil];
                                 0    1    2    3    4    5    6    7    8    9   10   11   12   13   14
             */
            
            
            [aArray1 replaceObjectAtIndex:0 withObject:[NSNumber numberWithFloat:itemActive]];  // L
            [aArray1 replaceObjectAtIndex:1 withObject:[NSNumber numberWithFloat:itemActive]];  // A
            [aArray1 replaceObjectAtIndex:2 withObject:[NSNumber numberWithFloat:itemNotActive]]; // B
            [aArray1 replaceObjectAtIndex:3 withObject:[NSNumber numberWithFloat:itemNotActive]]; // C
            [aArray1 replaceObjectAtIndex:4 withObject:[NSNumber numberWithFloat:itemNotActive]]; // D
            [aArray1 replaceObjectAtIndex:5 withObject:[NSNumber numberWithFloat:itemNotActive]]; // E
            [aArray1 replaceObjectAtIndex:6 withObject:[NSNumber numberWithFloat:itemNotActive]];  // F
            [aArray1 replaceObjectAtIndex:7 withObject:[NSNumber numberWithFloat:itemNotActive]];  // G
            [aArray1 replaceObjectAtIndex:8 withObject:[NSNumber numberWithFloat:itemNotActive]]; //H
            [aArray1 replaceObjectAtIndex:9 withObject:[NSNumber numberWithFloat:itemActive]]; //M
            [aArray1 replaceObjectAtIndex:10 withObject:[NSNumber numberWithFloat:itemActive]]; // I
            [aArray1 replaceObjectAtIndex:11 withObject:[NSNumber numberWithFloat:itemActive]];  // J
            [aArray1 replaceObjectAtIndex:12 withObject:[NSNumber numberWithFloat:itemActive]];  // K
            [aArray1 replaceObjectAtIndex:13 withObject:[NSNumber numberWithFloat:itemNotActive]];  // P
            
            [pickerView reloadComponent:0];
            
        
            if ( [cur1 isEqual: @"B"]  )
            {
                cur1 = @"K";
                [pickerView selectRow:12 inComponent:1 animated:YES];
                sel1 = 12;
            }
            
            
            if ( [cur1 isEqual: @"C"] || [cur1 isEqual: @"D"]  || [cur1 isEqual: @"E"] || [cur1 isEqual: @"F"] || [cur1 isEqual: @"G"] || [cur1 isEqual: @"H"] || [cur1 isEqual: @"N"]  )
            {
                cur1 = @"A";
                [pickerView selectRow:1 inComponent:1 animated:YES];
                sel1 = 1;
            }
            
            
        }
        
        //     BL California      or   Atoll
        if ( [cur2 isEqual: @"J"] || [cur2 isEqual: @"L"] )
        {
           
            [aArray3 replaceObjectAtIndex:0 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [aArray3 replaceObjectAtIndex:1 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [aArray3 replaceObjectAtIndex:2 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [aArray3 replaceObjectAtIndex:3 withObject:[NSNumber numberWithFloat:itemActive]];
            [aArray3 replaceObjectAtIndex:4 withObject:[NSNumber numberWithFloat:itemActive]];
            [aArray3 replaceObjectAtIndex:5 withObject:[NSNumber numberWithFloat:itemNotActive]];
            
            [pickerView reloadComponent:2];
            
            if ([cur3 isEqual:@"A"] || [cur3 isEqual:@"B"] || [cur3 isEqual:@"C"]  || [cur3 isEqual:@"F"]   ){
                cur3 = @"D";
                [pickerView selectRow:3 inComponent:2 animated:YES];
                sel3 = 3;
                
            }
            
            // do not allow  T =F,G P
            [aArray1 replaceObjectAtIndex:0 withObject:[NSNumber numberWithFloat:itemActive]];
            [aArray1 replaceObjectAtIndex:1 withObject:[NSNumber numberWithFloat:itemActive]];
            [aArray1 replaceObjectAtIndex:2 withObject:[NSNumber numberWithFloat:itemActive]];
            [aArray1 replaceObjectAtIndex:3 withObject:[NSNumber numberWithFloat:itemActive]];
            [aArray1 replaceObjectAtIndex:4 withObject:[NSNumber numberWithFloat:itemActive]];
            [aArray1 replaceObjectAtIndex:5 withObject:[NSNumber numberWithFloat:itemActive]];
            [aArray1 replaceObjectAtIndex:6 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [aArray1 replaceObjectAtIndex:7 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [aArray1 replaceObjectAtIndex:8 withObject:[NSNumber numberWithFloat:itemActive]];
            [aArray1 replaceObjectAtIndex:9 withObject:[NSNumber numberWithFloat:itemActive]];
            [aArray1 replaceObjectAtIndex:10 withObject:[NSNumber numberWithFloat:itemActive]];
            [aArray1 replaceObjectAtIndex:11 withObject:[NSNumber numberWithFloat:itemActive]];
            [aArray1 replaceObjectAtIndex:12 withObject:[NSNumber numberWithFloat:itemActive]];
            [aArray1 replaceObjectAtIndex:13 withObject:[NSNumber numberWithFloat:itemNotActive]];  //special case will be addressed in a following condition for ATOLL
            
            /*if ( [cur1 isEqual: @"B"] || [cur1 isEqual: @"C" ] || [cur1 isEqual: @"D"] || [cur1 isEqual: @"E"] || [cur1 isEqual: @"H"] )
            {
                
                
                [aArray4 replaceObjectAtIndex:0 withObject:[NSNumber numberWithFloat:itemActive]];
                [aArray4 replaceObjectAtIndex:1 withObject:[NSNumber numberWithFloat:itemNotActive]];
                [aArray4 replaceObjectAtIndex:2 withObject:[NSNumber numberWithFloat:itemNotActive]];
                [aArray4 replaceObjectAtIndex:3 withObject:[NSNumber numberWithFloat:itemNotActive]];
                [aArray4 replaceObjectAtIndex:4 withObject:[NSNumber numberWithFloat:itemNotActive]];
                [aArray4 replaceObjectAtIndex:5 withObject:[NSNumber numberWithFloat:itemNotActive]];

                
                if ( [cur4 isEqual: @"C"]  || [cur4 isEqual: @"D"] || [cur4 isEqual: @"E"] || [cur4 isEqual: @"F"]){
                    cur4 = @"A";
                    [pickerView selectRow:0 inComponent:3 animated:YES];
                    sel4 = 0;
                    
                }
            }*/
            
            
            [pickerView reloadComponent:0];
            [pickerView reloadComponent:2];
            [pickerView reloadComponent:3];
        }
        
        
        
        if ( [cur2 isEqual:@"A"] || [cur2 isEqual:@"B"] || [cur2 isEqual:@"C"] || [cur2 isEqual:@"D"] || [cur2 isEqual:@"P"])
        {
            
            // do not allow  T =F,G
            [aArray1 replaceObjectAtIndex:0 withObject:[NSNumber numberWithFloat:itemActive]];
            [aArray1 replaceObjectAtIndex:1 withObject:[NSNumber numberWithFloat:itemActive]];
            [aArray1 replaceObjectAtIndex:2 withObject:[NSNumber numberWithFloat:itemActive]];
            [aArray1 replaceObjectAtIndex:3 withObject:[NSNumber numberWithFloat:itemActive]];
            [aArray1 replaceObjectAtIndex:4 withObject:[NSNumber numberWithFloat:itemActive]];
            [aArray1 replaceObjectAtIndex:5 withObject:[NSNumber numberWithFloat:itemActive]];
            [aArray1 replaceObjectAtIndex:6 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [aArray1 replaceObjectAtIndex:7 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [aArray1 replaceObjectAtIndex:8 withObject:[NSNumber numberWithFloat:itemActive]];
            [aArray1 replaceObjectAtIndex:9 withObject:[NSNumber numberWithFloat:itemActive]];
            [aArray1 replaceObjectAtIndex:10 withObject:[NSNumber numberWithFloat:itemActive]];
            [aArray1 replaceObjectAtIndex:11 withObject:[NSNumber numberWithFloat:itemActive]];
            [aArray1 replaceObjectAtIndex:12 withObject:[NSNumber numberWithFloat:itemActive]];
            [aArray1 replaceObjectAtIndex:13 withObject:[NSNumber numberWithFloat:itemActive]];
            
            [pickerView reloadComponent:0];

        }
        
        // added by Alex, 2020/03/23, for Bar Button
        if ([cur2 isEqual:@"M"] || [cur2 isEqual:@"N"] || [cur2 isEqual:@"O"]){
            [aArray1 replaceObjectAtIndex:0 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [aArray1 replaceObjectAtIndex:1 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [aArray1 replaceObjectAtIndex:2 withObject:[NSNumber numberWithFloat:itemActive]];
            [aArray1 replaceObjectAtIndex:3 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [aArray1 replaceObjectAtIndex:4 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [aArray1 replaceObjectAtIndex:5 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [aArray1 replaceObjectAtIndex:6 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [aArray1 replaceObjectAtIndex:7 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [aArray1 replaceObjectAtIndex:8 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [aArray1 replaceObjectAtIndex:9 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [aArray1 replaceObjectAtIndex:10 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [aArray1 replaceObjectAtIndex:11 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [aArray1 replaceObjectAtIndex:12 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [aArray1 replaceObjectAtIndex:13 withObject:[NSNumber numberWithFloat:itemNotActive]];
            
            [pickerView reloadComponent:0];
            
            // If cur1 is not Julius Surround then, just force it to scroll to Julius automatically
            if (![cur1 isEqualToString:@"B"]){
                cur1 = @"B";
                
                [pickerView selectRow:2 inComponent:1 animated:YES];
                sel1 = 2;
            }
        }
        
        // added by Alex, 2020/03/23, for Bar Button
        if ([cur2 isEqual:@"M"] || [cur2 isEqual:@"N"] || [cur2 isEqual:@"O"]){
            [aArray1 replaceObjectAtIndex:0 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [aArray1 replaceObjectAtIndex:1 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [aArray1 replaceObjectAtIndex:2 withObject:[NSNumber numberWithFloat:itemActive]];
            [aArray1 replaceObjectAtIndex:3 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [aArray1 replaceObjectAtIndex:4 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [aArray1 replaceObjectAtIndex:5 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [aArray1 replaceObjectAtIndex:6 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [aArray1 replaceObjectAtIndex:7 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [aArray1 replaceObjectAtIndex:8 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [aArray1 replaceObjectAtIndex:9 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [aArray1 replaceObjectAtIndex:10 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [aArray1 replaceObjectAtIndex:11 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [aArray1 replaceObjectAtIndex:12 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [aArray1 replaceObjectAtIndex:13 withObject:[NSNumber numberWithFloat:itemNotActive]];
            
            [pickerView reloadComponent:0];
            
            // If cur1 is not Julius Surround then, just force it to scroll to Julius automatically
            if (![cur1 isEqualToString:@"B"]){
                cur1 = @"B";
                
                [pickerView selectRow:2 inComponent:1 animated:YES];
                sel1 = 2;
            }
        }
        
        // If Sherman Touchless, default Illumination is White
        // Added by Alex, 2021/02/24
        if ( [cur2 isEqual: @"P"] )
        {
           
            [aArray3 replaceObjectAtIndex:0 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [aArray3 replaceObjectAtIndex:1 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [aArray3 replaceObjectAtIndex:2 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [aArray3 replaceObjectAtIndex:3 withObject:[NSNumber numberWithFloat:itemActive]];
            [aArray3 replaceObjectAtIndex:4 withObject:[NSNumber numberWithFloat:itemActive]];
            [aArray3 replaceObjectAtIndex:5 withObject:[NSNumber numberWithFloat:itemNotActive]];
            
            [pickerView reloadComponent:2];
            
            if (![cur3 isEqual:@"D"] && ![cur3 isEqual:@"E"]){
                cur3 = @"D";
                [pickerView selectRow:3 inComponent:2 animated:YES];
                sel3 = 3;
                
            }
        }
        
        // added by Alex, 2020/04/06
        if ([cur2 isEqual:@"J"] && ([cur1 isEqual:@"B"] || [cur1 isEqual:@"C"] || [cur1 isEqual:@"D"] || [cur1 isEqual:@"E"] || [cur1 isEqual:@"H"])){
            [aArray4 replaceObjectAtIndex:0 withObject:[NSNumber numberWithFloat:itemActive]];
            [aArray4 replaceObjectAtIndex:1 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [aArray4 replaceObjectAtIndex:2 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [aArray4 replaceObjectAtIndex:3 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [aArray4 replaceObjectAtIndex:4 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [aArray4 replaceObjectAtIndex:4 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [aArray4 replaceObjectAtIndex:5 withObject:[NSNumber numberWithFloat:itemNotActive]];
            
            [pickerView reloadComponent:3];
            
            // If cur4 is not #4 SS then, just force it to scroll to #4 SS
            if (![cur4 isEqualToString:@"A"]){
                cur4 = @"A";
                [pickerView selectRow:0 inComponent:3 animated:YES];
                sel4 = 0;
            }
        }
        
        // allow fishtail tactile only for the ATOLL button
        //  2018-04-06 Allow Fishtail tactile for the other supported buttons
        /*
         BD With Symbol   G
         BL Black        E
         BL California    J
         BL Symbol       F
         BP Classic      D
         BS Classic      A
         BS California   C
         BS Moon         B
         
         
         
         ATOLL          L   ( This already supports Fishtail  the others above need to support California Fishtail )
         
         

         */
        if ([cur2 isEqual: @"G"]  ||  [cur2 isEqual: @"E"]  || [cur2 isEqual: @"J"]  || [cur2 isEqual: @"F"]  || [cur2 isEqual: @"D"]  || [cur2 isEqual: @"A"]  || [cur2 isEqual: @"C"]  ||   [cur2 isEqual: @"B"]  || [cur2 isEqual: @"L"]  || [cur2 isEqual: @"P"] )
        {

            [aArray1 replaceObjectAtIndex:13 withObject:[NSNumber numberWithFloat:itemActive]];
            [pickerView reloadComponent:0];
            
        }
        else
        {

            [aArray1 replaceObjectAtIndex:13 withObject:[NSNumber numberWithFloat:itemNotActive]];
            
            if ( [cur1 isEqual: @"P"]  )
            {
                cur1 = @"B";
                [pickerView selectRow:2 inComponent:1 animated:YES];
                    
            }

            [pickerView reloadComponent:0];
        }
        
        
        
        
        /*
         MASTER:
         PPPPP fArray2 = [[NSMutableArray alloc] initWithObjects:@"E",@"F",@"J",@"G",@"A",@"B",@"C",@"D",@"H",@"K", @"L", nil];
                                                                   0    1    2    3    4    5    6    7    8    9   10
         
         */
        
        
        /*  if( cur2 == @"J" ){
         
         aArray3[0] = [NSNumber numberWithFloat:itemActive];
         aArray3[1] = [NSNumber numberWithFloat:itemActive];
         aArray3[2] = [NSNumber numberWithFloat:itemActive];
         aArray3[3] = [NSNumber numberWithFloat:itemActive];
         aArray3[4] = [NSNumber numberWithFloat:itemActive];
         aArray3[5] = [NSNumber numberWithFloat:itemActive];
         
         
         aArray4[0] = [NSNumber numberWithFloat:itemActive];
         aArray4[1] = [NSNumber numberWithFloat:itemActive];
         aArray4[2] = [NSNumber numberWithFloat:itemActive];
         aArray4[3] = [NSNumber numberWithFloat:itemActive];
         aArray4[4] = [NSNumber numberWithFloat:itemActive];
         aArray4[5] = [NSNumber numberWithFloat:itemActive];
         
         aArray1[0] = [NSNumber numberWithFloat:itemActive];
         aArray1[1] = [NSNumber numberWithFloat:itemActive];
         aArray1[2] = [NSNumber numberWithFloat:itemActive];
         aArray1[3] = [NSNumber numberWithFloat:itemActive];
         aArray1[4] = [NSNumber numberWithFloat:itemActive];
         aArray1[5] = [NSNumber numberWithFloat:itemActive];
         aArray1[6] = [NSNumber numberWithFloat:itemActive];
         aArray1[7] = [NSNumber numberWithFloat:itemActive];
         aArray1[8] = [NSNumber numberWithFloat:itemActive];
         aArray1[9] = [NSNumber numberWithFloat:itemActive];
         aArray1[10] = [NSNumber numberWithFloat:itemActive];
         aArray1[11] = [NSNumber numberWithFloat:itemActive];
         aArray1[12] = [NSNumber numberWithFloat:itemActive];
         aArray1[13] = [NSNumber numberWithFloat:itemActive];
         }*/
        
    }
    
    currentSellection = [NSString stringWithFormat: @"%@%@%@%@",cur1,cur2,cur3,cur4];
    
    arrayTheProduct = [arrayProducts mutableCopy];
    [arrayTheProduct filterUsingPredicate:[NSPredicate  predicateWithFormat:@"product == %@", currentSellection]];
    
    if(arrayTheProduct.count > 0 )
    {
        
        // load the photo and text from the current sellection;
        product= [[arrayTheProduct objectAtIndex:0] objectForKey:keyProduct];
        photo= [NSString stringWithFormat: @"%@.jpg", [[arrayTheProduct objectAtIndex:0] objectForKey:keyPhoto]];
        name= [[arrayTheProduct objectAtIndex:0] objectForKey:keyPhoto];
        desc= [[arrayTheProduct objectAtIndex:0] objectForKey:keyDesc];
        //msg= [[arrayTheProduct objectAtIndex:0] objectForKey:keyMsg];
        
        
        if(( [previousSellection isEqualToString:@"NotPossible"] && [name isEqualToString:@"NotPossible"] )
           || ( [previousSellection isEqualToString:@"NotRecommended"] && [name isEqualToString:@"NotRecommended"] ))
            
        {
            
            [imageSwitchIndicator startAnimating];
            
            [UIView animateWithDuration:1 animations:^{
                self.productImage.alpha = 0;
            } completion:^(BOOL finished) {
                //Set New image and display again
                [productImage setImage:[UIImage imageNamed:photo]];
                
                [UIView animateWithDuration:1.0 animations:^{
                    self.productImage.alpha = 1;
                }];
            }];
        }
        else {
            [productImage setImage:[UIImage imageNamed:photo]];
            // productImage.alpha = 1;
            
        }
        

        descLabel.text = desc;
        descLabel.numberOfLines = 5;
        
        previousSellection = name;
        
        psel1 = sel1;
        psel2 = sel2;
        psel3 = sel3;
        psel4 = sel4;
        
        [pickerView reloadComponent:0];
        [pickerView reloadComponent:1];
        [pickerView reloadComponent:2];
        [pickerView reloadComponent:3];
        
    }
    
    
    //  Apply the rules for the next Product update - the special case is when the
    //  the predefined configurations ( collections ) are selected.
    applyRules = true;
}


-(IBAction)checkImages{

    
    arrayTheProduct = [arrayProducts mutableCopy];
     
    for ( int i = 0; i < arrayTheProduct.count; i++ )
    {
        photo= [NSString stringWithFormat: @"%@.jpg", [[arrayTheProduct objectAtIndex:i] objectForKey:keyPhoto]];

        
        
        
       NSFileManager *fileManager = [NSFileManager defaultManager];
        //NSString *documentsDirectory = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
       // NSString *path = [documentsDirectory stringByAppendingPathComponent:@"NotPossible.jpg"];

        
        NSString* resourcePath =[[NSBundle mainBundle] resourcePath];
        NSString *path = [resourcePath stringByAppendingPathComponent:photo];
        
        if ([fileManager fileExistsAtPath: path] == NO){

             NSLog(@"MISSING %@\n",path);
        }

        
    }

}

                  
-(IBAction)sendEmail {
    
    MFMailComposeViewController *composer = [[MFMailComposeViewController alloc] init];
    
    [composer setMailComposeDelegate:self];
    
    if ([MFMailComposeViewController canSendMail]) {
        
        //[composer setToRecipients:[NSArray arrayWithObjects:@"info@madelevator.com", nil]];
        
        [composer setCcRecipients:[NSArray arrayWithObjects:@"info@madelevator.com", nil]];
        
        
        [composer setSubject:@"MAD Elevator - Pushbutton Selection"];
        
        NSString *TheMsg = [NSString stringWithFormat:@"\n\nPlease find attached selected pushbutton.\n\n%@\n\nPlease let your MAD Sales Rep know if you have any questions.\n\n\nThe MAD Elevator Team\n1-866-967-8500\ninfo@madelevator.com\n\n Sent from MAD Fixtures App",desc];
        
        
        [composer setMessageBody:TheMsg isHTML:NO];
        
        
        CGSize newSize = CGSizeMake(1024, 768);
        UIGraphicsBeginImageContext( newSize );
        [[UIImage imageNamed:photo] drawInRect:CGRectMake(0,0,newSize.width,newSize.height) blendMode:kCGBlendModeNormal alpha:1];
        // add the copyright
        
        [[UIImage imageNamed:@"copyright.png"] drawInRect:CGRectMake(624,668,400,100) blendMode:kCGBlendModeNormal alpha:1];
        
        UIImage *photoImage = UIGraphicsGetImageFromCurrentImageContext();
        
        UIGraphicsEndImageContext();
        
        
        NSData *photoData = UIImageJPEGRepresentation(photoImage, 1);
        [composer addAttachmentData:photoData mimeType:@"image/jpeg" fileName:@"PushButton.jpg"];
        
        
        
        [composer setModalTransitionStyle:UIModalTransitionStyleCrossDissolve];
        
        //[self presentModalViewController:composer animated:YES];
        [self presentViewController:composer animated:YES completion:nil];
        //[composer release];
        
    }
    
    //else
    
    //[composer release];
    
}

-(void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error {
    
    if (error) {
        
        UIAlertController * alert = [UIAlertController
                                     alertControllerWithTitle:@"Error Occured"
                                     message:[NSString stringWithFormat:@"error - %@", [error description]]
                                     preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction* dismissButton = [UIAlertAction
                                        actionWithTitle:@"dismiss"
                                        style:UIAlertActionStyleDefault
                                        handler:^(UIAlertAction * action) {
                                            //Handle your yes please button action here
                                            [alert dismissViewControllerAnimated:YES completion:nil];
                                        }];
        [alert addAction:dismissButton];
        [self presentViewController:alert animated:YES completion:nil];
        
        //[self dismissModalViewControllerAnimated:YES];
        [self dismissViewControllerAnimated:YES completion:nil];
        
    }
    
    else {
        
        //[self dismissModalViewControllerAnimated:YES];
        [self dismissViewControllerAnimated:YES completion:nil];
        
    }
    
}




-(IBAction)SetCollection:(UIButton *)sender{
    
    UIButton *button = sender;
    
    //  Apply the rules for the next Product update - the special case is when the
    //  the predefined configurations ( collections ) are selected.
    applyRules = false;
    
    if(!applyRules)
    {
        // re-set all rules
        [aArray3 replaceObjectAtIndex:0 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray3 replaceObjectAtIndex:1 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray3 replaceObjectAtIndex:2 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray3 replaceObjectAtIndex:3 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray3 replaceObjectAtIndex:4 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray3 replaceObjectAtIndex:5 withObject:[NSNumber numberWithFloat:itemActive]];
        
        
        [aArray4 replaceObjectAtIndex:0 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray4 replaceObjectAtIndex:1 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray4 replaceObjectAtIndex:2 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray4 replaceObjectAtIndex:3 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray4 replaceObjectAtIndex:4 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray4 replaceObjectAtIndex:5 withObject:[NSNumber numberWithFloat:itemActive]];
        
        
        [aArray1 replaceObjectAtIndex:0 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray1 replaceObjectAtIndex:1 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray1 replaceObjectAtIndex:2 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray1 replaceObjectAtIndex:3 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray1 replaceObjectAtIndex:4 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray1 replaceObjectAtIndex:5 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray1 replaceObjectAtIndex:6 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray1 replaceObjectAtIndex:7 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray1 replaceObjectAtIndex:8 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray1 replaceObjectAtIndex:9 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray1 replaceObjectAtIndex:10 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray1 replaceObjectAtIndex:11 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray1 replaceObjectAtIndex:12 withObject:[NSNumber numberWithFloat:itemActive]];
        [aArray1 replaceObjectAtIndex:13 withObject:[NSNumber numberWithFloat:itemActive]];
        
        
        [pickerView reloadComponent:0];
        [pickerView reloadComponent:2];
        [pickerView reloadComponent:3];
    }
    
    
    
    
    
    if ( button.tag == 1)
    {
        
        
        // BAR Button
        sel1 = 2;
        sel2 = 13;
        sel3 = 3;
        sel4 = 0;
        
    }
    else if ( button.tag == 2)
    {
        
        
        //Julius
        sel1 = 2;
        sel2 = 8;
        sel3 = 0;
        sel4 = 0;
        
        
    }
    else if ( button.tag == 3)
    {
        //Ceasar
        sel1 = 5;
        sel2 = 4;
        sel3 = 0;
        sel4 = 0;
        
        
    }
    else if ( button.tag == 4)
    {
        //Dune
        sel1 = 6;
        sel2 = 9;
        sel3 = 1;
        sel4 = 0;
        
        
    }
    else if ( button.tag == 5)
    {
        //Ritz
        sel1 = 8;
        sel2 = 5;
        sel3 = 3;
        sel4 = 0;
        
        
    }
    
    
    
    [pickerView selectRow:sel1 inComponent:1 animated:YES];
    [pickerView selectRow:sel2 inComponent:0 animated:YES];
    [pickerView selectRow:sel3 inComponent:2 animated:YES];
    [pickerView selectRow:sel4 inComponent:3 animated:YES];
    
    cur1 = [fArray1 objectAtIndex:sel1];
    cur2 = [fArray2 objectAtIndex:sel2];
    cur3 = [fArray3 objectAtIndex:sel3];
    cur4 = [fArray4 objectAtIndex:sel4];
    
    
    [pickerView reloadComponent:0];
    [pickerView reloadComponent:1];
    [pickerView reloadComponent:2];
    [pickerView reloadComponent:3];
    
    
    [self updateProduct];
    
    
}


-(void)loading {
    
    if (productImage.alpha < 1.0 )
    {
        [imageSwitchIndicator startAnimating];
    }
    else
    {
        
        [imageSwitchIndicator stopAnimating];
    }
}


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    
    viewControls.hidden = FALSE;
    imgUiBg.hidden = FALSE;
    
    self.containerView.backgroundColor = [UIColor blackColor];
    self.productImage.contentMode = UIViewContentModeScaleAspectFit;
    
    //  Apply the rules for the next Product update - the special case is when the
    //  the predefined configurations ( collections ) are selected.
    // the first collection is a predefined collection!
    applyRules = false;
    
    // PREVIOUS SELECTION NOT DEFINED YET
    
    psel1=-1;
    psel2=-1;
    psel3=-1;
    psel4=-1;
    
    
    // check device
    is_iPhone = TRUE;
    
    
    NSString *deviceType = [UIDevice currentDevice].model;
    
	
	if([deviceType isEqualToString:@"iPad"])
		is_iPhone = FALSE;
	
	if([deviceType isEqualToString:@"iPad Simulator"])
		is_iPhone = FALSE;
    
    
    [self.view addSubview:imageSwitchIndicator];
    
    // a timmer to display the activity indicator
    timer = [NSTimer scheduledTimerWithTimeInterval:(1.0/8.0)
             
                                             target:self
             
                                           selector:@selector(loading)
             
                                           userInfo:nil
             
                                            repeats:YES];
    
    /*  DEBUG MODE */


/*

 pArray1 = [[NSMutableArray alloc] initWithObjects:@"L - No Tactile",@"A - Square - Surface Mount",@"B - Julius Surround",@"C - Caesar Non Illuminated",@"D - Caesar White Illuminated",@"E - Caesar Blue Illuminated", @"N - Black Caesar - White Illum.",@"F - Dune - White Illumination",@"G - Dune - Cast Tactile",@"H - Pin Mount Tactile",@"M - Slimline - Flush Mount",@"I - Square - Flush Mount",@"J - Round - Flush Mount",@"K - Julius - Flush Mount",nil];
  
 pArray2 = [[NSMutableArray alloc] initWithObjects:@"E-BL Blank",@"F-BL w/t Symbol",@"J-BL California",@"G-BD w/t Symbol",@"A-BS Classic",@"B-BS Moon",@"C-BS California",@"D-BP Classic",@"H-Dune", @"K-Dune California", @"I-Colossus", nil];
    
 pArray3 = [[NSMutableArray alloc] initWithObjects:@"A - Red",@"B - Blue",@"C - Green",@"D - White",@"E - No Illumination",@"F - Amber/Blue", nil];
 
 pArray4 = [[NSMutableArray alloc] initWithObjects:@"A - #4 SS",@"B - #8 SS",@"C - #4 Brass",@"D - #8 Brass",@"E - Oil Rubbed-Medium",@"F - Oil Rubbed-Dark", nil];
*/
    pArray1 = [[NSMutableArray alloc] initWithObjects:@"No Tactile",@"Square - Surface Mount",@"Julius Surround",@"Caesar Non Illuminated",@"Caesar White Illuminated",@"Caesar Blue Illuminated",@"Dune - White Illumination",@"Dune - Cast Tactile",@"Pin Mount Tactile",@"Slimline - Flush Mount",@"Square - Flush Mount",@"Round - Flush Mount",@"Julius - Flush Mount",@"California Fishtail",nil];
    
    pArray2 = [[NSMutableArray alloc] initWithObjects:@"BL Blank",@"BL w/t Symbol",@"BL California",@"BD w/t Symbol",@"BS Classic",@"BS Moon",@"BS California",@"Sherman Touchless",@"BP Classic",@"Dune", @"Dune California", @"Colossus", @"Atoll", @"BAR Button Illuminated", @"BAR Button Etched/Engraved", @"BAR Button Blank", nil];
    
    pArray3 = [[NSMutableArray alloc] initWithObjects:@"Red",@"Blue",@"Green",@"White",@"No Illumination",@"Amber/Blue", nil];
    
    pArray4 = [[NSMutableArray alloc] initWithObjects:@"#4 SS",@"#8 SS",@"#4 Brass",@"#8 Brass",@"Oil Rubbed-Medium",@"Oil Rubbed-Dark", nil];
  
    
    
    fArray1 = [[NSMutableArray alloc] initWithObjects:@"L",@"A",@"B",@"C",@"D",@"E",@"F",@"G",@"H",@"M",@"I",@"J",@"K",@"P", nil];
    
    fArray2 = [[NSMutableArray alloc] initWithObjects:@"E",@"F",@"J",@"G",@"A",@"B",@"C",@"P",@"D",@"H",@"K",@"I",@"L", @"M",@"N",@"O",nil];
    
    fArray3 = [[NSMutableArray alloc] initWithObjects:@"A",@"B",@"C",@"D",@"E",@"F", nil];
    
    fArray4 = [[NSMutableArray alloc] initWithObjects:@"A",@"B",@"C",@"D",@"E",@"F", nil];
    
    
    
    // alpha values
    
    aArray1 = [[NSMutableArray alloc] initWithObjects:[NSNumber numberWithFloat:itemActive],[NSNumber numberWithFloat:itemActive],[NSNumber numberWithFloat:itemActive],[NSNumber numberWithFloat:itemActive],[NSNumber numberWithFloat:itemActive],[NSNumber numberWithFloat:itemActive],[NSNumber numberWithFloat:itemActive],[NSNumber numberWithFloat:itemActive],[NSNumber numberWithFloat:itemActive],[NSNumber numberWithFloat:itemActive],[NSNumber numberWithFloat:itemActive],[NSNumber numberWithFloat:itemActive],[NSNumber numberWithFloat:itemActive],[NSNumber numberWithFloat:itemActive], nil];
    
    aArray2 = [[NSMutableArray alloc] initWithObjects:[NSNumber numberWithFloat:itemActive],[NSNumber numberWithFloat:itemActive],[NSNumber numberWithFloat:itemActive],[NSNumber numberWithFloat:itemActive],[NSNumber numberWithFloat:itemActive],[NSNumber numberWithFloat:itemActive],[NSNumber numberWithFloat:itemActive],[NSNumber numberWithFloat:itemActive],[NSNumber numberWithFloat:itemActive],[NSNumber numberWithFloat:itemActive],[NSNumber numberWithFloat:itemActive],[NSNumber numberWithFloat:itemActive],[NSNumber numberWithFloat:itemActive],[NSNumber numberWithFloat:itemActive],[NSNumber numberWithFloat:itemActive],[NSNumber numberWithFloat:itemActive],[NSNumber numberWithFloat:itemActive], nil];
    
    aArray3 = [[NSMutableArray alloc] initWithObjects:[NSNumber numberWithFloat:itemActive],[NSNumber numberWithFloat:itemActive],[NSNumber numberWithFloat:itemActive],[NSNumber numberWithFloat:itemActive],[NSNumber numberWithFloat:itemActive],[NSNumber numberWithFloat:itemActive], nil];
    
    aArray4 = [[NSMutableArray alloc] initWithObjects:[NSNumber numberWithFloat:itemActive],[NSNumber numberWithFloat:itemActive],[NSNumber numberWithFloat:itemActive],[NSNumber numberWithFloat:itemActive],[NSNumber numberWithFloat:itemActive],[NSNumber numberWithFloat:itemActive], nil];
    
    
    
    
    cur1 = [fArray1 objectAtIndex:0];
    cur2 = [fArray2 objectAtIndex:0];
    cur3 = [fArray3 objectAtIndex:0];
    cur4 = [fArray4 objectAtIndex:0];
    
    
    // load the list of buttons
    
    if ( ! arrayProducts )
	{
		
		arrayProducts = [[NSMutableArray alloc] init];
		
		for (NSDictionary *productDict   in [self theListOfProducts])
		{
			product = [productDict valueForKey:keyProduct];
			photo = [productDict valueForKey:keyPhoto];
            desc = [productDict valueForKey:keyDesc];
            
			[arrayProducts addObject:[NSDictionary dictionaryWithObjectsAndKeys:
                                      product, keyProduct,
                                      photo, keyPhoto,
                                      desc, keyDesc,
                                      nil]];
		}
	}
	
    
	
    
    // set the default collection:
    //Ceasar  - EAAA  (which is also the preset for Caesar collection)
    [pickerView selectRow:5 inComponent:1 animated:YES];
    [pickerView selectRow:4 inComponent:0 animated:YES];
    [pickerView selectRow:0 inComponent:2 animated:YES];
    [pickerView selectRow:0 inComponent:3 animated:YES];
    
    cur1 = [fArray1 objectAtIndex:5];
    cur2 = [fArray2 objectAtIndex:4];
    cur3 = [fArray3 objectAtIndex:0];
    cur4 = [fArray4 objectAtIndex:0];
    
    
    sel1 = 5;
    sel2 = 4;
    sel3 = 0;
    sel4 = 0;
    
    applyRules = false;
    
    [self updateProduct];
    
    
    [super viewDidLoad];
    
    UITapGestureRecognizer *doubleTapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(scrollViewDoubleTapped:)];
    doubleTapRecognizer.numberOfTapsRequired = 2;
    doubleTapRecognizer.numberOfTouchesRequired = 1;
    [self.scrollView addGestureRecognizer:doubleTapRecognizer];
    
    UITapGestureRecognizer *twoFingerTapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(scrollViewTwoFingerTapped:)];
    twoFingerTapRecognizer.numberOfTapsRequired = 1;
    twoFingerTapRecognizer.numberOfTouchesRequired = 2;
    [self.scrollView addGestureRecognizer:twoFingerTapRecognizer];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    // Set up the minimum & maximum zoom scales
    self.scrollView.minimumZoomScale = 1.0f;//minScale;
    self.scrollView.maximumZoomScale = 4.0f;
    
    pickerView.alpha = 1;
    imgPickerViewBg.hidden = NO;
    
    viewControls.hidden = FALSE;
    imgUiBg.hidden = FALSE;
    
    if (is_iPhone) {
        self.topConstraint.constant = 40;
        self.bottomConstraint.constant = 40 + MIN(self.view.frame.size.width, self.view.frame.size.height) / 128 * 39 + 6 + (MIN(self.view.frame.size.width, self.view.frame.size.height) - 6) / 7;
    } else {
        self.topConstraint.constant = 50;
        self.bottomConstraint.constant = MAX(self.view.frame.size.height, self.view.frame.size.width) - btnColl1.frame.origin.y + 10;
    }
    
    [self.view layoutIfNeeded];
    
    [self scrollviewZoomToFullSize];
    
    [self.view bringSubviewToFront:scrollView];
    
    [self adjustForOrientation];
}


- (UIView *)pickerView:(UIPickerView *)pickerView
            viewForRow:(NSInteger)row
          forComponent:(NSInteger)component
           reusingView:(UIView *)view {

    UILabel *pickerLabel = (UILabel *)view;
    
    if ( is_iPhone ) {
        if (pickerLabel == nil) {
            //label size
            CGRect frame = CGRectMake(0.0, 0.0, 70, 30);
            
            pickerLabel = [[UILabel alloc] initWithFrame:frame];
            
            [pickerLabel setTextAlignment: NSTextAlignmentCenter];
            [pickerLabel setNumberOfLines:1];
            [pickerLabel setLineBreakMode: NSLineBreakByTruncatingTail];
            
            [pickerLabel setBackgroundColor:[UIColor clearColor]];
            
            
            //here you can play with fonts
            [pickerLabel setFont:[UIFont systemFontOfSize:10.0]];
            
        }
        //picker view array is the datasource
        [pickerLabel setFont:[UIFont systemFontOfSize:10.0]];
        
        if (component == 3 ) {
            [pickerLabel setText:[pArray4 objectAtIndex:row]];
        }else if (component == 2 ) {
            [pickerLabel setText:[pArray3 objectAtIndex:row]];
        }else if (component == 1 ) {
            [pickerLabel setText:[pArray1 objectAtIndex:row]];
            
        }else{
            [pickerLabel setText:[pArray2 objectAtIndex:row]];
        }
        
       [pickerLabel setTextColor:([UIColor blackColor]) ];
        
    } else {
        
        if (pickerLabel == nil) {
            //label size
            CGRect frame = CGRectMake(0.0, 0.0, 150, 30);
            
            pickerLabel = [[UILabel alloc] initWithFrame:frame];
            
            [pickerLabel setTextAlignment:NSTextAlignmentLeft];
            
            [pickerLabel setBackgroundColor:[UIColor clearColor]];
            
            //here you can play with fonts
            [pickerLabel setFont:[UIFont fontWithName:@"Arial-BoldMT" size:12.0]];
        }
        
        //picker view array is the datasource
         [pickerLabel setFont:[UIFont fontWithName:@"Arial-BoldMT" size:16.0]];
        if (component == 3 ) {
            [pickerLabel setText:[pArray4 objectAtIndex:row]];
        }else if (component == 2 ) {
            [pickerLabel setText:[pArray3 objectAtIndex:row]];
        }else if (component == 1 ) {
            [pickerLabel setText:[pArray1 objectAtIndex:row]];
        }else{
            [pickerLabel setText:[pArray2 objectAtIndex:row]];
        }
        
        [pickerLabel setTextColor:([UIColor blackColor]) ];
    }
    
    
    if (component == 3 ) {
        pickerLabel.alpha =[[aArray4 objectAtIndex:row] floatValue];
    }else if (component == 2 ) {
        pickerLabel.alpha =[[aArray3 objectAtIndex:row] floatValue];
    }else if (component == 1 ) {
        pickerLabel.alpha =[[aArray1 objectAtIndex:row] floatValue];
    }else{
        pickerLabel.alpha =[[aArray2 objectAtIndex:row] floatValue];
    }
    
    return pickerLabel;
}

- (void)adjustForOrientation{
    // set rotation factor
    UIInterfaceOrientation iOrientation = [UIApplication sharedApplication].windows.firstObject.windowScene.interfaceOrientation;
    UIDeviceOrientation dOrientation = [UIDevice currentDevice].orientation;
    
    bool landscape;
    
    if (dOrientation == UIDeviceOrientationUnknown || dOrientation == UIDeviceOrientationFaceUp || dOrientation == UIDeviceOrientationFaceDown) {
        // If the device is laying down, use the UIInterfaceOrientation based on the status bar.
        landscape = UIInterfaceOrientationIsLandscape(iOrientation);
    } else {
        // If the device is not laying down, use UIDeviceOrientation.
        landscape = UIDeviceOrientationIsLandscape(dOrientation);
    }
    
    //UIInterfaceOrientation interfaceOrientation = (UIInterfaceOrientation)[[UIDevice currentDevice] orientation];
    
    if (!landscape) {
        pickerView.alpha = 1;
        imgPickerViewBg.hidden = NO;
        
        viewControls.hidden = FALSE;
        imgUiBg.hidden = FALSE;

        if (is_iPhone) {
            self.topConstraint.constant = 40;
            self.bottomConstraint.constant = 40 + MIN(self.view.frame.size.width, self.view.frame.size.height) / 128 * 39 + 6 + (MIN(self.view.frame.size.width, self.view.frame.size.height) - 6) / 7;
        } else {
            self.topConstraint.constant = 50;
            self.bottomConstraint.constant = MAX(self.view.frame.size.height, self.view.frame.size.width) - btnColl1.frame.origin.y + 10;
        }
        
        [self.view layoutIfNeeded];
        
        [self scrollviewZoomToFullSize];
        
        [self.view bringSubviewToFront:scrollView];
        
    } else {
        
        pickerView.alpha = 0;
        imgPickerViewBg.hidden = YES;
        
        
        viewControls.hidden = TRUE;

        imgUiBg.hidden = TRUE;

        self.topConstraint.constant = 0;
        self.bottomConstraint.constant = 0;
        
        [self.view layoutIfNeeded];
        
        [self scrollviewZoomToFullSize];
    }
}

#pragma mark ---- Orientation ----
- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskAll;
}

- (BOOL)shouldAutorotate {
    
    return YES;
}

- (void)viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator {
    
    [coordinator animateAlongsideTransition:^(id<UIViewControllerTransitionCoordinatorContext> context)
     {
         //UIInterfaceOrientation interfaceOrientation = (UIInterfaceOrientation)[[UIDevice currentDevice] orientation];
         
         //bool landscape = UIInterfaceOrientationIsLandscape(interfaceOrientation);
         [self adjustForOrientation];
         [self.view layoutIfNeeded];
         [self scrollviewZoomToFullSize];
     } completion:^(id<UIViewControllerTransitionCoordinatorContext> context)
     {
         
     }];
    
    [super viewWillTransitionToSize:size withTransitionCoordinator:coordinator];
}

#pragma mark ---- UIPickerViewDataSource delegate methods ----

// returns the number of columns to display.
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    
	return 4;
}

- (CGFloat)pickerView:(UIPickerView *)_pickerView rowHeightForComponent:(NSInteger)component {
    return _pickerView.bounds.size.height / 234 * 30;
}

// returns the number of rows
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
	
    
    if (component == 3 ) {
        return [pArray4 count];
    }else if (component == 2 ) {
        return [pArray3 count];
    }else if (component == 1 ) {
        return [pArray1 count];
    }else{
        return [pArray2 count];
    }
    
    
    //return [array1 count];
}


#pragma mark ---- UIPickerViewDelegate delegate methods ----

// returns the title of each row
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
	
    
    if (component == 3 ) {
        return [pArray4  objectAtIndex:row];
    }else if (component == 2 ) {
        return [pArray3  objectAtIndex:row];
    }else if (component == 1 ) {
        return [pArray1  objectAtIndex:row];
    }else{
        return [pArray2  objectAtIndex:row];
    }
    
}

// gets called when the user settles on a row
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
	
    if (component == 3 ) {
        sel4 = row;
        cur4 = [fArray4 objectAtIndex:row];
    }else if (component == 2 ) {
        sel3 = row;
        cur3 = [fArray3 objectAtIndex:row];
    }else if (component == 1 ) {
        sel1 = row;
        cur1 = [fArray1 objectAtIndex:row];
    }else{
        sel2 = row;
        cur2 = [fArray2 objectAtIndex:row];
    }
    
    
    [self updateProduct];
}

#pragma mark ---- scrollView delegate methods ----

- (void)scrollviewZoomToFullSize
{
//    CGSize scrollViewSize = self.scrollView.bounds.size;
//    
//    CGFloat w = scrollViewSize.width / self.scrollView.minimumZoomScale;
//    CGFloat h = scrollViewSize.height / self.scrollView.minimumZoomScale;
//    CGFloat x = 0;
//    CGFloat y = 0;
//    
//    CGRect rectToZoomTo = CGRectMake(x, y, w, h);
//    
//    [self.scrollView zoomToRect:rectToZoomTo animated:YES];
    [self.scrollView setZoomScale:1 animated:YES];
}

- (void)scrollViewDoubleTapped:(UITapGestureRecognizer*)recognizer {
    // Get the location within the image view where we tapped
    CGPoint pointInView = [recognizer locationInView:self.containerView];
    
    // Get a zoom scale that's zoomed in slightly, capped at the maximum zoom scale specified by the scroll view
    CGFloat newZoomScale = self.scrollView.zoomScale * 1.5f;
    newZoomScale = MIN(newZoomScale, self.scrollView.maximumZoomScale);
    
    // Figure out the rect we want to zoom to, then zoom to it
    CGSize scrollViewSize = self.scrollView.bounds.size;
    
    CGFloat w = scrollViewSize.width / newZoomScale;
    CGFloat h = scrollViewSize.height / newZoomScale;
    CGFloat x = pointInView.x - (w / 2.0f);
    CGFloat y = pointInView.y - (h / 2.0f);
    
    CGRect rectToZoomTo = CGRectMake(x, y, w, h);
    
    [self.scrollView zoomToRect:rectToZoomTo animated:YES];
}

- (void)scrollViewTwoFingerTapped:(UITapGestureRecognizer*)recognizer {
    // Zoom out slightly, capping at the minimum zoom scale specified by the scroll view
    CGFloat newZoomScale = self.scrollView.zoomScale / 1.5f;
    newZoomScale = MAX(newZoomScale, self.scrollView.minimumZoomScale);
    [self.scrollView setZoomScale:newZoomScale animated:YES];
}



-(UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView{
    return containerView;
}


- (BOOL)prefersStatusBarHidden
{
    return YES;
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    UIViewController *vc = [segue destinationViewController];
    vc.modalPresentationStyle = UIModalPresentationFullScreen;
}

@end

