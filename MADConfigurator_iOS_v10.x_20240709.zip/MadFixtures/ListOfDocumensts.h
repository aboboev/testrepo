//
//  ListOfDocumensts.h
//  MadFixtures
//
//  Created by Antonio Pena on 12-03-19.
//  Copyright (c) 2012 Kioaxis. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ListOfDocumensts : UITableViewController{
    
    NSMutableArray *docs;
    NSMutableArray *brochures;
    NSMutableArray *technical;

}


@end
