//
//  ViewController.m
//  MadFixtures
//
//  Created by Antonio Pena on 12-01-14.
//  Copyright (c) 2012 Kioaxis. All rights reserved.
//

#import "ViewController.h"

#define IDIOM    [UIDevice currentDevice].userInterfaceIdiom
#define IPAD     UIUserInterfaceIdiomPad

@implementation ViewController

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    /*for (UIButton *button in self.buttons) {
        UIImage *image = [button imageForState:UIControlStateNormal];
        [button setBackgroundImage:[image stretchableImageWithLeftCapWidth:image.size.width - 60 topCapHeight:image.size.height / 2] forState:UIControlStateNormal];
        [button setImage:nil forState:UIControlStateNormal];

        image = [button imageForState:UIControlStateHighlighted];
        [button setBackgroundImage:[image stretchableImageWithLeftCapWidth:image.size.width - 60 topCapHeight:image.size.height / 2] forState:UIControlStateHighlighted];
        [button setImage:nil forState:UIControlStateHighlighted];
    }*/
    
    //NSLog(@"%f-%f", [[UIScreen mainScreen] bounds].size.width, [[UIScreen mainScreen] bounds].size.height);
    
    float width = MIN([[UIScreen mainScreen] bounds].size.width, [[UIScreen mainScreen] bounds].size.height);
    if (IDIOM == IPAD){
        _firstButtonHeightConstraint.constant = width * 152 / 768;
    }else{
        _firstButtonHeightConstraint.constant = width * 198 / 768;
    }
    
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}




-(BOOL) shouldAutorotate { return NO; }

-(UIInterfaceOrientationMask) supportedInterfaceOrientations { return UIInterfaceOrientationMaskPortrait; }

- (BOOL)prefersStatusBarHidden
{
    return YES;
}

- (IBAction)openHelp:(id)sender {
    self.helpView.alpha = 0;
    self.helpView.hidden = NO;
    
    [UIView animateWithDuration:0.2 animations:^{
        self.helpView.alpha = 1;
    }];
}

- (IBAction)closeHelp:(id)sender {
    [UIView animateWithDuration:0.2 animations:^{
        self.helpView.alpha = 0;
    } completion:^(BOOL finished) {
        self.helpView.hidden = YES;
    }];
}

- (IBAction)goCabConfig:(id)sender {
    UIViewController * vc = [[UIStoryboard storyboardWithName:@"Configurator" bundle:nil] instantiateInitialViewController];
    vc.modalPresentationStyle = UIModalPresentationFullScreen;
    [self presentViewController:vc animated:YES completion:nil];
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    ViewController *vc = [segue destinationViewController];
    vc.modalPresentationStyle = UIModalPresentationFullScreen;
}

@end
