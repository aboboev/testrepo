//
//  HallStation.h
//  MadFixtures
//
//  Created by Antonio Pena on 2012-12-30.
//  Copyright (c) 2012 Kioaxis. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HallStation : NSObject{

    NSString *fGroup;
    
    NSInteger fType;
    NSInteger fStyle;
    NSInteger fFinish;
    NSInteger fWidth;
    NSInteger fHeight;
    NSInteger fFireService;
    NSInteger fAppendix;
    
    
    NSString *imgName;
    NSString *imgNameZoom;
    
    NSString *imgDescription;

    
    NSMutableArray *options;
    NSMutableArray *finishoptions;
    
    
    NSMutableArray *dType;
    NSMutableArray *dStyle;
    NSMutableArray *dFinish;
    NSMutableArray *dWidth;
    NSMutableArray *dHeight;
    NSMutableArray *dFireService;
    NSMutableArray *dAppendix;
}

-(id) initGroup:(NSString *)fgroup type:(NSInteger)ftype style:(NSInteger)fstyle finish:(NSInteger)ffinish width:(NSInteger)fwidth height:(NSInteger)fheight fireservice:(NSInteger)ffireservice appendinx:(NSInteger)fappendinx;

-(void)updateName;

@property (nonatomic, copy) NSString *fGroup;
@property (assign, nonatomic) NSInteger fType;
@property (assign, nonatomic) NSInteger fStyle;
@property (assign, nonatomic) NSInteger fFinish;
@property (assign, nonatomic) NSInteger fWidth;
@property (assign, nonatomic) NSInteger fHeight;
@property (assign, nonatomic) NSInteger fFireService;
@property (assign, nonatomic) NSInteger fAppendix;


@property (nonatomic, copy) NSString *imgName;
@property (nonatomic, copy) NSString *imgNameZoom;

@property (nonatomic, copy) NSString *imgDescription;


@end
