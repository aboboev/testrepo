//
//  ProdPickerViewController.h
//  MadFixtures
//
//  Created by Antonio Pena on 12-01-04.
//  Copyright (c) 2012 Kioaxis. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MessageUI/MFMailComposeViewController.h>

#define firstArrayComponent  0
#define secondArrayComponent 1
#define thirdArrayComponent  2
#define fourthArrayComponent 3


static const CGFloat itemActive    = 1.0;
static const CGFloat itemNotActive = 0.3;

@interface ProdPickerViewController : UIViewController <UIPickerViewDelegate, MFMailComposeViewControllerDelegate,  UIScrollViewDelegate> {


    IBOutlet UIActivityIndicatorView *imageSwitchIndicator;
    NSTimer *timer;
    
    IBOutlet UIPickerView *pickerView;
    IBOutlet UIImageView *imgPickerViewBg;
    
    IBOutlet UILabel *descLabel;
    IBOutlet UIImageView *productImage;
    IBOutlet UIImageView *productBackImage;
    
    IBOutlet UIButton *btnColl1;
    IBOutlet UIButton *btnColl2;
    IBOutlet UIButton *btnColl3;
    IBOutlet UIButton *btnColl4;
    IBOutlet UIButton *btnColl5;
    
   
    IBOutlet UILabel *lbl1;
    IBOutlet UILabel *lbl2;
    IBOutlet UILabel *lbl3;
    IBOutlet UILabel *lbl4;
    
    IBOutlet UIImageView *lblback;
    IBOutlet UIImageView *imgBackfill;
    
    IBOutlet UIImageView *imgUiBg;
    
    IBOutlet UIView *viewControls;
    
	NSMutableArray *pArray1;
    NSMutableArray *pArray2;
    NSMutableArray *pArray3;
    NSMutableArray *pArray4;
    
    NSMutableArray *fArray1;
    NSMutableArray *fArray2;
    NSMutableArray *fArray3;
    NSMutableArray *fArray4;
    
    NSMutableArray *aArray1;
    NSMutableArray *aArray2;
    NSMutableArray *aArray3;
    NSMutableArray *aArray4;
    
    
    NSString *cur1;
    NSString *cur2;
    NSString *cur3;
    NSString *cur4;
    

    NSInteger sel1;
    NSInteger sel2;
    NSInteger sel3;
    NSInteger sel4;
    
    NSInteger psel1;
    NSInteger psel2;
    NSInteger psel3;
    NSInteger psel4;
    
    
    
    NSString *product;
    NSString *photo;
    NSString *name;
    NSString *desc;
    NSString *msg;
    
    NSMutableArray *arrayProducts;
	
	NSMutableArray *arrayTheProduct;
    
    NSString *currentSellection;
    NSString *previousSellection;
    
    
    BOOL is_iPhone;
    
    BOOL applyRules;
    
}

@property(nonatomic, retain)IBOutlet UIActivityIndicatorView *imageSwitchIndicator;
@property(nonatomic, retain)IBOutlet UIPickerView *pickerView;
@property(nonatomic, retain)IBOutlet UIImageView *imgPickerViewBg;

@property(nonatomic, retain)IBOutlet UILabel *descLabel;
@property(nonatomic, retain)IBOutlet UIImageView *productImage;
@property(nonatomic, retain)IBOutlet UIImageView *productBackImage;

@property(nonatomic, retain)IBOutlet UIButton *btnColl1;
@property(nonatomic, retain)IBOutlet UIButton *btnColl2;
@property(nonatomic, retain)IBOutlet UIButton *btnColl3;
@property(nonatomic, retain)IBOutlet UIButton *btnColl4;
@property(nonatomic, retain)IBOutlet UIButton *btnColl5;


@property(nonatomic, retain)IBOutlet UILabel *lbl1;
@property(nonatomic, retain)IBOutlet UILabel *lbl2;
@property(nonatomic, retain)IBOutlet UILabel *lbl3;
@property(nonatomic, retain)IBOutlet UILabel *lbl4;
@property(nonatomic, retain)IBOutlet UIImageView *lblback;
@property(nonatomic, retain)IBOutlet UIImageView *imgBgip5;
@property(nonatomic, retain)IBOutlet UIImageView *imgBackfill;
@property(nonatomic, retain)IBOutlet UIView *viewControls;

@property(nonatomic, retain)IBOutlet UIImageView *imgUiBg;



@property (nonatomic, strong) IBOutlet UIScrollView *scrollView;
@property (nonatomic, strong) IBOutlet UIView *containerView;


@property (nonatomic, weak) IBOutlet NSLayoutConstraint *topConstraint;
@property (nonatomic, weak) IBOutlet NSLayoutConstraint *bottomConstraint;


-(IBAction)SetCollection:(UIButton*)sender;

-(IBAction)sendEmail;

-(IBAction)checkImages;
@end
