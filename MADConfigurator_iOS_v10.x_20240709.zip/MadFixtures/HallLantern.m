//
//  HallLantern.m
//  MadFixtures
//
//  Created by Antonio Pena on 2012-12-30.
//  Copyright (c) 2012 Kioaxis. All rights reserved.
//

#import "HallLantern.h"

@implementation HallLantern


@synthesize fGroup;
@synthesize fType;
@synthesize fStyle;
@synthesize fFinish;
@synthesize fWidth;
@synthesize fHeight;
@synthesize fOrientation;
@synthesize fArrowStyle;
@synthesize fPositionIndicator;

@synthesize imgName, imgNameZoom, imgDescription;



-(id) initGroup:(NSString *)fgroup type:(NSInteger)ftype style:(NSInteger )fstyle finish:(NSInteger)ffinish width:(NSInteger)fwidth height:(NSInteger)fheight orientation:(NSInteger)forientation arrowstyle:(NSInteger)farrowstyle positionindicator:(NSInteger)fpositionindicator
{
    
     self = [self init];
    
    options = [[NSMutableArray alloc] initWithObjects:@"A",@"B",@"C",@"D",@"E", nil];
    finishoptions = [[NSMutableArray alloc] initWithObjects:@"A",@"C", nil];
    
    dType  = [[NSMutableArray alloc] initWithObjects:@"Terminal",@"Intermediate", nil];
    dStyle = [[NSMutableArray alloc] initWithObjects:@"Flush Mount",@"Gilda Surface Mount",@"Gilda Curve Surface Mount",@"Gilda Corner Surface Mount", nil];
   
    
    // July 26 2016 - remove other finishes not being used
    //dFinish = [[NSMutableArray alloc] initWithObjects:@"#4 Stainless Steel",@"#8 Stainless Steel",@"#4 Brass/PVD",@"#8 Brass/PVD",@"Oil Rubbed Bronze", nil];
    
    dFinish = [[NSMutableArray alloc] initWithObjects:@"Stainless Steel", @"Brass", nil];
    
    dWidth = [[NSMutableArray alloc] initWithObjects:@"4-4.5\"",@"6\"",@"8\"", nil];    // height for horizontal
    dHeight = [[NSMutableArray alloc] initWithObjects:@"12\"",@"16\"",@"20\"", nil];   //width for horizontal
    dOrientation = [[NSMutableArray alloc] initWithObjects:@"Vertical",@"Horizontal", nil];
    dArrowStyle = [[NSMutableArray alloc] initWithObjects:@"Traditional ADA",@"Vandal",@"PI Only",@"Vision Series", nil];
    
    // Aug 2
    // Position Indicator
    //dPositionIndicator = [[NSMutableArray alloc] initWithObjects:@"16 Segment, ",@"",@"4.3\" Giotto, ",@"7\" Giotto, ",nil];
    // new images for Giotto and Raffaello
    //  4.3 Giotto === C
    //   Raffaello === D
    
    dPositionIndicator = [[NSMutableArray alloc] initWithObjects:@"16 Segmented", @"None", @"4.3\" Giotto", @"Raffaello", nil];
    
    
    
    fGroup = fgroup;
    fType = ftype;
    fStyle = fstyle;
    fFinish = ffinish;
    fWidth = fwidth;
    fHeight = fheight;
    fOrientation = forientation;
    fArrowStyle= farrowstyle;
    fPositionIndicator = fpositionindicator;
    
    [self updateName];
    
    return self;
}

-(void) updateName {
    imgName =     [NSString stringWithFormat: @"%@%@%@%@%@%@%@%@%@AAF.jpg",fGroup,
                   [options objectAtIndex:fType],
                   [options objectAtIndex:fStyle],
                   [finishoptions objectAtIndex:fFinish],
                   [options objectAtIndex:fWidth],
                   [options objectAtIndex:fHeight],
                   [options objectAtIndex:fOrientation],
                   [options objectAtIndex:fArrowStyle],
                   [options objectAtIndex:fPositionIndicator] ];

    imgNameZoom = [NSString stringWithFormat: @"%@%@%@%@%@%@%@%@%@AAZ.jpg",fGroup,
                   [options objectAtIndex:fType],
                   [options objectAtIndex:fStyle],
                   [finishoptions objectAtIndex:fFinish],
                   [options objectAtIndex:fWidth],
                   [options objectAtIndex:fHeight],
                   [options objectAtIndex:fOrientation],
                   [options objectAtIndex:fArrowStyle],
                   [options objectAtIndex:fPositionIndicator] ];
    
    
    if(fOrientation == 0)  // vertical
    {
    
        imgDescription = [NSString stringWithFormat: @"%@ %@ Hall Lantern, %@ %@ Position Indicator, %@ %@ x %@",
                      [dStyle objectAtIndex:fStyle],
                      [dType objectAtIndex:fType],
                      [dArrowStyle objectAtIndex:fArrowStyle],
                      [dPositionIndicator objectAtIndex:fPositionIndicator],
                      [dFinish objectAtIndex:fFinish],
                          
                      [dWidth objectAtIndex:fHeight],
                      [dHeight objectAtIndex:fWidth  ]
                      
                      ];
    }
    else                 // horizontal
    {
        imgDescription = [NSString stringWithFormat: @"%@ %@ Hall Lantern, %@ %@ Position Indicator, %@ %@ x %@",
                          [dStyle objectAtIndex:fStyle],
                          [dType objectAtIndex:fType],
                          [dArrowStyle objectAtIndex:fArrowStyle],
                          [dPositionIndicator objectAtIndex:fPositionIndicator],
                          [dFinish objectAtIndex:fFinish],
                         
                          [dHeight objectAtIndex:fWidth],
                          [dWidth objectAtIndex:fHeight]
                        
                          ];
    
    }
    
    //NSLog(@" Station img %@\n",imgName);
    //NSLog(@" Station img ZOOM %@\n",imgNameZoom);
}

@end
