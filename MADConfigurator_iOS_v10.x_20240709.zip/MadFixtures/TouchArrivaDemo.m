//
//  TouchArrivaDemo.m
//  MadFixtures
//
//  Created by Antonio Pena on 12-01-18.
//  Copyright (c) 2012 Kioaxis. All rights reserved.
//

#import "TouchArrivaDemo.h"

@implementation TouchArrivaDemo


@synthesize insideCab;


-(IBAction)buttonOnOff :(UIButton *)sender {

    
    UIButton *button = sender;    
    int theTag = [button.titleLabel.text intValue]+100;
    

    UIButton *myfloor = (UIButton *)[self.view viewWithTag:theTag];
    
    
    if ( button.tag == 1)
    {
        [button setBackgroundImage: [UIImage imageNamed:@"_clear.png"] forState: UIControlStateNormal];
        if ( theTag < 137 )
        {
            [myfloor setBackgroundImage: [UIImage imageNamed:@"_clear.png"] forState: UIControlStateNormal];    
        }
        
        //[theButton setBackgroundImage: [UIImage imageNamed:@"_clear.png"] forState: UIControlStateNormal];
        
        button.tag = 0;
    }
    else
    {
        NSString *fullfilename =[NSString stringWithFormat: @"%@/Arriva-%@.jpg", self.title,  button.titleLabel.text];
       [button setBackgroundImage: [UIImage imageNamed:fullfilename] forState: UIControlStateNormal];
        
        button.tag = 1;
        
        
        // display or ( show / hide ) the floo
        if ( theTag < 137 )
        {
            NSString *fullfilenameFloor =[NSString stringWithFormat: @"%@/arriva-floor-%@.jpg", self.title,  button.titleLabel.text];
            [myfloor setBackgroundImage: [UIImage imageNamed:fullfilenameFloor] forState: UIControlStateNormal];
        }

    }
}



-(IBAction)zoomBtn :(UIButton *)sender {
    
    UIButton *button = sender;
    
    if (button.tag == 1 )
    {
        [button setImage: [UIImage imageNamed:@"zoom_out.png"] forState: UIControlStateNormal];
        //[button setTitle:@"Zoom -" forState:UIControlStateNormal];
        insideCab.hidden = YES;
        button.tag = 0;
        
    }
    else
    {
        [button setImage: [UIImage imageNamed:@"zoom_in.png"] forState: UIControlStateNormal];
        //[button setTitle:@"Zoom +" forState:UIControlStateNormal];
        insideCab.hidden = NO;
        button.tag = 1;
    }
    
}




- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
    insideCab.hidden = YES;
}

- (BOOL)shouldAutorotate {
    
    UIInterfaceOrientation interfaceOrientation = (UIInterfaceOrientation)[[UIDevice currentDevice] orientation];

    // Return YES for supported orientations
    //return (interfaceOrientation == UIInterfaceOrientationPortrait);
    
    if( interfaceOrientation == UIInterfaceOrientationPortrait )
    {
        return (YES);
        
    }
    else if( interfaceOrientation == UIDeviceOrientationPortraitUpsideDown )
    {
        return (YES);
    }
    else if( interfaceOrientation == UIDeviceOrientationLandscapeRight )
    {
        return (NO);
    }
    else
    {
        return (NO);
    }
    
}

- (BOOL)prefersStatusBarHidden
{
    return YES;
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    UIViewController *vc = [segue destinationViewController];
    vc.modalPresentationStyle = UIModalPresentationFullScreen;
}

@end
