//
//  HallStation.m
//  MadFixtures
//
//  Created by Antonio Pena on 2012-12-30.
//  Copyright (c) 2012 Kioaxis. All rights reserved.
//

#import "HallStation.h"

@implementation HallStation

@synthesize fGroup;

@synthesize fType, fStyle, fFinish, fWidth, fHeight, fFireService, fAppendix;

@synthesize imgName, imgNameZoom, imgDescription;



-(id) initGroup:(NSString *)fgroup type:(NSInteger)ftype style:(NSInteger)fstyle finish:(NSInteger)ffinish width:(NSInteger)fwidth height:(NSInteger)fheight fireservice:(NSInteger)ffireservice appendinx:(NSInteger)fappendinx
{
    
    self = [self init];
    
    options = [[NSMutableArray alloc] initWithObjects:@"A",@"B",@"C",@"D",@"E", nil];
    finishoptions = [[NSMutableArray alloc] initWithObjects:@"A",@"C", nil];
    
    dType  = [[NSMutableArray alloc] initWithObjects:@"Terminal",@"Intermediate", nil];
    dStyle = [[NSMutableArray alloc] initWithObjects:@"Flush Mount",@"Gilda Surface Mount",@"Gilda Curve Surface Mount",@"Gilda Corner Surface Mount", nil];
    
    // July 26 2016 - remove other finishes not being used
    //dFinish = [[NSMutableArray alloc] initWithObjects:@"#4 Stainless Steel",@"#8 Stainless Steel",@"#4 Brass/PVD",@"#8 Brass/PVD",@"Oil Rubbed Bronze", nil];
    
    dFinish = [[NSMutableArray alloc] initWithObjects:@"Stainless Steel", @"Brass", nil];
    
    dWidth = [[NSMutableArray alloc] initWithObjects:@"4\"",@"6\"",@"8\"", nil];
    dHeight = [[NSMutableArray alloc] initWithObjects:@"12\"",@"20\"",@"24\"", nil];
    dFireService = [[NSMutableArray alloc] initWithObjects:@"Phase 1 Fire Service, ",@"", nil];
    dAppendix = [[NSMutableArray alloc] initWithObjects:@"Appendix O/H, ",@"", nil];

    
    
    fGroup = fgroup;
    fType = ftype;
    fStyle = fstyle;
    fFinish = ffinish;
    fWidth = fwidth;
    fHeight = fheight;
    fFireService = ffireservice;
    fAppendix = fappendinx;
    
    [self updateName];
    
    return self;
}

-(void) updateName {
   imgName =     [NSString stringWithFormat: @"%@%@%@%@%@%@%@%@AAAF.jpg",fGroup,
                  [options objectAtIndex:fType],
                  [options objectAtIndex:fStyle],
                  [finishoptions objectAtIndex:fFinish],
                  [options objectAtIndex:fWidth],
                  [options objectAtIndex:fHeight],
                  [options objectAtIndex:fFireService],
                  [options objectAtIndex:fAppendix] ] ;
                   
    imgNameZoom = [NSString stringWithFormat: @"%@%@%@%@%@%@%@%@AAAZ.jpg",fGroup,
                   [options objectAtIndex:fType],
                   [options objectAtIndex:fStyle],
                   [finishoptions objectAtIndex:fFinish],
                   [options objectAtIndex:fWidth],
                   [options objectAtIndex:fHeight],
                   [options objectAtIndex:fFireService],
                   [options objectAtIndex:fAppendix] ] ;
    
    
    imgDescription = [NSString stringWithFormat: @"%@ %@ Hall Station, %@ %@ %@ %@ x %@",
                      [dStyle objectAtIndex:fStyle],
                      [dType objectAtIndex:fType],
                      [dFireService objectAtIndex:fFireService],
                      [dAppendix objectAtIndex:fAppendix],
                      [dFinish objectAtIndex:fFinish],
                      [dWidth objectAtIndex:fWidth],
                      [dHeight objectAtIndex:fHeight]
                      
                      ];
    
    //NSLog(@" Lantern img %@\n",imgName);
    //NSLog(@" Lantern img ZOOM %@\n",imgNameZoom);
    
}




@end
