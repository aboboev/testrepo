//
//  TouchArrivaDemo.h
//  MadFixtures
//
//  Created by Antonio Pena on 12-01-18.
//  Copyright (c) 2012 Kioaxis. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TouchArrivaDemo : UIViewController{
    
    
    IBOutlet UIButton *theButton;
    IBOutlet UIImageView *insideCab;
    
    
}

@property (nonatomic, retain) IBOutlet UIImageView *insideCab;


-(IBAction)buttonOnOff:(UIButton*)sender;
-(IBAction)zoomBtn:(UIButton*)sender;

@end
