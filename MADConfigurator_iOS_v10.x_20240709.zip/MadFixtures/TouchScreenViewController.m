//
//  NewTouchScreen.m
//  MadFixtures
//
//  Created by Alex Yuan on 2024/6/13.
//  Copyright © 2024 Mad Elevator. All rights reserved.
//

#import "TouchScreenViewController.h"
#import "TouchScreenPagerCell.h"
#import <WebKit/WebKit.h>

@interface TouchScreenViewController () <UICollectionViewDataSource,UICollectionViewDelegate>
#define TITLES    @[@"Retail", @"Office", @"Stadium", @"Airport", @"Residential", @"Medical", @"Hotel", @"Casino", @"Hotel", @"Residential"]
@end

@implementation TouchScreenViewController

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //TouchScreenFlowLayout * layout = [[TouchScreenFlowLayout alloc] init];
    //self.collectionView.collectionViewLayout = layout;
    //UICollectionViewFlowLayout * layout = self.collectionView.collectionViewLayout;
    //layout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    //layout.minimumLineSpacing = 0;
    self.collectionView.pagingEnabled = YES;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
}

-(BOOL) shouldAutorotate { return NO; }

-(UIInterfaceOrientationMask) supportedInterfaceOrientations { return UIInterfaceOrientationMaskPortrait; }

- (BOOL)prefersStatusBarHidden
{
    return YES;
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    UIViewController *vc = [segue destinationViewController];
    vc.modalPresentationStyle = UIModalPresentationFullScreen;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return 10;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    return collectionView.bounds.size;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    TouchScreenPagerCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
    
    WKWebViewConfiguration *configuration = [[WKWebViewConfiguration alloc] init];
    WKWebsiteDataStore *dataStore = [WKWebsiteDataStore nonPersistentDataStore];
    configuration.websiteDataStore = dataStore;
    
    cell.webView = [[WKWebView alloc] initWithFrame:cell.bounds configuration:configuration];
    [cell.contentView addSubview:cell.webView];
    
    NSString *htmlFilePath = [[NSBundle mainBundle] pathForResource:@"theme" ofType:@"html" inDirectory:[NSString stringWithFormat:@"TTGHtmls/%d", (int)indexPath.row + 1]];
    NSURL *htmlFileURL = [NSURL fileURLWithPath:htmlFilePath];
    NSURLRequest *request = [NSURLRequest requestWithURL:htmlFileURL];
    
    CGFloat width = cell.bounds.size.width;
    CGFloat height = cell.bounds.size.height;
    CGFloat displayRate = width / height;
    CGFloat htmlRate = (float)(1080.0 / 1920.0);
    if (displayRate > htmlRate){
        cell.webView.frame = CGRectMake((width - height * htmlRate) / 2, 0, height * htmlRate, height);
    }else{
        cell.webView.frame = CGRectMake(0, (height - width / htmlRate) / 2, width, width / htmlRate);
    }
    
    /*cell.webView.contentMode = UIViewContentModeScaleAspectFit;
    cell.webView.scrollView.minimumZoomScale = 1.0;
    cell.webView.scrollView.maximumZoomScale = 1.0;
    cell.webView.scrollView.bouncesZoom = NO;
    cell.webView.scrollView.zoomScale = 1.0;*/
    
    [cell.webView loadRequest:request];
    
    return cell;
}

// Implement UICollectionViewDelegate method to handle scrolling
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    CGFloat pageWidth = self.collectionView.frame.size.width;
    int currentPage = floor((self.collectionView.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
    self.titleLabel.text = TITLES[currentPage];
}

- (IBAction)goPrev:(id)sender {
    CGFloat pageWidth = self.collectionView.frame.size.width;
    int currentPage = floor((self.collectionView.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
    int prevPage = currentPage - 1;
    if (prevPage < 0) return;
    
    CGPoint prevPoint = CGPointMake(pageWidth * prevPage, 0);
    [self.collectionView setContentOffset:prevPoint animated:YES];
    self.titleLabel.text = TITLES[prevPage];
}

- (IBAction)goNext:(id)sender {
    CGFloat pageWidth = self.collectionView.frame.size.width;
    int nextPage = 1 + (floor((self.collectionView.contentOffset.x - pageWidth / 2) / pageWidth) + 1);
    if (nextPage >= 10) return;
    
    CGPoint nextPoint = CGPointMake(pageWidth * nextPage, 0);
    [self.collectionView setContentOffset:nextPoint animated:YES];
    self.titleLabel.text = TITLES[nextPage];
}

@end
