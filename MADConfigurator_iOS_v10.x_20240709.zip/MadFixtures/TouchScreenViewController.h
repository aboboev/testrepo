//
//  NewTouchScreen.h
//  MadFixtures
//
//  Created by Alex Yuan on 2024/6/13.
//  Copyright © 2024 Mad Elevator. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TouchScreenViewController : UIViewController
@property (nonatomic, weak) IBOutlet UICollectionView *collectionView;

- (IBAction)goNext:(id)sender;
- (IBAction)goPrev:(id)sender;
@property (nonatomic, weak) IBOutlet UILabel *titleLabel;

@end
