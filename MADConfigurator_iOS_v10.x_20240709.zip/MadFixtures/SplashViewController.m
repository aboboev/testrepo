//
//  SplashViewController.m
//  MadFixtures
//
//  Created by Alex on 5/30/18.
//  Copyright © 2018 Mad Elevator. All rights reserved.
//

#import "SplashViewController.h"
#import "DownloadAlertView.h"
#import "ViewController.h"

@interface SplashViewController ()

@end

@implementation SplashViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
    [self checkDownload];
    //[self performSegueWithIdentifier:@"showHome" sender:nil];
}


- (void)checkDownload {
    NSString *url = @"https://madfixtures.net/madfixtures_version/version.json";
    //NSString *url = @"http://10.97.5.36/madfixtures_version/version.json";
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    [request setHTTPMethod:@"GET"];
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    dispatch_async(dispatch_get_main_queue(), ^{
        // This is for removing cache
        NSURLSessionConfiguration *ephemeralConfigObject = [NSURLSessionConfiguration ephemeralSessionConfiguration];
        [[[NSURLSession sessionWithConfiguration:ephemeralConfigObject] dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
            if (error) {
                NSLog(@"%@", error);
                dispatch_async(dispatch_get_main_queue(), ^{
                    [self performSegueWithIdentifier:@"showHome" sender:nil];
                });
            } else{
                NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:0 error:&error];
                if ([dict isKindOfClass:[NSDictionary class]] && ![dict[@"ios_version"] isEqualToString:[self appVersion]]) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        DownloadAlertView *view = [DownloadAlertView showOnView:self.view];
                        [view setYesBlock:^{
                            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"https://itunes.apple.com/ca/app/mad-elevator-fixtures-elevator/id517282873?mt=8"] options:@{} completionHandler:nil];
                            exit(0);
                        }];
                        [view setNoBlock:^{
                            [self performSegueWithIdentifier:@"showHome" sender:nil];
                        }];
                    });
                    
                    return;
                }
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    [self performSegueWithIdentifier:@"showHome" sender:nil];
                });
            }
        }] resume];
    });
}

- (NSString *)appVersion {
    NSString *version = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
    NSLog(@"CurrentVersion: %@", version);
    return version;
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if ([[segue identifier] isEqualToString:@"showHome"]){
        ViewController *vc = [segue destinationViewController];
        vc.modalPresentationStyle = UIModalPresentationFullScreen;
    }
}

- (BOOL)prefersStatusBarHidden{
    return YES;
}

@end
