//
//  TouchScreenDemo.h
//  MadFixtures
//
//  Created by Antonio Pena on 11-12-08.
//  Copyright (c) 2011 Kioaxis. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TouchScreenDemo : UIViewController{
    
    IBOutlet UIButton *theButton;
    IBOutlet UIImageView *insideCab;

    
}

@property (nonatomic, retain) IBOutlet UIImageView *insideCab;


-(IBAction)buttonOnOff:(UIButton*)sender;
-(IBAction)zoomBtn:(UIButton*)sender;


@end
