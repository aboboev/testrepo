//
//  TouchScreenPagerCell.h
//  MadFixtures
//
//  Created by Alex Yuan on 2024/6/14.
//  Copyright © 2024 Mad Elevator. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>

@interface TouchScreenPagerCell : UICollectionViewCell
//@property (nonatomic, weak) IBOutlet WKWebView *webView;
@property (nonatomic, strong) WKWebView *webView;
@end
