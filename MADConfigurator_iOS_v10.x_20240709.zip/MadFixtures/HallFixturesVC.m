//
//  HallFixturesVC.m
//  MadFixtures
//
//  Created by Antonio Pena on 2012-12-29.
//  Copyright (c) 2012 Kioaxis. All rights reserved.
//

#import "HallFixturesVC.h"

#import "JTTransformableTableViewCell.h"



#define IDIOM    [UIDevice currentDevice].userInterfaceIdiom
#define IPAD     UIUserInterfaceIdiomPad

#define IS_IPHONE ([UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPhone)
#define IS_IPHONE_4 (IS_IPHONE && [[UIScreen mainScreen] bounds].size.height == 480.0f)



#define rotationIPADlandscape    1.0
#define rotationIPADportrait     0.75
#define rotationIPHONElandscape  0.46875
#define rotationIPHONEportrait   0.3125



#define Rgb2UIColor(r, g, b)  [UIColor colorWithRed:((r) / 255.0) green:((g) / 255.0) blue:((b) / 255.0) alpha:1.0]


#define COMMITING_CREATE_CELL_HEIGHT 50
#define NORMAL_CELL_FINISHING_HEIGHT 50


#define LANTERNTAG_START 100


@interface HallFixturesVC ()

@end

@implementation HallFixturesVC
{
    float rotationFactor;
    BOOL orientationPortrait;
    
    NSMutableArray *settingGenType, *settingGenStyle, *settingGenFinish ;
    NSMutableArray *settingLanternWidth, *settingLanternHeight, *settingLanternOrientation, *settingLanternArrowStyle, *settingLanternPositionIndicator;
    NSMutableArray *settingHallWidth, *settingHallHeight, *settingHallFireService, *settingHallApendixOH;
    
    NSMutableArray *settingListsGen, *settingListsLantern, *settingListsHall;
    
    
    
    NSMutableArray *settingStateGenType, *settingStateGenStyle, *settingStateGenFinish ;
    NSMutableArray *settingStateLanternWidth, *settingStateLanternHeight, *settingStateLanternOrientation, *settingStateLanternArrowStyle, *settingStateLanternPositionIndicator;
    NSMutableArray *settingStateHallWidth, *settingStateHallHeight, *settingStateHallFireService, *settingStateHallApendixOH;
    
    NSMutableArray *settingStateListsGen, *settingStateListsLantern, *settingStateListsHall;
    
    
    BOOL isAiPhone;
    
    
    int currentTableRow;
    

    NSMutableArray *optionsLantern;
    NSMutableArray *optionsHall;
    
    NSMutableArray *settingStatesLantern, *settingStatesHall;
   
    
    
    NSMutableArray *hvPickerActive;
    int activeHvPicker;
    int activeHvSelection;
    
    NSMutableArray *activeState;
    
    int hallOrLantern;
    
    //  to manage table section collaps
    NSMutableSet* _collapsedSectionsHall;
    NSMutableSet* _collapsedSectionsLantern;
    
    int currentSection;

    
    
}

@synthesize tblHallFixtures, tblLanternFixtures;

@synthesize imgBackground, imgTop, imgTopCenter, imgBottom;

@synthesize viewConfig, viewZoom;

@synthesize imglogoBg,imgConfigBg;

@synthesize btnHallLantern, btnHallStation;


@synthesize imgZoom, imgZoomBg;

@synthesize btnZoomIn1, btnZoomIn2, btnZoomIn3, btnZoomIn4;

@synthesize debugFileName, debugsFileName;

@synthesize btnZoomOut, btnBigZoomOut;

@synthesize btnHelp, imgHelp, viewHelp;

@synthesize btnSendMail;

@synthesize scrollView, containerView;


const int ZOOM_NONE     = 0;
const int ZOOM_LANTERN  = 1;
const int ZOOM_STATION  = 2;

-(IBAction)ZoomIn:(UIButton *)sender{
    
    UIButton *button = sender;
    
    
    if ( button.tag == 1)
    {
        [imgZoom      setImage:[UIImage imageNamed:myLantern.imgNameZoom]];
        zoomMode = ZOOM_LANTERN;
    }
    else if ( button.tag == 2)
    {
        [imgZoom      setImage:[UIImage imageNamed:myStation.imgNameZoom]];
        zoomMode = ZOOM_STATION;
    }

    viewZoom.hidden = NO;
    
    imgZoom.hidden = FALSE;
    btnZoomOut.hidden = FALSE;
    
    btnBigZoomOut.hidden = FALSE;
}


-(void) UnZoom
{
    
    if ( zoomMode != ZOOM_NONE )
    {
        imgZoom.hidden = TRUE;
        btnZoomOut.hidden = TRUE;
        btnBigZoomOut.hidden = TRUE;

        zoomMode = ZOOM_NONE;
        
        viewZoom.hidden = YES;
    }
}


-(IBAction)Help:(UIButton*)sender{

    
    if ( zoomMode == ZOOM_NONE )
    {
        [imgHelp      setImage:[UIImage imageNamed:@"help-HF-main.jpg"]];

    }
    else if( zoomMode == ZOOM_LANTERN)
    {
        [imgHelp      setImage:[UIImage imageNamed:@"help-HL.jpg"]];
    }
    else  if( zoomMode == ZOOM_STATION)
    {
        [imgHelp      setImage:[UIImage imageNamed:@"help-HS.jpg"]];
    }
    
    
    UIButton *button = sender;
    
    
    if ( button.tag == 0) // Show Help
    {
        viewHelp.hidden = FALSE;

    }
    else if (button.tag ==1 ) // Hide Help
    {
        viewHelp.hidden =  TRUE;
    }
    
    
}

-(IBAction)ZoomOut:(UIButton*)sender
{
    if ( zoomMode != ZOOM_NONE )
    {
        [self UnZoom];
    }
}



- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}


#pragma mark ---- Setup ----

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    
    // display the debug names to debug file names
    // hide the debuging fields
    debugFileName.hidden = TRUE;
    debugsFileName.hidden = TRUE;
    
    self.portraitCon.priority = UILayoutPriorityDefaultHigh + 1;
    self.landscapeCon.priority = UILayoutPriorityDefaultLow;

    // Special case, The background image never changes for this Version
    [imgBackground  setImage:[UIImage imageNamed:@"BAAAAAAAAAAA.jpg"]];
    
    
    // this will be displayed if options are visibel
    // and the position of the closup image (imgZoom ) is scaled down
    [imgZoomBg      setImage:[UIImage imageNamed:@"HS-ZoomBg.jpg"]];  // for now
    imgZoomBg.hidden = TRUE;
    // Backgound image may n longer be required.
    
    // set some default value for now, but it gets re-set when zoom in is activated
    [imgZoom      setImage:[UIImage imageNamed:@"SABABCAAAAAZ.jpg"]];  // for now
    

    // Options
    optionsLantern = [[NSMutableArray alloc] initWithObjects:@"Type", @"Style", @"Finish",@"Width", @"Height", @"Orientation", @"Arrow Style", @"Position Indicator", nil];
    optionsHall = [[NSMutableArray alloc] initWithObjects:@"Type", @"Style", @"Finish",@"Width", @"Height", @"Fire Service", @"Apendix O/H",nil];

    
    
    
    // Options to be displayed on PickerView
    
   
    
    //  C LISTS for Gen
    
    settingGenType = [[NSMutableArray alloc] initWithObjects:@"Terminal", @"Intermediate", nil];
    settingGenStyle = [[NSMutableArray alloc] initWithObjects:@"Flush Mount", @"Gilda Surface Mount", @"Gilda Curve Surface Mount", @"Gilda Corner Surface Mount", nil];
    
    
    // July 26 2016 - remove other finishes not being used
    //settingGenFinish = [[NSMutableArray alloc] initWithObjects:@"#4 Stainless Steel", @"#8 Stainless Steel", @"#4 Brass/PVD", @"#8 Brass/PVD", @"Oil Rubbed Bronze", nil];
    
    settingGenFinish = [[NSMutableArray alloc] initWithObjects:@"Stainless Steel", @"Brass", nil];
    
    
    
    settingStateGenType = [[NSMutableArray alloc] initWithObjects:[NSNumber numberWithFloat:itemActive], [NSNumber numberWithFloat:itemActive], nil];
    settingStateGenStyle = [[NSMutableArray alloc] initWithObjects:[NSNumber numberWithFloat:itemActive],[NSNumber numberWithFloat:itemActive], [NSNumber numberWithFloat:itemActive],[NSNumber numberWithFloat:itemActive], nil];
    
    
    // July 26 2016 - remove other finishes not being used
    //settingStateGenFinish = [[NSMutableArray alloc] initWithObjects:[NSNumber numberWithFloat:itemActive],[NSNumber numberWithFloat:itemNotActive], [NSNumber numberWithFloat:itemActive], [NSNumber numberWithFloat:itemNotActive], [NSNumber numberWithFloat:itemNotActive], nil];
    
     settingStateGenFinish = [[NSMutableArray alloc] initWithObjects:[NSNumber numberWithFloat:itemActive], [NSNumber numberWithFloat:itemActive], nil];
    
    //  C LISTS for  Lantern
    
    
    settingLanternWidth= [[NSMutableArray alloc] initWithObjects:@"12\"", @"16\"", @"20\"", nil];
    settingLanternHeight= [[NSMutableArray alloc] initWithObjects:@"4-4.5\"", @"6\"", @"8\"", nil];
    settingLanternOrientation= [[NSMutableArray alloc] initWithObjects:@"Vertical", @"Horizontal",  nil];
    settingLanternArrowStyle= [[NSMutableArray alloc] initWithObjects:@"Traditional ADA", @"Vandal", @"PI Only", @"Vision Series", nil];
    
    // July 23 2016
    // settingLanternPositionIndicator= [[NSMutableArray alloc] initWithObjects:@"16 Segmented", @"None", @"4.3\" Giotto", @"7\" Giotto", nil];
    // new images for Giotto and Raffaello
    //  4.3 Giotto === C
    //   Raffaello === D
    settingLanternPositionIndicator= [[NSMutableArray alloc] initWithObjects:@"16 Segmented", @"None", @"4.3\" Giotto", @"Raffaello", nil];
    
    
    
    
    settingStateLanternWidth= [[NSMutableArray alloc] initWithObjects:[NSNumber numberWithFloat:itemNotActive], [NSNumber numberWithFloat:itemActive], [NSNumber numberWithFloat:itemActive], nil];
    settingStateLanternHeight= [[NSMutableArray alloc] initWithObjects:[NSNumber numberWithFloat:itemActive], [NSNumber numberWithFloat:itemActive], [NSNumber numberWithFloat:itemActive], nil];
    settingStateLanternOrientation= [[NSMutableArray alloc] initWithObjects:[NSNumber numberWithFloat:itemNotActive], [NSNumber numberWithFloat:itemActive], nil];
    settingStateLanternArrowStyle= [[NSMutableArray alloc] initWithObjects:
                                    [NSNumber numberWithFloat:itemActive],
                                    [NSNumber numberWithFloat:itemActive],
                                    [NSNumber numberWithFloat:itemActive],
                                    [NSNumber numberWithFloat:itemNotActive], nil];
    
    
    // ENABLE GIOTTO
    settingStateLanternPositionIndicator= [[NSMutableArray alloc] initWithObjects:
                                           [NSNumber numberWithFloat:itemActive],
                                           [NSNumber numberWithFloat:itemActive],
                                           [NSNumber numberWithFloat:itemActive],
                                           [NSNumber numberWithFloat:itemActive], nil];
    
    // C LISTS for hall
    
    settingHallWidth= [[NSMutableArray alloc] initWithObjects:@"4\"", @"6\"", @"8\"", nil];
    settingHallHeight= [[NSMutableArray alloc] initWithObjects:@"12\"", @"20\"", @"24\"", nil];
    settingHallFireService= [[NSMutableArray alloc] initWithObjects:@"YES", @"NO",  nil];
    settingHallApendixOH= [[NSMutableArray alloc] initWithObjects:@"YES", @"NO", nil];
    
    settingStateHallWidth= [[NSMutableArray alloc] initWithObjects:[NSNumber numberWithFloat:itemNotActive], [NSNumber numberWithFloat:itemActive], [NSNumber numberWithFloat:itemActive], nil];
    settingStateHallHeight= [[NSMutableArray alloc] initWithObjects:[NSNumber numberWithFloat:itemNotActive], [NSNumber numberWithFloat:itemNotActive], [NSNumber numberWithFloat:itemActive], nil];
    settingStateHallFireService= [[NSMutableArray alloc] initWithObjects:[NSNumber numberWithFloat:itemActive], [NSNumber numberWithFloat:itemActive],  nil];
    settingStateHallApendixOH= [[NSMutableArray alloc] initWithObjects:[NSNumber numberWithFloat:itemActive], [NSNumber numberWithFloat:itemActive],  nil];
    
    
    settingListsGen = [[NSMutableArray alloc] initWithObjects:settingGenType, settingGenStyle, settingGenFinish, nil];
    settingListsLantern = [[NSMutableArray alloc] initWithObjects:settingLanternWidth, settingLanternHeight, settingLanternOrientation, settingLanternArrowStyle, settingLanternPositionIndicator,nil];
    settingListsHall= [[NSMutableArray alloc] initWithObjects:settingHallWidth, settingHallHeight, settingHallFireService, settingHallApendixOH, nil];
    
    
    settingStateListsGen = [[NSMutableArray alloc] initWithObjects:
                            settingStateGenType,
                            settingStateGenStyle,
                            settingStateGenFinish, nil];
    
    
    settingStateListsLantern = [[NSMutableArray alloc] initWithObjects:
                                settingStateLanternWidth,
                                settingStateLanternHeight,
                                settingStateLanternOrientation,
                                settingStateLanternArrowStyle,
                                settingStateLanternPositionIndicator,nil];
    
    
    settingStateListsHall= [[NSMutableArray alloc] initWithObjects:
                            settingStateHallWidth,
                            settingStateHallHeight,
                            settingStateHallFireService,
                            settingStateHallApendixOH, nil];
    
    
    
    settingStatesLantern= [[NSMutableArray alloc] initWithObjects:
                           settingStateGenType,
                           settingStateGenStyle,
                           settingStateGenFinish,
                           settingStateLanternWidth,
                           settingStateLanternHeight,
                           settingStateLanternOrientation,
                           settingStateLanternArrowStyle,
                           settingStateLanternPositionIndicator,nil];
    
    settingStatesHall= [[NSMutableArray alloc] initWithObjects:
                        settingStateGenType,
                        settingStateGenStyle,
                        settingStateGenFinish,
                        settingStateHallWidth,
                        settingStateHallHeight,
                        settingStateHallFireService,
                        settingStateHallApendixOH, nil];
    
    
    
    
    
     viewZoom.hidden = YES;
    
    
    /// Old Stuff .....
    
    // help not visible;
    viewHelp.hidden = TRUE;

    
    // iPhone or iPad
    if ( IDIOM == IPAD )
        isAiPhone = FALSE;
    else
        isAiPhone = TRUE;
        
    
    // Initialize the Lantern and Station
    // using Numbers as indexes to the array of letters
    // this makes it easier to manage,update and check current opttions settings
    //  A  B  C  D  E
    //  0  1  2  3  4
    
    myLantern = [[HallLantern alloc]initGroup:@"L" type:0 style:1 finish:0 width:2 height:1 orientation:1 arrowstyle:2 positionindicator:0];
    
    myStation = [[HallStation alloc]initGroup:@"S" type:0 style:1 finish:0 width:1 height:2 fireservice:0 appendinx:0];
    
    
    // intiate some default states
    
    imgZoom.hidden = TRUE;
    btnZoomOut.hidden = TRUE;
    btnBigZoomOut.hidden = TRUE;
    
    zoomMode = ZOOM_NONE;
   
    [self updateImagesToBeDispalyed];
    
    
    // table view stuff
    currentTableRow = -1;
    
    
    hallOrLantern = -1;
    
    
   // handle table collaps sections
    currentSection = -1;
    _collapsedSectionsHall = [NSMutableSet new];
    _collapsedSectionsLantern = [NSMutableSet new];
    
 
    UITapGestureRecognizer *doubleTapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(scrollViewDoubleTapped:)];
    doubleTapRecognizer.numberOfTapsRequired = 2;
    doubleTapRecognizer.numberOfTouchesRequired = 1;
    [self.scrollView addGestureRecognizer:doubleTapRecognizer];
    
    UITapGestureRecognizer *twoFingerTapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(scrollViewTwoFingerTapped:)];
    twoFingerTapRecognizer.numberOfTapsRequired = 1;
    twoFingerTapRecognizer.numberOfTouchesRequired = 2;
    [self.scrollView addGestureRecognizer:twoFingerTapRecognizer];
    


}


- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
}



- (void) checkRules
{
    // check Rules


    
    // deal with the buttons here
    //////////////////////////////////////////////////////////////////////////////
    //
    //          RULES AT BUTTON PRESS
    //
    //////////////////////////////////////////////////////////////////////////////
    //Hall Station
    //  If fire service selected, 12" height is not allowed.  (If selection made while 12" is active, change to 20")
    //  If Appendix O is selected, 12" height is not allowed.  (If selection made while 12" is active, change to 20")
    //  If fire service selected, AND Appendix O/H is active, 20"  height is not allowed.  (If selection made while 20" is active, change to 24")
    //  If appendix O/H is selected, AND fire service is active, 20"  height is not allowed.  (If selection made while 20" is active, change to 24")
    //  If Appendix O/H is selected, 4" Width is not allowed. (If selection made while 4" active, change to 6")
    
    if ( (myStation.fAppendix == APPENDIX_YES) || (myStation.fFireService == FS_YES))
    {
        if ( (myStation.fAppendix == APPENDIX_YES) && (myStation.fFireService == FS_YES))
        {
            
            [settingStateHallHeight replaceObjectAtIndex:0 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [settingStateHallHeight replaceObjectAtIndex:1 withObject:[NSNumber numberWithFloat:itemNotActive]];
            
            //btnfsHeight1.enabled = FALSE;
            //btnfsHeight2.enabled = FALSE;
        }
        else
        {
            //btnfsHeight1.enabled = FALSE;
            //btnfsHeight2.enabled = TRUE;
            [settingStateHallHeight replaceObjectAtIndex:0 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [settingStateHallHeight replaceObjectAtIndex:1 withObject:[NSNumber numberWithFloat:itemActive]];
           
            
        }
        
        
        if (myStation.fAppendix == APPENDIX_YES)
        {
           // btnfsWidth1.enabled = FALSE;
            [settingStateHallWidth replaceObjectAtIndex:0 withObject:[NSNumber numberWithFloat:itemNotActive]];
        }
        else
        {
          //  btnfsWidth1.enabled = TRUE;
             [settingStateHallWidth replaceObjectAtIndex:0 withObject:[NSNumber numberWithFloat:itemActive]];
        }
    }
    else
    {
        //btnfsHeight1.enabled = TRUE;
        //btnfsHeight2.enabled = TRUE;
        
        //btnfsWidth1.enabled = TRUE;
    
        [settingStateHallHeight replaceObjectAtIndex:0 withObject:[NSNumber numberWithFloat:itemActive]];
        [settingStateHallHeight replaceObjectAtIndex:1 withObject:[NSNumber numberWithFloat:itemActive]];
        
        [settingStateHallWidth replaceObjectAtIndex:0 withObject:[NSNumber numberWithFloat:itemActive]];

    }
    
    
    // Hall Lantern
    // IF vertical orientation is selected, please reverse the Width and Height labels in selector (will refer to actual labels only in rules)
    // If Position Indicator is selected,  (Any of them),  Vertical orientation is not allowed.   If orientation is vertical, change to horizontal.
    // If vertical orientation selected, 20" width not allowed.  (if selected, change to 16")
    // If a PI only selected from arrow style, 1 PI MUST be selected.  Automatically select 16 Segment
    // If None is select under PI and PI only under arrow style is active, change PI only to ADA arrow
    // If Vandal Arrow selected, 4-4.5" height is not allowed.  If active, change to 6"
    //          But if style is guilda Curve then Height 8"
    // If 16 segment select and ADA or vandal arrow is selected, 12" and 16" is not allowed.   If selected, change width to 20"
   
    
    if (myLantern.fArrowStyle == LARROW_Vandal) {  // Vandal
         // btnfHeight1.enabled = FALSE;
        [settingStateLanternHeight replaceObjectAtIndex:0 withObject:[NSNumber numberWithFloat:itemNotActive]];
    }
    else
    {
        // btnfHeight1.enabled = TRUE;
        [settingStateLanternHeight replaceObjectAtIndex:0 withObject:[NSNumber numberWithFloat:itemActive]];
        
    }
    
    //July 25 2016
    //if ( myLantern.fPositionIndicator == LPI_16segment  )
    // giotto and Raffaello are the same as 16 segment
    
    if ( myLantern.fPositionIndicator != LPI_None  )
    {
        if(myLantern.fArrowStyle != 2)// 16 segment select and ADA or vandal arrow
        {
            //btnfWidth1.enabled = FALSE;
            //btnfWidth2.enabled = FALSE;
            
            [settingStateLanternWidth replaceObjectAtIndex:0 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [settingStateLanternWidth replaceObjectAtIndex:1 withObject:[NSNumber numberWithFloat:itemNotActive]];
        }
        else
        {
            //btnfWidth1.enabled = FALSE;
            //btnfWidth2.enabled = TRUE;
        
            [settingStateLanternWidth replaceObjectAtIndex:0 withObject:[NSNumber numberWithFloat:itemNotActive]];
            [settingStateLanternWidth replaceObjectAtIndex:1 withObject:[NSNumber numberWithFloat:itemActive]];
        }
        
    }
    else
    {
        //btnfWidth1.enabled = TRUE;
        //btnfWidth2.enabled = TRUE;
        [settingStateLanternWidth replaceObjectAtIndex:0 withObject:[NSNumber numberWithFloat:itemActive]];
        [settingStateLanternWidth replaceObjectAtIndex:1 withObject:[NSNumber numberWithFloat:itemActive]];
        
    }
    
    
    if (myLantern.fPositionIndicator != LPI_None) {
        myLantern.fOrientation = LORIENT_Horizontal;  // Horizontal
        //btnfOrientation1.enabled = FALSE;
        [settingStateLanternOrientation replaceObjectAtIndex:0 withObject:[NSNumber numberWithFloat:itemNotActive]];
        
    }
    else
    {
        //btnfOrientation1.enabled = TRUE;
        [settingStateLanternOrientation replaceObjectAtIndex:0 withObject:[NSNumber numberWithFloat:itemActive]];
        
    }
    
    
    
    if (myLantern.fOrientation == LORIENT_Vertial ) { // vertical == 0
        
        [optionsLantern replaceObjectAtIndex:3 withObject:@"Height"];
        [optionsLantern replaceObjectAtIndex:4 withObject:@"Width"];
        
        //lblHeight.text = @"Width";
        //lblWidth.text = @"Height";
    }else
    {
        [optionsLantern replaceObjectAtIndex:3 withObject:@"Width"];
        [optionsLantern replaceObjectAtIndex:4 withObject:@"Height"];
       
        //lblHeight.text = @"Height";
        //lblWidth.text = @"Width";
    }
    
    
    if (myLantern.fOrientation == LORIENT_Vertial)  // vertical == 0
    {
        //btnfWidth3.enabled = FALSE;
        [settingStateLanternWidth replaceObjectAtIndex:2 withObject:[NSNumber numberWithFloat:itemNotActive]];
        
        if (myLantern.fWidth == LWIDTH_20 ) // 20"
        {
            myLantern.fWidth = LWIDTH_16;   // 16"
        }
        
    }
    else
    {
       //btnfWidth3.enabled  = TRUE;
        [settingStateLanternWidth replaceObjectAtIndex:2 withObject:[NSNumber numberWithFloat:itemActive]];
        
    }
    


    // if Gilda Curve is selected, 6" not possible.
    
    if (myLantern.fStyle == STYLE_GildaCurveSurfaceMount)
    {
        // 6" option disbled
       // btnfHeight2.enabled = FALSE;
       // btnfsWidth2.enabled = FALSE;
        
        [settingStateLanternHeight replaceObjectAtIndex:1 withObject:[NSNumber numberWithFloat:itemNotActive]];
        [settingStateHallWidth replaceObjectAtIndex:1 withObject:[NSNumber numberWithFloat:itemNotActive]];

    }
    else
    {
        // enable 6"
       // btnfHeight2.enabled = TRUE;
       // btnfsWidth2.enabled = TRUE;
        
        [settingStateLanternHeight replaceObjectAtIndex:1 withObject:[NSNumber numberWithFloat:itemActive]];
        [settingStateHallWidth replaceObjectAtIndex:1 withObject:[NSNumber numberWithFloat:itemActive]];

    }
    
   
    
    if ( zoomMode != ZOOM_NONE)
    {
        imgZoom.hidden = FALSE;
        viewZoom.hidden = NO;
    }
    else
    {
        [self UnZoom];
    }
}


- (void) updateImagesToBeDispalyed
{
    if (myLantern.fOrientation == 1) // If Horizontal Then Top image is active
    {
        [imgTop         setImage:[UIImage imageNamed:myLantern.imgName]];
        imgTop.hidden = FALSE;
        btnZoomIn1.hidden = NO;
        btnZoomIn2.hidden = NO;
        imgTopCenter.hidden = TRUE;
        btnZoomIn3.hidden = YES;
    }
    else
    {
        imgTop.hidden = TRUE;
        btnZoomIn1.hidden = YES;
        btnZoomIn2.hidden = YES;
        imgTopCenter.hidden = FALSE;
        btnZoomIn3.hidden = NO;
        [imgTopCenter   setImage:[UIImage imageNamed:myLantern.imgName]];
    }
    
    
    if (myLantern.fFinish == 0) // #4 Stainless Steel
    {
        // SS
        [imgBackground  setImage:[UIImage imageNamed:@"BAAAAAAAAAAA.jpg"]];
    }
    else   // if not stainless Steel then it is #4 brass
    {
        // Brass
        [imgBackground  setImage:[UIImage imageNamed:@"BAACAAAAAAAA.jpg"]];
    }
    
    
    [imgBottom      setImage:[UIImage imageNamed:myStation.imgName]];

    

    if (zoomMode == ZOOM_LANTERN) {
        [imgZoom   setImage:[UIImage imageNamed:myLantern.imgNameZoom]];
    }
    else if (zoomMode == ZOOM_STATION) {
        [imgZoom   setImage:[UIImage imageNamed:myStation.imgNameZoom]];
    }
    
    debugFileName.text = [NSString stringWithFormat: @"L: FULL %@  ZOOMIN %@", myLantern.imgName, myLantern.imgNameZoom];
    debugsFileName.text = [NSString stringWithFormat: @"S: FULL %@  ZOOMIN %@", myStation.imgName, myStation.imgNameZoom];
    
    
    
}

-(IBAction)SetType:(UIButton*)sender
{
    UIButton *button = sender;
    //[button setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    
    
    myLantern.fType = button.tag;
    [myLantern updateName];
    
    myStation.fType = button.tag;
    [myStation updateName];
    
    
    [self updateImagesToBeDispalyed ];
    
    debugFileName.text = [NSString stringWithFormat: @"L: FULL %@  ZOOMIN %@", myLantern.imgName, myLantern.imgNameZoom];
    debugsFileName.text = [NSString stringWithFormat: @"S: FULL %@  ZOOMIN %@", myStation.imgName, myStation.imgNameZoom];
}



#pragma mark --  Send Mail


///  Send Mail with attachment

-(IBAction)sendEmail {
    
    MFMailComposeViewController *composer = [[MFMailComposeViewController alloc] init];
    
    [composer setMailComposeDelegate:self];
    
    if ([MFMailComposeViewController canSendMail]) {
        
        NSString *TheMsg;
        
        //[composer setToRecipients:[NSArray arrayWithObjects:@"info@madelevator.com", nil]];
        
        [composer setCcRecipients:[NSArray arrayWithObjects:@"info@madelevator.com", nil]];
        
        
        [composer setSubject:@"MAD Elevator - Hall Fixture Selection"];
        
        if (zoomMode == ZOOM_NONE) {
            
        TheMsg = [NSString stringWithFormat:@"\nPlease find attached your Hall Fixture Selection.\n\n%@\n\n%@\n\nPlease let your MAD Sales Rep know if you have any questions.\n\n\nThe MAD Elevator Team\n1-866-967-8500\ninfo@madelevator.com\n\n Sent from MAD Fixtures App",myLantern.imgDescription,myStation.imgDescription];
        
        }
        else if (zoomMode == ZOOM_LANTERN){
        
        TheMsg = [NSString stringWithFormat:@"\nPlease find attached your Hall Fixture Selection.\n\n%@\n\nPlease let your MAD Sales Rep know if you have any questions.\n\n\nThe MAD Elevator Team\n1-866-967-8500\ninfo@madelevator.com\n\n Sent from MAD Fixtures App",myLantern.imgDescription];
            
        }
        else if (zoomMode == ZOOM_STATION){
      
            TheMsg = [NSString stringWithFormat:@"\nPlease find attached your Hall Fixture Selection.\n\n%@\n\nPlease let your MAD Sales Rep know if you have any questions.\n\n\nThe MAD Elevator Team\n1-866-967-8500\ninfo@madelevator.com\n\n Sent from MAD Fixtures App",myStation.imgDescription];
            
        }
            
            
        [composer setMessageBody:TheMsg isHTML:NO];
        
        // build the composed image
               
        
        CGSize newSize = CGSizeMake(1024, 768);
        UIGraphicsBeginImageContext( newSize );
        
        
        // this depends on the current state of view.  Zoom IN/OUT lantern or station
        // zoom mode
        
        if (zoomMode == ZOOM_NONE) {
          
            // draw the images
            
            // backgound
            // top or top center
            // bottom
            
            [imgBackground.image drawInRect:CGRectMake(0,0,newSize.width,newSize.height) blendMode:kCGBlendModeNormal alpha:1];
            
            if (myLantern.fOrientation == 1) // If Horizontal Then Top image is active
            {
                [imgTop.image drawInRect:CGRectMake(0,0,1024,201) blendMode:kCGBlendModeNormal alpha:1];
            }else
            {
                [imgTopCenter.image drawInRect:CGRectMake(300,155,315,151) blendMode:kCGBlendModeNormal alpha:1];
            }

            [imgBottom.image drawInRect:CGRectMake(300,300,315,468) blendMode:kCGBlendModeNormal alpha:1];
            

        }
        else if ( (zoomMode == ZOOM_LANTERN) || (zoomMode == ZOOM_STATION) )
        {
            [imgZoom.image drawInRect:CGRectMake(0,0,newSize.width,newSize.height) blendMode:kCGBlendModeNormal alpha:1];
            
        }
        
        // add the copyright
         
        [[UIImage imageNamed:@"copyright.png"] drawInRect:CGRectMake(624,668,400,100) blendMode:kCGBlendModeNormal alpha:1];
        
        
        UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
        
        UIGraphicsEndImageContext();
        
        
        NSData *photoData = UIImageJPEGRepresentation(newImage, 1);
        [composer addAttachmentData:photoData mimeType:@"image/jpeg" fileName:@"HallFixture.jpg"];
    
        [composer setModalTransitionStyle:UIModalTransitionStyleCrossDissolve];
        
        //[self presentModalViewController:composer animated:YES];
        
        [self presentViewController:composer animated:YES completion:nil];
        
        //[composer release];
        
    }
    
    //else
    
    //[composer release];
    
}

-(void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error {
    
    if (error) {
        UIAlertController * alert = [UIAlertController
                                     alertControllerWithTitle:@"Error Occured"
                                     message:[NSString stringWithFormat:@"error - %@", [error description]]
                                     preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction* dismissButton = [UIAlertAction
                                        actionWithTitle:@"dismiss"
                                        style:UIAlertActionStyleDefault
                                        handler:^(UIAlertAction * action) {
                                            //Handle your yes please button action here
                                            [alert dismissViewControllerAnimated:YES completion:nil];
                                        }];
        [alert addAction:dismissButton];
        [self presentViewController:alert animated:YES completion:nil];
        
       // [self dismissModalViewControllerAnimated:YES];
        [self dismissViewControllerAnimated:YES completion:nil];
        
    }
    
    else {
        
       // [self dismissModalViewControllerAnimated:YES];
        [self dismissViewControllerAnimated:YES completion:nil];
        
    }
    
}


///


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    // set rotation factor
    UIInterfaceOrientation iOrientation = [UIApplication sharedApplication].windows.firstObject.windowScene.interfaceOrientation;
	UIDeviceOrientation dOrientation = [UIDevice currentDevice].orientation;
    
    
    bool landscape;
	
	if (dOrientation == UIDeviceOrientationUnknown || dOrientation == UIDeviceOrientationFaceUp || dOrientation == UIDeviceOrientationFaceDown) {
		// If the device is laying down, use the UIInterfaceOrientation based on the status bar.
		landscape = UIInterfaceOrientationIsLandscape(iOrientation);
	} else {
		// If the device is not laying down, use UIDeviceOrientation.
		landscape = UIDeviceOrientationIsLandscape(dOrientation);
	}
    
    [self adjustForRotation:landscape];
    
    // PINCH ZOOM SCROLL VIEW STUFF
    
    // Set up the minimum & maximum zoom scales
    self.scrollView.minimumZoomScale = 1.0f;//minScale;
    self.scrollView.maximumZoomScale = 4.0f;
    
    [self scrollviewZoomToFullSize];
}



- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}


#pragma mark ---- Orientation ----
- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskAll;
}


- (BOOL)shouldAutorotate
{
    return YES;
}

- (void)viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator {
    
    [coordinator animateAlongsideTransition:^(id<UIViewControllerTransitionCoordinatorContext> context)
     {
         UIInterfaceOrientation interfaceOrientation = (UIInterfaceOrientation)[[UIDevice currentDevice] orientation];
         
         bool landscape = UIInterfaceOrientationIsLandscape(interfaceOrientation);
         [self adjustForRotation:landscape];
         [self.view layoutIfNeeded];
         [self scrollviewZoomToFullSize];
     } completion:^(id<UIViewControllerTransitionCoordinatorContext> context)
     {
         
     }];
    
    [super viewWillTransitionToSize:size withTransitionCoordinator:coordinator];
}

- (void)adjustImgViewSize:(UIImageView *)imgView nx:(CGFloat)nx  ny:(CGFloat)ny   nw:(CGFloat)nw  nh:(CGFloat)nh
{
    //[image1 setCenter: CGPointMake(634, 126)];
    CGRect myFrame = imgView.frame;
    
    myFrame.origin.x = nx * rotationFactor;
    myFrame.origin.y = ny * rotationFactor;
    
    myFrame.size.width = nw * rotationFactor;
    myFrame.size.height = nh * rotationFactor;
    
    imgView.frame = myFrame;
}

- (void)adjustButtonSize:(UIButton *)imgView nx:(CGFloat)nx  ny:(CGFloat)ny   nw:(CGFloat)nw  nh:(CGFloat)nh
{
    //[image1 setCenter: CGPointMake(634, 126)];
    CGRect myFrame = imgView.frame;
    
    myFrame.origin.x = nx * rotationFactor;
    myFrame.origin.y = ny * rotationFactor;
    
    myFrame.size.width = nw * rotationFactor;
    myFrame.size.height = nh * rotationFactor;
    imgView.frame = myFrame;
}



- ( void )adjustForRotation:(BOOL)landscape
{
    if( landscape )
    {
        viewConfig.hidden = YES;
        
        self.portraitCon.priority = UILayoutPriorityDefaultLow;
        self.landscapeCon.priority = UILayoutPriorityDefaultHigh + 1;
        self.varCon.constant = 0;
        
        if( IDIOM == IPAD)
        {
            rotationFactor = rotationIPADlandscape;
        }
        else
        {
            rotationFactor = rotationIPHONElandscape;
        }
        
    }
    else // Portrait
    {
        viewConfig.hidden = NO;

        self.portraitCon.priority = UILayoutPriorityDefaultHigh + 1;
        self.landscapeCon.priority = UILayoutPriorityDefaultLow;

        if( IDIOM == IPAD)
        {
            rotationFactor = rotationIPADportrait;
            self.varCon.constant = 50;
        }
        else
        {
            rotationFactor = rotationIPHONEportrait;
            self.varCon.constant = 40;
        }
    }
}



- (BOOL)prefersStatusBarHidden
{
    return YES;
}





#pragma mark - Table view data source


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if(tableView == tblHallFixtures)
    {
        return [optionsHall count];
    }
    else
    {
        return [optionsLantern count];
    }
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
   // return [_collapsedSections containsObject:@(section)] ? 1 : 0;
    
    if (tableView == tblHallFixtures)
    {
        return [_collapsedSectionsHall containsObject:@(section)] ? 1 : 0;
    }
    else
    {
        return [_collapsedSectionsLantern containsObject:@(section)] ? 1 : 0;
    }

    
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (isAiPhone) {
        return 30;
    } else {
        return NORMAL_CELL_FINISHING_HEIGHT;
    }
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section;
{
    if (isAiPhone) {
        return 30;
    } else {
        return 45;
    }
}

- (NSString *)titleForSection:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    
    if( tableView == tblHallFixtures )
    {
        return [NSString stringWithFormat:@"    %@",[optionsHall objectAtIndex:section]];
        
    }
    else if ( tableView == tblLanternFixtures )
    {
        return  [NSString stringWithFormat:@"    %@",[optionsLantern objectAtIndex:section]];
        
    }
    
    return @"";
}


- (NSString *)titleForSectionDetailed:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    NSString *theDetail;
    
    
    
    if( tableView == tblHallFixtures )
    {
        
        switch(section)
        {
            case hpv_HALL_Type:
            {
                theDetail = [settingGenType objectAtIndex:myLantern.fType];
            }
                break;
            case hpv_HALL_Style:
            {
                theDetail = [settingGenStyle objectAtIndex:myLantern.fStyle];
            }
                break;
            case hpv_HALL_Finish:
            {
                theDetail = [settingGenFinish objectAtIndex:myLantern.fFinish];
            }
                break;
            case hpv_HALL_Width:
            {
                theDetail = [settingHallWidth objectAtIndex:myStation.fWidth];
            }
                break;
            case hpv_HALL_Height:
            {
                theDetail = [settingHallHeight objectAtIndex:myStation.fHeight];
            }
                break;
            case hpv_HALL_FireService:
            {
                theDetail = [settingHallFireService objectAtIndex:myStation.fFireService];
            }
                break;
            case hpv_HALL_ApendixOH:
            {
                theDetail = [settingHallApendixOH objectAtIndex:myStation.fAppendix];
            }
                break;
        }

        return [NSString stringWithFormat:@"    %@ - %@",[optionsHall objectAtIndex:section], theDetail];
        
    }
    else if ( tableView == tblLanternFixtures )
    {
        
        switch(section)
        {
                
            case hpv_LANTERN_Type:
            {
                theDetail = [settingGenType objectAtIndex:myLantern.fType];
            }
                break;
            case hpv_LANTERN_Style:
            {
                theDetail = [settingGenStyle objectAtIndex:myLantern.fStyle];
            }
                break;
            case hpv_LANTERN_Finish:
            {
                theDetail = [settingGenFinish objectAtIndex:myLantern.fFinish];
            }
                break;
            case hpv_LANTERN_Width:
            {
                theDetail = [settingLanternWidth objectAtIndex:myLantern.fWidth];
            }
                break;
            case hpv_LANTERN_Height:
            {
                theDetail = [settingLanternHeight objectAtIndex:myLantern.fHeight];
            }
                break;
                
            case hpv_LANTERN_Orientation:
            {
                theDetail = [settingLanternOrientation objectAtIndex:myLantern.fOrientation];
            }
                break;
            case hpv_LANTERN_ArrowStyle:
            {
                theDetail = [settingLanternArrowStyle objectAtIndex:myLantern.fArrowStyle];
            }
                break;
            case hpv_LANTERN_PositionIndicator:
            {
                theDetail = [settingLanternPositionIndicator objectAtIndex:myLantern.fPositionIndicator];
            }
                break;
        }
    
        return  [NSString stringWithFormat:@"    %@ - %@",[optionsLantern objectAtIndex:section],theDetail];
    
    }
    

    
    
    
    
    
    
    return @"";
}



-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    
    //int sectionReference = section;
    //if ( sectionReference >= LANTERNTAG_START)
    //    sectionReference = sectionReference - LANTERNTAG_START;
    
    UIButton* result = [UIButton buttonWithType:UIButtonTypeCustom];
    
    [result addTarget:self action:@selector(sectionButtonTouchUpInside:) forControlEvents:UIControlEventTouchUpInside];
    
   // NSLog(@"VIEW FOR HEADER currentSection %d ",currentSection);
    
    
    
    UITableView *myTableView;
    
    if (hallOrLantern == hpv_OPTIONS_Hall)
    {
        myTableView = tblHallFixtures;
    }
    else
    {
        myTableView = tblLanternFixtures;
    }
    
    
    if( (currentSection != section) || (tableView != myTableView) )
    {
        result.backgroundColor =  Rgb2UIColor(229, 229, 229);//[UIColor lightGrayColor];
        [result setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [result setTitleColor:[UIColor blackColor] forState:UIControlStateHighlighted];
        [result setTitle:[self titleForSectionDetailed:tableView titleForHeaderInSection:section ] forState:UIControlStateNormal];
    }
    else
    {
        result.backgroundColor =  [UIColor blackColor];// Rgb2UIColor(236, 28, 36);//[UIColor blueColor];
        [result setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [result setTitleColor:[UIColor whiteColor] forState:UIControlStateHighlighted];
        [result setTitle:[self titleForSection:tableView titleForHeaderInSection:section ] forState:UIControlStateNormal];
    }
    
    if (isAiPhone) {
        [result.titleLabel setFont:[UIFont systemFontOfSize:10.0f]];
    } else {
        [result.titleLabel setFont:[UIFont systemFontOfSize:14.0f]];
    }
    
   // [result.titleLabel setTextAlignment: NSTextAlignmentLeft];
    //result.titleLabel.textAlignment=NSTextAlignmentLeft;
    
    result.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    result.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    
    
    if ( tableView == tblHallFixtures)
        result.tag = section;
    else
        result.tag = section + LANTERNTAG_START;
    
    return result;
    
}

-(NSArray*) indexPathsForSection:(int)section withNumberOfRows:(int)numberOfRows {
    
    NSMutableArray* indexPaths = [NSMutableArray new];
    
    for (int i = 0; i < numberOfRows; i++) {
        NSIndexPath* indexPath = [NSIndexPath indexPathForRow:i inSection:section];
        [indexPaths addObject:indexPath];
    }
    
    return indexPaths;
}

-(void)sectionButtonTouchUpInside:(UIButton*)sender {
    
   // NSLog(@"currentSection %d  ButtonTag %d",currentSection, (int)sender.tag);
    
    int previousSection = currentSection;
    
    
    int sectionCollapsed = -1;
    int tableCollapsed = -1;
    
    
    UITableView *myTableView;
    
    if (hallOrLantern == hpv_OPTIONS_Hall)
    {
        myTableView = tblHallFixtures;
    }
    else
    {
         myTableView = tblLanternFixtures;
    }
    
    [myTableView beginUpdates];
    
    if ( currentSection != -1 )
    {
        bool shouldCollapsePrevious;
        
        if (hallOrLantern == hpv_OPTIONS_Hall)
        {
            shouldCollapsePrevious= [_collapsedSectionsHall containsObject:@(currentSection)];
        }
        else
        {
            shouldCollapsePrevious= [_collapsedSectionsLantern containsObject:@(currentSection)];
        }
        
        if (shouldCollapsePrevious)
        {
            
            sectionCollapsed = currentSection;
            tableCollapsed = hallOrLantern;
            
            
            int numOfRows;
            
            numOfRows = (int)[myTableView numberOfRowsInSection:currentSection];
                
            
            if (hallOrLantern == hpv_OPTIONS_Hall)
            {
                [_collapsedSectionsHall removeObject:@(currentSection)];
            }
            else
            {
                [_collapsedSectionsLantern removeObject:@(currentSection)];
            }

            
            NSArray* indexPaths = [self indexPathsForSection:currentSection withNumberOfRows:numOfRows];
            [myTableView deleteRowsAtIndexPaths:indexPaths withRowAnimation:UITableViewRowAnimationTop];
            
        }
        
        currentSection = -1;
        
        [myTableView reloadSections: [NSIndexSet indexSetWithIndex:previousSection] withRowAnimation:UITableViewRowAnimationNone];
        
    }
    
    [myTableView endUpdates];
    //[NSThread sleepForTimeInterval:0.6];  //wait a bit for the animation
    
    // [myTableView reloadData];  // make sure that the last header turned grey ( not selected )
    int section = (int)sender.tag;
    bool shouldExpand;
    
    
    if (section >= LANTERNTAG_START)
    {
        section = section - LANTERNTAG_START;
        myTableView = tblLanternFixtures;
        hallOrLantern = hpv_OPTIONS_Lantern;
        shouldExpand = ![_collapsedSectionsLantern containsObject:@(section)];
    }
    else
    {
        myTableView = tblHallFixtures;
        hallOrLantern = hpv_OPTIONS_Hall;
        shouldExpand = ![_collapsedSectionsHall containsObject:@(section)];
    }
    
    
   // NSLog(@"currentSection %d  ButtonTag %d",currentSection, (int)sender.tag);
  
    
    [myTableView beginUpdates];
    
    if ( shouldExpand && !( tableCollapsed==hallOrLantern && sectionCollapsed== section ) ) // should expand oly if it was not just collpased
    {
        currentSection = section;
        
        sender.backgroundColor = Rgb2UIColor(236, 28, 36);// [UIColor blackColor];// Rgb2UIColor(236, 28, 36);//[UIColor blueColor];
        
        if (hallOrLantern == hpv_OPTIONS_Hall)
        {
            [_collapsedSectionsHall addObject:@(currentSection)];
        }
        else
        {
            [_collapsedSectionsLantern addObject:@(currentSection)];
        }
      
        int numOfRows = 1;
        
        NSArray* indexPaths = [self indexPathsForSection:currentSection withNumberOfRows:numOfRows];
        
        [myTableView insertRowsAtIndexPaths:indexPaths withRowAnimation:UITableViewRowAnimationTop];
        
        [myTableView reloadSections: [NSIndexSet indexSetWithIndex:currentSection] withRowAnimation:UITableViewRowAnimationNone];
        
       // NSLog(@"SET currentSection %d ",currentSection);
        
    }
    else
    {
        currentSection = -1;
    }
    
    [myTableView endUpdates];
    
    
    if (  currentSection != -1 )
    {
    
        if (hallOrLantern == hpv_OPTIONS_Hall)
        {
            
            [tblHallFixtures scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:currentSection] atScrollPosition:UITableViewScrollPositionNone  animated:YES];
        }
        else
        {
            [tblLanternFixtures scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:currentSection] atScrollPosition:UITableViewScrollPositionNone  animated:YES];
        }
    }
    
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    //static NSString *CellIdentifier = @"Cell";
    
    //UITableViewCell *cell;// = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
   
    //cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    
    NSString *cellIdentifier = nil;
    JTTransformableTableViewCell *cell = nil;
    cellIdentifier = @"UnfoldingTableViewCell";
    
    
    if (cell == nil) {
        cell = [JTTransformableTableViewCell transformableTableViewCellWithStyle:JTTransformableTableViewCellStyleUnfolding
                                                                 reuseIdentifier:cellIdentifier];
        cell.textLabel.adjustsFontSizeToFitWidth = YES;
        cell.textLabel.textColor = [UIColor whiteColor];
    }
    cell.tintColor =  Rgb2UIColor(236, 28, 36); // red //[UIColor blueColor];
    
    if (isAiPhone) {
        cell.finishedHeight = 30;
    } else {
        cell.finishedHeight = COMMITING_CREATE_CELL_HEIGHT;
    }
    
    
    // Configure the cell...
   // NSLog(@"CELL FOR ROW %d ",(int)indexPath.row );
    
    [cell setBackgroundColor:[UIColor clearColor]];
    UILabel *textLable = [[UILabel alloc] initWithFrame:CGRectZero];
    
    cell.accessoryView = nil;
    cell.accessoryType = UITableViewCellAccessoryNone;
    
   // cell.backgroundColor =  Rgb2UIColor(229, 229, 229);
    
    cell.contentView.backgroundColor = [UIColor clearColor];
    
    textLable.backgroundColor = [UIColor clearColor];
    
    [self setupHorizontalPickerView:currentSection];
    
    //[cell addSubview:self.hPickerView];

    
    return cell;
}


-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    // change the height of cell over .6 of a second
    cell.layer.opacity = 1;
    
    CGRect myFrame = cell.frame;
    
    myFrame.size.height = 0;
    
    cell.frame= myFrame;
    
    [self.hPickerView removeFromSuperview]; // since will get re added after animation;
    
    [UIView animateWithDuration:0.6
                     animations:^{
        
                         CGRect myFrame = cell.frame;
                         if (isAiPhone) {
                             myFrame.size.height = 30;
                         } else {
                             myFrame.size.height = 50;
                         }
                         cell.frame= myFrame;
                         cell.layer.opacity = 1;
    
                     }
                     completion:^(BOOL finished){
                         [cell addSubview:self.hPickerView];
                     }];
}



#pragma mark - Table view delegate

#pragma mark - HorizontalPickerView Inintialization
- (void)setupHorizontalPickerView:(int)thePickerOptions {
    
    self.hPickerView = nil;
    
    
    activeHvPicker = thePickerOptions;
    
    
    
    if (thePickerOptions < 0)
        return;
    
    if ( hallOrLantern == hpv_OPTIONS_Hall )
    {
    
        switch(activeHvPicker)
        {
            case hpv_HALL_Type:
            {
                hvPickerActive = settingGenType;
                activeHvSelection = (int)myLantern.fType;
                activeState = [settingStatesHall objectAtIndex:hpv_HALL_Type];
            }
                break;
            case hpv_HALL_Style:
            {
                hvPickerActive = settingGenStyle;
                activeHvSelection =(int)myLantern.fStyle;
                activeState = [settingStatesHall objectAtIndex:hpv_HALL_Style];
                
            }
                break;
            case hpv_HALL_Finish:
            {
                hvPickerActive = settingGenFinish;
                activeHvSelection =(int)myLantern.fFinish;
                activeState = [settingStatesHall objectAtIndex:hpv_HALL_Finish];
            }
                break;
            case hpv_HALL_Width:
            {
                hvPickerActive = settingHallWidth;
                activeHvSelection = (int)myStation.fWidth;
                activeState = [settingStatesHall objectAtIndex:hpv_HALL_Width];
            }
                break;
            case hpv_HALL_Height:
            {
                hvPickerActive = settingHallHeight;
                activeHvSelection = (int)myStation.fHeight;
                activeState = [settingStatesHall objectAtIndex:hpv_HALL_Height];
            }
                break;
            case hpv_HALL_FireService:
            {
                hvPickerActive = settingHallFireService;
                activeHvSelection = (int)myStation.fFireService;
                activeState = [settingStatesHall objectAtIndex:hpv_HALL_FireService];
            }
                break;
            case hpv_HALL_ApendixOH:
            {
                hvPickerActive = settingHallApendixOH;
                activeHvSelection = (int)myStation.fAppendix;
                activeState = [settingStatesHall objectAtIndex:hpv_HALL_ApendixOH];
            }
                break;
        }
    }
    else
    {
        
        switch(activeHvPicker)
        {

            case hpv_LANTERN_Type:
            {
                hvPickerActive = settingGenType;
                activeHvSelection = (int)myLantern.fType;
                activeState = [settingStatesLantern objectAtIndex:hpv_LANTERN_Type];
            }
                break;
            case hpv_LANTERN_Style:
            {
                hvPickerActive = settingGenStyle;
                activeHvSelection =(int)myLantern.fStyle;
                activeState = [settingStatesLantern objectAtIndex:hpv_LANTERN_Style];
                
            }
                break;
            case hpv_LANTERN_Finish:
            {
                hvPickerActive = settingGenFinish;
                activeHvSelection =(int)myLantern.fFinish;
                activeState = [settingStatesLantern objectAtIndex:hpv_LANTERN_Finish];
            }
                break;
                

            case hpv_LANTERN_Width:
            {
                hvPickerActive = settingLanternWidth;
                activeHvSelection = (int)myLantern.fWidth;
                activeState = [settingStatesLantern objectAtIndex:hpv_LANTERN_Width];
            }
                break;
                
            case hpv_LANTERN_Height:
            {
                hvPickerActive = settingLanternHeight;
                activeHvSelection = (int)myLantern.fHeight;
                activeState = [settingStatesLantern objectAtIndex:hpv_LANTERN_Height];
            }
                break;
                
            case hpv_LANTERN_Orientation:
            {
                hvPickerActive = settingLanternOrientation;
                activeHvSelection = (int)myLantern.fOrientation;
                activeState = [settingStatesLantern objectAtIndex:hpv_LANTERN_Orientation];
            }
                break;
                
            case hpv_LANTERN_ArrowStyle:
            {
                hvPickerActive = settingLanternArrowStyle;
                activeHvSelection = (int)myLantern.fArrowStyle;
                activeState = [settingStatesLantern objectAtIndex:hpv_LANTERN_ArrowStyle];
            }
                break;
                
            case hpv_LANTERN_PositionIndicator:
            {
                hvPickerActive = settingLanternPositionIndicator;
                activeHvSelection = (int)myLantern.fPositionIndicator;
                activeState = [settingStatesLantern objectAtIndex:hpv_LANTERN_PositionIndicator];
            }
                break;
        }
    }
    
    
    CGRect tmpFrame;
    if(isAiPhone)
        tmpFrame = CGRectMake(10,0,290,30);
    else
        tmpFrame = CGRectMake(10,0,360,40);
    
    
    
	self.hPickerView = [[V8HorizontalPickerView alloc] initWithFrame:tmpFrame];
	self.hPickerView.backgroundColor   = Rgb2UIColor(236, 28, 36);
	self.hPickerView.selectedTextColor = [UIColor whiteColor];
	self.hPickerView.textColor   = [UIColor whiteColor];
	self.hPickerView.delegate    = self;
	self.hPickerView.dataSource  = self;
    self.hPickerView.clipsToBounds = YES;
    if(isAiPhone)
    {
        self.hPickerView.elementFont = [UIFont boldSystemFontOfSize:10.0f];
        self.hPickerView.selectionPoint = CGPointMake(155, 0);
    }
    else
    {
        self.hPickerView.elementFont = [UIFont boldSystemFontOfSize:14.0f];
        self.hPickerView.selectionPoint = CGPointMake(190, 0);
    }
    // add carat or other view to indicate selected element
	UIImageView *indicator = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"indicator"]];
	self.hPickerView.selectionIndicatorView = indicator;
    
    // add gradient images to left and right of view if desired
    UIImageView *leftFade = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"left_fade"]];
    self.hPickerView.leftEdgeView = leftFade;
    
    UIImageView *rightFade = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"right_fade"]];
    self.hPickerView.rightEdgeView = rightFade;
    
    
    // set the intial value of the picker
    [self.hPickerView scrollToElement:activeHvSelection animated:NO];
    
}



-(void) updateHorizontalSelection:(unsigned int) newSelection;
{
    if ( [[activeState objectAtIndex:newSelection] floatValue] == itemNotActive )
    {
        // item is not active so re set pick wheel to previewous
        
        [self.hPickerView scrollToElement:activeHvSelection animated:NO];
        
        return;
        
    }

    activeHvSelection = newSelection;
    
    
    if ( activeHvPicker <= hpv_HALL_Finish)
    {
        // this is the general stuff
        switch(activeHvPicker)
        {
            case hpv_HALL_Type:
            {
                myLantern.fType = activeHvSelection;
                myStation.fType = activeHvSelection;
                
                [settingStateLanternHeight replaceObjectAtIndex:1 withObject:[NSNumber numberWithFloat:itemActive]];
                [settingStateHallWidth replaceObjectAtIndex:1 withObject:[NSNumber numberWithFloat:itemActive]];
                
            }
                break;
            case hpv_HALL_Style:
            {
                myLantern.fStyle = activeHvSelection;
                myStation.fStyle = activeHvSelection;
                
                // 6" not allowed change to 8" for Gilda Curve
                if ((myLantern.fHeight == 1) && (activeHvSelection == STYLE_GildaCurveSurfaceMount) )
                {
                    if (myStation.fWidth == 1 )
                    {
                        myStation.fWidth = 2; // 8"
                    }
                    if (myLantern.fHeight == 1 )
                    {
                        myLantern.fHeight = 2; // 8"
                    }
                }
                
            }
                break;
            case hpv_HALL_Finish:
            {
                myLantern.fFinish = activeHvSelection;
                myStation.fFinish = activeHvSelection;
            }
                break;
                
            default:
                break;
        }

        
    }
    else
    {
        // this is the specific Hall or Lantern stuff
        // decide if lantern or hall station is active;
        if ( hallOrLantern == hpv_OPTIONS_Hall )
        {
            switch (activeHvPicker) {
                case hpv_HALL_Width:
                {
                    myStation.fWidth = activeHvSelection;
                }
                    break;
                case hpv_HALL_Height:
                {
                    myStation.fHeight = activeHvSelection;
                }
                    break;
                case hpv_HALL_FireService:
                {
                    myStation.fFireService = activeHvSelection;
                    
                    // Check Special case here:
                    // If fire service selected, 12" height is not allowed.  (If selection made while 12" is active, change to 20")
                    // relative to code if fireservice == 0 then height can not be 12 or (0) must be 20 or (1) if 12 is active
                    
                    // also
                    //If fire service selected, AND Appendix O/H is active, 20"  height is not allowed.  (If selection made while 20" is active, change to 24")
                    
                    //  Note check the rules when displaying the options screeen.
                    
                    if (myStation.fFireService == FS_YES)
                    {
                        if (myStation.fAppendix == APPENDIX_YES)
                        {
                            myStation.fHeight = HHEIGHT_24; // 24"
                        }
                        else if (myStation.fHeight == 0) {
                            myStation.fHeight = HHEIGHT_20; // 20"
                        }
                    }
                    
                    
                    
                }
                    break;
                case hpv_HALL_ApendixOH:
                {
                    myStation.fAppendix = activeHvSelection;
                    
                    //Check Special case here:
                    
                    /// If Appendix O is selected, 12" height is not allowed.  (If selection made while 12" is active, change to 20"
                    // realative to code if apendinx == 0 then height can not be 12 or (0 )  must be 20 or (1) if 12 is active
                    
                    // also
                    //If appendix O/H is selected, AND fire service is active, 20"  height is not allowed.  (If selection made while 20" is active, change to 24")
                    
                    if (myStation.fAppendix == APPENDIX_YES)
                    {
                        if (myStation.fFireService == FS_YES)
                        {
                            myStation.fHeight = HHEIGHT_24; // 24"
                            
                        }
                        else if (myStation.fHeight == 0) {
                            myStation.fHeight = HHEIGHT_20; // 20"
                        }
                        
                        
                        // extra appendix rule
                        // If Appendix O/H is selected, 4" Width is not allowed. (If selection made while 4" active, change to 6")
                        // but if gilda curve selected must be 8"
                        
                        if (myStation.fWidth == HWIDTH_4) {
                            myStation.fWidth = HWIDTH_6; // 6"
                            // if Gilda Curve is selected, 6" not possible.
                            if (myLantern.fStyle == STYLE_GildaCurveSurfaceMount)
                            {
                                myStation.fWidth = HWIDTH_8; //8"
                            }
                        }
                    }
                    
                    
                }
                    break;
                    
                default:
                    break;
            }
            
            
        }
        else
        {
            
            switch (activeHvPicker) {
                case hpv_LANTERN_Width:
                {
                    myLantern.fWidth = activeHvSelection;
                }
                    break;
                case hpv_LANTERN_Height:
                {
                    myLantern.fHeight = activeHvSelection;
                }
                    break;
                case hpv_LANTERN_Orientation:
                {
                    myLantern.fOrientation = activeHvSelection;
                }
                    break;
                case hpv_LANTERN_ArrowStyle:
                {
                    myLantern.fArrowStyle = activeHvSelection;
                    
                    // when arrow style changes
                    
                    if (myLantern.fArrowStyle == LARROW_Vandal) {  // Vandal
                        if (myLantern.fHeight == LHEIGHT_4_45) // 4-4.45"
                        {
                            // IF Style guilda Curve Must be 8"
                            
                            // if Gilda Curve is selected, 6" not possible.
                            if (myLantern.fStyle == STYLE_GildaCurveSurfaceMount)
                            {
                                // 8" only option for if Gilda Curve
                                myLantern.fHeight = LHEIGHT_8; /// 8"
                            }
                            else
                            {
                                // enable 6"
                                myLantern.fHeight = LHEIGHT_6; /// 6"
                            }
                        }
                    }
                    else if (myLantern.fArrowStyle == LARROW_PIonly) {  //PI ONLY
                        if (myLantern.fPositionIndicator== LPI_None)
                        {
                            myLantern.fPositionIndicator= LPI_16segment; /// 16 segment
                        }
                    }
                    
                    
                    // check this here are well as when setting Position indicator
                    if ((myLantern.fPositionIndicator == LPI_16segment ) && (myLantern.fArrowStyle != LARROW_PIonly))// 16 segment select and ADA or vandal arrow
                    {
                        myLantern.fWidth = LWIDTH_20;  // 20"
                    }
                    
                    if ((myLantern.fPositionIndicator == LPI_16segment) && (myLantern.fArrowStyle == LARROW_PIonly))// 16 segment select and ADA or vandal arrow
                    {
                        if (myLantern.fWidth == LWIDTH_12) {
                            myLantern.fWidth = LWIDTH_16; //16"
                        }
                    }

                }
                    break;
                case hpv_LANTERN_PositionIndicator:
                {
                    myLantern.fPositionIndicator = activeHvSelection;
                    
                    
                    // when PI changes
                    
                    if ((myLantern.fPositionIndicator == LPI_16segment) && (myLantern.fArrowStyle != LARROW_PIonly))// 16 segment select and ADA or vandal arrow
                    {
                        myLantern.fWidth = LWIDTH_20;  // 20"
                    }
                    
                    if ((myLantern.fPositionIndicator == LPI_None) && (myLantern.fArrowStyle == LARROW_PIonly))// NONE  && PI ONLY
                    {
                        myLantern.fArrowStyle = LARROW_TraditionalADA; // Traditiona/ ADA
                    }

                }
                    break;
                    
                default:
                    break;
            }
            
        }
    
    }
    
    [self checkRules];
    
    [myLantern updateName];
    [myStation updateName];
    
    [self updateImagesToBeDispalyed];
    
    
    // force the detailed header name to be updated.
    [tblHallFixtures beginUpdates];
    
    for ( int i = 0; i< [tblHallFixtures numberOfSections]; i++)
    {
        [tblHallFixtures reloadSections: [NSIndexSet indexSetWithIndex:i] withRowAnimation:UITableViewRowAnimationNone];
    }
    
    [tblHallFixtures endUpdates];

    [tblLanternFixtures beginUpdates];
    
    for ( int i = 0; i< [tblLanternFixtures numberOfSections]; i++)
    {
        [tblLanternFixtures reloadSections: [NSIndexSet indexSetWithIndex:i] withRowAnimation:UITableViewRowAnimationNone];
    }
    
    [tblLanternFixtures endUpdates];

    
   
}



#pragma mark - HorizontalPickerView DataSource Methods
- (NSInteger)numberOfElementsInHorizontalPickerView:(V8HorizontalPickerView *)picker {
	return [hvPickerActive count];
}

#pragma mark - HorizontalPickerView Delegate Methods
/*
 - (NSString *)horizontalPickerView:(V8HorizontalPickerView *)picker titleForElementAtIndex:(NSInteger)index {
	return [hvPickerActive objectAtIndex:index];
}
*/


- (UIView *)horizontalPickerView:(V8HorizontalPickerView *)picker viewForElementAtIndex:(NSInteger)index;
{
    CGSize constrainedSize = CGSizeMake(MAXFLOAT, MAXFLOAT);
	NSString *text = [hvPickerActive objectAtIndex:index];
	
    CGSize textSize;
    
    UIFont *font;
    
    if ( isAiPhone )
    {
        font = [UIFont systemFontOfSize:10.0f];
    }
    else
    {
        font = [UIFont systemFontOfSize:14.0f];
    }
    
    NSAttributedString *attributedText =
    [[NSAttributedString alloc]
     initWithString:text
     attributes:@
     {
     NSFontAttributeName: font
     }];
    CGRect rect = [attributedText boundingRectWithSize:constrainedSize
                                               options:NSStringDrawingUsesLineFragmentOrigin
                                               context:nil];
    textSize = rect.size;

    
	
    float theWidth;
    
    if ( isAiPhone )
         theWidth = textSize.width + 30.0f; // 20px padding on each side
    else
        theWidth = textSize.width + 40.0f; // 20px padding on each side
    
    CGRect labelFrame     = CGRectMake(0, 0, theWidth, 40);
    
    
	UILabel *theLable = [[UILabel alloc] initWithFrame:labelFrame];
    
	theLable.textAlignment   = NSTextAlignmentCenter;
	theLable.backgroundColor = [UIColor clearColor];
	theLable.text            = [hvPickerActive objectAtIndex:index];
    if ( isAiPhone )
        theLable.font = [UIFont systemFontOfSize:10.0f];
    else
        theLable.font = [UIFont boldSystemFontOfSize:14.0f];
    
    if ( [[activeState objectAtIndex:index] floatValue] == itemNotActive )
        theLable.textColor=[UIColor lightGrayColor];
    else
        theLable.textColor=[UIColor whiteColor];

    
	return theLable;
}



- (NSInteger) horizontalPickerView:(V8HorizontalPickerView *)picker widthForElementAtIndex:(NSInteger)index {
	CGSize constrainedSize = CGSizeMake(MAXFLOAT, MAXFLOAT);
	NSString *text = [hvPickerActive objectAtIndex:index];
    
	CGSize textSize;
    
    UIFont *font;
    if ( isAiPhone )
        font = [UIFont systemFontOfSize:10.0f];
    else
        font = [UIFont systemFontOfSize:14.0f];
    
    NSAttributedString *attributedText =
    [[NSAttributedString alloc]
     initWithString:text
     attributes:@
     {
     NSFontAttributeName: font
     }];
    CGRect rect = [attributedText boundingRectWithSize:constrainedSize
                                               options:NSStringDrawingUsesLineFragmentOrigin
                                               context:nil];
    textSize = rect.size;
    
    
    
    
    if ( isAiPhone )
        return textSize.width + 30.0f; // 20px padding on each side
    else
        return textSize.width + 40.0f; // 20px padding on each side
    
}


- (void)horizontalPickerView:(V8HorizontalPickerView *)picker didSelectElementAtIndex:(NSInteger)index {
    
    // handel selection here
    [self updateHorizontalSelection:(int)index];
    
}




#pragma mark ---- scrollView delegate methods ----

- (void)scrollviewZoomToFullSize
{
    CGSize scrollViewSize = self.scrollView.bounds.size;
    
    CGFloat w = scrollViewSize.width; // / self.scrollView.minimumZoomScale;
    CGFloat h = scrollViewSize.height; // / self.scrollView.minimumZoomScale;
    CGFloat x = 0;
    CGFloat y = 0;
    
    CGRect rectToZoomTo = CGRectMake(x, y, w, h);
    
    [self.scrollView zoomToRect:rectToZoomTo animated:NO];
}

- (void)scrollViewDoubleTapped:(UITapGestureRecognizer*)recognizer {
    // Get the location within the image view where we tapped
    CGPoint pointInView = [recognizer locationInView:self.containerView];
    
    // Get a zoom scale that's zoomed in slightly, capped at the maximum zoom scale specified by the scroll view
    CGFloat newZoomScale = self.scrollView.zoomScale * 1.5f;
    newZoomScale = MIN(newZoomScale, self.scrollView.maximumZoomScale);
    
    // Figure out the rect we want to zoom to, then zoom to it
    CGSize scrollViewSize = self.scrollView.bounds.size;
    
    CGFloat w = scrollViewSize.width / newZoomScale;
    CGFloat h = scrollViewSize.height / newZoomScale;
    CGFloat x = pointInView.x - (w / 2.0f);
    CGFloat y = pointInView.y - (h / 2.0f);
    
    CGRect rectToZoomTo = CGRectMake(x, y, w, h);
    
    [self.scrollView zoomToRect:rectToZoomTo animated:YES];
}

- (void)scrollViewTwoFingerTapped:(UITapGestureRecognizer*)recognizer {
    // Zoom out slightly, capping at the minimum zoom scale specified by the scroll view
    CGFloat newZoomScale = self.scrollView.zoomScale / 1.5f;
    newZoomScale = MAX(newZoomScale, self.scrollView.minimumZoomScale);
    [self.scrollView setZoomScale:newZoomScale animated:YES];
}



-(UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView{
    return containerView;
}

@end
