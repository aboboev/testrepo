//
//  HallLantern.h
//  MadFixtures
//
//  Created by Antonio Pena on 2012-12-30.
//  Copyright (c) 2012 Kioaxis. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HallLantern : NSObject{
    
    NSString *fGroup;
    NSInteger fType;
    NSInteger fStyle;
    NSInteger fFinish;
    NSInteger fWidth;
    NSInteger fHeight;
    NSInteger fOrientation;
    NSInteger fArrowStyle;
    NSInteger fPositionIndicator;
    
    NSString *imgName;
    NSString *imgNameZoom;
    
    NSString *imgDescription;
    
    
    NSMutableArray *options;
    NSMutableArray *finishoptions;
    
    NSMutableArray *dType;
    NSMutableArray *dStyle;
    NSMutableArray *dFinish;
    NSMutableArray *dWidth;
    NSMutableArray *dHeight;
    NSMutableArray *dOrientation;
    NSMutableArray *dArrowStyle;
    NSMutableArray *dPositionIndicator;
    
}

-(id) initGroup:(NSString *)fgroup type:(NSInteger)ftype style:(NSInteger )fstyle finish:(NSInteger)ffinish width:(NSInteger)fwidth height:(NSInteger)fheight orientation:(NSInteger)forientation arrowstyle:(NSInteger)farrowstyle positionindicator:(NSInteger)fpositionindicator;

-(void)updateName;

@property (nonatomic, copy) NSString *fGroup;
@property (assign, nonatomic) NSInteger fType;
@property (assign, nonatomic) NSInteger fStyle;
@property (assign, nonatomic) NSInteger fFinish;
@property (assign, nonatomic) NSInteger fWidth;
@property (assign, nonatomic) NSInteger fHeight;
@property (assign, nonatomic) NSInteger fOrientation;
@property (assign, nonatomic) NSInteger fArrowStyle;
@property (assign, nonatomic) NSInteger fPositionIndicator;


@property (nonatomic, copy) NSString *imgName;
@property (nonatomic, copy) NSString *imgNameZoom;
@property (nonatomic, copy) NSString *imgDescription;

@end

