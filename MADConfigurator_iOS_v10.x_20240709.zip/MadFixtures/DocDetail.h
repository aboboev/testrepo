//
//  DocDetail.h
//  MadFixtures
//
//  Created by Antonio Pena on 12-03-19.
//  Copyright (c) 2012 Kioaxis. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DocDetail : NSObject

@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *subtitle;
@property (nonatomic, copy) NSString *filename;



@end
