//
//  TouchScreenPagerCell.c
//  MadFixtures
//
//  Created by Alex Yuan on 2024/6/14.
//  Copyright © 2024 Mad Elevator. All rights reserved.
//

#import "TouchScreenPagerCell.h"

@implementation TouchScreenPagerCell

/*- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.webView = [[WKWebView alloc] initWithFrame:self.bounds];
        [self.contentView addSubview:self.webView];
    }
    return self;
}*/

@end
