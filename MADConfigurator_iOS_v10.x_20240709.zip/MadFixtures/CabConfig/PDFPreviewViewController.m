//
//  PDFPreviewViewController.m
//  MadCabConfigurator
//
//  Created by Alex on 2/16/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import "PDFPreviewViewController.h"
#import "CCRequestData.h"
#import "CCBaseSetting.h"
#import "CCSettingItemView.h"
#import <MessageUI/MessageUI.h>
#import "Constants.h"
#import "PDFItem.h"
#import "Utils.h"

#define PORTRAIT_TITLE_FONT_SIZE          ([UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPad) ? 14: 7
#define LANDSCAPE_TITLE_FONT_SIZE          ([UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPad) ? 20 : 16

#define PORTRAIT_DETAIL_FONT_SIZE          ([UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPad) ? 10 : 5
#define LANDSCAPE_DETAIL_FONT_SIZE          ([UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPad) ? 14: 10

#define PORTRAIT_NUM_HEIGHT          ([UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPad) ? 18 : 9
#define LANDSCAPE_NUM_HEIGHT          ([UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPad) ? 24 : 22

#define PORTRAIT_OTHER_FONT_SIZE          ([UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPad) ? 12 : 6
#define LANDSCAPE_OTHER_FONT_SIZE          ([UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPad) ? 15 : 11

@interface PDFPreviewViewController ()
{
    NSMutableData * pdfData;
    IBOutlet NSLayoutConstraint * bottomHeightConstraint;
    BOOL isLandscape;
    BOOL isSS;
}
@end

@implementation PDFPreviewViewController

#pragma mark ---- Orientation ----
- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskLandscape;
}

- (BOOL)shouldAutorotate {
    return NO;
}

- (void) initUI {
    
    for (UIButton * button in buttons) {
        button.layer.cornerRadius = 3;
    }
}

- (void) setUIElementsForOrientation:(UIInterfaceOrientation) orientation {
    isLandscape = YES; //UIInterfaceOrientationIsLandscape(orientation);
    
    /*if (UIInterfaceOrientationIsPortrait(orientation)) {
        leftTitleLabel.hidden = YES;
        rightTitleLabel.hidden = NO;
        topButtonsView.hidden = YES;
        bottomBarView.hidden = NO;
        bottomHeightConstraint.constant = 44;
    } else {*/
        leftTitleLabel.hidden = NO;
        rightTitleLabel.hidden = YES;
        topButtonsView.hidden = NO;
        bottomBarView.hidden = YES;
        bottomHeightConstraint.constant = 0;
    //}
    
    [self loadData];
}

- (void)loadData {
    if (self.data.isPDFCOP){
        [self populateListFrontSetting];
    }else{
        frontContainer.hidden = YES;
        
        [frontContainer addConstraint:[NSLayoutConstraint constraintWithItem:frontContainer attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:0]];
        
    }
    
    if (self.data.isPDFCabInterior){
        [self populateListBackSetting];
    }else{
        backContainer.hidden = YES;
        
        [backContainer addConstraint:[NSLayoutConstraint constraintWithItem:backContainer attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:0]];
    }
    
    if (self.data.isPDFHallFixtures){
        [self populateListHallSetting];
    }else{
        hallMainContainer.hidden = YES;
        [hallMainContainer addConstraint:[NSLayoutConstraint constraintWithItem:hallMainContainer attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:0]];
        
        hallTypicalContainer.hidden = YES;
        [hallTypicalContainer addConstraint:[NSLayoutConstraint constraintWithItem:hallTypicalContainer attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:0]];
    }
    
    
    /*for (UIView * v in componentStackView.arrangedSubviews) {
        if (v.tag == 100)
            continue;
        [componentStackView removeArrangedSubview:v];
        [v removeFromSuperview];
    }
    projectLabel.text = self.data.projName;
    
    NSDateFormatter * formatter = [[NSDateFormatter alloc] init];
    formatter.dateStyle = NSDateFormatterMediumStyle;
    
    dateLabel.text = [formatter stringFromDate:self.data.issuedDate];
    
    // list
    NSInteger no = 1;
    
    CCSettingItemView * materialFinishView = nil;
    NSString * materialFinishesDesc = @"";
    
    CCSettingItemView * handrailView = nil;
    NSString * handrailTypeDesc = @"";
    
    for (CCBaseSetting * setting in self.data.settings) {
        CCSettingItemView * sview = [CCSettingItemView view];
        [sview configWithSetting:setting no:no];
        
        if (isLandscape) {
            [sview.numLabel setFont:[UIFont systemFontOfSize:LANDSCAPE_TITLE_FONT_SIZE]];
            [sview.titleLabel setFont:[UIFont boldSystemFontOfSize:LANDSCAPE_TITLE_FONT_SIZE]];
            [sview.descLabel setFont:[UIFont systemFontOfSize:LANDSCAPE_DETAIL_FONT_SIZE]];
            [sview setNumLabelHeightConstant:LANDSCAPE_NUM_HEIGHT];
        } else {
            [sview.numLabel setFont:[UIFont systemFontOfSize:PORTRAIT_TITLE_FONT_SIZE]];
            [sview.titleLabel setFont:[UIFont boldSystemFontOfSize:PORTRAIT_TITLE_FONT_SIZE]];
            [sview.descLabel setFont:[UIFont systemFontOfSize:PORTRAIT_DETAIL_FONT_SIZE]];
            [sview setNumLabelHeightConstant:PORTRAIT_NUM_HEIGHT];
        }

        if ([setting.menuTitle hasPrefix:@"Wall Material Finish"] && materialFinishesDesc.length > 0 && materialFinishView) {
            materialFinishView.thumbImageView.image = [UIImage imageNamed:setting.fileName];
            materialFinishesDesc = [materialFinishesDesc stringByAppendingFormat:@"\n\n%@ : %@", setting.menuTitle, setting.desc];
            materialFinishView.descLabel.text = materialFinishesDesc;
            continue;
        }
        
        if ([setting.menuTitle hasPrefix:@"Finish Below Handrail"] && materialFinishesDesc.length > 0 && materialFinishView) {
            materialFinishesDesc = [materialFinishesDesc stringByAppendingFormat:@"\n\n%@: %@", setting.menuTitle, setting.desc];
            materialFinishView.descLabel.text = materialFinishesDesc;
            continue;
        }
        
        if ([setting.menuTitle hasPrefix:@"Bumper Rail"] && handrailTypeDesc.length > 0 && handrailView) {
            handrailTypeDesc = [handrailTypeDesc stringByAppendingFormat:@"\n\n%@: %@", setting.menuTitle, [setting getDescFromMany:isSS]];
            handrailView.descLabel.text = handrailTypeDesc;
            continue;
        }
        ////
        if ([setting.menuTitle isEqualToString:@"Front / Reveal Finish"]) {
            isSS = [setting.fileName isEqualToString:@"no4Brushed.jpg"];
            materialFinishesDesc = [NSString stringWithFormat:@"%@: %@", setting.menuTitle, setting.desc];
            materialFinishView = sview;
            materialFinishView.titleLabel.text = @"Material Finishes";
        }
        
        if ([setting.menuTitle hasPrefix:@"Handrail Type"]) {
            handrailTypeDesc = [NSString stringWithFormat:@"Handrail Type: %@", [setting getDescFromMany:isSS]];
            handrailView = sview;
            handrailView.descLabel.text = handrailTypeDesc;
        }
        
        if ([setting.menuTitle hasPrefix:@"Ceiling"]) {
            sview.descLabel.text = [setting getDescFromMany:isSS];
        }
        
        if (no <= 8){
            [componentBackStackView insertArrangedSubview:sview atIndex:no - 1];
        }else{
            [componentStackView insertArrangedSubview:sview atIndex:no - 9];
        }
        no++;
    }
    
    // Cropping Front Image, so make it larger for COP view
    UIImage * originImg = self.data.frontImage;
    UIImage * croppedImg = [self imageByCroppingImage:self.data.frontImage toSize:CGSizeMake(originImg.size.width * 0.7, originImg.size.height * 0.7)];
    frontImageView.image = croppedImg;
    backImageView.image = self.data.backImage;
    
    for (UILabel * label in infoLabels) {
        [label setFont:[UIFont boldSystemFontOfSize:(isLandscape) ? LANDSCAPE_OTHER_FONT_SIZE: PORTRAIT_OTHER_FONT_SIZE]];
    }
    for (UILabel * label in valueLabels) {
        [label setFont:[UIFont systemFontOfSize:(isLandscape) ? LANDSCAPE_OTHER_FONT_SIZE: PORTRAIT_OTHER_FONT_SIZE]];
    }
    
    [contactLabel setFont:[UIFont systemFontOfSize:(isLandscape) ? LANDSCAPE_OTHER_FONT_SIZE : PORTRAIT_OTHER_FONT_SIZE]];*/
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    pdfData = [NSMutableData new];
    isSS = NO;
    
    [self initUI];
    
    UIInterfaceOrientation cOri = [UIApplication sharedApplication].windows.firstObject.windowScene.interfaceOrientation;
    [self setUIElementsForOrientation:cOri];
    
    if (self.fromRFQ) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self submit:nil];
        });
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator {
    
    [coordinator animateAlongsideTransition:^(id<UIViewControllerTransitionCoordinatorContext> context)
     {
         UIInterfaceOrientation interfaceOrientation = (UIInterfaceOrientation)[[UIDevice currentDevice] orientation];
         
         [self setUIElementsForOrientation:interfaceOrientation];
     } completion:^(id<UIViewControllerTransitionCoordinatorContext> context)
     {
         
     }];
    
    [super viewWillTransitionToSize:size withTransitionCoordinator:coordinator];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (PDFItem *) generatePDFLine:(NSInteger) index title:(NSString *) title hallLanding:(NSString *) landing{
    PDFItem *pdfItem = [[PDFItem alloc] init];
    pdfItem.number = index;
    pdfItem.title = title;
    NSString * tempDescription = @"";
    
    NSString * lanternArrowType = @"";
    
    for (CCBaseSetting * setting in self.data.settings) {
        if ([title isEqualToString:@"COP Location"]){
            if ([setting.menuTitle isEqualToString:@"Front COP Selection"]){
                pdfItem.image1 = setting.fileName;
                pdfItem.content = setting.desc;
            }else if ([setting.menuTitle isEqualToString:@"Rear COP Selection"]){
                pdfItem.image2 = setting.fileName;
                pdfItem.content = [pdfItem.content stringByAppendingFormat:@" %@", setting.desc];
            }
        }else if ([title isEqualToString:@"Pushbutton Style"]){
            if ([setting.menuTitle isEqualToString:@"Interaction Type"]){
                pdfItem.content = setting.desc;
            }else if ([setting.menuTitle isEqualToString:@"Tactile Style"]){
                pdfItem.content = [pdfItem.content stringByAppendingFormat:@" %@", setting.desc];
                pdfItem.image1 = setting.fileName;
            }else if ([setting.menuTitle isEqualToString:@"Pushbutton"]){
                pdfItem.content = [pdfItem.content stringByAppendingFormat:@" %@ %@", setting.desc, tempDescription];
            }else if ([setting.menuTitle isEqualToString:@"Number of Floors"] || [setting.menuTitle isEqualToString:@"Touchscreen Size"]){
                tempDescription = setting.desc;
            }
        }else if ([title isEqualToString:@"Accessories & Details"]){
            if ([setting.menuTitle isEqualToString:@"Accessories"]){
                pdfItem.content = setting.desc;
            }
        }else if ([title isEqualToString:@"Wall Layout"]){
            if ([setting.menuTitle isEqualToString:@"Back Wall Layout"]){
                pdfItem.image1 = setting.fileName;
                pdfItem.content = setting.desc;
            }else if ([setting.menuTitle isEqualToString:@"Side Wall Layout"]){
                pdfItem.image2 = setting.fileName;
                pdfItem.content = [pdfItem.content stringByAppendingFormat:@"\n\n%@", setting.desc];
            }
        }else if ([title isEqualToString:@"Material Finishes"]){
            if ([setting.menuTitle isEqualToString:@"Front / Reveal Finish"]){
                pdfItem.content = [NSString stringWithFormat:@"Front / Reveal Finish: %@", setting.desc];
                isSS = [setting.fileName containsString:@"no4Brushed"];
            }else if ([setting.menuTitle isEqualToString:@"Wall Material Finish"]){
                pdfItem.image1 = setting.fileName;
                pdfItem.content = [pdfItem.content stringByAppendingFormat:@"\n\nMaterials: %@", setting.desc];
            }else if ([setting.menuTitle isEqualToString:@"Finish Below Handrail (optional)"]){
                pdfItem.content = [pdfItem.content stringByAppendingFormat:@"\n\nFinish Below Handrail: %@", setting.desc];
            }
        }else if ([title isEqualToString:@"Handrail"]){
            if ([setting.menuTitle isEqualToString:@"Location"]){
                pdfItem.content = [NSString stringWithFormat:@"Location: %@", setting.desc];
            }else if ([setting.menuTitle containsString:@"Handrail"]){
                pdfItem.image1 = setting.fileName;
                pdfItem.content = [pdfItem.content stringByAppendingFormat:@"\n\nHandrail: %@", [setting getDescFromMany:isSS]];
            }else if ([setting.menuTitle containsString:@"Bumper Rail"]){
                pdfItem.content = [pdfItem.content stringByAppendingFormat:@"\n\nBumper Rail: %@", [setting getDescFromMany:isSS]];
            }
        }else if ([title isEqualToString:@"Ceiling"]){
            if ([setting.menuTitle containsString:@"Ceiling"]){
                pdfItem.image1 = setting.fileName;
                pdfItem.content = [setting getDescFromMany:isSS];
            }
        }else if ([title isEqualToString:@"Other Details"]){
            if ([setting.menuTitle containsString:@"Door Opening"]){
                pdfItem.content = setting.desc;
            }else if ([setting.menuTitle containsString:@"Floor"]){
                pdfItem.content = [pdfItem.content stringByAppendingFormat:@", %@", setting.desc];
            }
        }else if ([title isEqualToString:@"Finish"]){
            if ([setting.menuTitle containsString:[NSString stringWithFormat:@"%@-hall_finish", landing]]){
                pdfItem.image1 = setting.fileName;
                pdfItem.content = [setting desc];
            }
        }else if ([title isEqualToString:@"Style"]){
            if ([setting.menuTitle containsString:[NSString stringWithFormat:@"%@-hall_style_mounting", landing]]){
                pdfItem.image1 = setting.fileName;
                pdfItem.content = [setting desc];
            }else if ([setting.menuTitle containsString:[NSString stringWithFormat:@"%@-hall_style_width", landing]]){
                pdfItem.content = [pdfItem.content stringByAppendingFormat:@", %@", setting.desc];
            }else if ([setting.menuTitle containsString:[NSString stringWithFormat:@"%@-hall_style_height", landing]]){
                pdfItem.content = [pdfItem.content stringByAppendingFormat:@", %@", setting.desc];
            }
        }else if ([title isEqualToString:@"Pushbutton"]){
            if ([setting.menuTitle containsString:[NSString stringWithFormat:@"%@-hall_pushbutton", landing]]){
                pdfItem.image1 = setting.fileName;
                pdfItem.content = [setting desc];
            }
        }else if ([title isEqualToString:@"Options"]){
            if ([setting.menuTitle containsString:[NSString stringWithFormat:@"%@-hall_options", landing]]){
                pdfItem.content = [setting desc];
                NSArray * arry = [setting.fileName componentsSeparatedByString:@", "];
                if (arry.count > 1){
                    pdfItem.image1 = arry[0];
                    pdfItem.image2 = arry[1];
                }else if (arry.count == 1){
                    pdfItem.image1 = arry[0];
                }
            }
        }else if ([title isEqualToString:@"Lantern"]){
            if ([setting.menuTitle containsString:[NSString stringWithFormat:@"%@-hall_lantern_arrow_type", landing]]){
                lanternArrowType = setting.desc;
                pdfItem.image1 = setting.fileName;
            }else if ([setting.menuTitle containsString:[NSString stringWithFormat:@"%@-hall_lantern_orientation", landing]] || [setting.menuTitle containsString:[NSString stringWithFormat:@"%@-hall_lantern_mounting", landing]] || [setting.menuTitle containsString:[NSString stringWithFormat:@"%@-hall_lantern_width", landing]] || [setting.menuTitle containsString:[NSString stringWithFormat:@"%@-hall_lantern_height", landing]]){
                    pdfItem.content = [pdfItem.content stringByAppendingFormat:@", %@", setting.desc];
            }else if ([setting.menuTitle containsString:[NSString stringWithFormat:@"%@-hall_lantern_pi", landing]]){
                if ([lanternArrowType isEqualToString:@""]){
                    // Nothing is selected on Arrow Type
                    if (!setting.desc){
                        // None is selected on Lantern PI
                        return nil;
                    }else{
                        pdfItem.content = [NSString stringWithFormat:@"%@%@", setting.desc, pdfItem.content];
                    }
                }else{
                    if (setting.desc){
                        pdfItem.content = [NSString stringWithFormat:@"%@, %@%@", lanternArrowType, setting.desc, pdfItem.content];
                    }else{
                        pdfItem.content = [NSString stringWithFormat:@"%@%@", lanternArrowType, pdfItem.content];
                    }
                }
            }
        }else if ([setting.menuTitle containsString:title]){
            pdfItem.image1 = setting.fileName;
            pdfItem.content = setting.desc;
            NSLog(@"%@, %@, %@, %@", setting.menuTitle, title, setting.fileName, setting.desc);
        }
    }
    
    return pdfItem;
}

- (void) populateListFrontSetting{
    NSArray * frontsAry = @[@"COP Type", @"COP Location", @"Position Indicator", @"Pushbutton Style", @"Fire Service", @"Accessories & Details"];
    
    for (UIView * v in componentFrontStackView.arrangedSubviews) {
        if (v.tag == 100)
            continue;
        [componentFrontStackView removeArrangedSubview:v];
        [v removeFromSuperview];
    }
    
    frontProjectLabel.text = self.data.projName;
    NSDateFormatter * formatter = [[NSDateFormatter alloc] init];
    formatter.dateStyle = NSDateFormatterMediumStyle;
    frontDateLabel.text = [formatter stringFromDate:self.data.issuedDate];
    
    for (int i = 0; i < frontsAry.count; i++){
        PDFItem * item = [self generatePDFLine:i + 1 title:frontsAry[i] hallLanding:@""];
        
        CCSettingItemView * sview = [CCSettingItemView view];
        [sview configWithPDFItem:item];
        [componentFrontStackView insertArrangedSubview:sview atIndex:item.number - 1];
    }
    
    // Cropping Front Image, so make it larger for COP view
    UIImage * originImg = self.data.frontImage;
    UIImage * croppedImg = [self imageByCroppingImage:self.data.frontImage toSize:CGSizeMake(originImg.size.width * 0.7, originImg.size.height * 0.7)];
    frontImageView.image = croppedImg;
    
//    for (UILabel * label in infoLabels) {
//        [label setFont:[UIFont systemFontOfSize:(isLandscape) ? LANDSCAPE_OTHER_FONT_SIZE: PORTRAIT_OTHER_FONT_SIZE]];
//    }
//    for (UILabel * label in valueLabels) {
//        UIFont *ft = label.font;
//        [ft fontWithSize:LANDSCAPE_OTHER_FONT_SIZE];
//        [label setFont:ft];
//    }
    
    //[contactFrontLabel setFont:[UIFont systemFontOfSize:(isLandscape) ? LANDSCAPE_OTHER_FONT_SIZE : PORTRAIT_OTHER_FONT_SIZE]];
}

- (void) populateListBackSetting{
    isSS = NO;
    NSArray * backsAry = @[@"Wall Layout", @"Binding / Edging", @"Material Finishes", @"Ceiling", @"Handrail", @"Other Details"];
    
    for (UIView * v in componentBackStackView.arrangedSubviews) {
        if (v.tag == 100)
            continue;
        [componentBackStackView removeArrangedSubview:v];
        [v removeFromSuperview];
    }
    
    backProjectLabel.text = self.data.projName;
    NSDateFormatter * formatter = [[NSDateFormatter alloc] init];
    formatter.dateStyle = NSDateFormatterMediumStyle;
    backDateLabel.text = [formatter stringFromDate:self.data.issuedDate];
    
    for (int i = 0; i < backsAry.count; i++){
        PDFItem * item = [self generatePDFLine:i + 1 title:backsAry[i] hallLanding:@""];
        
        CCSettingItemView * sview = [CCSettingItemView view];
        [sview configWithPDFItem:item];
        [componentBackStackView insertArrangedSubview:sview atIndex:item.number - 1];
    }
    
    backImageView.image = self.data.backImage;
    
//    for (UILabel * label in infoLabels) {
//        [label setFont:[UIFont boldSystemFontOfSize:(isLandscape) ? LANDSCAPE_OTHER_FONT_SIZE: PORTRAIT_OTHER_FONT_SIZE]];
//    }
//    for (UILabel * label in valueLabels) {
//        [label setFont:[UIFont systemFontOfSize:(isLandscape) ? LANDSCAPE_OTHER_FONT_SIZE: PORTRAIT_OTHER_FONT_SIZE]];
//    }
    
    //[contactBackLabel setFont:[UIFont systemFontOfSize:(isLandscape) ? LANDSCAPE_OTHER_FONT_SIZE : PORTRAIT_OTHER_FONT_SIZE]];
}

- (void) populateListHallSetting{
    NSArray * hallAry = @[@"Finish", @"Style", @"Pushbutton", @"Options", @"Lantern"];
    
    for (UIView * v in componentHallMainStackView.arrangedSubviews) {
        if (v.tag == 100)
            continue;
        [componentHallMainStackView removeArrangedSubview:v];
        [v removeFromSuperview];
    }
    
    for (UIView * v in componentHallTypicalStackView.arrangedSubviews) {
        if (v.tag == 100)
            continue;
        [componentHallTypicalStackView removeArrangedSubview:v];
        [v removeFromSuperview];
    }
    
    hallMainProjectLabel.text = self.data.projName;
    NSDateFormatter * formatter = [[NSDateFormatter alloc] init];
    formatter.dateStyle = NSDateFormatterMediumStyle;
    hallMainDateLabel.text = [formatter stringFromDate:self.data.issuedDate];
    
    hallTypicalProjectLabel.text = self.data.projName;
    formatter.dateStyle = NSDateFormatterMediumStyle;
    hallTypicalDateLabel.text = [formatter stringFromDate:self.data.issuedDate];
    
    for (int i = 0; i < hallAry.count; i++){
        PDFItem * item = [self generatePDFLine:i + 1 title:hallAry[i] hallLanding:@"M"];
        if (!item) continue;
        CCSettingItemView * sview = [CCSettingItemView view];
        [sview configWithPDFItem:item];
        [componentHallMainStackView insertArrangedSubview:sview atIndex:item.number - 1];
    }
    
    for (int i = 0; i < hallAry.count; i++){
        PDFItem * item = [self generatePDFLine:i + 1 title:hallAry[i] hallLanding:@"T"];
        if (!item) continue;
        CCSettingItemView * sview = [CCSettingItemView view];
        [sview configWithPDFItem:item];
        [componentHallTypicalStackView insertArrangedSubview:sview atIndex:item.number - 1];
    }
    
    hallMainImageView.image = self.data.hallMainImage;
    hallTypicalImageView.image = self.data.hallTypicalImage;
}

- (void) generatePDF {
    CGSize contentSize = scrollView.contentSize;
    CGFloat hiddenHeight = contentSize.height - scrollView.frame.size.height;
    if (hiddenHeight > 0) {
        scrollViewBottomConstraint.constant = hiddenHeight;
        [self.view layoutSubviews];
    }
    
    UIGraphicsBeginPDFContextToData(pdfData, CGRectMake(0, 0, contentSize.width, contentSize.height), nil);

    //UIGraphicsBeginPDFPageWithInfo(CGRectMake(0, contentSize.height / 2, contentSize.width, contentSize.height), nil);
    
    
    //    UIImage * screenImage = nil; //? capture scrollview's content
    //
    //    CGContextDrawImage(UIGraphicsGetCurrentContext(), CGRectMake(0, 0, screenImage.size.width, screenImage.size.height), screenImage.CGImage);
    
    CGContextRef pdfContext = UIGraphicsGetCurrentContext();
        
    float pageHeight = (!self.data.isPDFCOP || !self.data.isPDFCabInterior)? (!self.data.isPDFHallFixtures? contentSize.height:contentSize.height / 3) : (!self.data.isPDFHallFixtures? contentSize.height / 2:contentSize.height / 4);
    if (self.data.isPDFCOP){
        //UIGraphicsBeginPDFPage();
        UIGraphicsBeginPDFPageWithInfo(CGRectMake(0, 0, contentSize.width, pageHeight), nil);
        [frontContainer.layer renderInContext:pdfContext];
    }
    
    if (self.data.isPDFCabInterior){
        //UIGraphicsBeginPDFPage();
        UIGraphicsBeginPDFPageWithInfo(CGRectMake(0, 0, contentSize.width, pageHeight), nil);
        [backContainer.layer renderInContext:pdfContext];
    }
    
    if (self.data.isPDFHallFixtures){
        //UIGraphicsBeginPDFPage();
        UIGraphicsBeginPDFPageWithInfo(CGRectMake(0, 0, contentSize.width, pageHeight), nil);
        [hallMainContainer.layer renderInContext:pdfContext];
        
        UIGraphicsBeginPDFPageWithInfo(CGRectMake(0, 0, contentSize.width, pageHeight), nil);
        [hallTypicalContainer.layer renderInContext:pdfContext];
    }
    
    
    UIGraphicsEndPDFContext();
    
    NSString *rootPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,
                                                              NSUserDomainMask, YES) objectAtIndex:0];
    
    NSString *pdfName = [self getPDFFileName];
        
    NSString * filePath = [rootPath stringByAppendingPathComponent:pdfName];
    if ([[NSFileManager defaultManager] fileExistsAtPath:filePath]) {
        [[NSFileManager defaultManager] removeItemAtPath:filePath error:nil];
    }
    [pdfData writeToFile:filePath atomically:YES];
    NSLog(@"%@", filePath);
    
    scrollViewBottomConstraint.constant = 0;
}

- (IBAction)back:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)submit:(id)sender {
    // generate pdf and attach
    [self generatePDF];
    
    // Fixture selection body should not contain Interior selection info
    // Interior selection body should not contain Fixture selection info
    // Location should be underneath Handrail
    // Added by Alex, 2021/06/29
    NSArray *fixtures = @[@"COP Type", @"Front COP Selection", @"Rear COP Selection", @"Fire Service", @"Position Indicator", @"Altus", @"Interaction Type", @"Number of Floors", @"Touchscreen Size", @"Tactile Style", @"Pushbutton", @"Accessories"];
    NSArray *interior = @[@"Back Wall Layout", @"Side Wall Layout", @"Door Opening", @"Binding / Edging", @"Front / Reveal Finish", @"Wall Material Finish", @"Ceiling", @"Handrail", @"Location", @"Bumper Rail (optional)", @"Floor"];
    NSArray *halls = @[@"hall_finish", @"hall_style_mounting", @"hall_style_width", @"hall_style_height", @"hall_pushbutton", @"hall_options", @"hall_lantern_mounting", @"hall_lantern_orientation", @"hall_lantern_width", @"hall_lantern_height", @"hall_lantern_options", @"hall_lantern_arrow_type", @"hall_lantern_pi", @"hall_building"];
    
    NSString * commonSelectionString = @"\n";
    NSString * trackSelectionString = @"";
    if (self.data.isPDFCOP){
        for (int i = 0; i < fixtures.count; i++){
            NSString *item = fixtures[i];
            for (CCBaseSetting * setting in self.data.settings) {
                if (![setting.menuTitle isEqualToString:item]) continue;
                
                trackSelectionString = [trackSelectionString stringByAppendingFormat:@"|%@:%@", setting.menuTitle, setting.name];
                commonSelectionString = [commonSelectionString stringByAppendingFormat:@"\n%@: %@", setting.menuTitle, setting.name];
            }
        }
    }
    
    if (self.data.isPDFCabInterior){
        for (int i = 0; i < interior.count; i++){
            NSString *item = interior[i];
            for (CCBaseSetting * setting in self.data.settings) {
                if (![setting.menuTitle isEqualToString:item]) continue;
                
                trackSelectionString = [trackSelectionString stringByAppendingFormat:@"|%@:%@", setting.menuTitle, [item isEqualToString:@"Wall Material Finish"]? setting.desc:setting.name];
                commonSelectionString = [commonSelectionString stringByAppendingFormat:@"\n%@: %@", setting.menuTitle, [item isEqualToString:@"Wall Material Finish"]? setting.desc:setting.name];
            }
        }
    }
    
    if (self.data.isPDFHallFixtures){
        for (int j = 0; j < 2; j++){
            NSString *landing = j == 0? @"M":@"T";
            NSString *prefix = j == 0? @"Terminal":@"Intermediate Terminal";
            
            for (int i = 0; i < halls.count; i++){
                NSString *item = [NSString stringWithFormat:@"%@-%@", landing, halls[i]];
                for (CCBaseSetting * setting in self.data.settings) {
                    if (![setting.menuTitle isEqualToString:item]) continue;
                    
                    NSString *title = [NSString stringWithFormat:@"%@ %@", prefix, setting.description_ss];
                    NSString *desc = setting.name;
                    
                    trackSelectionString = [trackSelectionString stringByAppendingFormat:@"|%@:%@", title, desc];
                    commonSelectionString = [commonSelectionString stringByAppendingFormat:@"\n%@: %@", title, desc];
                }
            }
        }
    }
    
    if (![trackSelectionString isEqualToString:@""]){
        trackSelectionString = [trackSelectionString substringFromIndex:1];
    }
    
    NSString * subject = @"";
    NSString * subtitle = @"";
    NSString * content = @"";
    if (self.fromRFQ) {
        subject = @"Elevator Interior & Fixtures & Hall RFQ Submission";
        NSDateFormatter * formatter = [[NSDateFormatter alloc] init];
        [formatter setDateFormat:@"yyyy-MM-dd hh:mma"];
        
        NSString * ctr = self.data.controller;
        if (![self.data.controllerType isEqualToString:@""]){
            ctr = [ctr stringByAppendingFormat:@"(%@)", self.data.controllerType];
        }
        
        content = [NSString stringWithFormat:@"\nNew Cab RFQ submission from Cab Configurator.\n\n%@: %@\n%@: %@\n%@: %@\n%@: %@\n%@: %@\n%@: %@\n%@: %@\n\n%@: %@\n%@: %@\n%@: %@\n%@: %@\n%@: %@\n%@: %@\n%@: %@\n%@: %@\n%@: %@\n%@: %@%@\n\nIf you have any questions, please contact MAD Elevator Inc.\nEmail: customerservice@madelevator.com\nToll Free: 1-886-967-8500",
                   @"Date time", [formatter stringFromDate:[NSDate date]],
                   @"Name", self.data.name,
                   @"Company", self.data.company,
                   @"Phone", self.data.phone,
                   @"Project Name", self.data.projName,
                   @"Project Address", self.data.address,
                   @"E-mail", self.data.email,
                   @"Width", self.data.width,
                   @"Depth", self.data.depth,
                   @"Height(to canopy)", self.data.height,
                   @"Capacity", self.data.capacity,
                   @"# of Elevators", self.data.numOfElevs,
                   @"# of Risers", self.data.numOfRisers,
                   @"# of Openings", self.data.numOfOpenings,
                   @"Controller", ctr,
                   @"Additional Notes", self.data.notes,
                   @"Provide Quote For", self.data.providerQuoteFor,
                   commonSelectionString];
    } else {
        subject = [self getEmailSubject];
                
        subtitle = [self getEmailHeader];
        
        content = [NSString stringWithFormat:@"\nPlease see attached your %@ selections. Details below:%@\n\nIf you have any questions, please contact MAD Elevator Inc.\nEmail: customerservice@madelevator.com\nToll Free: 1-886-967-8500",
                   subtitle,
                   commonSelectionString
                   ];
    }
        
    NSString * strHtml = [content stringByReplacingOccurrencesOfString:@"\n" withString:@"<br />"];
    [self sendPDFTrackData:self.data.email track_title:subject track_data:trackSelectionString track_html:strHtml track_type:self.fromRFQ? @"Q":@"P"];
    
    NSLog(@"subject: %@", subject);
    NSLog(@"email: %@", content);
    
    if ([MFMailComposeViewController canSendMail] == NO) {
        return;
    }
    
    MFMailComposeViewController * mvc = [[MFMailComposeViewController alloc] init];
    [mvc setMailComposeDelegate:self];
    
    [mvc setSubject:subject];
    [mvc setMessageBody:content isHTML:NO];
    
    if (self.fromRFQ) {
        [mvc setToRecipients:@[@"customerservice@madelevator.com"]];
    } else {
        [mvc setToRecipients:@[self.data.email]];
        [mvc setCcRecipients:@[@"customerservice@madelevator.com"]];
    }
    
    [mvc addAttachmentData:pdfData mimeType:@"application/pdf" fileName:[self getPDFFileName]];
    [self presentViewController:mvc animated:YES completion:nil];
}

-(void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error {
    
    
    // restore the screen image sizes after attachemnt is created
    
    
    if (error) {
        UIAlertController * alert = [UIAlertController
                                     alertControllerWithTitle:@"Error Occured"
                                     message:[NSString stringWithFormat:@"error - %@", [error description]]
                                     preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction* dismissButton = [UIAlertAction
                                    actionWithTitle:@"dismiss"
                                    style:UIAlertActionStyleDefault
                                    handler:^(UIAlertAction * action) {
                                        //Handle your yes please button action here
                                        [alert dismissViewControllerAnimated:YES completion:nil];
                                    }];
        [alert addAction:dismissButton];
        [self presentViewController:alert animated:YES completion:nil];
        
        // [self dismissModalViewControllerAnimated:YES];
        [self dismissViewControllerAnimated:YES completion:nil];
    }
    
    else {
        
        //[self dismissModalViewControllerAnimated:YES];
        [self dismissViewControllerAnimated:YES completion:nil];
        
    }
    
}

- (BOOL)prefersStatusBarHidden{
    return YES;
}

- (UIImage *)imageByCroppingImage:(UIImage *)image toSize:(CGSize)size{
    // not equivalent to image.size (which depends on the imageOrientation)!
    double refWidth = CGImageGetWidth(image.CGImage);
    double refHeight = CGImageGetHeight(image.CGImage);
    
    double x = (refWidth - size.width) / 2.0;
    double y = (refHeight - size.height) / 2.0;
    
    CGRect cropRect = CGRectMake(x, y, size.height, size.width);
    CGImageRef imageRef = CGImageCreateWithImageInRect([image CGImage], cropRect);
    
    UIImage *cropped = [UIImage imageWithCGImage:imageRef scale:0.0 orientation:image.imageOrientation];
    CGImageRelease(imageRef);
    
    return cropped;
}

- (NSString *) encodePostParams:(NSString*) params{
    NSMutableCharacterSet * lQueryAllowedCharacterSet = [[NSMutableCharacterSet alloc]init];
    [lQueryAllowedCharacterSet formUnionWithCharacterSet:[NSCharacterSet URLQueryAllowedCharacterSet]];
    [lQueryAllowedCharacterSet removeCharactersInString:@"&"];
    
    return [params stringByAddingPercentEncodingWithAllowedCharacters:lQueryAllowedCharacterSet];
}

- (void)sendPDFTrackData:(NSString *)track_email track_title:(NSString *)track_title track_data:(NSString *)track_data track_html:(NSString *)track_html track_type:(NSString *)track_type{
    NSString *url = @"https://www.madelevator.com/pdf-track-api.html";
    //NSString *url = @"http://10.97.5.21:900/pdf-track-api.html";
    
    track_email = [self encodePostParams:track_email];
    track_title = [self encodePostParams:track_title];
    track_data = [self encodePostParams:track_data];
    track_html = [self encodePostParams:track_html];
    
    NSString *params = [@[@"track_email=", track_email,
                             @"&track_title=", track_title,
                             @"&track_data=", track_data,
                             @"&track_html=", track_html,
                             @"&track_type=", track_type,
                             @"&track_source=", @"MAD iOS"] componentsJoinedByString:@""];
    NSData *data = [params dataUsingEncoding:NSUTF8StringEncoding];

    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    [request setHTTPMethod:@"POST"];
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [request setHTTPBody:data];

    dispatch_async(dispatch_get_main_queue(), ^{
        [[[NSURLSession sharedSession] dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
            if (error) {
                NSLog(@"%@", error);
                dispatch_async(dispatch_get_main_queue(), ^{
                    return;
                });
            }
            
            NSLog(@"%@", [NSString stringWithUTF8String:[data bytes]]);
            
            dispatch_async(dispatch_get_main_queue(), ^{
                NSLog(@"Track Data Submit Success!");
            });
        }] resume];
    });
}

- (NSString *)getPDFFileName{
    NSString *subject = [[self getEmailSubject] stringByReplacingOccurrencesOfString:@" " withString:@""];
    return [NSString stringWithFormat:@"%@.pdf", subject];
}

- (NSString *) getEmailSubject{
    NSString *str = @"";
    if (self.data.isPDFCabInterior){
        str = [str stringByAppendingString:@" & Interior"];
    }
    if (self.data.isPDFCOP){
        str = [str stringByAppendingString:@" & Fixture"];
    }
    if (self.data.isPDFHallFixtures){
        str = [str stringByAppendingString:@" & Hall Fixture"];
    }
    if (![str isEqualToString:@""]){
        str = [str substringFromIndex:3];
    }
    return [NSString stringWithFormat:@"Elevator %@ Selection", str];
}

- (NSString *) getEmailHeader{
    NSString *title = @"Cab Interior & Fixture";
    if (!self.data.isPDFCabInterior && self.data.isPDFCOP){
        title = @"Fixture";
    }
    if (self.data.isPDFCabInterior && !self.data.isPDFCOP){
        title = @"Cab Interior";
    }
    if (self.data.isPDFHallFixtures){
        title = [title stringByAppendingFormat:@" & Hall Fixture"];
    }
    return title;
}
@end
