//
//  PopularLayoutViewController.m
//  MadCabConfigurator
//
//  Created by Alex on 12/22/19.
//  Copyright © 2019 seniorcoder. All rights reserved.
//

#import "PopularLayoutViewController.h"
#import "CabConfigViewController.h"
#import "CabConfig.h"
#import "SharedData.h"

@interface PopularLayoutViewController ()
{
    CabConfig * selectedLayout;
    BOOL isFront;
    int hallMode;
}
@end

@implementation PopularLayoutViewController

#pragma mark ---- Orientation ----
- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskLandscape;
}

- (BOOL)shouldAutorotate {
    return NO;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [[SharedData shared] initialize];
    isFront = YES;
    hallMode = 0;
    
    if ([UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPad) {
        heightConstraint.constant = 300;
    }
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Navigation

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    
    UIViewController *vc = [segue destinationViewController];
    vc.modalPresentationStyle = UIModalPresentationFullScreen;
    if ([vc isKindOfClass:[CabConfigViewController class]] && selectedLayout) {
        ((CabConfigViewController*)vc).defaultSide = isFront;
        ((CabConfigViewController*)vc).defaultMode = hallMode;
        ((CabConfigViewController*)vc).defaultConfig = selectedLayout;
    }
}

- (IBAction)onSelectLayout:(id)sender {
    NSInteger pIndex = [(UIButton*) sender tag];
    SharedData * shared = [SharedData shared];
    
    isFront = pIndex < 4;
    hallMode = pIndex == 8? 1:(pIndex == 9? 2:0);
    selectedLayout = shared.popularLayouts[pIndex % 4];
}

- (IBAction)back:(id)sender {
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)profile:(id)sender {
    
}

- (IBAction)configs:(id)sender {
    
}

- (BOOL)prefersStatusBarHidden{
    return YES;
}

@end
