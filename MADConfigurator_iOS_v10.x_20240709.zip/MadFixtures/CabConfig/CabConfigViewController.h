//
//  CabConfigViewController.h
//  MadCabConfigurator
//
//  Created by Alex on 12/28/19.
//  Copyright © 2019 seniorcoder. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CCCanvasView.h"

@class CabConfig;
@interface CabConfigViewController : UIViewController <UITableViewDelegate, UITableViewDataSource, UIScrollViewDelegate>
{
    IBOutletCollection(UIButton) NSArray *buttons;
    IBOutlet UITableView * menuTableView;
    IBOutlet UIView * contentView;
    IBOutlet UIView * mainView;
    IBOutlet UIView * leftDoorView;
    IBOutlet UIView * rightDoorView;
    IBOutlet UIView * doorView;
    IBOutlet UIView * hallWallView;
    IBOutlet CCCanvasView * canvasView;
    IBOutlet UIActivityIndicatorView * activityIndicator;
    IBOutlet UIScrollView *scrollView;
    IBOutlet UIButton *btnCollapse;
    IBOutlet UIButton *btnOpen;
    IBOutlet UIStackView *stackCollapseMenu;
    IBOutlet NSLayoutConstraint *stackWidthConstraint;
    IBOutlet UIButton *btnMainMenu;
    IBOutlet UIView *openCloseView;
    IBOutlet UISwitch *swhOpenCloseDoors;
    
    IBOutlet UIView *editPanelInstructionView;
    
    IBOutlet UIStackView *stackSwitchMenu;
    IBOutlet UIButton *btnSwitchView;
    IBOutlet UIButton *btnHallView;
    IBOutlet UIButton *btnSwitchTerminal;
    
    IBOutlet UIButton *btnSaveAs;
    IBOutlet NSLayoutConstraint *menuLeadingConstraint;
    IBOutlet UILabel *lblSwitchDesc;
    IBOutlet NSLayoutConstraint *contentLeadingConstraint;
    IBOutlet NSLayoutConstraint *menuTableTopConstraint;
    IBOutlet NSLayoutConstraint *exitPanelHeightConstraint;
    
    IBOutlet UIButton *btnAttachGraphics;
    IBOutlet UIButton *btnRevert;
    
    IBOutlet UIButton *btnMenuSwitch;
    IBOutlet UIButton *btnMenuHallView;
    IBOutlet UIButton *btnMenuCabView;
    IBOutlet UIButton *btnMenuCloseDoorView;
    IBOutlet UIButton *btnMenuOpenDoorView;
    IBOutlet UIButton *btnMenuSwitchTerminalView;
    
    IBOutlet NSLayoutConstraint *leftDoorOpenedConstraint;
    IBOutlet NSLayoutConstraint *leftDoorClosedConstraint;
    
    IBOutlet NSLayoutConstraint *rightDoorOpenedConstraint;
    IBOutlet NSLayoutConstraint *rightDoorClosedConstraint;
    
    IBOutlet NSLayoutConstraint *doorOpenedConstraint;
    IBOutlet NSLayoutConstraint *doorClosedConstraint;
    
    IBOutlet NSLayoutConstraint *menuBottomAreaHeightConstraint;
    
    IBOutlet UIButton *btnHallZoomInS;
    IBOutlet UIButton *btnHallZoomInL;
    IBOutlet UIButton *btnHallZoomOut;
    IBOutlet UIButton *btnHallZoomSZone;
    IBOutlet UIButton *btnHallZoomLZone;
    
    IBOutlet NSLayoutConstraint *hallZoomInSBtnLeadingConstraint;
    IBOutlet NSLayoutConstraint *hallZoomInSBtnTopConstraint;
    IBOutlet NSLayoutConstraint *hallZoomInLBtnLeadingConstraint;
    IBOutlet NSLayoutConstraint *hallZoomInLBtnTopConstraint;
    
    IBOutlet NSLayoutConstraint *hallZoomSZoneBtnLeadingConstraint;
    IBOutlet NSLayoutConstraint *hallZoomSZoneBtnTopConstraint;
    IBOutlet NSLayoutConstraint *hallZoomSZoneBtnWidthConstraint;
    IBOutlet NSLayoutConstraint *hallZoomSZoneBtnHeightConstraint;
    
    IBOutlet NSLayoutConstraint *hallZoomLZoneBtnLeadingConstraint;
    IBOutlet NSLayoutConstraint *hallZoomLZoneBtnTopConstraint;
    IBOutlet NSLayoutConstraint *hallZoomLZoneBtnWidthConstraint;
    IBOutlet NSLayoutConstraint *hallZoomLZoneBtnHeightConstraint;
    
    IBOutlet NSLayoutConstraint *hallZoomOutBtnLeadingConstraint;
    IBOutlet NSLayoutConstraint *hallZoomOutBtnTopConstraint;
}

@property (nonatomic, assign) BOOL defaultSide;
@property (nonatomic, assign) int defaultMode;
@property (nonatomic, strong) CabConfig * defaultConfig;
@property (nonatomic, assign) BOOL shouldGoPDF;
@property (nonatomic, strong) IBOutlet NSLayoutConstraint *mainRatioConstraint;

- (IBAction)editIndividualPanel:(id)sender;
- (IBAction)exitPanelEditor:(id)sender;
- (IBAction)createPDF:(id)sender;
- (IBAction)requestQuote:(id)sender;
- (IBAction)switchView:(id)sender;
- (IBAction)switchTerminal:(id)sender;
- (IBAction)saveAs:(id)sender;
- (IBAction)mainMenu:(id)sender;

- (IBAction)hallView:(id)sender;
- (IBAction)switchDoor:(id)sender;

- (IBAction)attachGraphics:(id)sender;
- (IBAction)onRevert:(id)sender;

- (IBAction)closeDoor:(id)sender;
- (IBAction)openDoor:(id)sender;

- (IBAction)hallZoomInS:(id)sender;
- (IBAction)hallZoomInL:(id)sender;
- (IBAction)hallZoomOut:(id)sender;


@end
