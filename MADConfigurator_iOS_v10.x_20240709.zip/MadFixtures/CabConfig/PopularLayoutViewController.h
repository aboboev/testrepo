//
//  PopularLayoutViewController.h
//  MadCabConfigurator
//
//  Created by Alex on 12/22/19.
//  Copyright © 2019 seniorcoder. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PopularLayoutViewController : UIViewController
{
    
    IBOutletCollection(UIButton) NSArray *layoutButtons;
    IBOutletCollection(UILabel) NSArray *layoutTitleLabels;
    
    IBOutlet NSLayoutConstraint * heightConstraint;
}

- (IBAction)profile:(id)sender;
- (IBAction)configs:(id)sender;

- (IBAction)back:(id)sender;

@end
