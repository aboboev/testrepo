//
//  SavedConfigsViewController.m
//  MadCabConfigurator
//
//  Created by Alex on 1/23/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import "SavedConfigsViewController.h"
#import "SavedConfigCell.h"
#import "CabConfig.h"
#import "RemoveConfigConfirmView.h"

#import "CabConfigViewController.h"
#import "RequestQuoteViewController.h"
#import "SharedData.h"

#define SORTS    @[@"Date (New-Old)", @"Date (Old-New)", @"Project Name (A-Z)", @"Project Name (Z-A)", @"Customer Name (A-Z)", @"Customer Name (Z-A)"]

@interface SavedConfigsViewController () <SavedConfigCellDelegate>
{
    NSMutableArray * configs;
    CabConfigSort currentSort;
    BOOL currentAsc;
}
@end

@implementation SavedConfigsViewController

- (void) loadConfigs {
    configs = [[CabConfig getConfigsWithSort:currentSort ascending:currentAsc] mutableCopy];
    
    [configsTableView reloadData];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    currentSort = CabConfigSortDate;
    currentAsc = YES;
    sortLabel.text = SORTS[0];

    backButton.layer.cornerRadius = 3;
    newButton.layer.cornerRadius = 3;
    
    [self loadConfigs];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return configs.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString * cellId = @"SavedConfigCell";
    
    SavedConfigCell * cell = (SavedConfigCell*)[tableView dequeueReusableCellWithIdentifier:cellId forIndexPath:indexPath];
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    CabConfig * config = [configs objectAtIndex:indexPath.row];
    [cell configWithConfig:config];
    cell.delegate = self;
    cell.index = indexPath.row;
    
    return cell;
}

- (void) onTapProjectNameForConfigAtIndex:(NSInteger) i {
    CabConfig * config = configs[i];
    
    CabConfigViewController * vc = [[UIStoryboard storyboardWithName:@"Configurator" bundle:nil] instantiateViewControllerWithIdentifier:@"CabConfigViewController"];
    vc.defaultConfig = config;
    vc.modalPresentationStyle = UIModalPresentationFullScreen;
    [self.navigationController pushViewController:vc animated:YES];
}

- (void) onTapRequestQuoteForConfigAtIndex:(NSInteger) i {
// not used
}

- (void) onTapRemoveForConfigAtIndex:(NSInteger) i {
    CabConfig * config = configs[i];

    RemoveConfigConfirmView * cView = [RemoveConfigConfirmView showOnView:self.view];
    [cView configWithConfig:config];
    [cView setYesBlock:^() {
        [CabConfig removeConfig:config];
        [self loadConfigs];
    }];
}

- (void) onTapCreatePDFForConfigAtIndex:(NSInteger) i {
// not used
}

- (IBAction)back:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)newConfig:(id)sender {
    CabConfigViewController * vc = [[UIStoryboard storyboardWithName:@"Configurator" bundle:nil] instantiateViewControllerWithIdentifier:@"CabConfigViewController"];
    
    SharedData * shared = [SharedData shared];
    CabConfig* selectedLayout = [shared.popularLayouts firstObject];

    vc.defaultConfig = selectedLayout;
    vc.modalPresentationStyle = UIModalPresentationFullScreen;
    [self.navigationController pushViewController:vc animated:YES];
}

- (IBAction)sort:(id)sender {
    UIAlertController *menu = [UIAlertController alertControllerWithTitle:@"Sort Types" message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    
    for (NSInteger i = 0; i < SORTS.count; i ++) {
        NSString * sort = SORTS[i];
        
        [menu addAction:[UIAlertAction actionWithTitle:sort style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            sortLabel.text = sort;
            currentAsc = (i % 2 == 0);
            if (i < 2) {
                currentSort = CabConfigSortDate;
            } else if (i < 4) {
                currentSort = CabConfigSortProject;
            } else {
                currentSort = CabConfigSortCustomer;
            }
            [self loadConfigs];
        }]];
    }

    if ([UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPad) {
        menu.popoverPresentationController.sourceView = sortButton;
        menu.popoverPresentationController.sourceRect = sortButton.frame;
    }
    
    [self presentViewController:menu animated:YES completion:nil];
}

- (BOOL)prefersStatusBarHidden{
    return YES;
}

#pragma mark ---- Orientation ----
- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskLandscape;
}

- (BOOL)shouldAutorotate {
    return NO;
}

@end
