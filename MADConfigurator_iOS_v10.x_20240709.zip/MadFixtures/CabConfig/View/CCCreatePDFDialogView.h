//
//  CCCreatePDFDialogView.h
//  MadCabConfigurator
//
//  Created by Alex on 2/17/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MadFixtures-Swift.h"

typedef void (^create_pdf_block)(NSString * proj, NSString * email, BOOL isCabInterior, BOOL isCOP, BOOL isHallFixtures);

@interface CCCreatePDFDialogView : UIView <BEMCheckBoxDelegate, UITextFieldDelegate>
{
    IBOutlet UITextField * projectTextField;
    IBOutlet UITextField * emailTextField;
    IBOutlet UIButton * createButton;
    IBOutlet UIView * formView;
    IBOutlet NSLayoutConstraint * centerYConstraint;
    IBOutlet BEMCheckBox * chkCabInterior;
    IBOutlet BEMCheckBox * chkCOP;
    IBOutlet BEMCheckBox * chkHallFixtures;
}

@property (nonatomic) create_pdf_block dialogBlock;

- (IBAction)close:(id)sender;
- (IBAction)create:(id)sender;

+ (CCCreatePDFDialogView*) showOnView:(UIView*) view;
- (void) setProjectName:(NSString*) pName;
- (void) setEmail:(NSString*) email;
- (void) setInitChecks;

@end

