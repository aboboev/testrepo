//
//  CCCreatePDFDialogView.m
//  MadCabConfigurator
//
//  Created by Alex on 2/17/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import "CCCreatePDFDialogView.h"

@implementation CCCreatePDFDialogView

+ (CCCreatePDFDialogView*) showOnView:(UIView*) view_ {
    if (view_ == nil) return nil;
    
    CCCreatePDFDialogView * opView = (CCCreatePDFDialogView*) [[[NSBundle mainBundle] loadNibNamed:@"CCCreatePDFDialogView" owner:nil options:nil] firstObject];
    opView.translatesAutoresizingMaskIntoConstraints = NO;
    
    [view_ addSubview:opView];
    
    NSMutableArray * constraints = [[NSMutableArray alloc] init];
    [constraints addObjectsFromArray:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[opView]|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(opView)]];
    [constraints addObjectsFromArray:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[opView]|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(opView)]];
    [view_ addConstraints:constraints];

    return opView;
}

- (void) setProjectName:(NSString*) pName {
    projectTextField.text = pName;
}

- (void) setEmail:(NSString*) email {
    emailTextField.text = email;
}

- (void) setInitChecks{
    chkCOP.on = YES;
    chkCabInterior.on = YES;
    chkHallFixtures.on = YES;
    chkCOP.delegate = self;
    chkCabInterior.delegate = self;
}

- (IBAction)close:(id)sender {
    [self removeFromSuperview];
}

- (void)didTap:(BEMCheckBox *)checkBox{
    if (checkBox == chkCOP && !checkBox.on && !chkCabInterior.on){
        chkCabInterior.on = YES;
    }
    if (checkBox == chkCabInterior && !checkBox.on && !chkCOP.on){
        chkCOP.on = YES;
    }
}

- (IBAction)create:(id)sender {
    if (projectTextField.text.length == 0 ||
        emailTextField.text.length == 0) {
        return;
    }
    
    [self close:sender];
    if (self.dialogBlock) {
        self.dialogBlock(projectTextField.text, emailTextField.text, chkCabInterior.on, chkCOP.on, chkHallFixtures.on);
        self.dialogBlock = nil;
    }
}

- (void)awakeFromNib {
    [super awakeFromNib];
    
    formView.layer.cornerRadius = 8;
    createButton.layer.cornerRadius = 3;
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
    
    projectTextField.delegate = self;
    emailTextField.delegate = self;
}

- (void)removeFromSuperview {
    [super removeFromSuperview];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void) keyboardWillShow:(NSNotification*) notification {
    centerYConstraint.constant = -90;
}

- (void) keyboardWillHide:(NSNotification*) notification {
    centerYConstraint.constant = 0;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
	[textField resignFirstResponder];
	return YES;
}

@end
