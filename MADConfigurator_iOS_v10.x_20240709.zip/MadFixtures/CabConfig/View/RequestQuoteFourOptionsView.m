//
//  RequestQuoteTwoOptionsView.m
//  MadCabConfigurator
//
//  Created by Alex on 1/22/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import "RequestQuoteFourOptionsView.h"

@implementation RequestQuoteFourOptionsView

- (void)awakeFromNib {
    [super awakeFromNib];
    
    selectView.layer.cornerRadius = 8;
}

- (IBAction)close:(id)sender {
    [self removeFromSuperview];
}

- (IBAction)first:(id)sender {
    [self removeFromSuperview];
    if (self.firstBlock) {
        self.firstBlock();
        self.firstBlock = nil;
    }
}

- (IBAction)second:(id)sender {
    [self removeFromSuperview];
    if (self.secondBlock) {
        self.secondBlock();
        self.secondBlock = nil;
    }
}

- (IBAction)third:(id)sender {
    [self removeFromSuperview];
    if (self.thirdBlock) {
        self.thirdBlock();
        self.thirdBlock = nil;
    }
}

- (IBAction)fourth:(id)sender {
    [self removeFromSuperview];
    if (self.fourthBlock) {
        self.fourthBlock();
        self.fourthBlock = nil;
    }
}

+ (RequestQuoteFourOptionsView*) showOnView:(UIView*) view firstOption:(NSString*) option1 secondOption:(NSString*) option2 thirdOption:(NSString*) option3 fourthOption:(NSString*) option4 {
    if (view == nil) return nil;
    RequestQuoteFourOptionsView * bview = (RequestQuoteFourOptionsView*) [[[NSBundle mainBundle] loadNibNamed:@"RequestQuoteFourOptionsView" owner:nil options:nil] firstObject];
    bview.translatesAutoresizingMaskIntoConstraints = NO;
    [bview.firstButton setTitle:option1 forState:UIControlStateNormal];
    [bview.secondButton setTitle:option2 forState:UIControlStateNormal];
    [bview.thirdButton setTitle:option3 forState:UIControlStateNormal];
    [bview.fourthButton setTitle:option4 forState:UIControlStateNormal];
    
    [view addSubview:bview];
    
    NSMutableArray * constraints = [[NSMutableArray alloc] init];
    [constraints addObjectsFromArray:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[bview]|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(bview)]];
    
    [constraints addObjectsFromArray:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[bview]|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(bview)]];
    
    [view addConstraints:constraints];
    
    return bview;
}

@end
