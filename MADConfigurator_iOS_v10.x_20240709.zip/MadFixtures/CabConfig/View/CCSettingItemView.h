//
//  CCSettingItemView.h
//  MadCabConfigurator
//
//  Created by Alex on 2/17/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PDFItem.h"
@class CCBaseSetting;
@interface CCSettingItemView : UIView
{

}

@property (nonatomic, weak) IBOutlet UILabel * numLabel;
@property (nonatomic, weak) IBOutlet UILabel * titleLabel;
@property (nonatomic, weak) IBOutlet UILabel * descLabel;
@property (nonatomic, weak) IBOutlet UIImageView * thumbImageView1;
@property (nonatomic, weak) IBOutlet UIImageView * thumbImageView2;
@property (nonatomic, weak) IBOutlet NSLayoutConstraint * numLabelHeight;
@property (nonatomic, weak) IBOutlet NSLayoutConstraint * thumb1WidthConstraint;
@property (nonatomic, weak) IBOutlet NSLayoutConstraint * thumb2WidthConstraint;
+ (CCSettingItemView*) view;
- (void) configWithSetting:(CCBaseSetting *) setting no:(NSInteger) no;
- (void) configWithPDFItem:(PDFItem *) pdfItem;
- (void)setNumLabelHeightConstant:(CGFloat)height;

@end
