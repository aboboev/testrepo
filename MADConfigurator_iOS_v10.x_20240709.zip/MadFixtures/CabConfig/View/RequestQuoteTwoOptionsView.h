//
//  RequestQuoteTwoOptionsView.h
//  MadCabConfigurator
//
//  Created by Alex on 1/22/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^first_block)(void);
typedef void (^second_block)(void);

@interface RequestQuoteTwoOptionsView : UIView
{
    IBOutlet UIView * selectView;
}

@property (nonatomic, weak) IBOutlet UIButton * firstButton;
@property (nonatomic, weak) IBOutlet UIButton * secondButton;

@property (nonatomic) first_block firstBlock;
@property (nonatomic) second_block secondBlock;

- (IBAction)close:(id)sender;

- (IBAction)first:(id)sender;
- (IBAction)second:(id)sender;

+ (RequestQuoteTwoOptionsView*) showOnView:(UIView*) view firstOption:(NSString*) option1 secondOption:(NSString*) option2;
@end
