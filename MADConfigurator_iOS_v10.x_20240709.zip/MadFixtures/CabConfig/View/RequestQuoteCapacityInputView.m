//
//  RequestQuoteCapacityInputView.m
//  MadCabConfigurator
//
//  Created by Alex on 1/22/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import "RequestQuoteCapacityInputView.h"

@implementation RequestQuoteCapacityInputView

- (void)awakeFromNib {
    [super awakeFromNib];
    
    selectView.layer.cornerRadius = 8;
    okButton.layer.cornerRadius = 3;
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
}

- (void)removeFromSuperview {
    [super removeFromSuperview];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void) keyboardWillShow:(NSNotification*) notification {
    centerYConstraint.constant = -120;
}

- (void) keyboardWillHide:(NSNotification*) notification {
    centerYConstraint.constant = 0;
}

- (IBAction)close:(id)sender {
    [self removeFromSuperview];
}

- (IBAction)onSelectValue:(id)sender {
    UIButton * button = (UIButton*) sender;
    NSInteger val = button.tag;
    
    if (self.selectedValueBlock) {
        self.selectedValueBlock(val);
        self.selectedValueBlock = nil;
    }
    
    [self removeFromSuperview];
}

- (IBAction)ok:(id)sender {
    if (_otherTextField.text.length == 0) {
        return;
    }
    
    NSInteger val = [_otherTextField.text integerValue];
    
    [self removeFromSuperview];

    if (self.selectedValueBlock) {
        self.selectedValueBlock(val);
        self.selectedValueBlock = nil;
    }
}

+ (RequestQuoteCapacityInputView*) showOnView:(UIView*) view {
    if (view == nil) return nil;
    RequestQuoteCapacityInputView * bview = (RequestQuoteCapacityInputView*) [[[NSBundle mainBundle] loadNibNamed:@"RequestQuoteCapacityInputView" owner:nil options:nil] firstObject];
    bview.translatesAutoresizingMaskIntoConstraints = NO;
    
    [view addSubview:bview];
    
    NSMutableArray * constraints = [[NSMutableArray alloc] init];
    [constraints addObjectsFromArray:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[bview]|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(bview)]];
    
    [constraints addObjectsFromArray:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[bview]|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(bview)]];
    
    [view addConstraints:constraints];
    
    return bview;
    
}

@end
