//
//  RequestQuoteBottomView.m
//  MadCabConfigurator
//
//  Created by Alex on 1/22/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import "CCInputScreenBottomBar.h"
#import "AppDelegate.h"

#define BottomBarTag            19298
@implementation CCInputScreenBottomBar

+ (CCInputScreenBottomBar*) showOnView:(UIView*) view {
    if (view == nil) return nil;
    CCInputScreenBottomBar * bview = (CCInputScreenBottomBar*) [[[NSBundle mainBundle] loadNibNamed:@"CCInputScreenBottomBar" owner:nil options:nil] firstObject];
    bview.translatesAutoresizingMaskIntoConstraints = NO;
    bview.tag = BottomBarTag;
    
    [view addSubview:bview];
    
    NSMutableArray * constraints = [[NSMutableArray alloc] init];
    [constraints addObjectsFromArray:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[bview]|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(bview)]];
    
    [constraints addObject:[NSLayoutConstraint constraintWithItem:bview attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:view attribute:NSLayoutAttributeBottom multiplier:1.0 constant:0]];

    [view addConstraints:constraints];
    
    [bview addConstraint:[NSLayoutConstraint constraintWithItem:bview attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1.0 constant:44]];
    
    return bview;
}

+ (CCInputScreenBottomBar*) view {
    CCInputScreenBottomBar * bview = (CCInputScreenBottomBar*) [[[NSBundle mainBundle] loadNibNamed:@"CCInputScreenBottomBar" owner:nil options:nil] firstObject];
//    bview.translatesAutoresizingMaskIntoConstraints = NO;
//
//    [bview addConstraint:[NSLayoutConstraint constraintWithItem:bview attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1.0 constant:44]];
    
    return bview;
}

- (void) setSubmitButtonTitle:(NSString*) title {
    [submitButton setTitle:title forState:UIControlStateNormal];
}

- (void)awakeFromNib {
    [super awakeFromNib];
    backButton.layer.cornerRadius = 3;
    submitButton.layer.cornerRadius = 3;
}

- (IBAction)onSubmit:(id)sender {
    if (self.submitBlock) {
        self.submitBlock();
    }
}

- (IBAction)onBack:(id)sender {
    if (self.backBlock) {
        self.backBlock();
    }
}

+ (void)removeBottomBar {
    UIWindow * window = [(AppDelegate*)[UIApplication sharedApplication].delegate window];
    for (UIView* v in window.subviews) {
        if (v.tag == BottomBarTag) {
            [v removeFromSuperview];
            break;
        }
    }
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
