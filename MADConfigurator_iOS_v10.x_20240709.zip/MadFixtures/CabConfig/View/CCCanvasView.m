//
//  CCCanvasView.m
//  MadFixtures
//
//  Created by Alex on 2/6/24.
//  Copyright © 2024 Mad Elevator. All rights reserved.
//

#import "CCCanvasView.h"

@implementation CCCanvasView

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    _panels = [NSMutableArray new];
    _selectedPanel = nil;
}

- (void)drawRect:(CGRect)rect{
    if (_panels.count <= 0) return;
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetStrokeColorWithColor(context, [UIColor whiteColor].CGColor);
    //CGContextSetRGBFillColor(context, 0.0, 0.0, 1.0, 1.0);
    CGContextSetLineWidth(context, 2.0);
    CGContextSetLineJoin(context, kCGLineJoinRound);
    CGContextSetLineCap(context, kCGLineCapRound);
    for (int i = 0; i < _panels.count; i++){
        CCLayoutPanel * panel = _panels[i];
        if (panel.visible && !panel.locked){
            CCPoint * firstPoint = panel.points[0];
            CGContextMoveToPoint(context, rect.size.width * firstPoint.x / 2048, rect.size.height * firstPoint.y / 2048);
            for (int j = 1; j < panel.points.count; j++){
                CCPoint * point = panel.points[j];
                //[path addLineToPoint:CGPointMake(point.x, point.y)];
                CGContextAddLineToPoint(context, rect.size.width * point.x / 2048, rect.size.height * point.y / 2048);
            }
            CGContextAddLineToPoint(context, rect.size.width * firstPoint.x / 2048, rect.size.height * firstPoint.y / 2048);
            CGContextStrokePath(context);
        }
    }
}

- (void) setTouchedPanel:(CGPoint) touchedPoint ZoomScale:(CGFloat)zoomScale{
    CGFloat width = zoomScale * self.frame.size.width;
    CGFloat height = zoomScale * self.frame.size.height;
        
    for (int i = 0; i < _panels.count; i++){
        UIBezierPath *polygonPath = [UIBezierPath bezierPath];
        CCLayoutPanel *panel = _panels[i];
        for (int j = 0; j < panel.points.count; j++){
            CCPoint *point = panel.points[j];
            CGPoint polygonPoint = CGPointMake(point.x * width / 2048, point.y * height / 2048);
            if (j == 0){
                [polygonPath moveToPoint:polygonPoint];
            }else{
                [polygonPath addLineToPoint:polygonPoint];
            }
        }
        [polygonPath closePath];
        
        if (!panel.locked && [polygonPath containsPoint:touchedPoint]){
            _selectedPanel = panel;
            return;
        }
    }
    _selectedPanel = nil;
}

-(void) setPanelsVisibility:(BOOL)visible selection:(BOOL)selection{
    for (int i = 0; i < _panels.count; i++){
        _panels[i].visible = visible;
    }
    
    if (_selectedPanel) _selectedPanel.visible = selection;
}

@end
