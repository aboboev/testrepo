//
//  CCSaveConfigDialogView.h
//  MadCabConfigurator
//
//  Created by Alex on 1/14/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^save_config_block)(NSString * proj, NSString * customer);
@interface CCSaveConfigDialogView : UIView
{
    IBOutlet UITextField * projectTextField;
    IBOutlet UITextField * customerTextField;
    IBOutlet UIButton * saveButton;
    IBOutlet UIView * formView;
    IBOutlet NSLayoutConstraint * centerYConstraint;
    
    IBOutlet UIView * successView;
}

@property (nonatomic) save_config_block saveBlock;

- (IBAction)close:(id)sender;
- (IBAction)save:(id)sender;

+ (CCSaveConfigDialogView*) showOnView:(UIView*) view;
- (void) setProjectName:(NSString*) projectName customerName:(NSString*) custoerName;
- (void) showSuccess;

@end
