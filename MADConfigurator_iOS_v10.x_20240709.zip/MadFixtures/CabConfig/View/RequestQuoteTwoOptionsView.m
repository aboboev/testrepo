//
//  RequestQuoteTwoOptionsView.m
//  MadCabConfigurator
//
//  Created by Alex on 1/22/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import "RequestQuoteTwoOptionsView.h"

@implementation RequestQuoteTwoOptionsView

- (void)awakeFromNib {
    [super awakeFromNib];
    
    selectView.layer.cornerRadius = 8;
}

- (IBAction)close:(id)sender {
    [self removeFromSuperview];
}

- (IBAction)first:(id)sender {
    [self removeFromSuperview];
    if (self.firstBlock) {
        self.firstBlock();
        self.firstBlock = nil;
    }
}

- (IBAction)second:(id)sender {
    [self removeFromSuperview];
    if (self.secondBlock) {
        self.secondBlock();
        self.secondBlock = nil;
    }
}

+ (RequestQuoteTwoOptionsView*) showOnView:(UIView*) view firstOption:(NSString*) option1 secondOption:(NSString*) option2 {
    if (view == nil) return nil;
    RequestQuoteTwoOptionsView * bview = (RequestQuoteTwoOptionsView*) [[[NSBundle mainBundle] loadNibNamed:@"RequestQuoteTwoOptionsView" owner:nil options:nil] firstObject];
    bview.translatesAutoresizingMaskIntoConstraints = NO;
    [bview.firstButton setTitle:option1 forState:UIControlStateNormal];
    [bview.secondButton setTitle:option2 forState:UIControlStateNormal];
    
    [view addSubview:bview];
    
    NSMutableArray * constraints = [[NSMutableArray alloc] init];
    [constraints addObjectsFromArray:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[bview]|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(bview)]];
    
    [constraints addObjectsFromArray:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[bview]|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(bview)]];
    
    [view addConstraints:constraints];
    
    return bview;
}

@end
