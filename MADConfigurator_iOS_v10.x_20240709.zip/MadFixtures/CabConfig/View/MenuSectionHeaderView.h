//
//  MenuSectionHeaderView.h
//  MadCabConfigurator
//
//  Created by Alex on 1/8/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MenuSectionHeaderView : UIView

@property (nonatomic, weak) IBOutlet UILabel * numberLabel;
@property (nonatomic, weak) IBOutlet UILabel * titleLabel;

- (void) setSelected:(BOOL) selected;

@end
