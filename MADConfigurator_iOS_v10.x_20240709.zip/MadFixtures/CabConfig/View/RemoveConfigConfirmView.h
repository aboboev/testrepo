//
//  RemoveConfigConfirmView.h
//  MadCabConfigurator
//
//  Created by Alex on 2/16/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^remove_config_block)(void);

@class CabConfig;
@interface RemoveConfigConfirmView : UIView
{
    IBOutlet UIView * confirmView;
    IBOutlet UILabel * projLabel;
    IBOutlet UILabel * customerLabel;
    IBOutlet UILabel * dateLabel;
}

@property (nonatomic) remove_config_block yesBlock;

- (IBAction)close:(id)sender;

- (IBAction)yes:(id)sender;
- (IBAction)no:(id)sender;

+ (RemoveConfigConfirmView*) showOnView:(UIView*) view;
- (void) configWithConfig:(CabConfig*) config;

@end
