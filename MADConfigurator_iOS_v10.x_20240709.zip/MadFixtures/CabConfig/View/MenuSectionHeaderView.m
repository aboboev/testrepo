//
//  MenuSectionHeaderView.m
//  MadCabConfigurator
//
//  Created by Alex on 1/8/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import "MenuSectionHeaderView.h"
#import "Constants.h"

@implementation MenuSectionHeaderView

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    _numberLabel.layer.masksToBounds = YES;
    _numberLabel.layer.cornerRadius = 14;//_numberLabel.frame.size.height / 2;
}

- (void) setSelected:(BOOL) selected {
    _numberLabel.backgroundColor = (selected) ? PRIMARY_COLOR : [UIColor lightGrayColor];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
