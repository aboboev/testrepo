//
//  CCSettingItemView.m
//  MadCabConfigurator
//
//  Created by Alex on 2/17/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import "CCSettingItemView.h"
#import "CCBaseSetting.h"

@implementation CCSettingItemView

+ (CCSettingItemView*) view {
    CCSettingItemView * opView = (CCSettingItemView*) [[[NSBundle mainBundle] loadNibNamed:@"CCSettingItemView" owner:nil options:nil] firstObject];
    opView.translatesAutoresizingMaskIntoConstraints = NO;
    return opView;
}

- (void) configWithSetting:(CCBaseSetting *) setting no:(NSInteger) no {
    /*_numLabel.text = [NSString stringWithFormat:@"%ld", (long)no];
    _titleLabel.text = setting.menuTitle;
    _descLabel.text = setting.desc;

    UIImage * image = [UIImage imageNamed:setting.fileName];
    _thumbImageView.image = image;
    CGFloat ratio = image.size.height / image.size.width;
    NSLayoutConstraint * constraint = [NSLayoutConstraint constraintWithItem:_thumbImageView attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:_thumbImageView attribute:NSLayoutAttributeWidth multiplier:ratio constant:0];
    [_thumbImageView addConstraint:constraint];*/
}

- (void) configWithPDFItem:(PDFItem *) item{
    _numLabel.text = [NSString stringWithFormat:@"%ld", (long)item.number];
    _titleLabel.text = item.title;
    _descLabel.text = item.content;

    if (![item.image1 isEqualToString:@""]){
        UIImage * image = [UIImage imageNamed:item.image1];
        _thumbImageView1.image = image;
        CGFloat ratio = image.size.height / image.size.width;
        NSLayoutConstraint * constraint = [NSLayoutConstraint constraintWithItem:_thumbImageView1 attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:_thumbImageView1 attribute:NSLayoutAttributeWidth multiplier:ratio constant:0];
        [_thumbImageView1 addConstraint:constraint];
    }else{
        _thumbImageView1.hidden = YES;
        _thumb1WidthConstraint.active = NO;
        NSLayoutConstraint * constraint = [NSLayoutConstraint constraintWithItem:_thumbImageView1 attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:0];
        [_thumbImageView1 addConstraint:constraint];
    }
    
    if (![item.image2 isEqualToString:@""]){
        UIImage * image = [UIImage imageNamed:item.image2];
        _thumbImageView2.image = image;
        CGFloat ratio = image.size.height / image.size.width;
        NSLayoutConstraint * constraint = [NSLayoutConstraint constraintWithItem:_thumbImageView2 attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:_thumbImageView2 attribute:NSLayoutAttributeWidth multiplier:ratio constant:0];
        [_thumbImageView2 addConstraint:constraint];
    }else{
        _thumbImageView2.hidden = YES;
        _thumb2WidthConstraint.active = NO;
        NSLayoutConstraint * constraint = [NSLayoutConstraint constraintWithItem:_thumbImageView2 attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:0];
        [_thumbImageView2 addConstraint:constraint];
    }
}

- (void)setNumLabelHeightConstant:(CGFloat)height {
    _numLabelHeight.constant = height;
    _numLabel.layer.cornerRadius = _numLabelHeight.constant / 2;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    
    _numLabel.layer.cornerRadius = _numLabelHeight.constant / 2;
    _numLabel.clipsToBounds = YES;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
