//
//  RequestQuoteFourOptionsView.h
//  MadCabConfigurator
//
//  Created by Alex on 12/25/20.
//  Copyright © 2020 Alex Hong. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^one_block)(void);
typedef void (^two_block)(void);
typedef void (^three_block)(void);
typedef void (^four_block)(void);

@interface RequestQuoteFourOptionsView : UIView
{
    IBOutlet UIView * selectView;
}

@property (nonatomic, weak) IBOutlet UIButton * firstButton;
@property (nonatomic, weak) IBOutlet UIButton * secondButton;
@property (nonatomic, weak) IBOutlet UIButton * thirdButton;
@property (nonatomic, weak) IBOutlet UIButton * fourthButton;

@property (nonatomic) one_block firstBlock;
@property (nonatomic) two_block secondBlock;
@property (nonatomic) three_block thirdBlock;
@property (nonatomic) four_block fourthBlock;

- (IBAction)close:(id)sender;

- (IBAction)first:(id)sender;
- (IBAction)second:(id)sender;
- (IBAction)third:(id)sender;
- (IBAction)fourth:(id)sender;

+ (RequestQuoteFourOptionsView*) showOnView:(UIView*) view firstOption:(NSString*) option1 secondOption:(NSString*) option2 thirdOption:(NSString*) option3 fourthOption:(NSString*) option4;
@end
