//
//  CCThumbCollectionViewCell.m
//  MadCabConfigurator
//
//  Created by Alex on 2/18/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import "CCThumbCollectionViewCell.h"
#import "CCThumb.h"
#import "Constants.h"
#import "CCMenuItem.h"

#define THUMB_TITLE_LABEL_HEIGHT        36

@implementation CCThumbCollectionViewCell

- (void) awakeFromNib {
    [super awakeFromNib];
    _selectedRectView.backgroundColor = [UIColor clearColor];
    _selectedRectView.layer.borderWidth = 2.0f;
    _selectedRectView.layer.borderColor = PRIMARY_COLOR.CGColor;
    _selectedRectView.hidden = YES;
}

+ (CGFloat) heightForCellWidth:(CGFloat) cellWidth {
    //    UIImage * thumbImage = [UIImage imageNamed:thumb.imageName];
    //    CGFloat ratio = thumbImage.size.height / thumbImage.size.width;
    //    CGFloat imageHeight = cellWidth * ratio;
    
    //    CGFloat cellHeight = imageHeight + 36 + 8;  // + label height + margins
    //    return cellHeight;
    
    // cellwidth - hmargins + labelheight + vmargins
    return cellWidth - 8 + THUMB_TITLE_LABEL_HEIGHT + 8;
}

- (void) populateWithThumb:(CCThumb*) thumb_ {
    thumb = thumb_;
    _titleLabel.text = thumb.name;
    
    UIImage * image = [UIImage imageNamed:thumb.imageName];
    _thumbImageView.image = image;
    
    _contentHolderView.layer.cornerRadius = 0.0f;
    _contentHolderView.layer.borderWidth = 0;
    _contentHolderView.layer.shadowOffset = CGSizeZero;
    
    _selectedRectView.hidden = !thumb.isSelected;
}

@end
