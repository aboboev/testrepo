//
//  CCMenuItemWithSubmenuCell.m
//  MadCabConfigurator
//
//  Created by Alex on 2/18/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import "CCMenuItemWithSubmenuCell.h"
#import "CCMenuItem.h"
#import "CCSubmenuItemCell.h"
#import "CCThumbCollectionViewCell.h"
#import "Constants.h"
#import "CCSeparator.h"

@interface CCMenuItemWithSubmenuCell() <CCSubmenuItemCellDelegate> {
    CCMenuItem * menuItem;
    NSMutableArray * subMenuItems;
    NSInteger cols;
    
    BOOL forSeparators;
    BOOL showsGraphicControlMenu;
//    NSMutableArray * expandedSubMenuItems;
}

@property (nonatomic, strong) NSString* graphicSize;
@property (nonatomic, strong) NSString* horizontalAlignment;
@property (nonatomic, strong) NSString* verticalAlignment;

@end

@implementation CCMenuItemWithSubmenuCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
//    expandedSubMenuItems = [NSMutableArray new];
}

- (void)prepareForReuse {
    [super prepareForReuse];
    forSeparators = NO;
    menuItem = nil;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void) populateSubmenusWithMenuItem:(CCMenuItem*) menuItem_ showsGraphicControlMenu:(BOOL)showsGraphicControlMenu_ graphicSize:(NSString *)graphicSize_ horizontalAlignment:(NSString *)horizontalAlignment_ verticalAlignment:(NSString *)verticalAlignment_ {
    menuItem = menuItem_;
    showsGraphicControlMenu = showsGraphicControlMenu_;
    self.graphicSize = graphicSize_;
    self.horizontalAlignment = horizontalAlignment_;
    self.verticalAlignment = verticalAlignment_;
    subMenuItems = [[NSMutableArray alloc] init];//[menuItem_.subMenuItems mutableCopy];
    for (CCMenuItem * subMenu in menuItem_.subMenuItems){
        if (subMenu.isShown) [subMenuItems addObject: subMenu];
    }
    
    cols = 2;
    if ([menuItem.folder isEqualToString:@"wall_material"] || [menuItem.folder isEqualToString:@"back_wall"] || [menuItem.folder isEqualToString:@"handrail_type"]) {
        cols = 3;
    }
    
    if (![menuItem hasSubMenuItems] && [menuItem hasSeparators]) {
        forSeparators = YES;
    } else {
        forSeparators = NO;
        if (menuItem.thumbs.count > 0) {
            // fake sub item -> handrail
            CCMenuItem * item = [CCMenuItem new];
            item.ID = FAKE_SUBMENU_ID;
            item.dataRel = menuItem.dataRel;
            item.sub = @"1";
            item.drop = @"0";
            item.thumbs = menuItem.thumbs;
            item.isExpanded = YES;
//            [item.thumbs addObjectsFromArray:menuItem.thumbs];
            
            [subMenuItems insertObject:item atIndex:0];
        }
    }
    
    [_submenuItemsTableView reloadData];
}

- (CGFloat) currentHeightForSubMenuItem:(CCMenuItem*) subMenuItem andSeparator:(CCSeparator*) separator {
    CGFloat gap = (cols == 2) ? MENU_ITEM_HORIZONTAL_GAP : MENU_ITEM_HORIZONTAL_GAP * 2;
    CGFloat width = (_submenuItemsTableView.frame.size.width - gap) / cols;
    CGFloat height = [CCThumbCollectionViewCell heightForCellWidth:width];
    
    NSInteger count = [[subMenuItem visibleThumbs:separator] count];
    NSInteger rows = count % cols == 0 ? count / cols : count / cols + 1;
    
    // For wall material submenu, show EDIT INDIVIDUAL PANEL button
    NSInteger subMenuHeight = [subMenuItem.dataRel isEqualToString:@"wall_material"] ? SUBTITLE_LABEL_WITH_BUTTON_HEIGHT:SUBTITLE_LABEL_HEIGHT;
    
    if (subMenuItem.isExpanded || separator.isExpanded) {
        if (showsGraphicControlMenu && [subMenuItem.graphicControlMenu isEqualToString:@"1"]) {
            height += 120;
        }

        if ([subMenuItem.ID isEqualToString:FAKE_SUBMENU_ID]) {
            // fake item
            return (height + 4) * rows;
        }
        return (height + 4) * rows + subMenuHeight;
    }
    
    return subMenuHeight;
}

#pragma mark - TableView

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (forSeparators) {
        NSInteger c = menuItem.separators.count;
        return c;
    }
    return subMenuItems.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (forSeparators) {
        CCSeparator * separator = menuItem.separators[indexPath.row];
        return [self currentHeightForSubMenuItem:menuItem andSeparator:separator]; // menuItem considered as subMenuItem
    }
    
    CCMenuItem * submenu = subMenuItems[indexPath.row];
    return [self currentHeightForSubMenuItem:submenu andSeparator:nil];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString * cellId = @"CCSubmenuItemCell";
    
    CCSubmenuItemCell * cell = (CCSubmenuItemCell*)[tableView dequeueReusableCellWithIdentifier:cellId forIndexPath:indexPath];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.delegate = self;
    
    if (forSeparators) {
        CCSeparator * separator = menuItem.separators[indexPath.row];
        [cell populateThumbsWithMenuItem:menuItem columns:cols withSeparator:separator showsGraphicControlMenu:NO graphicSize:nil horizontalAlignment:nil verticalAlignment:nil];
    } else {
        CCMenuItem * submenu = subMenuItems[indexPath.row];
        [cell populateThumbsWithMenuItem:submenu columns:cols withSeparator:nil showsGraphicControlMenu:showsGraphicControlMenu && [submenu.graphicControlMenu isEqualToString:@"1"] graphicSize:self.graphicSize horizontalAlignment:self.horizontalAlignment verticalAlignment:self.verticalAlignment];
    }
    
    return cell;
}

#pragma mark - CCSubmenuItemCellDelegate

- (void) submenuItem:(CCMenuItem *)item didSelectThumb:(CCThumb *)thumb inCollectionView:(UICollectionView *)cView {
    if (self.delegate && [self.delegate respondsToSelector:@selector(menuItem:subMenuItem:didSelectThumb:inCollectionView:)]) {
        [self.delegate menuItem:menuItem subMenuItem:item didSelectThumb:thumb inCollectionView:cView];
    }
}

- (void) submenuItem: (CCMenuItem*) item didExpandedOrCollapsed:(BOOL) expanded {
    [_submenuItemsTableView reloadData];
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(menuItem:didExpandOrCollapseSubMenuItem:)]) {
        [self.delegate menuItem:menuItem didExpandOrCollapseSubMenuItem:item];
    }
}

- (void)didTapGraphicSize {
    [self.delegate didTapGraphicSize];
}

- (void)didTapHorizontalAlignment {
    [self.delegate didTapHorizontalAlignment];
}

- (void)didTapVerticalAlignment {
    [self.delegate didTapVerticalAlignment];
}

- (UIView *)selectedThumbCell {
    NSInteger rows = [self tableView:self.submenuItemsTableView numberOfRowsInSection:0];
    for (NSInteger row = 0 ; row < rows ; row ++) {
        CCSubmenuItemCell *cell = (CCSubmenuItemCell *)[self.submenuItemsTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:row inSection:0]];
        UIView *selectedCell = [cell selectedThumbCell];
        if (selectedCell != nil) return selectedCell;
    }
    return nil;
}

- (UIView *)visibleGraphicControlMenuView {
    NSInteger rows = [self tableView:self.submenuItemsTableView numberOfRowsInSection:0];
    for (NSInteger row = 0 ; row < rows ; row ++) {
        CCSubmenuItemCell *cell = (CCSubmenuItemCell *)[self.submenuItemsTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:row inSection:0]];
        UIView *view = [cell visibleGraphicControlMenuView];
        if (view != nil) return view;
    }
    return nil;
}

@end
