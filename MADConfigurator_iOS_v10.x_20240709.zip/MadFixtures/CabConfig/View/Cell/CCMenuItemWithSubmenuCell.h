//
//  CCMenuItemWithSubmenuCell.h
//  MadCabConfigurator
//
//  Created by Alex on 2/18/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

#define SUBTITLE_LABEL_HEIGHT       32
#define SUBTITLE_LABEL_WITH_BUTTON_HEIGHT 72

@class CCMenuItem;
@class CCSeparator;
@class CCThumb;
@class CCMenuItemCell;

@class CCMenuItemWithSubmenuCell;

@protocol CCMenuItemWithSubmenuCellDelegate <NSObject>
- (void) menuItem: (CCMenuItem*) menuItem subMenuItem:(CCMenuItem*) subMenuItem didSelectThumb:(CCThumb*) thumb inCollectionView:(UICollectionView*) cView;
- (void) menuItem:(CCMenuItem *) menuItem didExpandOrCollapseSubMenuItem:(CCMenuItem *) subMenuItem;
- (void) didTapGraphicSize;
- (void) didTapHorizontalAlignment;
- (void) didTapVerticalAlignment;
@end

@interface CCMenuItemWithSubmenuCell : UITableViewCell <UITableViewDelegate, UITableViewDataSource>
{

}

@property (nonatomic, weak) IBOutlet UITableView * submenuItemsTableView;
@property (nonatomic, assign) id<CCMenuItemWithSubmenuCellDelegate> delegate;

- (void) populateSubmenusWithMenuItem:(CCMenuItem*) menuItem showsGraphicControlMenu:(BOOL)showsGraphicControlMenu graphicSize:(NSString*)graphicSize horizontalAlignment:(NSString*)horizontalAlignment verticalAlignment:(NSString*)verticalAlignment;

- (UIView *)selectedThumbCell;
- (UIView *)visibleGraphicControlMenuView;

@end
