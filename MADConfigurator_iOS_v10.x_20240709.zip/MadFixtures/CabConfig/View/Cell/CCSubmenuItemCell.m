//
//  CCSubmenuItemCell.m
//  MadCabConfigurator
//
//  Created by Alex on 2/19/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import "CCSubmenuItemCell.h"
#import "CCThumbCollectionViewCell.h"
#import "CCMenuItemWithSubmenuCell.h"
#import "CCMenuItem.h"
#import "CCSeparator.h"
#import "Constants.h"
#import "CCThumb.h"

@interface CCSubmenuItemCell ()  <UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout>
{
    CCMenuItem * subMenuItem;
    CCSeparator * separator;
    NSInteger columns;
    NSArray * thumbs;
    BOOL showsGraphicControlMenu;
}

@property (nonatomic, strong) NSString* graphicSize;
@property (nonatomic, strong) NSString* horizontalAlignment;
@property (nonatomic, strong) NSString* verticalAlignment;

@end

@implementation CCSubmenuItemCell

- (void)awakeFromNib {
    [super awakeFromNib];
    columns = 2;
    // Initialization code
    
    self.btnGraphicSize.layer.borderWidth = 1;
    self.btnGraphicSize.layer.cornerRadius = 4;
    self.btnGraphicSize.layer.borderColor = [UIColor darkGrayColor].CGColor;
    self.btnGraphicSize.clipsToBounds = YES;
    
    self.btnHorizontalAlignment.layer.borderWidth = 1;
    self.btnHorizontalAlignment.layer.cornerRadius = 4;
    self.btnHorizontalAlignment.layer.borderColor = [UIColor darkGrayColor].CGColor;
    self.btnHorizontalAlignment.clipsToBounds = YES;
    
    self.btnVerticalAlignment.layer.borderWidth = 1;
    self.btnVerticalAlignment.layer.cornerRadius = 4;
    self.btnVerticalAlignment.layer.borderColor = [UIColor darkGrayColor].CGColor;
    self.btnVerticalAlignment.clipsToBounds = YES;
}

- (IBAction)expandOrCollapse:(id)sender {
    if (separator) {
        separator.isExpanded = !separator.isExpanded;
    } else {
        subMenuItem.isExpanded = !subMenuItem.isExpanded;
    }
    
    thumbCollectionView.hidden = (separator) ? !separator.isExpanded : !subMenuItem.isExpanded;
    
    if (separator) {
        if (subMenuItem.isExpanded) {
            arrowImageView.image = [UIImage imageNamed:@"ic_black_arrow_down"];
        } else {
            arrowImageView.image = [UIImage imageNamed:@"ic_black_arrow_right"];
        }
    } else {
        if (separator.isExpanded) {
            arrowImageView.image = [UIImage imageNamed:@"ic_black_arrow_down"];
        } else {
            arrowImageView.image = [UIImage imageNamed:@"ic_black_arrow_right"];
        }
    }
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(submenuItem:didExpandedOrCollapsed:)]) {
        [self.delegate submenuItem:subMenuItem didExpandedOrCollapsed:subMenuItem.isExpanded];
    }
}

- (void) populateThumbsWithMenuItem:(CCMenuItem*) menuItem columns:(NSInteger)columns_ withSeparator:(CCSeparator*) separator_ showsGraphicControlMenu:(BOOL)showGraphicControlMenu_ graphicSize:(NSString *)graphicSize_ horizontalAlignment:(NSString *)horizontalAlignment_ verticalAlignment:(NSString *)verticalAlignment_ {
    subMenuItem = menuItem;
    separator = separator_;
    columns = columns_;
    showsGraphicControlMenu = showGraphicControlMenu_;
    self.graphicSize = graphicSize_;
    self.horizontalAlignment = horizontalAlignment_;
    self.verticalAlignment = verticalAlignment_;
    thumbs = [menuItem visibleThumbs:separator];
    
    submenuTitleLabel.text = (separator) ? separator.title : menuItem.title;
    
    if (separator) {
        if (separator.isExpanded) {
            arrowImageView.image = [UIImage imageNamed:@"ic_black_arrow_down"];
            thumbCollectionView.hidden = NO;
        } else {
            arrowImageView.image = [UIImage imageNamed:@"ic_black_arrow_right"];
            thumbCollectionView.hidden = YES;
        }
    } else {
        if ([subMenuItem.ID isEqualToString:FAKE_SUBMENU_ID]) {
            subMenuItem.isExpanded = YES;
            submenuTitleView.hidden = YES;
            submenuTitleViewHeight.constant = 0;
            thumbCollectionView.hidden = NO;
        } else {
            submenuTitleView.hidden = NO;
            submenuTitleViewHeight.constant = SUBTITLE_LABEL_HEIGHT;

            if (subMenuItem.isExpanded) {
                arrowImageView.image = [UIImage imageNamed:@"ic_black_arrow_down"];
                thumbCollectionView.hidden = NO;
            } else {
                arrowImageView.image = [UIImage imageNamed:@"ic_black_arrow_right"];
                thumbCollectionView.hidden = YES;
            }
        }
    }
    
    if ([subMenuItem.dataRel isEqualToString:@"wall_material"]){
        editIndividualPanelBtn.hidden = NO;
        editIndividualPanelBtn.layer.cornerRadius = 3.0f;
        submenuTitleViewTop.constant = 40;
    }else{
        editIndividualPanelBtn.hidden = YES;
        submenuTitleViewTop.constant = 0;
    }
    
    _viewGraphicControlMenu.hidden = !showsGraphicControlMenu;
    
    if ([self.graphicSize isEqualToString:GRAPHIC_SIZE_FULL]) {
        [_btnGraphicSize setTitle:@"Full" forState:UIControlStateNormal];
    } else if ([self.graphicSize isEqualToString:GRAPHIC_SIZE_MEDIUM]) {
        [_btnGraphicSize setTitle:@"Medium" forState:UIControlStateNormal];
    } else if ([self.graphicSize isEqualToString:GRAPHIC_SIZE_SMALL]) {
        [_btnGraphicSize setTitle:@"Small" forState:UIControlStateNormal];
    } else {
        [_btnGraphicSize setTitle:@"" forState:UIControlStateNormal];
    }
    
    if ([self.horizontalAlignment isEqualToString:GRAPHIC_HALIGN_LEFT]) {
        [_btnHorizontalAlignment setTitle:@"Left" forState:UIControlStateNormal];
    } else if ([self.horizontalAlignment isEqualToString:GRAPHIC_HALIGN_RIGHT]) {
        [_btnHorizontalAlignment setTitle:@"Right" forState:UIControlStateNormal];
    } else if ([self.horizontalAlignment isEqualToString:GRAPHIC_HALIGN_CENTER]) {
        [_btnHorizontalAlignment setTitle:@"Center" forState:UIControlStateNormal];
    } else {
        [_btnHorizontalAlignment setTitle:@"" forState:UIControlStateNormal];
    }

    if ([self.verticalAlignment isEqualToString:GRAPHIC_VALIGN_TOP]) {
        [_btnVerticalAlignment setTitle:@"Top" forState:UIControlStateNormal];
    } else if ([self.verticalAlignment isEqualToString:GRAPHIC_VALIGN_BOTTOM]) {
        [_btnVerticalAlignment setTitle:@"Bottom" forState:UIControlStateNormal];
    } else if ([self.verticalAlignment isEqualToString:GRAPHIC_VALIGN_CENTER]) {
        [_btnVerticalAlignment setTitle:@"Center" forState:UIControlStateNormal];
    } else {
        [_btnVerticalAlignment setTitle:@"" forState:UIControlStateNormal];
    }
    
    [thumbCollectionView reloadData];
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return thumbs.count;
}

- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    CCThumbCollectionViewCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"CCThumbCollectionViewCell" forIndexPath:indexPath];
    
    CCThumb * thumb = thumbs[indexPath.row];
    [cell populateWithThumb:thumb];
    
    return cell;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    CGFloat gap = (columns == 2) ? MENU_ITEM_HORIZONTAL_GAP : MENU_ITEM_HORIZONTAL_GAP * 2;

    CGFloat cellWidth = (collectionView.frame.size.width - gap) / columns;
    CGFloat cellHeight = [CCThumbCollectionViewCell heightForCellWidth:cellWidth];
    
    return CGSizeMake(cellWidth, cellHeight);
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    if (self.delegate && [self.delegate respondsToSelector:@selector(submenuItem:didSelectThumb:inCollectionView:)]) {
        CCThumb * thumb = thumbs[indexPath.row];
        [self.delegate submenuItem:subMenuItem didSelectThumb:thumb inCollectionView:collectionView];
    }
}


- (void)onTapGraphicSize:(id)sender {
    [self.delegate didTapGraphicSize];
}

- (void)onTapHorizontalAlignment:(id)sender {
    [self.delegate didTapHorizontalAlignment];
}

- (void)onTapVerticalAlignment:(id)sender {
    [self.delegate didTapVerticalAlignment];
}

- (UIView *)selectedThumbCell {
    if (thumbCollectionView.isHidden) return nil;
    
    for (NSInteger index = 0 ; index < thumbs.count ; index ++ ) {
        CCThumb *thumb = thumbs[index];
        if (thumb.isSelected) {
            return [thumbCollectionView cellForItemAtIndexPath:[NSIndexPath indexPathForItem:index inSection:0]];
        }
    }
    
    return nil;
}

- (UIView *)visibleGraphicControlMenuView {
    if (self.viewGraphicControlMenu.isHidden) return nil;
    return self.viewGraphicControlMenu;
}

@end
