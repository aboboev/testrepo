//
//  CCMenuItemCell.m
//  MadCabConfigurator
//
//  Created by Alex on 2/18/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import "CCMenuItemCell.h"
#import "CCThumbCollectionViewCell.h"
#import "CCMenuItem.h"
#import "CCSeparator.h"
#import "Constants.h"
#import "CCThumb.h"

@interface CCMenuItemCell ()  <UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout>
{
    CCMenuItem * parentMenuItem;
    NSInteger columns;
    NSArray * thumbs;
}
@end

@implementation CCMenuItemCell

- (void)awakeFromNib {
    [super awakeFromNib];
    columns = 2;
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

- (void) populateThumbsWithMenuItem:(CCMenuItem*) menuItem {
    parentMenuItem = menuItem;
    thumbs = [menuItem visibleThumbs:nil];
    
    [_thumbCollectionView reloadData];
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return thumbs.count;
}

- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    CCThumbCollectionViewCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"CCThumbCollectionViewCell" forIndexPath:indexPath];
    
    CCThumb * thumb = thumbs[indexPath.row];
    [cell populateWithThumb:thumb];
    
    return cell;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    long cols = columns;
    if ([parentMenuItem.folder isEqualToString:@"opening_type"] || [parentMenuItem.folder isEqualToString:@"hall_finish"] || [parentMenuItem.folder isEqualToString:@"side_wall"] || [parentMenuItem.folder isEqualToString:@"hall_building"] || [parentMenuItem.folder isEqualToString:@"ending_type"] || [parentMenuItem.folder isEqualToString:@"cop_type"] || [parentMenuItem.folder isEqualToString:@"ceiling_type"]){
        cols = 3;
    }
    CGFloat cellWidth = (collectionView.frame.size.width - MENU_ITEM_HORIZONTAL_GAP * (cols - 1)) / cols;
    CGFloat cellHeight = [CCThumbCollectionViewCell heightForCellWidth:cellWidth];
    
    return CGSizeMake(cellWidth, cellHeight);
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    if (self.delegate && [self.delegate respondsToSelector:@selector(menuItemCell:didSelectThumb:inCollectionView:atIndex:)]) {
        CCThumb * thumb = thumbs[indexPath.row];        
        [self.delegate menuItemCell:self didSelectThumb:thumb inCollectionView:collectionView atIndex:indexPath.row];
    }
}

@end
