//
//  SavedConfigCell.h
//  MadCabConfigurator
//
//  Created by Alex on 1/16/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CabConfig;
@protocol SavedConfigCellDelegate <NSObject>

- (void) onTapProjectNameForConfigAtIndex:(NSInteger) i;
- (void) onTapRequestQuoteForConfigAtIndex:(NSInteger) i;
- (void) onTapRemoveForConfigAtIndex:(NSInteger) i;
- (void) onTapCreatePDFForConfigAtIndex:(NSInteger) i;

@end

@interface SavedConfigCell : UITableViewCell
{
    
}

@property (nonatomic, strong) CabConfig * config;

@property (nonatomic, assign) id delegate;
@property (nonatomic, assign) NSInteger index;
@property (nonatomic, weak) IBOutlet UILabel * dateLabel;
@property (nonatomic, weak) IBOutlet UILabel * customerLabel;
@property (nonatomic, weak) IBOutlet UIButton * projButton;

- (void) configWithConfig:(CabConfig*) config;

- (IBAction) project:(id)sender;
- (IBAction) requestQuote:(id)sender;
- (IBAction) email:(id)sender;
- (IBAction) remove:(id)sender;

@end
