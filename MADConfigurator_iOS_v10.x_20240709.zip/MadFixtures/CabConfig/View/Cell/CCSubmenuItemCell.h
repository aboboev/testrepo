//
//  CCSubmenuItemCell.h
//  MadCabConfigurator
//
//  Created by Alex on 2/19/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CCMenuItem;
@class CCSeparator;
@class CCThumb;
@class CCMenuItemCell;

@class CCSubmenuItemCell;
@protocol CCSubmenuItemCellDelegate <NSObject>
- (void) submenuItem: (CCMenuItem*) item didSelectThumb:(CCThumb*) thumb inCollectionView:(UICollectionView*) cView;
- (void) submenuItem: (CCMenuItem*) item didExpandedOrCollapsed:(BOOL) expanded;
- (void) didTapGraphicSize;
- (void) didTapHorizontalAlignment;
- (void) didTapVerticalAlignment;
@end

@interface CCSubmenuItemCell : UITableViewCell 
{
    IBOutlet UICollectionView * thumbCollectionView;
    IBOutlet UILabel * submenuTitleLabel;
    IBOutlet UIImageView * arrowImageView;
    
    IBOutlet UIView * submenuTitleView;
    IBOutlet NSLayoutConstraint * submenuTitleViewHeight;
    IBOutlet UIButton * editIndividualPanelBtn;
    IBOutlet NSLayoutConstraint * submenuTitleViewTop;
}

@property (nonatomic, assign) id<CCSubmenuItemCellDelegate> delegate;
@property (nonatomic, strong) NSIndexPath * indexPath;

@property (nonatomic, weak) IBOutlet UIView *viewGraphicControlMenu;
@property (nonatomic, weak) IBOutlet UIButton *btnGraphicSize;
@property (nonatomic, weak) IBOutlet UIButton *btnHorizontalAlignment;
@property (nonatomic, weak) IBOutlet UIButton *btnVerticalAlignment;

- (IBAction)onTapGraphicSize:(id)sender;
- (IBAction)onTapHorizontalAlignment:(id)sender;
- (IBAction)onTapVerticalAlignment:(id)sender;

- (void) populateThumbsWithMenuItem:(CCMenuItem*) menuItem columns:(NSInteger)columns withSeparator:(CCSeparator*) separator showsGraphicControlMenu:(BOOL)showsGraphicControlMenu graphicSize:(NSString*)graphicSize horizontalAlignment:(NSString*)horizontalAlignment verticalAlignment:(NSString*)verticalAlignment;

- (IBAction)expandOrCollapse:(id)sender;

- (UIView *)selectedThumbCell;
- (UIView *)visibleGraphicControlMenuView;

@end
