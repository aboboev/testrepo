//
//  SavedConfigCell.m
//  MadCabConfigurator
//
//  Created by Alex on 1/16/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import "SavedConfigCell.h"
#import "CabConfig.h"

@implementation SavedConfigCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void) configWithConfig:(CabConfig*) config {
    self.config = config;
    
    NSDateFormatter * formatter = [[NSDateFormatter alloc] init];
    formatter.dateStyle = NSDateFormatterShortStyle;
//    [formatter setDateFormat:@"yyyy/MM/dd"];
    
    self.dateLabel.text = [formatter stringFromDate:config.configDate];
    [self.projButton setTitle:config.projectName forState:UIControlStateNormal];
    self.customerLabel.text = config.customerName;
}

- (IBAction) project:(id)sender {
    if (self.delegate && [self.delegate respondsToSelector:@selector(onTapProjectNameForConfigAtIndex:)]) {
        [self.delegate onTapProjectNameForConfigAtIndex:self.index];
    }
}

- (IBAction) requestQuote:(id)sender {
    if (self.delegate && [self.delegate respondsToSelector:@selector(onTapRequestQuoteForConfigAtIndex:)]) {
        [self.delegate onTapRequestQuoteForConfigAtIndex:self.index];
    }
}

- (IBAction) email:(id)sender {
    if (self.delegate && [self.delegate respondsToSelector:@selector(onTapCreatePDFForConfigAtIndex:)]) {
        [self.delegate onTapCreatePDFForConfigAtIndex:self.index];
    }
}

- (IBAction) remove:(id)sender {
    if (self.delegate && [self.delegate respondsToSelector:@selector(onTapRemoveForConfigAtIndex:)]) {
        [self.delegate onTapRemoveForConfigAtIndex:self.index];
    }
}

@end
