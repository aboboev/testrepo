//
//  CCThumbCollectionViewCell.h
//  MadCabConfigurator
//
//  Created by Alex on 2/18/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CCThumb;
@interface CCThumbCollectionViewCell : UICollectionViewCell
{
    CCThumb * thumb;
}
@property (nonatomic, weak) IBOutlet NSLayoutConstraint * thumbImageViewHeight;

@property (nonatomic, weak) IBOutlet UIImageView * thumbImageView;
@property (nonatomic, weak) IBOutlet UILabel * titleLabel;
@property (nonatomic, weak) IBOutlet UIView * selectedRectView;
@property (nonatomic, weak) IBOutlet UIView * contentHolderView;

+ (CGFloat) heightForCellWidth:(CGFloat) width;
- (void) populateWithThumb:(CCThumb*) thumb;

@end
