//
//  CCMenuItemCell.h
//  MadCabConfigurator
//
//  Created by Alex on 2/18/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CCMenuItem;
@class CCSeparator;
@class CCThumb;
@class CCMenuItemCell;

// MenuItemCell without separator or submenus such as Side wall or Door opening

@protocol CCMenuItemCellDelegate <NSObject>
- (void) menuItemCell: (CCMenuItemCell*) cell didSelectThumb:(CCThumb*) thumb inCollectionView:(UICollectionView*) cView atIndex:(NSInteger) index;
@end

@interface CCMenuItemCell : UITableViewCell

@property (nonatomic, assign) id<CCMenuItemCellDelegate> delegate;
@property (nonatomic, weak) IBOutlet UICollectionView * thumbCollectionView;


- (void) populateThumbsWithMenuItem:(CCMenuItem*) menuItem;

@end
