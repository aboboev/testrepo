//
//  RequestQuoteTopView.h
//  MadCabConfigurator
//
//  Created by Alex on 1/22/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CCInputScreenTopBar : UIView
{

}

@property(nonatomic, weak) IBOutlet UILabel * titleLabel;

+ (CCInputScreenTopBar*) showOnView:(UIView*) view  topGuide: (CGFloat) topGuide;
- (void)setTitle:(NSString*) title;

+ (void)removeTopBar;

@end
