//
//  RequestQuoteCapacityInputView.h
//  MadCabConfigurator
//
//  Created by Alex on 1/22/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^selection_block)(NSInteger capacity);
@interface RequestQuoteCapacityInputView : UIView
{
    IBOutlet UIView * selectView;
    IBOutlet UIButton * okButton;
    IBOutlet NSLayoutConstraint * centerYConstraint;
}

@property (nonatomic, weak) IBOutletCollection(UIButton) NSArray* buttons;
@property (nonatomic, weak) IBOutlet UITextField * otherTextField;

@property (nonatomic) selection_block selectedValueBlock;

- (IBAction)close:(id)sender;

- (IBAction)onSelectValue:(id)sender;
- (IBAction)ok:(id)sender;

+ (RequestQuoteCapacityInputView*) showOnView:(UIView*) view;

@end
