//
//  RequestQuoteBottomView.h
//  MadCabConfigurator
//
//  Created by Alex on 1/22/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^on_submit_block)(void);
typedef void (^on_back_block)(void);

@interface CCInputScreenBottomBar : UIView
{
    IBOutlet UIButton * submitButton;
    IBOutlet UIButton * backButton;
}

@property (nonatomic) on_submit_block submitBlock;
@property (nonatomic) on_back_block backBlock;

+ (CCInputScreenBottomBar*) showOnView:(UIView*) view;
+ (CCInputScreenBottomBar*) view;

- (void) setSubmitButtonTitle:(NSString*) title;

- (IBAction)onSubmit:(id)sender;
- (IBAction)onBack:(id)sender;

+ (void)removeBottomBar;

@end
