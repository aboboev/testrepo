//
//  RequestQuoteTopView.m
//  MadCabConfigurator
//
//  Created by Alex on 1/22/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import "CCInputScreenTopBar.h"
#import "AppDelegate.h"

#define TopBarTag      19991

@implementation CCInputScreenTopBar

+ (CCInputScreenTopBar*) showOnView:(UIView*) view topGuide: (CGFloat) topGuide {
    if (view == nil) return nil;
    CCInputScreenTopBar * bview = (CCInputScreenTopBar*) [[[NSBundle mainBundle] loadNibNamed:@"CCInputScreenTopBar" owner:nil options:nil] firstObject];
    bview.translatesAutoresizingMaskIntoConstraints = NO;
    bview.tag = TopBarTag;
    [view addSubview:bview];
    
    NSMutableArray * constraints = [[NSMutableArray alloc] init];
    [constraints addObjectsFromArray:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[bview]|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(bview)]];
    [constraints addObject:[NSLayoutConstraint constraintWithItem:bview attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:view attribute:NSLayoutAttributeTop multiplier:1.0 constant:topGuide]];
    
    [view addConstraints:constraints];
    
    [bview addConstraint:[NSLayoutConstraint constraintWithItem:bview attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1.0 constant:44]];
    
    return bview;
}

+ (void)removeTopBar {
    UIWindow * window = [(AppDelegate*)[UIApplication sharedApplication].delegate window];
    for (UIView* v in window.subviews) {
        if (v.tag == TopBarTag) {
            [v removeFromSuperview];
            break;
        }
    }
}

- (void)setTitle:(NSString*) title {
    self.titleLabel.text = title;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
