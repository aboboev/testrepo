//
//  CCCanvasView.h
//  MadFixtures
//
//  Created by Alex on 2/6/24.
//  Copyright © 2024 Mad Elevator. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CCLayoutPanel.h"

@interface CCCanvasView : UIView
{
    
}
- (void) setTouchedPanel:(CGPoint) touchedPoint ZoomScale:(CGFloat)zoomScale;
- (void) setPanelsVisibility:(BOOL)visible selection:(BOOL)selection;
@property (nonatomic, strong) CCLayoutPanel * selectedPanel;
@property (nonatomic, strong) NSMutableArray <CCLayoutPanel*>* panels;
@end
