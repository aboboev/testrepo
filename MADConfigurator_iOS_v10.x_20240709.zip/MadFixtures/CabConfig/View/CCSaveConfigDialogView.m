//
//  CCSaveConfigDialogView.m
//  MadCabConfigurator
//
//  Created by Alex on 1/14/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import "CCSaveConfigDialogView.h"

@implementation CCSaveConfigDialogView

+ (CCSaveConfigDialogView*) showOnView:(UIView*) view_ {
    if (view_ == nil) return nil;
    
    CCSaveConfigDialogView * opView = (CCSaveConfigDialogView*) [[[NSBundle mainBundle] loadNibNamed:@"CCSaveConfigDialogView" owner:nil options:nil] firstObject];
    opView.translatesAutoresizingMaskIntoConstraints = NO;
    
    [view_ addSubview:opView];
    
    NSMutableArray * constraints = [[NSMutableArray alloc] init];
    [constraints addObjectsFromArray:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[opView]|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(opView)]];
    [constraints addObjectsFromArray:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[opView]|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(opView)]];
    [view_ addConstraints:constraints];
    
    return opView;
}

- (void) setProjectName:(NSString*) projectName customerName:(NSString*) custoerName {
    projectTextField.text = projectName;
    customerTextField.text = custoerName;
}

- (void) showSuccess {
    formView.hidden = YES;
    successView.hidden = NO;
}

- (IBAction)close:(id)sender {
    [self removeFromSuperview];
}

- (IBAction)save:(id)sender {
    if (projectTextField.text.length == 0 ||
        customerTextField.text.length == 0) {
        return;
    }
    if (self.saveBlock) {
        self.saveBlock(projectTextField.text, customerTextField.text);
    }
    [self endEditing:YES];
}

- (void)awakeFromNib {
    [super awakeFromNib];
    
    formView.layer.cornerRadius = 8;
    successView.layer.cornerRadius = 8;
    saveButton.layer.cornerRadius = 3;

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
}

- (void)removeFromSuperview {
    [super removeFromSuperview];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void) keyboardWillShow:(NSNotification*) notification {
    centerYConstraint.constant = -90;
}

- (void) keyboardWillHide:(NSNotification*) notification {
    centerYConstraint.constant = 0;
}

@end
