//
//  RemoveConfigConfirmView.m
//  MadCabConfigurator
//
//  Created by Alex on 2/16/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import "RemoveConfigConfirmView.h"
#import "CabConfig.h"

@implementation RemoveConfigConfirmView

+ (RemoveConfigConfirmView*) showOnView:(UIView*) view_ {
    if (view_ == nil) return nil;
    
    RemoveConfigConfirmView * opView = (RemoveConfigConfirmView*) [[[NSBundle mainBundle] loadNibNamed:@"RemoveConfigConfirmView" owner:nil options:nil] firstObject];
    opView.translatesAutoresizingMaskIntoConstraints = NO;
    
    [view_ addSubview:opView];
    
    NSMutableArray * constraints = [[NSMutableArray alloc] init];
    [constraints addObjectsFromArray:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[opView]|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(opView)]];
    [constraints addObjectsFromArray:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[opView]|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(opView)]];
    [view_ addConstraints:constraints];
    
    return opView;
}

- (void) configWithConfig:(CabConfig*) config {
    projLabel.text = config.projectName;
    customerLabel.text = config.customerName;
    
    NSDateFormatter * formatter = [[NSDateFormatter alloc] init];
    formatter.dateStyle = NSDateFormatterShortStyle;
    
    dateLabel.text = [formatter stringFromDate:config.configDate];
}

- (IBAction)close:(id)sender {
    [self removeFromSuperview];
}

- (IBAction)yes:(id)sender {
    [self close:sender];
    if (self.yesBlock) {
        self.yesBlock();
        self.yesBlock = nil;
    }
}

- (IBAction)no:(id)sender {
    [self close:sender];
}

- (void)awakeFromNib {
    [super awakeFromNib];
    
    confirmView.layer.cornerRadius = 8;
}

@end
