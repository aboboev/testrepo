//
//  LandscapeNavigationController.h
//  MadCabConfigurator
//
//  Created by Alex on 2/26/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LandscapeNavigationController : UINavigationController

@end
