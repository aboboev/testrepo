//
//  RequestQuoteViewController.m
//  MadCabConfigurator
//
//  Created by Alex on 1/22/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import "RequestQuoteViewController.h"
#import "CCInputScreenBottomBar.h"
#import "CCInputScreenTopBar.h"
#import "RequestQuoteTwoOptionsView.h"
#import "RequestQuoteFourOptionsView.h"
#import "RequestQuoteCapacityInputView.h"
#import "AppDelegate.h"
#import "Constants.h"
#import "CCRequestData.h"
#import "PDFPreviewViewController.h"

@interface RequestQuoteViewController ()
{
    BOOL didAddBars;
}
@end

@implementation RequestQuoteViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    didAddBars = NO;
    
    [self.tableView setKeyboardDismissMode:UIScrollViewKeyboardDismissModeOnDrag];
    
    [self setInputAccessoryViews];
    
    notesTextView.layer.cornerRadius = 8;
    notesTextView.layer.borderWidth = 1.0f;
    notesTextView.layer.borderColor = [UIColor lightGrayColor].CGColor;
    
    chkCabInterior.on = YES;
    chkCabInterior.delegate = self;
    chkShell.on = YES;
    chkShell.delegate = self;
    chkCOP.on = YES;
    chkCOP.delegate = self;
    chkFixtures.on = YES;
    chkFixtures.delegate = self;
    
    [self fillInputs];
    // Do any additional setup after loading the view.
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    
    if (!didAddBars) {
        [self addHeaderAndFooter];
        didAddBars = YES;
    }
}

- (void) setInputAccessoryViews {
    CCInputScreenBottomBar* bottomBar = [CCInputScreenBottomBar view];
    [bottomBar setSubmitButtonTitle:@"Submit"];
    
    nameTextField.inputAccessoryView = bottomBar;
    emailTextField.inputAccessoryView = bottomBar;
    companyTextField.inputAccessoryView = bottomBar;
    phoneTextField.inputAccessoryView = bottomBar;
    projectTextField.inputAccessoryView = bottomBar;
    addressTextField.inputAccessoryView = bottomBar;
    widthTextField.inputAccessoryView = bottomBar;
    heightTextField.inputAccessoryView = bottomBar;
    depthTextField.inputAccessoryView = bottomBar;
    risersNumTextField.inputAccessoryView = bottomBar;
    openingsNumTextField.inputAccessoryView = bottomBar;
    elevatorNumTextField.inputAccessoryView = bottomBar;
    controllerTextField.inputAccessoryView = bottomBar;
    controllerTypeTextField.inputAccessoryView = bottomBar;
    capacityTextField.inputAccessoryView = bottomBar;
    notesTextView.inputAccessoryView = bottomBar;
    
    __weak RequestQuoteViewController* wself = self;
    bottomBar.backBlock = ^(void) {
        [self.view endEditing:YES];
        [CCInputScreenBottomBar removeBottomBar];
        [CCInputScreenTopBar removeTopBar];
        [wself dismissViewControllerAnimated:YES completion:nil];
    };
    
    bottomBar.submitBlock = ^(void) {
        [wself submitAndRemove];
    };
}

- (void) fillInputs {
    NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
    
    if (self.customerName != nil && self.customerName.length > 0) {
        nameTextField.text = self.customerName;
    } else {
        NSString * name = [defaults objectForKey:USER_NAME_KEY];
        if (name) {
            nameTextField.text = name;
        }
    }
    
    NSString * email = [defaults objectForKey:USER_EMAIL_KEY];
    if (email) {
        emailTextField.text = email;
    }
    NSString * company = [defaults objectForKey:USER_COMPANY_KEY];
    if (company) {
        companyTextField.text = company;
    }
    NSString * phone = [defaults objectForKey:USER_PHONE_KEY];
    if (phone) {
        phoneTextField.text = phone;
    }
    
    projectTextField.text = self.projName;
}

- (void) addHeaderAndFooter {
    __weak CCInputScreenBottomBar * bottomView = [CCInputScreenBottomBar showOnView:[(AppDelegate*)[UIApplication sharedApplication].delegate window]];
    #pragma clang diagnostic ignored "-Wdeprecated-declarations"
    CGFloat topMargin = self.topLayoutGuide.length;
    CCInputScreenTopBar * topView = [CCInputScreenTopBar showOnView:[(AppDelegate*)[UIApplication sharedApplication].delegate window] topGuide:topMargin];
    [topView setTitle:@"REQUEST QUOTE"];
    
    self.tableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
    self.tableView.contentInset = UIEdgeInsetsMake(0, 0, 0, 0);
    
    CGRect frame = self.tableView.frame;
    frame.origin.y += topMargin;
    frame.size.height -= topMargin;
    self.tableView.frame = frame;
    
    bottomView.submitBlock = ^(void) {
        [self submitAndRemove];
    };
    bottomView.backBlock = ^(void) {
        
        [self.view endEditing:YES];
        [CCInputScreenBottomBar removeBottomBar];
        [CCInputScreenTopBar removeTopBar];

        [self dismissViewControllerAnimated:YES completion:nil];
    };
}

- (void) submitAndRemove {
    if (self.requestData == nil) {
        return;
    }

    NSString * name = nameTextField.text;
    NSString * email = emailTextField.text;
    NSString * company = companyTextField.text;
    NSString * phone = phoneTextField.text;
    NSString * project = projectTextField.text;
    NSString * address = addressTextField.text;
    
    UITextField * errorField = nil;
    NSString * error = nil;
    
    if (name.length == 0) {
        errorField = nameTextField;
        error = @"Please input your Name!";
    } else if (email.length == 0) {
        errorField = emailTextField;
        error = @"Please input your Email!";
    } else if (company.length == 0) {
        errorField = companyTextField;
        error = @"Please input your Company!";
    } else if (phone.length == 0) {
        errorField = phoneTextField;
        error = @"Please input your Phone!";
    } else if (project.length == 0){
        errorField = projectTextField;
        error = @"Please input project name!";
    } else if (address.length == 0){
        errorField = addressTextField;
        error = @"Please input project address";
    }
    
    if (error && errorField) {
        UIAlertController *menu = [UIAlertController alertControllerWithTitle:nil message:error preferredStyle:UIAlertControllerStyleAlert];
        [menu addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
            [errorField becomeFirstResponder];
        }]];
        [self presentViewController:menu animated:YES completion:nil];
        return;
    }
    
    [self.view endEditing:YES];
    
//    [CCInputScreenBottomBar removeBottomBar];
//    [CCInputScreenTopBar removeTopBar];

    self.requestData.projName = projectTextField.text;
    self.requestData.email = emailTextField.text;
    self.requestData.issuedDate = [NSDate date];
    self.requestData.name = nameTextField.text;
    self.requestData.company = companyTextField.text;
    self.requestData.phone = phoneTextField.text;
    self.requestData.address = addressTextField.text;
    self.requestData.width = widthTextField.text;
    self.requestData.depth = depthTextField.text;
    self.requestData.height = heightTextField.text;
    self.requestData.capacity = capacityTextField.text;
    self.requestData.numOfElevs = elevatorNumTextField.text;
    self.requestData.numOfRisers = risersNumTextField.text;
    self.requestData.numOfOpenings = openingsNumTextField.text;
    self.requestData.controller = controllerTextField.text;
    self.requestData.controllerType = controllerTypeTextField.text;
    self.requestData.notes = notesTextView.text;
    self.requestData.isPDFCOP = chkCOP.on;
    self.requestData.isPDFCabInterior = chkCabInterior.on;
    self.requestData.isPDFHallFixtures = chkFixtures;
    NSString * provider = @"";
    if (chkCabInterior.on){
        provider = [provider stringByAppendingString:@", Cab Interior"];
    }
    if (chkShell.on){
        provider = [provider stringByAppendingString:@", Shell"];
    }
    if (chkCOP.on){
        provider = [provider stringByAppendingString:@", Car Operating Panel"];
    }
    if (chkFixtures.on){
        provider = [provider stringByAppendingString:@", Hall Fixtures"];
    }
    if (![provider isEqualToString:@""]) provider = [provider substringFromIndex:2];
    self.requestData.providerQuoteFor = provider;
    
    PDFPreviewViewController * lvc = [[UIStoryboard storyboardWithName:@"Configurator" bundle:nil] instantiateViewControllerWithIdentifier:@"PDFPreviewViewController"];
    lvc.data = self.requestData;
    lvc.fromRFQ = YES;
    lvc.modalPresentationStyle = UIModalPresentationFullScreen;
    [self presentViewController:lvc animated:YES completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)onControllerTypeInput:(id)sender {
    UIWindow * appWindow = [(AppDelegate*)[UIApplication sharedApplication].delegate window];
    
    RequestQuoteTwoOptionsView * oView = [RequestQuoteTwoOptionsView showOnView:appWindow firstOption:@"New" secondOption:@"Retaining"];
    oView.firstBlock = ^(void) {
        controllerTypeTextField.text = @"New";
    };
    oView.secondBlock = ^(void) {
        controllerTypeTextField.text = @"Retaining";
    };
}

- (IBAction)onCapacityInput:(id)sender {
    UIWindow * appWindow = [(AppDelegate*)[UIApplication sharedApplication].delegate window];
    
    RequestQuoteCapacityInputView * oView = [RequestQuoteCapacityInputView showOnView:appWindow];
    
    [oView setSelectedValueBlock:^(NSInteger val) {
        capacityTextField.text = [NSString stringWithFormat:@"%ld", (long)val];
    }];
}

- (BOOL)prefersStatusBarHidden{
    return YES;
}

- (void)didTap:(BEMCheckBox *)checkBox{
    if (!chkCabInterior.on && !chkShell.on && !chkFixtures.on && !chkCOP.on){
        chkCabInterior.on = YES;
    }
}

#pragma mark ---- Orientation ----
- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskPortrait;
}

- (BOOL)shouldAutorotate {
    return NO;
}

@end
