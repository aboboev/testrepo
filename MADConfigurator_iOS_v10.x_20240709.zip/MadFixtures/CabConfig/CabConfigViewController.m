//
//
//  CabConfigViewController.m
//  MadCabConfigurator
//
//  Created by Alex on 12/28/19.
//  Copyright © 2019 seniorcoder. All rights reserved.
//

#import "CabConfigViewController.h"
#import "RequestQuoteViewController.h"

#import "CCSaveConfigDialogView.h"
#import "CCMenuItemCell.h"
#import "SharedData.h"
#import "CabConfig.h"
#import "CCMenuItem.h"
#import "CCSeparator.h"
#import "CCThumb.h"
#import "MenuSectionHeaderView.h"
#import "Constants.h"
#import "Utils.h"
#import "NSDictionary+Extra.h"
#import "PDFPreviewViewController.h"
#import "CCCreatePDFDialogView.h"
#import "CCRequestData.h"
#import "CCThumbCollectionViewCell.h"
#import "CCMenuItemWithSubmenuCell.h"
#import "CCSubmenuItemCell.h"
#import "CCLayer.h"
#import "CCBaseSetting.h"
#import "CCLayoutPanel.h"
#import "CCPoint.h"

@interface CabConfigViewController () <CCMenuItemCellDelegate, CCMenuItemWithSubmenuCellDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate>
{
    NSArray * menuItems;
    NSMutableArray * menuVisibleItems;
    
    NSInteger expandedSection;
    MenuSectionHeaderView * oldSectionHeaderView;
    
    BOOL isDisplayingFront;
    UIImage * currentImage;
    
    // image files with z
    NSMutableArray* layers;
    
    BOOL isCabViewMode;
    BOOL isHallMain;
    
    BOOL isCabEditMode;
    
    NSString * imagesPath;
    
    BOOL preparingReqData;
    int Hall_Zoom_Index;
}

@property (nonatomic, strong) UIButton *btnDeleteAttachGraphic;

@end

@implementation CabConfigViewController

#pragma mark ---- Orientation ----
- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskLandscape;
}

- (BOOL)shouldAutorotate {
    return NO;
}

- (void) initUI {
    // Set up the minimum & maximum zoom scales
    scrollView.minimumZoomScale = 1.0f;//minScale;
    scrollView.maximumZoomScale = 4.0f;
    
    UITapGestureRecognizer *doubleTapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(scrollViewDoubleTapped:)];
    doubleTapRecognizer.numberOfTapsRequired = 2;
    doubleTapRecognizer.numberOfTouchesRequired = 1;
    [scrollView addGestureRecognizer:doubleTapRecognizer];
    
    UITapGestureRecognizer *twoFingerTapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(scrollViewTwoFingerTapped:)];
    twoFingerTapRecognizer.numberOfTapsRequired = 1;
    twoFingerTapRecognizer.numberOfTouchesRequired = 2;
    [scrollView addGestureRecognizer:twoFingerTapRecognizer];
    
    for (UIButton * b in buttons) {
        b.layer.cornerRadius = 3.0f;
    }
    activityIndicator.hidesWhenStopped = YES;
    [activityIndicator stopAnimating];
    
    [menuTableView reloadData];
    
    swhOpenCloseDoors.layer.shadowColor = [[UIColor grayColor] CGColor];
    swhOpenCloseDoors.layer.shadowOffset = CGSizeMake(2.0, 2.0);
    swhOpenCloseDoors.layer.cornerRadius = swhOpenCloseDoors.frame.size.height / 2.0;
    swhOpenCloseDoors.clipsToBounds = YES;
    
    UITapGestureRecognizer *individualPanelTapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handlePanelTapped:)];
    [scrollView addGestureRecognizer:individualPanelTapRecognizer];
    
    btnAttachGraphics.layer.borderColor = UIColor.grayColor.CGColor;
    btnAttachGraphics.layer.borderWidth = 0.5;
    btnAttachGraphics.layer.cornerRadius = btnAttachGraphics.frame.size.height / 2.0;
    btnAttachGraphics.clipsToBounds = YES;
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    imagesPath = [paths objectAtIndex:0];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setImage:[UIImage systemImageNamed:@"xmark.circle.fill"] forState:UIControlStateNormal];
    [button addTarget:self action:@selector(onDeleteAttachment:) forControlEvents:UIControlEventTouchUpInside];
    button.tintColor = [UIColor whiteColor];
    button.alpha = 0.8;
    button.hidden = YES;
    [button setFrame:CGRectMake(0, 0, 36, 36)];
    [mainView.superview addSubview:button];
    
    self.btnDeleteAttachGraphic = button;
}

- (void) resetImage:(BOOL) shouldClear {
    if (layers == nil) {
        layers = [NSMutableArray new];
    }
    
    [layers removeAllObjects];
    
    for (NSInteger i = 0; i < IMAGE_LAYER_CNT; i ++) {
        // fill with 19 empty layers
        CCLayer * l = [[CCLayer alloc] init];
        [layers addObject:l];
    }
    
    if (shouldClear) {
        mainView.layer.contents = nil;
        doorView.layer.contents = nil;
        leftDoorView.layer.contents = nil;
        rightDoorView.layer.contents = nil;
        hallWallView.layer.contents = nil;
    }
}

- (void) displayCabImage {
    UIImage * result = [self getFullImage:0 MinimumLayer:1 MaximumLayer:23 ExcludeLayer:0];
    mainView.layer.contents = (__bridge id _Nullable)(result.CGImage);
    currentImage = result;
}

- (void) displayHallDoorImage {
    NSString * opening = [self getOpening];
    NSArray<UIImage *> * doorImages = [self getHallDoorImages];
    if ([opening isEqualToString:@"3"]){
        if (!doorImages[0] || !doorImages[1]) return;
        leftDoorView.layer.contents = (__bridge id _Nullable)(doorImages[0].CGImage);
        rightDoorView.layer.contents = (__bridge id _Nullable)(doorImages[1].CGImage);
        doorView.layer.contents = nil;
    }else{
        if (!doorImages[0]) return;
        doorView.layer.contents = (__bridge id _Nullable)(doorImages[0].CGImage);
        leftDoorView.layer.contents = nil;
        rightDoorView.layer.contents = nil;
    }
}

- (void) displayHallWallImage {
    UIImage * result = [self getFullImage:0 MinimumLayer:25 MaximumLayer:30 ExcludeLayer:0];
    hallWallView.layer.contents = (__bridge id _Nullable)(result.CGImage);
}

- (void) displayHallZoomImage {
    UIImage * result = [self getFullImage:0 MinimumLayer:30 MaximumLayer:40 ExcludeLayer:0];
    mainView.layer.contents = (__bridge id _Nullable)(result.CGImage);
}

- (void)viewDidLoad {
    [super viewDidLoad];

    isDisplayingFront = self.defaultSide;
    isCabViewMode = self.defaultMode <= 0;
    isHallMain = YES;
    isCabEditMode = NO;
    Hall_Zoom_Index = 0;
    preparingReqData = NO;
    
    [self resetImage:NO];
    
    expandedSection = -1;
    menuItems = [SharedData shared].menuItems;
    
    [self doSwitchMenus:isDisplayingFront];
    
    [self initUI];
    
    if (self.defaultConfig) {
        [self loadPredefinedConfig:self.defaultConfig];
    }
    // Do any additional setup after loading the view.
    
    leftDoorClosedConstraint.active = NO;
    leftDoorOpenedConstraint.active = NO;
    rightDoorClosedConstraint.active = NO;
    rightDoorOpenedConstraint.active = NO;
    doorClosedConstraint.active = NO;
    doorOpenedConstraint.active = NO;
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
    [menuTableView performSelector:@selector(flashScrollIndicators) withObject:nil afterDelay:0];
}

- (void)setMenuItemSetting:(NSMutableDictionary*) setting item:(CCMenuItem*) item {
    if(item.dataRel == nil || item.dataRel.length == 0){
        return;
    }
    
    if (item.multi != nil && [item.multi isEqualToString:@"1"]){
        // If for accessories
        if ([item.dataRel isEqualToString:@"accessory"]){
            NSArray<CCThumb *>* selectedThumbs = [item selectedThumbs];
            NSString * values = @"";
            NSString * prefixes = @"";
            for (CCThumb *thmb in selectedThumbs){
                values = [NSString stringWithFormat:@"%@,%@", values, [thmb.attritubes stringValueForKey:@"data-val"]];
                prefixes = [NSString stringWithFormat:@"%@,%@", prefixes, [thmb.attritubes stringValueForKey:@"data-prefix"]];
            }
            
            if (![values isEqualToString:@""]){
                values = [values substringFromIndex:1];
            }
            
            if (![prefixes isEqualToString:@""]){
                prefixes = [prefixes substringFromIndex:1];
            }
            
            [setting setObject:values forKey:@"accessories"];
            [setting setObject:prefixes forKey:@"accessories_prefix"];
        }else if ([item.dataRel isEqualToString:@"hall_options"]){
            NSArray<CCThumb *>* selectedThumbs = [item selectedThumbs];
            NSString * values = @"";
            NSString * egress = @"";
            for (CCThumb *thmb in selectedThumbs){
                values = [NSString stringWithFormat:@"%@,%@", values, [thmb.attritubes stringValueForKey:@"data-val"]];
                egress = [NSString stringWithFormat:@"%@,%@", egress, [thmb.attritubes stringValueForKey:@"data-main-egress"]];
            }
            
            if (![values isEqualToString:@""]){
                values = [values substringFromIndex:1];
            }
            
            if (![egress isEqualToString:@""]){
                egress = [egress substringFromIndex:1];
            }
            
            [setting setObject:values forKey:@"hall_options"];
            [setting setObject:egress forKey:@"hall_options_egress"];
        }
    }else{
        CCThumb *selected = item.selectedThumb;
        if (!selected) return;
        
        if ([item.dataRel isEqualToString:@"opening_type"]) {
            [setting setObject:(selected ? [selected.attritubes stringValueForKey:@"data-opening"] : @"") forKey:@"opening_door_type"];
            
            NSString * dataVal1 = selected ? [selected.attritubes stringValueForKey:@"data-val"] : @"";
            dataVal1 = [dataVal1 stringByTrimmingCharactersInSet:[NSCharacterSet uppercaseLetterCharacterSet]];
    //        NSRegularExpression * regex = [NSRegularExpression regularExpressionWithPattern:@"[^\\d]" options:NSRegularExpressionIgnoreMetacharacters error:nil];
    //        dataVal1 = [regex stringByReplacingMatchesInString:dataVal1 options:0 range:NSMakeRange(0, dataVal1.length) withTemplate:@""];
            [setting setObject:dataVal1 forKey:@"opening"];
            
            NSString * dataVal2 = selected ? [selected.attritubes stringValueForKey:@"data-val"] : @"";
            dataVal2 = [dataVal2 stringByTrimmingCharactersInSet:[NSCharacterSet decimalDigitCharacterSet]];
    //        regex = [NSRegularExpression regularExpressionWithPattern:@"[^A-Z]" options:NSRegularExpressionIgnoreMetacharacters error:nil];
    //        dataVal2 = [regex stringByReplacingMatchesInString:dataVal2 options:0 range:NSMakeRange(0, dataVal2.length) withTemplate:@""];
            [setting setObject:dataVal2 forKey:@"opening_side"];
            
        } else if ([item.dataRel isEqualToString:@"wall_material_optional"]) {
            if (![setting hasKey:@"floor_material"] || [setting stringValueForKey:@"floor_material"].length == 0) {
                
                [setting setObject:[selected.attritubes stringValueForKey:@"data-floor"] forKey:@"floor_material"];
                [setting setObject:[selected.attritubes stringValueForKey:@"data-floor-d"] forKey:@"floor_material_d"];
            }
        } else if ([item.dataRel isEqualToString:@"wall_material"]) {
            if (![setting hasKey:@"floor_material"] || [setting stringValueForKey:@"floor_material"].length == 0) {
                
                [setting setObject:[selected.attritubes stringValueForKey:@"data-floor"] forKey:@"floor_material"];
                [setting setObject:[selected.attritubes stringValueForKey:@"data-floor-d"] forKey:@"floor_material_d"];
            }
        } else if ([item.dataRel isEqualToString:@"back_wall"]) {
            [setting setObject:[selected.attritubes stringValueForKey:@"data-reflection"] forKey:@"back_wall_reflection"];
            //[setting setObject:[selected.attritubes stringValueForKey:@"data-handrail-type"] forKey:@"data-handrail-type"];
        } else if ([item.dataRel isEqualToString:@"number_of_floors"]){
            [setting setObject:[selected.attritubes stringValueForKey:@"data-refval"] forKey:@"number_of_floors_ref"];
        } else if ([item.dataRel isEqualToString:@"touchscreen_size"]){
            [setting setObject:[selected.attritubes stringValueForKey:@"data-refval"] forKey:@"touchscreen_size_ref"];
        } else if ([item.dataRel isEqualToString:@"position_indicator"]){
            [setting setObject:[selected.attritubes stringValueForKey:@"data-refval"] forKey:@"position_indicator_ref"];
        }
        
        if(selected != nil){
            [setting setObject:[selected.attritubes stringValueForKey:@"data-val"]  forKey:item.dataRel];
        }else{
            [setting setObject:@"" forKey:item.dataRel];
        }
    }
}

- (void)addLayerWithZ:(NSInteger) z imageName:(NSString*) imageName {
    CCLayer * oldLayer = layers[z - 1];
    oldLayer.zOrder = z;
    [oldLayer addImageName:imageName];
}

- (void)appendImage:(NSString*) imageName zOrder:(NSInteger)z {
    if (z > IMAGE_LAYER_CNT || z < 0) {
        return;
    }
    
    NSLog(@"Z = %ld File = %@", (long)z, imageName);
    [self addLayerWithZ:z imageName:imageName];
}

- (void)addLayerWithZ:(NSInteger) z attachedFileName:(NSString*) fileName graphicSize:(NSString *)graphicSize horizontalAlignment:(NSString *)horizontalAlignment verticalAlignment:(NSString *)verticalAlignment points:(NSMutableArray<CCPoint*>*) points {
    CCLayer * oldLayer = layers[z - 1];
    oldLayer.zOrder = z;
    [oldLayer attachGraphic:fileName graphicSize:graphicSize horizontalAlignment:horizontalAlignment verticalAlignment:verticalAlignment points:points];
}

- (void)attachGraphic:(NSString*) fileName zOrder:(NSInteger)z graphicSize:(NSString *)graphicSize horizontalAlignment:(NSString *)horizontalAlignment verticalAlignment:(NSString *)verticalAlignment points:(NSMutableArray<CCPoint*>*) points
 {
    if (z > IMAGE_LAYER_CNT || z < 0) {
        return;
    }
    
    NSLog(@"Z = %ld File = %@", (long)z, fileName);
     [self addLayerWithZ:z attachedFileName:fileName graphicSize:graphicSize horizontalAlignment:horizontalAlignment verticalAlignment:verticalAlignment points:points];
}

- (void)appendFireServiceImage:(NSString*) cop_location cop_location_left:(NSString*) cop_location_left cop_location_right:(NSString*)cop_location_right fire_service:(NSString*) fire_service value:(NSString*) value image:(NSString*) image z:(NSInteger) z{
    NSArray *side_ary = @[@"M"];
    if ([Utils containsString:cop_location_left inArray:side_ary]){
        [self appendImage:[NSString stringWithFormat:@"%@LFS%@%@", image, fire_service, value] zOrder:z];
    }
    
    if ([Utils containsString:cop_location_right inArray:side_ary]){
        [self appendImage:[NSString stringWithFormat:@"%@RFS%@%@", image, fire_service, value] zOrder:z];
    }
    
    if ([Utils containsString:cop_location inArray:side_ary]){
        [self appendImage:[NSString stringWithFormat:@"%@SFS%@%@", image, fire_service, value] zOrder:z];
    }
}

- (void)appendImagesForButtons:(NSString*) image cop_location:(NSString*) cop_location cop_location_left:(NSString*) cop_location_left cop_location_right:(NSString*)cop_location_right door_type:(NSString*) door_type cop_id:(NSString*)cop_id tactile_style:(NSString*)tactile_style pushbutton:(NSString*)pushbutton number_of_floors:(NSString*)number_of_floors ub_char:(NSString*)ub_char z:(NSInteger)z{
    NSArray * side_ary = @[@"M", @"X"];
    NSString * type = [ub_char isEqualToString:@""]? @"PB":@"UB";
    NSString * final_param = [ub_char isEqualToString:@""]? number_of_floors:ub_char;
    if ([Utils containsString:cop_location_left inArray:side_ary]){
        // Tactile
        if (tactile_style != nil && ![tactile_style isEqualToString:@""]){
            [self appendImage:[NSString stringWithFormat:@"%@%@L%@%@%@%@", image, door_type, cop_id, type, tactile_style, final_param] zOrder:z];
        }
        // Pushbutton
        if (pushbutton != nil && ![pushbutton isEqualToString:@""] && [pushbutton integerValue] >= 3){ // Atoll or BP Classic
            // Exception! (should be door_type + "L" = 3L)
            NSString * formatStr = [ub_char isEqualToString:@""]? @"1L":@"2R";
            [self appendImage:[NSString stringWithFormat:@"%@%@%@BT%@%@", image, formatStr, cop_id, pushbutton, final_param] zOrder:z+1];
        }
    }
    
    if ([Utils containsString:cop_location_right inArray:side_ary]){
        // Tactile
        if (tactile_style != nil && ![tactile_style isEqualToString:@""]){
            [self appendImage:[NSString stringWithFormat:@"%@%@R%@%@%@%@", image, door_type, cop_id, type, tactile_style, final_param] zOrder:z];
        }
        // Pushbutton
        if (pushbutton != nil && ![pushbutton isEqualToString:@""] && [pushbutton integerValue] >= 3){ // Atoll or BP Classic
            // Exception! (should be door_type + "R" = 3R)
            NSString * formatStr = [ub_char isEqualToString:@""]? @"2R":@"1L";
            [self appendImage:[NSString stringWithFormat:@"%@%@%@BT%@%@", image, formatStr, cop_id, pushbutton, final_param] zOrder:z+1];
        }
    }
    
    if ([Utils containsString:cop_location inArray:side_ary]){
        image = [image stringByAppendingFormat:@"%@", door_type];
        // Tactile
        if (tactile_style != nil && ![tactile_style isEqualToString:@""]){
            [self appendImage:[NSString stringWithFormat:@"%@S%@%@%@%@", image, cop_id, type, tactile_style, final_param] zOrder:z];
        }
        // Pushbutton
        if (pushbutton != nil && ![pushbutton isEqualToString:@""] && [pushbutton integerValue] >= 3){ // Atoll or BP Classic
            [self appendImage:[NSString stringWithFormat:@"%@S%@BT%@%@", image, cop_id, pushbutton, final_param] zOrder:z+1];
        }
    }
}

- (UIImage *)getFullImage:(int)equalLayer MinimumLayer:(int)minimumLayer MaximumLayer:(int)maximumLayer ExcludeLayer:(int)excludeLayer{
    UIGraphicsBeginImageContextWithOptions(CGSizeMake(IMAGE_MAX_SIZE, IMAGE_MAX_SIZE), NO, 1.0);
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextTranslateCTM(context, 0, IMAGE_MAX_SIZE);
    CGContextScaleCTM(context, 1.0, -1.0);

    for (CCLayer * layer in layers) {
        for (NSString * imageName in layer.imageNames) {
            UIImage * origin = [UIImage imageNamed:imageName];
            UIImage * image;
            if (origin.size.width == 2048) {
                image = [UIImage imageWithCGImage:origin.CGImage scale:2 orientation:origin.imageOrientation];
            } else {
                image = origin;
            }
            
            /*NSBundle *bundle = [NSBundle bundleWithIdentifier:@"com.abyteaday.MadFixtures"];;
            NSString *imagePath = [bundle pathForResource:imageName ofType:@"png"];
            if (imagePath){
                // Image path found
                NSLog(@"Image path: %@", imagePath);
            }else {
                // Image not found in the specified bundle
                NSLog(@"Image not found in the specified bundle:%@", imageName);
            }*/
            
            if (!image) continue;
            
            if (equalLayer > 0){
                if (layer.zOrder != equalLayer) continue;
            }else{
                if (layer.zOrder < minimumLayer || layer.zOrder > maximumLayer) continue;
            }
            
            if (excludeLayer > 0 && layer.zOrder == excludeLayer) continue;
            
            CGContextDrawImage(context, CGRectMake(0, 0, image.size.width, image.size.height), image.CGImage);
        }
        
        for (CCAttachedGraphic * attachedGraphic in layer.attachedGraphics) {
            UIImage * image = [UIImage imageWithContentsOfFile:[imagesPath stringByAppendingPathComponent:attachedGraphic.fileName]];
            
            if (!image) continue;
            
            if (equalLayer > 0){
                if (layer.zOrder != equalLayer) continue;
            }else{
                if (layer.zOrder < minimumLayer || layer.zOrder > maximumLayer) continue;
            }
            
            if (excludeLayer > 0 && layer.zOrder == excludeLayer) continue;
            
            CGRect frame = attachedGraphic.bounds;
            CGFloat width;
            CGFloat height;
            if (image.size.width / image.size.height < frame.size.width / frame.size.height) {
                width = frame.size.height / image.size.height * image.size.width;
                height = frame.size.height;
            } else {
                width = frame.size.width;
                height = frame.size.width / image.size.width * image.size.height;
            }

            if ([attachedGraphic.graphicSize isEqualToString:GRAPHIC_SIZE_SMALL]) {
                width *= 0.3;
                height *= 0.3;
            } else if ([attachedGraphic.graphicSize isEqualToString:GRAPHIC_SIZE_MEDIUM]) {
                width *= 0.6;
                height *= 0.6;
            }
            
            CGFloat x;
            if ([attachedGraphic.horizontalAlignment isEqualToString:GRAPHIC_HALIGN_LEFT]) {
                x = frame.origin.x;
            } else if ([attachedGraphic.horizontalAlignment isEqualToString:GRAPHIC_HALIGN_RIGHT]) {
                x = frame.origin.x + frame.size.width - width;
            } else {
                x = frame.origin.x + (frame.size.width - width) / 2;
            }

            CGFloat y;
            if ([attachedGraphic.verticalAlignment isEqualToString:GRAPHIC_VALIGN_TOP]) {
                y = IMAGE_MAX_SIZE - frame.origin.y - height;
            } else if ([attachedGraphic.verticalAlignment isEqualToString:GRAPHIC_VALIGN_BOTTOM]) {
                y = IMAGE_MAX_SIZE -  (frame.origin.y + frame.size.height - height) - height;
            } else {
                y = IMAGE_MAX_SIZE - (frame.origin.y + (frame.size.height - height) / 2) - height;
            }
            
            CGContextDrawImage(context, CGRectMake(x, y, width, height), image.CGImage);
        }
    }
    
    UIImage * result = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return result;
}

- (NSMutableArray *)getHallDoorImages {
    NSMutableArray * images = [[NSMutableArray alloc] init];
                
    for (CCLayer * layer in layers) {
        if (layer.zOrder == 24){
            for (NSString * imageName in layer.imageNames) {
                [images addObject:[self getImageFromName:imageName]];
            }
        }
    }
    return images;
}

- (UIImage *) getImageFromName:(NSString *) imageName{
    UIImage * image = [UIImage imageNamed:imageName];
    if (!image) return nil;
    
    UIGraphicsBeginImageContextWithOptions(CGSizeMake(IMAGE_MAX_SIZE, IMAGE_MAX_SIZE), NO, 1.0);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextTranslateCTM(context, 0, IMAGE_MAX_SIZE);
    CGContextScaleCTM(context, 1.0, -1.0);
    CGContextDrawImage(context, CGRectMake(0, 0, image.size.width, image.size.height), image.CGImage);
    UIImage * result = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return result;
}

- (void)loadImageProc:(BOOL) isFront {
    
    NSMutableArray * orders = [NSMutableArray new];
    
    for (CCMenuItem * item in menuItems) {
        CCThumb * thumb = item.selectedThumb;
        if (thumb != nil) {
            [orders addObject:item.dataRel];
        }
        for (CCMenuItem * subItem in item.subMenuItems) {
            CCThumb * subThumb = subItem.selectedThumb;
            if (subThumb) {
                [orders addObject:subItem.dataRel];
            }
        }
    }
    
    NSMutableDictionary * setting = [NSMutableDictionary new];
    for (CCMenuItem * item in menuItems) {
        for (CCMenuItem * child in item.subMenuItems) {
            [self setMenuItemSetting:setting item:child];
        }
        [self setMenuItemSetting:setting item:item];
    }
    
    NSString *openingType = [setting stringValueForKey:@"opening_type"];
//    NSRegularExpression * regex = [NSRegularExpression regularExpressionWithPattern:@"[^\\d]" options:NSRegularExpressionIgnoreMetacharacters error:nil];
//    openingType = [regex stringByReplacingMatchesInString:openingType options:0 range:NSMakeRange(0, openingType.length) withTemplate:@""];
    
    openingType = [openingType stringByTrimmingCharactersInSet:[NSCharacterSet uppercaseLetterCharacterSet]];
    
    NSString * handrail_location = [setting stringValueForKey:@"handrail_location"];
    NSString * handrail_type = [setting stringValueForKey:@"handrail_type"];
    
    NSString * handBumperFl = ([openingType isEqualToString:@"2"] && [Utils containsString:[setting stringValueForKey:@"back_wall"] inArray:ACR]) ? @"true" : @"false";
    
    [setting setObject:handBumperFl forKey:@"HandBumperFl"];
    
    NSString *cab_material = [setting stringValueForKey:@"cab_material"];
    NSString *opening_side = [setting stringValueForKey:@"opening_side"];
    NSString *opening_door_type = [setting stringValueForKey:@"opening_door_type"];
    NSString *opening = [setting stringValueForKey:@"opening"];
    // NSString *opening_type = [setting stringValueForKey:@"opening_type"];
    NSString *cop_type = [setting stringValueForKey:@"cop_type"];
    NSString *front_cop_location = [setting stringValueForKey:@"front_cop_selection"];
    NSString *rear_cop_location = [setting stringValueForKey:@"rear_cop_selection"];
    NSString *interaction_type = [setting stringValueForKey:@"interaction_type"];
    NSString *number_of_floors = [setting stringValueForKey:@"number_of_floors"];
    NSString *number_of_floors_ref = [setting stringValueForKey:@"number_of_floors_ref"];
    NSString *tactile_style = [setting stringValueForKey:@"tactile_style"];
    NSString *pushbutton = [setting stringValueForKey:@"pushbutton"];
    NSString *touchscreen_size = [setting stringValueForKey:@"touchscreen_size"];
    NSString *touchscreen_size_ref = [setting stringValueForKey:@"touchscreen_size_ref"];
    NSString *position_indicator = [setting stringValueForKey:@"position_indicator"];
    NSString *position_indicator_ref = [setting stringValueForKey:@"position_indicator_ref"];
    NSString *fire_service = [setting stringValueForKey:@"fire_service"];
    
    NSArray * accessories = [[NSArray alloc] init];
    NSArray * accessories_prefix = [[NSArray alloc] init];
    if (![[setting stringValueForKey:@"accessories"] isEqualToString: @""]){
        accessories = [[setting stringValueForKey:@"accessories"] componentsSeparatedByString:@","];
    }
    if (![[setting stringValueForKey:@"accessories_prefix"] isEqualToString:@""]){
        accessories_prefix = [[setting stringValueForKey:@"accessories_prefix"] componentsSeparatedByString:@","];
    }
    
    // P1: cab_material, P2: door_type(1,2,3), P3: cop_type
    NSString *door_type = [opening isEqualToString:@"2"]? @"3":([opening_side isEqualToString:@"R"]? @"2":@"1");
    if (!isFront){
        door_type = [opening isEqualToString:@"2"]? @"3":([opening_side isEqualToString:@"R"]? @"1":@"2");
    }
    NSString *cop_location_left = @"";
    NSString *cop_location_right = @"";
    NSString *cop_location = @"";
    if (!isFront && ![rear_cop_location isEqualToString:@""]){
        // Back wall
        cop_location = rear_cop_location;
    }else if (isFront && ![front_cop_location isEqualToString:@""]){
        // Front wall
        cop_location = front_cop_location;
    }
    if ([door_type isEqualToString:@"3"] && cop_location.length == 2){
        cop_location_left = [cop_location substringToIndex:1];
        cop_location_right = [cop_location substringFromIndex:1];
    }
    NSString *cop_id = ([cop_type isEqualToString:@"A"] || [cop_type isEqualToString:@"S"])? @"S":@"D";
    if ([interaction_type isEqualToString:@"TS"]){
        cop_id = @"T";
    }else if ([interaction_type isEqualToString:@"DD"]){
        cop_id = @"B";
    }
        
    BOOL hall_view = !isCabViewMode;
    BOOL hall_landing = isHallMain;
    NSString * hall_landing_suffix = hall_landing? @"A":@"B";
    NSString * hall_finish = [setting stringValueForKey:@"hall_finish"];
    NSString * hall_style_mounting = [setting stringValueForKey:@"hall_style_mounting"];
    NSString * hall_style_width = [setting stringValueForKey:@"hall_style_width"];
    NSString * hall_style_height = [setting stringValueForKey:@"hall_style_height"];
    
    NSArray * hall_options = [[NSArray alloc] init];
    NSArray * hall_options_egress = [[NSArray alloc] init];
    if (![[setting stringValueForKey:@"hall_options"] isEqualToString: @""]){
        hall_options = [[setting stringValueForKey:@"hall_options"] componentsSeparatedByString:@","];
    }
    if (![[setting stringValueForKey:@"hall_options_egress"] isEqualToString:@""]){
        hall_options_egress = [[setting stringValueForKey:@"hall_options_egress"] componentsSeparatedByString:@","];
    }
    
    for (NSString* order in orders) {
        NSString *imageName = @"";
        NSInteger z = -1;
        
        if ([order isEqualToString:@"back_wall"]) {
            z = 2;
            
            /*imageName = [NSString stringWithFormat:@"B%@%@%@%@",
                         isFront ? @"3" : @"1",
                         [setting stringValueForKey:@"cab_material"],
                         [setting stringValueForKey:@"opening_type"],
                         @"AN.png"
                         ];*/

            NSString  * BGRDImage = [NSString stringWithFormat:@"BGRD%@", cab_material];
            if (isFront){
                BGRDImage = [BGRDImage stringByAppendingString:[opening isEqualToString:@"2"]? @"CO":([opening_side isEqualToString:@"R"]? @"SL":@"SR")];
            }else{
                BGRDImage = [BGRDImage stringByAppendingString:[opening isEqualToString:@"2"]? @"CO":([opening_side isEqualToString:@"R"]? @"SR":@"SL")];
            }
            
            NSString *cop_type_char = cop_type;
            // TTG Applied
            if ([interaction_type isEqualToString:@"TS"] && [cop_type isEqualToString:@"A"]){
                cop_type_char = @"AT";
            }
            
            // DD Swing
            if ([interaction_type isEqualToString:@"DD"] && [cop_type isEqualToString:@"S"]){
                cop_type_char = @"SB";
            }
            
            // DD Applied
            if ([interaction_type isEqualToString:@"DD"] && [cop_type isEqualToString:@"A"]){
                cop_type_char = @"AB";
            }
            
            // For no rear cops door, no matter what cop is selected, we just show swing door image.
            if (!isFront && [opening_door_type isEqualToString:@"2"] && [self isEmptyCops:cop_location] &&
                [self isEmptyCops:cop_location_left] && [self isEmptyCops:cop_location_right]){
                cop_type_char = @"S";
            }
            BGRDImage = [BGRDImage stringByAppendingFormat:@"%@%@", cop_type_char, @".png"];
            
            imageName = BGRDImage;
            if (!isFront){
                imageName = [NSString stringWithFormat:@"R-%@", BGRDImage];
            }
            
            if (hall_view && !preparingReqData){
                // If hall view, we show the reflection image instead of mirror reflect back images.
                NSString * building = [setting stringValueForKey:@"hall_building"];
                imageName = [NSString stringWithFormat:@"REFLECT-%@.png", building];
            }
            [self appendImage:imageName zOrder:z];
            
            if (hall_view && !preparingReqData){
                // If hall view, we show the BGRD reflection image with transparent at door part.
                imageName = [NSString stringWithFormat:@"H-%@", BGRDImage];
                [self appendImage:imageName zOrder:z];
            }
            
            //NSInteger copItemsPrefix;
            // Reflection Images here
            if ([opening_door_type isEqualToString:@"1"] && !isFront){
                imageName = [NSString stringWithFormat:@"R-%@", cab_material];
                imageName = [imageName stringByAppendingFormat:@"%@%@%@", door_type, cop_id, tactile_style];
                if ([cop_id isEqualToString:@"S"] && ![[setting stringValueForKey:@"altus"] isEqualToString:@""]){
                    imageName = [imageName stringByAppendingString:@"AL0.png"];
                }else{
                    imageName = [imageName stringByAppendingString:position_indicator_ref];
                    if ([interaction_type isEqualToString:@"PB"]){
                        imageName = [imageName stringByAppendingString:number_of_floors_ref];
                    }else if ([interaction_type isEqualToString:@"TS"]){
                        imageName = [imageName stringByAppendingString:touchscreen_size_ref];
                    }else if ([interaction_type isEqualToString:@"DD"]){
                        imageName = [imageName stringByAppendingString:@"0"];
                    }
                    imageName = [imageName stringByAppendingString:@".png"];
                }
                [self appendImage:imageName zOrder:z];
            }
            
            NSString *openingSideTmp = [setting stringValueForKey:@"opening_side"];
            
            if (!isFront) {
                /* Layer Panel Back */
                imageName = @"";
                NSString * openingDoorType = [setting stringValueForKey:@"opening_door_type"];
                NSString * endingType = [setting stringValueForKey:@"ending_type"];
                if ([openingDoorType isEqualToString:@"1"]) {
                    if (endingType.length > 0) {
                        /* Layer Frame Back */
                        z = 11;
                        //NSString *backWall = [setting stringValueForKey:@"back_wall"];
                        //NSString *backWallStr = ([backWall isEqualToString:@"W"]) ? @"L" : backWall;
                        
                        imageName = [NSString stringWithFormat:@"%@%@%@%@",
                                     [setting stringValueForKey:@"ending_type"],
                                     [setting stringValueForKey:@"back_wall"],
                                     [setting stringValueForKey:@"cab_material"],
                                     @"NBN.png"
                                     ];
                        [self appendImage:imageName zOrder:z];
                    }else{
                        NSString *backWall = [setting stringValueForKey:@"back_wall"];
                        NSString * backWallStr = backWall;
                        if ([backWall isEqualToString:@"M"]){
                            // if Providence, then set as L (Ashburu), they are same
                            backWallStr = @"L";
                        }else if ([backWallStr isEqualToString:@"O"]){
                            // if Federation, then set as N (St Louise), they are same
                            backWallStr = @"N";
                        }
                        
                        z = 11;
                        imageName = [NSString stringWithFormat:@"X%@%@%@",
                                     backWallStr,
                                     [setting stringValueForKey:@"cab_material"],
                                     @"NBN.png"
                                     ];
                        [self appendImage:imageName zOrder:z];
                    }
                    
                    // Checking individual panel images
                    for (int i = 0; i < canvasView.panels.count; i++){
                        CCLayoutPanel * panel = canvasView.panels[i];
                        if ([panel.type isEqualToString:LAYOUT_TYPE_BACK] && ![panel.material isEqualToString:@""]){
                            z = 10;
                            
                            NSString * backWall = [setting stringValueForKey:@"back_wall"];
                            if ([backWall isEqualToString:@"M"]){
                                // if Providence, just use Ashbury resources, as they have same individual and no resources for providence.
                                imageName = [NSString stringWithFormat:@"RLNNB%@", panel.material];
                            }else if ([backWall isEqualToString:@"O"]){
                                // if Federation, just use St. Louise Square resources, as they have same individuals and no resources for Federation
                                imageName = [NSString stringWithFormat:@"RNNNB%@", panel.material];
                            }else{
                                imageName = [NSString stringWithFormat:@"R%@NNB%@", backWall, panel.material];
                            }
                            
                            imageName = [imageName stringByAppendingString:[NSString stringWithFormat:@"-%ld", panel.index]];
                            [self appendImage:imageName zOrder:z];
                        }
                        
                        if (panel.graphicImage != nil && ![panel.graphicImage isEqualToString: @""]) {
                            [self attachGraphic:panel.graphicImage zOrder:z graphicSize:panel.graphicSize horizontalAlignment:panel.graphicHoriAlign verticalAlignment:panel.graphicVertAlign points:panel.points];
                        }
                        
                        //if ([panel.type isEqualToString:LAYOUT_TYPE_BACK] && ![panel.graphicImage isEqualToString:@""]){
                            // var rect = getCustomGraphicRect(panel);
                            //z = 10;
                            //AppendGraphic(panel, rect, z, cntExt);
                        //}
                    }
                    imageName = @"";
                } else {
                    z = 10;
                    /*if ([[setting stringValueForKey:@"opening_side"] isEqualToString:@"L"]) {
                        imageName = [NSString stringWithFormat:@"B3%@%@RAN",
                                     [setting stringValueForKey:@"cab_material"],
                                     [setting stringValueForKey:@"opening"]
                                     ];
                    } else if ([[setting stringValueForKey:@"opening_side"] isEqualToString:@"R"]) {
                        imageName = [NSString stringWithFormat:@"B3%@%@LAN",
                                     [setting stringValueForKey:@"cab_material"],
                                     [setting stringValueForKey:@"opening"]
                                     ];
                    } else {
                        imageName = [NSString stringWithFormat:@"B3%@%@%@AN",
                                     [setting stringValueForKey:@"cab_material"],
                                     [setting stringValueForKey:@"opening"],
                                     [setting stringValueForKey:@"opening_side"]
                                     ];
                    }
                    
                    if ([[setting stringValueForKey:@"cab_material"] isEqualToString:@"B"] &&
                        [Utils containsString:[setting stringValueForKey:@"back_wall"] inArray:CMEXCEPW_ARR]) {
                        imageName = [imageName stringByAppendingString:@"-B"];
                    }*/
                    //imageName = [imageName stringByAppendingString:@".png"];
                    imageName = BGRDImage;
                    [self appendImage:imageName zOrder:z];
                }
                
                if ([[setting stringValueForKey:@"opening_side"] isEqualToString:@"L"]) {
                    openingSideTmp = @"R";
                } else if ([[setting stringValueForKey:@"opening_side"] isEqualToString:@"R"]){
                    openingSideTmp = @"L";
                }

                //copItemsPrefix = 2;
                NSLog(@"setting: %@", setting);
            } else {
                if ([[setting stringValueForKey:@"opening_side"] isEqualToString:@"L"]) {
                    openingSideTmp = @"R";
                } else if ([[setting stringValueForKey:@"opening_side"] isEqualToString:@"R"]){
                    openingSideTmp = @"L";
                }
                //copItemsPrefix = 4;
            }
            
            /* Layer Cop Items Reflection */
            if ([opening_door_type isEqualToString:@"2"] || ([opening_door_type isEqualToString:@"1"] && isFront)){
                z = 10;
                // For Altus Image, just put only Standard Altus PI image
                imageName = [NSString stringWithFormat:@"S%@S", door_type];
                if ([cop_location_left isEqualToString:@"A"]){
                    [self appendImage:[imageName stringByAppendingString:@"LPIA48.png"] zOrder:z];
                    cop_location_left = @"O";
                }
                if ([cop_location_right isEqualToString:@"A"]){
                    [self appendImage:[imageName stringByAppendingString:@"RPIA48.png"] zOrder:z];
                    cop_location_right = @"O";
                }
                if ([cop_location isEqualToString:@"A"]){
                    [self appendImage:[imageName stringByAppendingString:@"SPIA48.png"] zOrder:z];
                    cop_location = @"O";
                }
            }
            imageName = @"";
            
            //z = 3;

            /*imageName = [NSString stringWithFormat:@"B%ld%@%@%@NB.png",
                         (long)copItemsPrefix,
                         [setting stringValueForKey:@"cab_material"],
                         [setting stringValueForKey:@"opening"],
                         (!isFront) ? openingSideTmp : [setting stringValueForKey:@"opening_side"]
                         ];*/
        } else if ([order isEqualToString:@"back_wall_optional"]) {
            if (!isFront) {
                z = 12;
                
                if ([[setting stringValueForKey:@"opening"] isEqualToString:@"1"]) {
                    imageName = [NSString stringWithFormat:@"SB-R%@NNB%@.png",
                                 [setting stringValueForKey:@"back_wall"],
                                 [setting stringValueForKey:@"wall_material_optional"]
                                 ];
                } else {
                    imageName = [NSString stringWithFormat:@"SSB-B3S2%@AN.png",
                                 [setting stringValueForKey:@"opening_side"]];
                }
                
                [self appendImage:imageName zOrder:z];
            }
        } else if ([order isEqualToString:@"side_wall"]) {
            if (!isFront) {
                if ([[setting stringValueForKey:@"back_wall_reflection"] isEqualToString:@"1"])
                {
                    // Checking individual panel images
                    for (int i = 0; i < canvasView.panels.count; i++){
                        CCLayoutPanel * panel = canvasView.panels[i];
                        if ([panel.type isEqualToString:LAYOUT_TYPE_SIDE] && ![panel.material isEqualToString:@""]){
                            if (![[setting stringValueForKey:@"side_wall"] isEqualToString:@"T"]){
                                z = 5;
                                imageName = [NSString stringWithFormat:@"R-S%@NNB%@-%ld.png",
                                             [setting stringValueForKey:@"side_wall"],
                                             panel.material,
                                             panel.index
                                             ];
                                [self appendImage:imageName zOrder:z];
                            }
                        }
                    }
                    
                    if ([setting stringValueForKey:@"ending_type"].length > 0) {
                        /* Layer Frame Side Reflection */
                        
                        if (![[setting stringValueForKey:@"side_wall"] isEqualToString:@"T"]){
                            z = 6;
                            imageName = [NSString stringWithFormat:@"R-%@%@%@NSN.png",
                                         [setting stringValueForKey:@"ending_type"],
                                         [setting stringValueForKey:@"side_wall"],
                                         [setting stringValueForKey:@"cab_material"]
                                         ];
                            [self appendImage:imageName zOrder:z];
                        }
                    }else{
                        z = 6;
                        imageName = [NSString stringWithFormat:@"R-X%@%@NSN.png",
                                     [setting stringValueForKey:@"side_wall"],
                                     [setting stringValueForKey:@"cab_material"]];
                        [self appendImage:imageName zOrder:z];
                    }
                }
            }
            /* Layer Panel Side */
            
            // Checking individual panel images
            NSArray *reflections_array = [self getSideReflectionAry];
            
            for (int i = 0; i < canvasView.panels.count; i++){
                CCLayoutPanel * panel = canvasView.panels[i];
                if ([panel.type isEqualToString:LAYOUT_TYPE_SIDE] && ![panel.material isEqualToString:@""]){
                    z = 15;
                    NSString * backWall = [setting stringValueForKey:@"back_wall"];
                    NSString * sideWall = [setting stringValueForKey:@"side_wall"];
                    
                    imageName = [NSString stringWithFormat:@"S%@NNB%@",
                                 sideWall,
                                 panel.material
                                 ];
                    
                    if (isFront && (([backWall isEqualToString:@"R"] && [sideWall isEqualToString:@"O"]) || ([backWall isEqualToString:@"Q"] && [sideWall isEqualToString:@"N"]) || [backWall isEqualToString:@"4"])){
                        imageName = [imageName stringByAppendingString:@"-S"];
                    }
                    
                    if (!isFront){
                        imageName = [imageName stringByAppendingFormat:@"-%ld.png", panel.index];
                    }else{
                        imageName = [imageName stringByAppendingFormat:@"-%d.png", [reflections_array[panel.index - 1] intValue]];
                    }
                    
                    [self appendImage:imageName zOrder:z];
                }
            }
            
            if ([setting stringValueForKey:@"ending_type"].length > 0) {
                /* Layer Frame Side */
                
                z = 16;
                imageName = [NSString stringWithFormat:@"%@%@%@NSN%@.png",
                             [setting stringValueForKey:@"ending_type"],
                             [setting stringValueForKey:@"side_wall"],
                             [setting stringValueForKey:@"cab_material"],
                             (isFront && [[setting stringValueForKey:@"back_wall"] isEqualToString:@"4"])? @"-S":@""
                             ];
            }else{
                z = 16;
                imageName = [NSString stringWithFormat:@"X%@%@NSN",
                             [setting stringValueForKey:@"side_wall"],
                             [setting stringValueForKey:@"cab_material"]];
                
                NSString * backWall = [setting stringValueForKey:@"back_wall"];
                NSString * sideWall = [setting stringValueForKey:@"side_wall"];
                
                if (isFront && (([backWall isEqualToString:@"R"] && [sideWall isEqualToString:@"O"]) || ([backWall isEqualToString:@"Q"] && [sideWall isEqualToString:@"N"]))){
                    imageName = [imageName stringByAppendingString:@"-S"];
                }
                
                imageName = [imageName stringByAppendingString:@".png"];
            }
            [self appendImage:imageName zOrder:z];
            imageName = @"";
        }
        else if ([order isEqualToString:@"ceiling_type"]) {
            z = 4;
            imageName = [NSString stringWithFormat:@"C%@%@NNN%@.png",
                         [setting stringValueForKey:@"ceiling_type"],
                         [setting stringValueForKey:@"cab_material"],
                         (isFront) ? @"F" : @"B"
                         ];
        } else if ([order isEqualToString:@"handrail_type"]) {
            
            BOOL handrailBack = true;
            BOOL handrailSide = true;
            
            CCMenuItem *handrailTypeMenu = [CCMenuItem menuItemInMenuItems:menuItems withID:@"handrail_type"];
            CCMenuItem *bumperrailMenu = [CCMenuItem menuItemInMenuItems:menuItems withID:@"bumper_rail"];
            
            if (handrailTypeMenu != nil) {
                [handrailTypeMenu showAllThumbs:YES];
                [handrailTypeMenu showAllUnavailableThumbs:NO];
            }
            
            if (bumperrailMenu != nil) {
                bumperrailMenu.isShown = YES;
            }
            
            /*if ([[setting stringValueForKey:@"data-handrail-type"] isEqualToString:@"back"]) {
                handrailSide = false;
            } else if ([[setting stringValueForKey:@"data-handrail-type"] isEqualToString:@"0"]) {
                handrailBack = false;
                handrailSide = false;
                
                if (handrailTypeMenu != nil) {
                    [handrailTypeMenu showAllThumbs:NO];
                    [handrailTypeMenu showAllUnavailableThumbs:YES];
                }
                if (bumperrailMenu != nil) {
                    bumperrailMenu.isShown = NO;
                }
            }*/
            
            if ([handrail_location isEqualToString:@"A"]){
                handrailBack = YES;
                handrailSide = YES;
            }else if ([handrail_location isEqualToString:@"R"]){
                handrailBack = YES;
                handrailSide = NO;
            }
            
            NSArray<NSString*> *checkarr = [Utils mergeStringArray:(NSArray<NSString *> *)ACR
                                                           Array2:@[@"B"]];
            if (!isFront) {
                /* Layer Flushplate Top Side Wall Reflection */
                if (![Utils containsString:[setting stringValueForKey:@"back_wall"] inArray:ACR]) {
                    z = 7;
                    imageName = [NSString stringWithFormat:@"R-K1%@NSN.png",
                                 [setting stringValueForKey:@"cab_material"]
                                 ];
                    [self appendImage:imageName zOrder:z];
                }
                
                /* Layer Flushplate Hand Rail Side Wall Reflection */
                if (![Utils containsString:[setting stringValueForKey:@"side_wall"] inArray:checkarr]) {
                    z = 8;
                    imageName = [NSString stringWithFormat:@"R-K2%@NSN.png",
                                 [setting stringValueForKey:@"cab_material"]
                                 ];
                    [self appendImage:imageName zOrder:z];
                }
                
                if (handrailSide) {
                    if ([[setting stringValueForKey:@"opening_door_type"] isEqualToString:@"1"]) {
                        /* Layer Handrail Side Reflection */
                        z = 9;
                        imageName = [NSString stringWithFormat:@"R-H%@%@1S01NN.png",
                                     handrail_type, cab_material
                                     ];
                        [self appendImage:imageName zOrder:z];
                    }
                }
                
                if (handrailBack && [[setting stringValueForKey:@"opening_door_type"] isEqualToString:@"1"]) {
                    
                    /* Layer Kick And Top Flush Plate Backwall */
                    if (![Utils containsString:[setting stringValueForKey:@"back_wall"] inArray:ACR]) {
                        z = 12;
                        imageName = [NSString stringWithFormat:@"K1%@NBN.png",
                                     [setting stringValueForKey:@"cab_material"]
                                     ];
                        [self appendImage:imageName zOrder:z];
                    }
                    
                    /* Layer Handrail Flush Plate Back Wall */
                    if (![Utils containsString:[setting stringValueForKey:@"back_wall"] inArray:checkarr]) {
                        z = 13;
                        imageName = [NSString stringWithFormat:@"K2%@NBN.png",
                                     [setting stringValueForKey:@"cab_material"]
                                     ];
                        [self appendImage:imageName zOrder:z];
                    }
                }
            }
            
            /* Layer Kick And Top Flush Plate Side Wall */
            
            if (![Utils containsString:[setting stringValueForKey:@"back_wall"] inArray:ACR]) {
                z = 17;
                imageName = [NSString stringWithFormat:@"K1%@NSN.png",
                             [setting stringValueForKey:@"cab_material"]
                             ];
                [self appendImage:imageName zOrder:z];
            }
            
            /* Layer Handrail Flush Plate Side Wall */
            if (![Utils containsString:[setting stringValueForKey:@"side_wall"] inArray:SIDE_ARR]) {
                z = 18;
                imageName = [NSString stringWithFormat:@"K2%@NSN.png",
                             [setting stringValueForKey:@"cab_material"]
                             ];
                [self appendImage:imageName zOrder:z];
            }
            
            if (handrailSide) {
                
                /* Layer Handrail Side Wall */
                
                z = 19;
                imageName = [NSString stringWithFormat:@"H%@%@1S01NN.png",
                             handrail_type, cab_material];
                [self appendImage:imageName zOrder:z];
            }
            
            /* Layer Handrail Back Wall */
            
            if(handrailBack && !isFront && [[setting stringValueForKey:@"opening_door_type"] isEqualToString:@"1"]){
                z = 14;
                imageName = [NSString stringWithFormat:@"H%@%@BBNNNN.png",
                             handrail_type,
                             cab_material];
                [self appendImage:imageName zOrder:z];
                imageName = @"";
            }
        }
        else if ([order isEqualToString:@"bumper_rail"]) {
            /* Layer Bumper Rail Back Wall */
            
            if (!isFront && [[setting stringValueForKey:@"opening_door_type"] isEqualToString:@"1"]) {
                z = 14;
                
                imageName = [NSString stringWithFormat:@"G%@%@BBNNNN.png",
                             [setting stringValueForKey:@"bumper_rail"],
                             [setting stringValueForKey:@"cab_material"]];
                [self appendImage:imageName zOrder:z];
                imageName = @"";
            }
            
            NSString * back_wall_handrail = [handrail_location isEqualToString:@"R"]? @"back":@"";
            if (![back_wall_handrail isEqualToString:@"back"]){
                
                /* Layer Bumper Rail Side Wall */
                
                z = 19;
                
                imageName = [NSString stringWithFormat:@"G%@%@1S01NN.png",
                             [setting stringValueForKey:@"bumper_rail"],
                             [setting stringValueForKey:@"cab_material"]
                             ];
            }
        } else if ([order isEqualToString:@"floor_type"]) {
            z = 1;
            
            imageName = [imageName stringByAppendingFormat:@"F%@NNN",
                         [setting stringValueForKey:@"floor_type"]
                         ];
            if ([[setting stringValueForKey:@"floor_type"] isEqualToString:@"2"]) {
                imageName = [imageName stringByAppendingString:[setting stringValueForKey:@"floor_material_d"]];
            } else if ([[setting stringValueForKey:@"floor_type"] isEqualToString:@"5"]){
                imageName = [imageName stringByAppendingString:@"I"];
            }else {
                imageName = [imageName stringByAppendingString:[setting stringValueForKey:@"floor_material"]];
            }
            imageName = [imageName stringByAppendingString:@".png"];
        } else if ([order isEqualToString:@"interaction_type"]){
            z = 10;
            // on iOS, no need to check for path
            imageName = @"";
            // Touch screen doesn't depend on Cab material
            imageName = ![interaction_type isEqualToString:@"TS"]? cab_material:@"S";
            
            // >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Traditional
            if ([interaction_type isEqualToString:@"PB"]){
                // If COP_ID is "D" (Dover) then, we don't have BarButton tactile style. (Alex, 2020/06/06, because of no images)
                [self appendImagesForButtons:imageName cop_location:cop_location cop_location_left:cop_location_left cop_location_right:cop_location_right door_type:door_type cop_id:cop_id tactile_style:tactile_style pushbutton:pushbutton number_of_floors:number_of_floors ub_char:@"" z:z];
            }else if ([interaction_type isEqualToString:@"DD"] || [interaction_type isEqualToString:@"TS"]){
                // Destination Dispatch OR Touch Screen
                NSArray * side_ary = @[@"M", @"X"];
                NSString * final_param = @"200.png";
                if ([interaction_type isEqualToString:@"TS"]){
                    side_ary = @[@"M"];
                    if (isFront && [door_type isEqualToString:@"3"]){
                        side_ary = @[@"M", @"X"];
                    }
                    final_param = [NSString stringWithFormat:@"%@00.png", touchscreen_size];
                }
                if ([Utils containsString:cop_location_left inArray:side_ary]){
                    [self appendImage:[NSString stringWithFormat:@"%@%@%@L%@%@", imageName, door_type, cop_id, interaction_type, final_param] zOrder:z];
                }
                if ([Utils containsString:cop_location_right inArray:side_ary]){
                    [self appendImage:[NSString stringWithFormat:@"%@%@%@R%@%@", imageName, door_type, cop_id, interaction_type, final_param] zOrder:z];
                }
                if ([Utils containsString:cop_location inArray:side_ary]){
                    [self appendImage:[NSString stringWithFormat:@"%@%@%@S%@%@", imageName, [door_type isEqualToString:@"2"]? @"1":@"2", cop_id, interaction_type, final_param] zOrder:z];
                }
            }
            
            // >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Utility Button
            imageName = cab_material;
            NSString * ub_char = [NSString stringWithFormat:@"F%@", [opening_door_type isEqualToString:@"1"]? @"O":@"R"];
            if ([interaction_type isEqualToString:@"PB"]){
                if ([Utils containsString:@"UB" inArray:accessories_prefix]){
                    // If the UB layer is selected on Accessories
                    for (int i = 0; i < accessories.count; i++){
                        if ([accessories_prefix[i] isEqualToString:@"UB"]){
                            ub_char = [NSString stringWithFormat:@"%@%@", accessories[i], [opening_door_type isEqualToString:@"1"]? @"F":@"R"];
                        }
                    }
                }
                
                // if BAR BUTTON > 15 floors
                if ([cop_type isEqualToString:@"S"] && [number_of_floors isEqualToString:@"P3"] && [tactile_style isEqualToString:@"A"]){
                    ub_char = [NSString stringWithFormat:@"B%@", [opening_door_type isEqualToString:@"1"]? @"F":@"R"];
                }
                
                [self appendImagesForButtons:imageName cop_location:cop_location cop_location_left:cop_location_left cop_location_right:cop_location_right door_type:door_type cop_id:cop_id tactile_style:tactile_style pushbutton:pushbutton number_of_floors:@"" ub_char:ub_char z:z];
            }else if ([interaction_type isEqualToString:@"DD"]){
                [self appendImagesForButtons:imageName cop_location:cop_location cop_location_left:cop_location_left cop_location_right:cop_location_right door_type:door_type cop_id:cop_id tactile_style:tactile_style pushbutton:pushbutton number_of_floors:@"" ub_char:ub_char z:z];
            }else if ([interaction_type isEqualToString:@"TS"]){
                if ([Utils containsString:@"UB" inArray:accessories_prefix]){
                    for (int i = 0; i < accessories.count; i++){
                        if ([accessories_prefix[i] isEqualToString:@"UB"]){
                            ub_char = [NSString stringWithFormat:@"%@%@", accessories[i], [opening_door_type isEqualToString:@"1"]? @"F":@"R"];
                        }
                    }
                }
                NSString * ub_aux_char = [NSString stringWithFormat:@"A%@", [opening_door_type isEqualToString:@"1"]? @"F":@"R"];
                // Single opening
                if ([cop_location_left isEqualToString:@""] && [cop_location_right isEqualToString:@""]){
                    if ([cop_location isEqualToString:@"M"]){
                        // Tactile
                        if (tactile_style != nil && ![tactile_style isEqualToString:@""]){
                            [self appendImage:[NSString stringWithFormat:@"%@%@%@STB%@%@.png", imageName, door_type, cop_id, tactile_style, ub_char] zOrder:z];
                        }
                    }else if ([cop_location isEqualToString:@"X"]){
                        // Tactile
                        if (tactile_style != nil && ![tactile_style isEqualToString:@""]){
                            [self appendImage:[NSString stringWithFormat:@"%@%@%@STB%@%@.png", imageName, door_type, cop_id, tactile_style, ub_aux_char] zOrder:z];
                            
                        }
                    }
                    // Pushbutton
                    if (pushbutton != nil && ![pushbutton isEqualToString:@""] && [pushbutton integerValue] >= 3){ // Atoll or BP Classic
                        [self appendImage:[NSString stringWithFormat:@"%@%@S%@TB%@%@.png", imageName, door_type, cop_id, pushbutton, ub_char] zOrder:z];
                    }
                }
                
                // Center opening, Left
                if (![cop_location_left isEqualToString:@""] && ![cop_location_left isEqualToString:@"O"]){
                    if ([cop_location_left isEqualToString:@"M"]){
                        // Tactile
                        if (tactile_style != nil && ![tactile_style isEqualToString:@""]){
                            [self appendImage:[NSString stringWithFormat:@"%@%@%@LTB%@%@.png", imageName, door_type, cop_id, tactile_style, ub_char] zOrder:z];
                        }
                    }else if ([cop_location_left isEqualToString:@"X"]){
                        // Tactile
                        if (tactile_style != nil && ![tactile_style isEqualToString:@""]){
                            [self appendImage:[NSString stringWithFormat:@"%@%@%@LTB%@%@.png", imageName, door_type, cop_id, tactile_style, ub_aux_char] zOrder:z];
                        }
                    }
                    if (pushbutton != nil && ![pushbutton isEqualToString:@""] && [pushbutton integerValue] >= 3){      // Atoll or BP Classic
                        [self appendImage:[NSString stringWithFormat:@"%@1L%@TB%@%@.png", imageName, cop_id, pushbutton, ub_char] zOrder:z];
                    }
                }
                
                // Center opening, Right
                if (![cop_location_right isEqualToString:@""] && ![cop_location_right isEqualToString:@"O"]){
                    if ([cop_location_right isEqualToString:@"M"]){
                        // Tactile
                        if (tactile_style != nil && ![tactile_style isEqualToString:@""]){
                            [self appendImage:[NSString stringWithFormat:@"%@%@%@RTB%@%@.png", imageName, door_type, cop_id, tactile_style, ub_char] zOrder:z];
                        }
                    }else if ([cop_location_right isEqualToString:@"X"]){
                        // Tactile
                        if (tactile_style != nil && ![tactile_style isEqualToString:@""]){
                            [self appendImage:[NSString stringWithFormat:@"%@%@%@RTB%@%@.png", imageName, door_type, cop_id, tactile_style, ub_aux_char] zOrder:z];
                        }
                    }
                    if (pushbutton != nil && ![pushbutton isEqualToString:@""] && [pushbutton integerValue] >= 3){      // Atoll or BP Classic
                        [self appendImage:[NSString stringWithFormat:@"%@2R%@TB%@%@.png", imageName, cop_id, pushbutton, ub_char] zOrder:z];
                    }
                }
            }
            
            imageName = @"";
        } else if ([order isEqualToString:@"position_indicator"]){
            z = 10;
            // Position Indicator doesn't depend on Material (No specific for Brass)
            // So just make the path, but on iPhone, it doesn't have any path.
            imageName = [NSString stringWithFormat:@"S%@%@", door_type, cop_id];
            NSArray *side_ary = @[@"M", @"X"];
            NSString *appendix = @"";
            if ([Utils containsString:cop_location_left inArray:side_ary]){
                appendix = [NSString stringWithFormat:@"LPI%@", position_indicator];
                [self appendImage:[imageName stringByAppendingString:appendix] zOrder:z];
            }
            if ([Utils containsString:cop_location_right inArray:side_ary]){
                appendix = [NSString stringWithFormat:@"RPI%@", position_indicator];
                [self appendImage:[imageName stringByAppendingString:appendix] zOrder:z];
            }
            if ([Utils containsString:cop_location inArray:side_ary]){
                appendix = [NSString stringWithFormat:@"SPI%@", position_indicator];
                [self appendImage:[imageName stringByAppendingString:appendix] zOrder:z];
            }
            imageName = @"";
        } else if ([order isEqualToString:@"fire_service"]){
            z = 10;
            imageName = [NSString stringWithFormat:@"%@%@%@", cab_material, door_type, cop_id];
            // Accessory's Fire service Layer is selected
            if ([Utils containsString:@"FS" inArray:accessories_prefix]){
                for (int i = 0; i < accessories.count; i++){
                    if ([accessories_prefix[i] isEqualToString:@"FS"]){
                        [self appendFireServiceImage:cop_location cop_location_left:cop_location_left cop_location_right:cop_location_right fire_service:fire_service value:accessories[i] image:imageName z:z];
                    }
                }
            }else{
                [self appendFireServiceImage:cop_location cop_location_left:cop_location_left cop_location_right:cop_location_right fire_service:fire_service value:@"FM" image:imageName z:z];
            }
            imageName = @"";
        } else if ([order isEqualToString:@"accessory"]){
            for (int i = 0; i < accessories.count; i++){
                NSString * accessory = accessories[i];
                NSString * accessory_prefix = accessories_prefix[i];
                
                z = 10;
                NSArray * ary = @[@"E", @"F", @"G"];
                BOOL dependOnMaterials = [Utils containsString:accessory inArray:ary] || [accessory_prefix isEqualToString:@"AR"];
                //For iOS, no need to check the resource path folder
                imageName = @"";
                
                // For accessory, only service cabinet and certificate window, and will arrows depends on Material
                // Others are just for stainless only
                imageName = [NSString stringWithFormat:@"%@%@", imageName, dependOnMaterials? cab_material:@"S"];
                
                // Exception!
                bool side_inverse = false;
                if ([accessory_prefix isEqualToString:@"AC"] || [accessory_prefix isEqualToString:@"SC"]){
                    imageName = [NSString stringWithFormat:@"%@%@%@", imageName, !side_inverse? door_type:([door_type isEqualToString:@"1"]? @"2":@"1"), cop_id];
                    
                    NSString * prefix = [accessory_prefix isEqualToString:@"SC"]? @"AC":accessory_prefix;
                    NSArray * side_ary = @[@"M", @"X"];
                    NSArray * ary = @[@"A"];
                    if (![Utils containsString:accessory inArray:ary]){
                        side_ary = @[@"M"];
                    }
                    
                    if ([Utils containsString:cop_location_left inArray:side_ary]){
                        [self appendImage:[NSString stringWithFormat:@"%@L%@%@00", imageName, prefix, accessory] zOrder:z];
                    }
                    
                    if ([Utils containsString:cop_location_right inArray:side_ary]){
                        [self appendImage:[NSString stringWithFormat:@"%@R%@%@00", imageName, prefix, accessory] zOrder:z];
                    }
                    
                    if ([Utils containsString:cop_location inArray:side_ary]){
                        [self appendImage:[NSString stringWithFormat:@"%@S%@%@00", imageName, prefix, accessory] zOrder:z];
                    }
                }else if ([accessory_prefix isEqualToString:@"AR"]){
                    imageName = [NSString stringWithFormat:@"%@%@1%@", imageName, door_type, [door_type isEqualToString:@"3"]? @"1":@"S"];
                    if (isFront || (!isFront && [opening_door_type isEqualToString:@"2"] && ![cop_location isEqualToString:@"O"] && ![cop_location isEqualToString:@"OO"])){
                        [self appendImage:[NSString stringWithFormat:@"%@%@%@00", imageName, accessory_prefix, accessory] zOrder:z];
                    }
                }
            }
            
            imageName = @"";
        } else if ([order isEqualToString:@"hall_building"]){
            if (!hall_view) break;
            NSString * building = [setting stringValueForKey:(NSString *)@"hall_building"];
            NSString * finish = [hall_finish isEqualToString:@"C"]? @"B":@"S";
            
            z = 25;
            imageName = [NSString stringWithFormat:@"A%@%@3C%@", hall_landing? @"2":@"3", finish, building];
            [self appendImage:imageName zOrder:z];
            [self AppendHallZoomImage:imageName zOrder:z];
            
            // Adding reflection images
            z = 23;
            imageName = [NSString stringWithFormat:@"REFLECT-%@", building];
            //[self appendImage:imageName zOrder:z];
            
            // Adding door images
            z = 24;
            // Left or Right Single opening
            imageName = [NSString stringWithFormat:@"A1%@", finish];
            if ([opening isEqualToString:@"1"]){
                imageName = [NSString stringWithFormat:@"%@1A2", imageName];
                [self appendImage:imageName zOrder:z];
            }else{
                // Left side door image
                NSString * imageName1 = [NSString stringWithFormat:@"%@3C2-L", imageName];
                [self appendImage:imageName1 zOrder:z];
                
                
                // Right side door image
                NSString * imageName2 = [NSString stringWithFormat:@"%@3C2-R", imageName];
                [self appendImage: imageName2 zOrder:z];
            }
            
            imageName = @"";
        } else if ([order isEqualToString:@"hall_style_mounting"]){
            if (!hall_view) break;
            z = 26;
            
            NSString * tmp_image = [NSString stringWithFormat:@"A%@%@%@%@AAAAAAAAAAA", hall_style_mounting, hall_style_width, hall_style_height, hall_finish];
            imageName = [NSString stringWithFormat:@"%@%@", tmp_image, hall_landing_suffix];
            [self appendImage:imageName zOrder:z];
            
            imageName = [NSString stringWithFormat:@"%@B", tmp_image];
            [self AppendHallZoomImage:imageName zOrder:z];
            
            // For Main Egress
            if (hall_landing){
                // If Triflame is selected
                CCMenuItem * hallOptionsItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"hall_options"];
                if ([hallOptionsItem thumbByAttrKey:@"data-val" value:@"1"].isSelected){
                    // Fire Service on Middle Slot
                    imageName = [NSString stringWithFormat:@"CA%@A%@AACAAABAAAAB", hall_style_width, hall_finish];
                    [self appendImage:imageName zOrder:z];
                    [self AppendHallZoomImage:imageName zOrder:z];
                }else{
                    // Fire Service on Upper Slot
                    imageName = [NSString stringWithFormat:@"CA%@A%@AABAAABAAAA%@", hall_style_width, hall_finish, hall_landing_suffix];
                    [self appendImage:imageName zOrder:z];
                    [self AppendHallZoomImage:imageName zOrder:z];
                    
                    // Line Com on always Upper Slot too
                    imageName = [NSString stringWithFormat:@"CAAA%@AABAAAAAAAB%@", hall_finish, hall_landing_suffix];
                    [self appendImage:imageName zOrder:z];
                    [self AppendHallZoomImage:imageName zOrder:z];
                }
            }
            
            imageName = @"";
        }else if ([order isEqualToString:@"hall_pushbutton"]){
            if (!hall_view) break;
            z = 26;
            NSString * pushbutton = [setting stringValueForKey:@"hall_pushbutton"];
            NSString * pushbutton_zoom = @"";
            if ([pushbutton intValue] == 2){
                // BS Moon
                pushbutton_zoom = @"M";
            }else if ([pushbutton intValue] == 0){
                // BS Classic
                pushbutton_zoom = @"B";
            }else if ([pushbutton intValue] == 1){
                // BS California
                pushbutton_zoom = @"C";
            }else{
                pushbutton_zoom = [pushbutton intValue] == 3? @"F":@"E";
            }
            
            NSString * numberOfPB = hall_landing? @"B":@"C";
            imageName = [NSString stringWithFormat:@"BAAA%@%@%@DAAAAAAAA%@", hall_finish, ([pushbutton intValue] <= 2? @"B":([pushbutton intValue] == 3? @"F":@"E")), numberOfPB, hall_landing_suffix];
            [self appendImage:imageName zOrder:z];
            
            // For hall zoom, we need to specify correct image names
            imageName = [NSString stringWithFormat:@"BAAA%@%@%@DAAAAAAAA%@", hall_finish, pushbutton_zoom, numberOfPB, hall_landing_suffix];
            [self AppendHallZoomImage:imageName zOrder:z];
            
            imageName = @"";
        }else if ([order isEqualToString:@"hall_options"]){
            if (!hall_view) break;
            for (int i = 0; i < hall_options.count; i++){
                NSString * option = hall_options[i];
                //NSString * egress = hall_options_egress[i];
                
                z = 26;
                
                NSString * options_string = @"AAAAAAAA";
                int option_index = [option intValue] - 1;
                
                NSString * append_char = @"B";
                // 1PI or 2PI
                if (option_index == 1 || option_index == 2){
                    append_char = option_index == 1? @"B":@"C";
                    option_index = 1;
                }
                
                if (option_index > 2){
                    option_index--;
                }
                options_string = [NSString stringWithFormat:@"%@%@%@", [options_string substringToIndex:option_index], append_char, [options_string substringFromIndex:option_index + 1]];
                
                if ([hall_style_height isEqualToString:@"C"]){
                    // Extended Hall Style Height
                    NSString * slot_char = @"B"; // Default Slot is Upper
                    
                    // if Tri-flame, always on Upper slot
                    if ([option intValue] == 1){
                        slot_char = @"B";
                    }else if ([option intValue] > 3){
                        // if Tri-flame, or 1PI, or 2PIs is selected
                        CCMenuItem * hallOptionsMenuItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"hall_options"];
                        if ([hallOptionsMenuItem thumbByAttrKey:@"data-val" value:@"1"].isSelected || [hallOptionsMenuItem thumbByAttrKey:@"data-val" value:@"2"].isSelected || [hallOptionsMenuItem thumbByAttrKey:@"data-val" value:@"3"].isSelected){
                            slot_char = @"C";
                        }else{
                            int cur_index = [option intValue];
                            // Checking if other option is already on Upper, then make it Middle slot
                            NSArray * thumbs = [hallOptionsMenuItem selectedThumbs];
                            BOOL isSet = NO;
                            for (CCThumb * thumb in thumbs){
                                if (isSet) continue;
                                
                                if ([[[thumb attritubes] stringValueForKey:@"data-slot"] isEqualToString:@"B"] && [[[thumb attritubes] stringValueForKey:@"data-val"] intValue] != cur_index){
                                    slot_char = @"C";           // Make this slot as Middle
                                    isSet = YES;
                                }
                            }
                        }
                    }else if ([option intValue] <= 3){
                        // for 1PI or 2PIs, if Tri-flame is already selected, then go to middle slot
                        CCMenuItem * hallOptionsMenuItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"hall_options"];
                        if ([hallOptionsMenuItem thumbByAttrKey:@"data-val" value:@"1"].isSelected){
                            slot_char = @"C";
                        }
                    }
                    
                    if (option_index == 2 && hall_landing){
                        // If Main Egress and Code Blue, always Middle Slot
                        slot_char = @"C";
                    }
                    
                    CCMenuItem * hallOptionsMenuItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"hall_options"];
                    CCThumb * thumb = [hallOptionsMenuItem thumbByAttrKey:@"data-val" value:option];
                    [thumb.attritubes setValue:slot_char forKey:@"data-slot"];
                    
                    imageName = [NSString stringWithFormat:@"CAAA%@AA%@%@%@", hall_finish, slot_char, options_string, hall_landing_suffix];
                    [self appendImage:imageName zOrder:z];
                    [self AppendHallZoomImage:imageName zOrder:z];
                }else if ([hall_style_height isEqualToString:@"B"]){
                    // Regular Hall Style Height, always Middle
                    NSString * slot_char = @"C";
                    imageName = [NSString stringWithFormat:@"CAAA%@AA%@%@%@", hall_finish, slot_char, options_string, hall_landing_suffix];
                    [self appendImage:imageName zOrder:z];
                    [self AppendHallZoomImage:imageName zOrder:z];
                }
            }
            
            imageName = @"";
        }else if ([order isEqualToString:@"hall_lantern_orientation"]){
            if (!hall_view) break;
            
            NSString * hall_lantern_orientation = [setting stringValueForKey:@"hall_lantern_orientation"];
            NSString * hall_lantern_mounting = [setting stringValueForKey:@"hall_lantern_mounting"];
            NSString * hall_lantern_width = [setting stringValueForKey:@"hall_lantern_width"];
            NSString * hall_lantern_height = [setting stringValueForKey:@"hall_lantern_height"];
            
            // Drawing Lantern
            NSString * hall_lantern_arrow_type = [setting stringValueForKey:@"hall_lantern_arrow_type"];
            NSString * hall_lantern_pi = [setting stringValueForKey:@"hall_lantern_pi"];
            if ((hall_lantern_arrow_type != nil && ![hall_lantern_arrow_type isEqualToString:@""]) || ![hall_lantern_pi isEqualToString:@"A"]){
                z = 28;
                imageName = [NSString stringWithFormat:@"D%@%@%@%@%@AAA", hall_lantern_mounting, hall_lantern_width, hall_lantern_height, hall_finish, hall_lantern_orientation];
                [self appendImage:imageName zOrder:z];
                [self AppendHallZoomImage:imageName zOrder:z];
            }
            
            imageName = @"";
        }else if ([order isEqualToString:@"hall_lantern_pi"]){
            if (!hall_view) break;
            
            z = 29;
            
            NSString * hall_lantern_orientation = [setting stringValueForKey:@"hall_lantern_orientation"];
            NSString * hall_lantern_width = [setting stringValueForKey:@"hall_lantern_width"];
            NSString * hall_lantern_arrow_type = [setting stringValueForKey:@"hall_lantern_arrow_type"];
            NSString * hall_lantern_pi = [setting stringValueForKey:@"hall_lantern_pi"];
            
            // Drawing PI first, always on Middle Slot
            if (![hall_lantern_pi isEqualToString:@"A"]){
                imageName = [NSString stringWithFormat:@"CAAA%@%@ABF", hall_finish, hall_lantern_orientation];
                [self appendImage:imageName zOrder:z];
                [self AppendHallZoomImage:imageName zOrder:z];
            }
            
            // Drawing Arrows
            if (hall_lantern_arrow_type != nil && ![hall_lantern_arrow_type isEqualToString:@""]){
                NSString * slot_char = @"F";           // Default set as Outer
                
                if ([hall_lantern_width isEqualToString:@"C"]){
                    // if Extended, Outer Slot
                    slot_char = @"E";
                }
                
                imageName = [NSString stringWithFormat:@"CAAA%@%@%@A%@", hall_finish, hall_lantern_orientation, hall_lantern_arrow_type, slot_char];
                [self appendImage:imageName zOrder:z];
                [self AppendHallZoomImage:imageName zOrder:z];
            }
            
            imageName = @"";
        }
        
        if (imageName.length > 0) {
            [self appendImage:imageName zOrder:z];
        }
    }
    
    if (hall_view){
        [self saveOptionsForLandingType:NO];
    }
    
    if (!preparingReqData) [self configureHallZoomInZones];
}

- (void)loadImages:(BOOL) isFront shouldClearView:(BOOL) shouldClear{
    if (shouldClear) {
        [activityIndicator startAnimating];
        [self resetImage:YES];
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self loadImageProc:isFront];
            
            if (Hall_Zoom_Index > 0 && !btnHallZoomOut.hidden){
                [self displayHallZoomImage];
            }else{
                [self displayCabImage];
                if (!isCabViewMode){
                    [self displayHallDoorImage];
                    [self displayHallWallImage];
                }
            }
            
            [activityIndicator stopAnimating];
            
            // Alex, 2020/04/01
            if (btnCollapse.tag == 0){
                btnCollapse.hidden = NO;
                btnCollapse.tag = 100;
            }
        });
    } else {
        [self resetImage:shouldClear];
        [self loadImageProc:isFront];
    }
}

- (void)loadPredefinedConfig:(CabConfig* ) config {
    if (!config) return;
    
    [self resetTSImageSetting:NO];
    
    for (CCMenuItem * item in menuItems) {
        [item deselectAllThumbs];
        for (CCMenuItem * subItem in item.subMenuItems) {
            [subItem deselectAllThumbs];
        }
    }
    
    NSDictionary * items = config.items;
    for (NSString * key in items.allKeys) {
        CCMenuItem * menu = [CCMenuItem menuItemInMenuItems:menuItems withID:key];
        if (menu) {
            if (menu.multi == nil){
                NSString * file = items[key];
                CCThumb * thumb = [menu thumbByFileName:file];
                if (thumb) {
                    thumb.isSelected = YES;
                }
            }else if ([menu.multi isEqualToString:@"1"]){
                NSString * file = items[key];
                file = [file stringByReplacingOccurrencesOfString:@"#" withString:@","];
                NSArray<CCThumb *> *thumbsAry = [menu thumbsByIDsArray:file];
                for (CCThumb * thumb in thumbsAry){
                    if (thumb != nil){
                        thumb.isSelected = YES;
                    }
                }
            }
        }
    }

    for (NSString * key in items.allKeys) {
        CCMenuItem * menu = [CCMenuItem menuItemInMenuItems:menuItems withID:key];
        if (menu) {
            if ([key isEqualToString:@"ending_type"]) {
                [self filterOptionsEnding:NO];
            }
            
            NSString * file = items[key];
            CCThumb * thumb = [menu thumbByFileName:file];
            if (thumb) {
                [self filterOptions:thumb predefined:YES isBack:NO isLoop:YES];
            }
        }
    }
    
    if (self.defaultMode != 1){
        // Always Main Egress here, For Main Egress, if 6" width, then default select Triflame
        CCMenuItem * hallOptionsItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"hall_options"];
        for (CCThumb * thumb in [hallOptionsItem selectedThumbs]){
            thumb.isSelected = NO;
        }
        [hallOptionsItem thumbByAttrKey:@"data-val" value:@"1"].isSelected = YES;
        
        // Set G2 Surface Mount selected
        CCMenuItem * hallStyleMountingItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"hall_style_mounting"];
        [hallStyleMountingItem selectedThumb].isSelected = NO;
        [hallStyleMountingItem thumbByAttrKey:@"data-val" value:@"D"].isSelected = YES;
    }else{
        isHallMain = NO;
    }
    
    [self saveOptionsForLandingType:YES];
    
    // Set for saved hall menu items
    if (config.projectName != nil){
        BOOL hall_version = NO;
        for (NSString * key in items.allKeys) {
            if (![key hasPrefix:@"hall_"]) continue;
            
            hall_version = YES;
            CCMenuItem * menu = [CCMenuItem menuItemInMenuItems:menuItems withID:key];
            if (menu) {
                // data-typical,data-main#data-typical,data-main...
                NSString * vals = items[key];
                NSArray * thmb_val_arrs = [vals componentsSeparatedByString:@"!"];
                NSArray<CCThumb *> * thumbs = [menu thumbs];
                for (int i = 0; i < thumbs.count; i++){
                    CCThumb * thumb = thumbs[i];
                    if (thmb_val_arrs[i]){
                        NSArray * val_arrs = [thmb_val_arrs[i] componentsSeparatedByString:@"~"];
                        thumb.attritubes[@"data-main"] = val_arrs[0];
                        thumb.attritubes[@"data-typical"] = val_arrs[1];
                    }
                }
            }
        }
        
        if (hall_version){
            [self restoreOptionsForLandingType:1];      // Restore Main hall menu selections
        }
    }
    
    [self initializePanelData:LAYOUT_TYPE_ALL];
    
    if (config.panels != nil) {
        for (NSDictionary *dictionary in config.panels) {
            CCLayoutPanel *panel = [[CCLayoutPanel alloc] initWithDictionary:dictionary];
            for (CCLayoutPanel *existingPanel in canvasView.panels) {
                if ([existingPanel.type isEqualToString:panel.type] && existingPanel.index == panel.index) {
                    [canvasView.panels removeObject:existingPanel];
                    break;
                }
            }
            [canvasView.panels addObject:panel];
        }
    }
    
    if (self.defaultMode > 0){
        [self hallViewModeProcess];
    }else{
        [self loadImages:isDisplayingFront shouldClearView:YES];
    }
}

- (void) filterOptions:(CCThumb*) thumb predefined:(BOOL) predefined isBack:(BOOL) isBack isLoop:(BOOL) isLoop {
    NSString * data = thumb.parent.dataRel;
    if ( [data isEqualToString:@"back_wall"] ) {
        if ([thumb.attritubes stringValueForKey:@"data-exceptions"].length > 0) {
            [self updateException:thumb exceptions:@"cab-material"];
            [self updateException:thumb exceptions:@"bumper-rail"];
            
            if ([thumb.attritubes stringValueForKey:@"data-side-wall"].length > 0) {
                [self updateException:thumb exceptions:@"side-wall"];
            }
            
            if ([thumb.attritubes stringValueForKey:@"data-wall-material"].length > 0) {
                [self updateException:thumb exceptions:@"wall-material"];
                [self updateException:thumb exceptions:@"wall-material-optional"];
                [self updateException:thumb exceptions:@"wall-metals"];
                [self updateException:thumb exceptions:@"customize-materials"];
                [self updateException:thumb exceptions:@"customize-metals"];
            }
        }
        
        if(isBack){
            [self filterOptionsEnding:predefined];
            //[self filterOptionsCeiling:predefined];
        }
        
        //if(!isLoop){
        [self initOptionals];
        //}
        
        [self filterOptionsHandrail:predefined];
    } else if ([data isEqualToString:@"ceiling_type"]) {
        //[self filterOptionsCeiling:predefined];
    } else if ([data isEqualToString:@"cab_material"]) {
        if (!isLoop) {
            CCMenuItem * backWall = [CCMenuItem menuItemInMenuItems:menuItems withID:@"back_wall"];
            if (backWall) {
                [self updateException:backWall.selectedThumb exceptions:@"side-wall"];
                [self updateException:backWall.selectedThumb exceptions:@"wall-material"];
                [self updateException:backWall.selectedThumb exceptions:@"wall-metals"];
                [self updateException:backWall.selectedThumb exceptions:@"customize-materials"];
                [self updateException:thumb exceptions:@"customize-metals"];
            }
        }
        
        [self initCab];
        [self filterOptionsEnding:predefined];
        [self initOptionals];
    } else if ([data isEqualToString:@"opening_type"]){
        [self filterOptionsOpeningType:predefined];
        [self filterOptionsHandrail:predefined];
    } else if ([data isEqualToString:@"front_cop_selection"] || [data isEqualToString:@"rear_cop_selection"]){
        [self filterOptionsCopSelection:predefined];
    } else if ([data isEqualToString:@"interaction_type"]){
        [self filterOptionsInteractionType:predefined];
    } else if ([data isEqualToString:@"cop_type"]){
        [self filterOptionsCopType:predefined];
    } else if ([data isEqualToString:@"number_of_floors"]){
        [self setVisibilityForBarButton:predefined];
    } else if ([data isEqualToString:@"tactile_style"]){
        [self setVisibilityForPushButton:predefined];
    }else if ([data isEqualToString:@"hall_style_width"]){
        [self filterOptionsForHallStyleWidth:predefined];
    }else if ([data isEqualToString:@"hall_style_height"]){
        [self filterOptionsForHallStyleHeight:predefined];
    }else if ([data isEqualToString:@"hall_lantern_mounting"] || [data isEqualToString:@"hall_lantern_orientation"] || [data isEqualToString:@"hall_lantern_width"] || [data isEqualToString:@"hall_lantern_height"]){
        [self filterOptionsForHallLanternItems:predefined];
        
        if ([data isEqualToString:@"hall_lantern_orientation"]){
            [self filterOptionsForHallLanternOrientation:predefined];
        }
    }else if ([data isEqualToString:@"hall_lantern_arrow_type"]){
        [self filterOptionsForHallLanternArrowType:predefined];
    }
}

- (void) initCab {
    CCMenuItem *cabMaterial = [CCMenuItem menuItemInMenuItems:menuItems withID:@"cab_material"];
    CCMenuItem *backWall = [CCMenuItem menuItemInMenuItems:menuItems withID:@"back_wall"];
    CCMenuItem *wallMaterial = [CCMenuItem menuItemInMenuItems:menuItems withID:@"wall_material"];
    CCMenuItem *ceilingType = [CCMenuItem menuItemInMenuItems:menuItems withID:@"ceiling_type"];
    
    if(cabMaterial == nil || backWall == nil || ceilingType == nil || wallMaterial == nil){
        return;
    }
    
    CCThumb* selectedCab = cabMaterial.selectedThumb;
    CCThumb* selectedBackWall = backWall.selectedThumb;
    
    if(selectedBackWall == nil || selectedCab == nil){
        return;
    }
    
    if ([[selectedCab.attritubes stringValueForKey:@"data-val"] isEqualToString:@"B"]) {
        [CCMenuItem showThumbsByAttr:menuItems key:@"data-brass" value:@"0" shown:NO];
        [CCMenuItem showThumbsByAttr:[SharedData shared].menuEditPanelItems key:@"data-brass" value:@"0" shown:NO];
        
        NSArray * arr = @[@"L",@"M"];
        
        if ([Utils containsString:[selectedBackWall.attritubes stringValueForKey:@"data-val"] inArray:arr]) {
            /*NSArray * items = [ceilingType thumbsByAttrKeysAndValues:@[@"data-brass", @"0", @"data-ecr", @"0"]];
            for (CCThumb * item in items) {
                [item.classes addObject:@"dcl-none-brass"];
            }*/

            NSArray * items1 = [ceilingType thumbsByAttrKey:@"data-brass" value:@"0"];
            for (CCThumb * item in items1) {
                [item.classes addObject:@"dcl-none-brass"];
                item.isShown = NO;
            }
            /*[ceilingType showAllThumbs:NO];
            
            NSArray * items2 = [ceilingType thumbsByAttrKey:@"data-ecr" value:@"1"];
            for (CCThumb * item in items2) {
                [item.classes addObject:@"dcl-ecr-brass"];
                [item removeClass:@"dcl-none-brass"];
                item.isShown = YES;
            }
            
            CCThumb *selectedCeiling = ceilingType.selectedThumb;
            
            if(selectedCeiling && ![selectedCeiling hasClass:@"dcl-ecr-brass"]){
                selectedCeiling.isSelected = NO;
                NSArray * temp = [ceilingType thumbsByClasses:@[@"dcl-ecr-brass"]];
                
                if(temp.count > 0){
                    CCThumb * f = temp.firstObject;
                    f.isSelected = YES;
                }
            }*/
        }
        
        // If Brass then, no options for Dover(Impulse+)
        CCMenuItem * copTypeItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"cop_type"];
        CCThumb * thumb = [[copTypeItem thumbsByAttrKey:@"data-val" value:@"D"] objectAtIndex:0];
        thumb.isShown = NO;
        if (thumb.isSelected){
            thumb.isSelected = NO;
            [copTypeItem thumbsByAttrKeysAndValuesAndSelect:0 isSelect:YES keysAndValues:@[@"data-val", @"S"]];
        }
    }else{
        
        [CCMenuItem showThumbsByClassAndAttr:menuItems key:@"data-brass" value:@"0" class:@"dcl-ex-visible" shown:YES];
        [CCMenuItem showThumbsByClassAndAttr:[SharedData shared].menuEditPanelItems key:@"data-brass" value:@"0" class:@"dcl-ex-visible" shown:YES];
        /*if ([Utils containsString:[selectedBackWall.attritubes stringValueForKey:@"data-val"] inArray:ACR]) {
            [ceilingType setVisibleByAttr:@"data-ecr" value:@"1" shown:YES flag:YES];
        } else {
            [ceilingType setVisibleByAttr:@"data-ecr" value:@"1" shown:NO flag:YES];
        }*/
        
        CCMenuItem * copTypeItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"cop_type"];
        [copTypeItem setVisibleByAttr:@"data-val" value:@"D" shown:YES flag:YES];
    }
}

- (void) initOptionals {
    CCMenuItem *cabMaterial = [CCMenuItem menuItemInMenuItems:menuItems withID:@"cab_material"];
    CCMenuItem *backWall = [CCMenuItem menuItemInMenuItems:menuItems withID:@"back_wall"];
    CCMenuItem *wallMaterialOptional = [CCMenuItem menuItemInMenuItems:menuItems withID:@"wall_material_optional"];
    if(cabMaterial == nil || backWall == nil || wallMaterialOptional == nil){
        return;
    }
    
    CCThumb *selectedCab = cabMaterial.selectedThumb;
    CCThumb *selectedBackWall = backWall.selectedThumb;
    
    NSArray * arr = @[@"B", @"T",@"U",@"S"];
    
    if ((selectedCab && [[selectedCab.attritubes stringValueForKey:@"data-val"] isEqualToString:@"B"]) ||
        (selectedBackWall && [Utils containsString:[selectedBackWall.attritubes stringValueForKey:@"data-bal"] inArray:arr])) {
        [wallMaterialOptional showAllThumbs:NO];
        if ([wallMaterialOptional unavailableThumbsCount] == 1) {
            [wallMaterialOptional showAllUnavailableThumbs:YES];
        }
    }else{
        [wallMaterialOptional showAllThumbs:YES];
    }
}

-(void) filterOptionsCeiling:(BOOL) isPredefined {
    CCMenuItem *ceilingType = [CCMenuItem menuItemInMenuItems:menuItems withID:@"ceiling_type"];
    CCMenuItem *backWall = [CCMenuItem menuItemInMenuItems:menuItems withID:@"back_wall"];
    if(ceilingType == nil || backWall == nil){
        return;
    }
    
    CCThumb *backWallThumb = backWall.selectedThumb;
    NSString *chF = @""; NSString * chS = @"";
    if(backWallThumb &&
       [Utils containsString:[backWallThumb.attritubes stringValueForKey:@"data-val"] inArray:ACR]) {
        chF = @"1";
        chS = @"0";
    }else{
        chF = @"0";
        chS = @"1";
    }
    
    [ceilingType setVisibleByAttr:@"data-ecr" value:chF shown:YES flag:YES];
    [ceilingType setVisibleByAttr:@"data-ecr" value:chS shown:NO flag:YES];
    
    if(!isPredefined){
        NSArray * tempList = [ceilingType thumbsByAttrKey:@"data-ecr" value:chF];
        int cnt = 0;
        for(CCThumb *thumb in tempList){
            if(thumb.isSelected){
                cnt++;
            }
        }
        
        if(cnt == 0 && tempList.count > 0){
            [[tempList firstObject] setIsSelected:YES];
        }
    }
}

- (void) filterOptionsEnding:(BOOL) isPredefined {
    CCMenuItem *endingType = [CCMenuItem menuItemInMenuItems:menuItems withID:@"ending_type"];
    CCMenuItem *backWall = [CCMenuItem menuItemInMenuItems:menuItems withID:@"back_wall"];

    if(endingType == nil || backWall == nil){
        return;
    }
    [endingType showAllUnavailableThumbs:NO];
    
    CCThumb *backWallThumb = backWall.selectedThumb;
    if(backWallThumb &&
       [Utils containsString:[backWallThumb.attritubes stringValueForKey:@"data-val"] inArray:ACR]) {
        [endingType showAllThumbs:NO];
        
        NSString *prefix = @"";
        NSArray * arr = @[@"L", @"M", @"P", @"Q", @"R", @"T", @"1", @"2", @"3", @"4"];
        prefix = [Utils containsString:[backWallThumb.attritubes stringValueForKey:@"data-val"] inArray:arr] ? @"A" : @"C";
        
        CCThumb *etThumb = [endingType thumbByFileName:[NSString stringWithFormat:@"%@-Look.png", prefix]];
        
        if(etThumb){
            etThumb.isSelected = YES;
            etThumb.isAvailable = NO;
            //etThumb.isShown = YES;  // No this code in android
            [etThumb.attritubes setObject:prefix forKey:@"data-rel"];
            [etThumb.attritubes setObject:[NSString stringWithFormat:@"%@-Look.png", prefix] forKey:@"data-id"];
        }
    }else{
        if (!isPredefined) {
            [[endingType.thumbs firstObject] setIsSelected:YES];
        }
        
        BOOL linkField = true;
        CCMenuItem *cabMaterial = [CCMenuItem menuItemInMenuItems:menuItems withID:@"cab_material"];
        if(cabMaterial){
            CCThumb *selected = cabMaterial.selectedThumb;
            if(selected != nil && [[selected.attritubes stringValueForKey:@"data-val"] isEqualToString:@"B"]){
                linkField = false;
            }
        }
        
        CCMenuItem *objTMP = [CCMenuItem menuItemInMenuItems:menuItems withID:@"ending_type"];
        
        if(objTMP){
            if(linkField){
                [objTMP showAllThumbs:YES];
            }else{
                [objTMP setVisibleByAttr:@"data-brass" value:@"0" shown:YES flag:NO];
            }
        }
    }
    
    // For new layouts, Ashbury AL, Dundas AL, St. Mark's Square, Times Square, only self edge ending is available
    /*if ([Utils containsString:[backWallThumb.attritubes stringValueForKey:@"data-val"] inArray:@[@"1", @"2", @"3", @"4"]]){
        [endingType showAllUnavailableThumbs:NO];
        
        [endingType showAllThumbs:NO];
        endingType.selectedThumb.isSelected = NO;
        CCThumb * vThumb = [endingType thumbByAttrKey:@"data-val" value:@"V"];
        vThumb.isShown = YES;
        vThumb.isSelected = YES;
    }*/
}

- (void) filterOptionsHandrail:(BOOL) isPredefined{
    CCMenuItem * openingTypeMenu = [CCMenuItem menuItemInMenuItems:menuItems withID:@"opening_type"];
    CCMenuItem * backWallMenu = [CCMenuItem menuItemInMenuItems:menuItems withID:@"back_wall"];
    NSString * openingType = [openingTypeMenu.selectedThumb.attritubes stringValueForKey:@"data-opening"];
    NSString * back_wall = [backWallMenu.selectedThumb.attritubes stringValueForKey:@"data-val"];
    CCMenuItem * handrailLocationMenu = [CCMenuItem menuItemInMenuItems:menuItems withID:@"handrail_location"];
    CCThumb * selected = handrailLocationMenu.selectedThumb;
    if (selected != nil){
        selected.isSelected = NO;
    }
    
    // If front opening only
    if ([openingType isEqualToString:@"1"]){
        handrailLocationMenu.isShown = YES;
        if ([back_wall isEqualToString:@"T"] || [back_wall isEqualToString:@"S"]){
            [handrailLocationMenu thumbsByAttrKeysAndValuesAndSelect:0 isSelect:YES keysAndValues:@[@"data-val", @"R"]];
        }else{
            [handrailLocationMenu thumbsByAttrKeysAndValuesAndSelect:0 isSelect:YES keysAndValues:@[@"data-val", @"A"]];
        }
    }else{
        handrailLocationMenu.isShown = NO;
        [handrailLocationMenu thumbsByAttrKeysAndValuesAndSelect:0 isSelect:YES keysAndValues:@[@"data-val", @"A"]];
    }
}

- (void) filterOptionsOpeningType:(BOOL) isPredefined {
    NSString *opening = [self getOpening];
    CCMenuItem *openingTypeMenu = [CCMenuItem menuItemInMenuItems:menuItems withID:@"opening_type"];
    CCThumb *openingTypeThumb = openingTypeMenu.selectedThumb;
    NSString *openingType = [openingTypeThumb.attritubes stringValueForKey:@"data-opening"];
    
    CCMenuItem *frontCopSelection = [CCMenuItem menuItemInMenuItems:menuItems withID:@"front_cop_selection"];
    [frontCopSelection setVisibleByAttr:@"data-opening" value:opening shown:NO flag:NO];
    CCThumb *selectedThumb = [frontCopSelection selectedThumbByAttr:@"data-opening" value:opening key:NO flag:YES];
    if (!isPredefined && selectedThumb != nil){
        selectedThumb.isSelected = NO;
        [frontCopSelection thumbsByAttrKeysAndValuesAndSelect:0 isSelect:YES keysAndValues:@[@"data-opening", opening]];
    }
    [frontCopSelection setVisibleByAttr:@"data-opening" value:opening shown:YES flag:YES];
    
    // No rear opening type
    CCMenuItem *rearCopSelection = [CCMenuItem menuItemInMenuItems:menuItems withID:@"rear_cop_selection"];
    if ([openingType isEqualToString:@"1"]){
        if (rearCopSelection.selectedThumb != nil){
            rearCopSelection.selectedThumb.isSelected = NO;
        }
        rearCopSelection.isShown = NO;
    } else {
        rearCopSelection.isShown = YES;
        [rearCopSelection setVisibleByAttr:@"data-opening" value:opening shown:NO flag:NO];
        CCThumb *thumb = rearCopSelection.selectedThumb;
        if (!isPredefined && thumb != nil && ![[thumb.attritubes stringValueForKey:@"data-opening"] isEqualToString:opening]){
            thumb.isSelected = NO;
        }
        
        [rearCopSelection setVisibleByAttr:@"data-opening" value:opening shown:YES flag:YES];
        if (!isPredefined){
            [rearCopSelection thumbsByAttrKeysAndValuesAndSelect:0 isSelect:YES keysAndValues:@[@"data-opening", opening]];
        }
    }
    
    [self setVisibilityForAltusException:isPredefined];
    
    // if back and side wall all has doors, then lock the back panels
    [self lockAllBackPanels:![openingType isEqualToString:@"1"]];
}

- (void) filterOptionsCopSelection:(BOOL) isPredefined{
    CCMenuItem * frontCopSelection = [CCMenuItem menuItemInMenuItems:menuItems withID:@"front_cop_selection"];
    CCMenuItem * rearCopSelection = [CCMenuItem menuItemInMenuItems:menuItems withID:@"rear_cop_selection"];
    NSString * front_cop_location = [frontCopSelection.selectedThumb.attritubes stringValueForKey:@"data-val"];
    NSString * rear_cop_location = rearCopSelection.selectedThumb != nil? [rearCopSelection.selectedThumb.attritubes stringValueForKey:@"data-val"]:@"";
    NSString * cop_location = @"";
    if (!isDisplayingFront && ![rear_cop_location isEqualToString:@""]){
        cop_location = rear_cop_location;
    }else if (isDisplayingFront && ![front_cop_location isEqualToString:@""]){
        cop_location = front_cop_location;
    }
    
    // has Altus cop
    CCMenuItem * altusMenu = [CCMenuItem menuItemInMenuItems:menuItems withID:@"altus"];
    if ([cop_location containsString:@"A"]){
        [altusMenu setIsShown:YES];
        altusMenu.thumbs[0].isSelected = YES;
    }else {
        [altusMenu setIsShown:NO];
        altusMenu.thumbs[0].isSelected = NO;
    }
}

- (void) filterOptionsCopType:(BOOL) isPredefined{
    CCMenuItem * copTypeItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"cop_type"];
    CCMenuItem * positionIndicatorItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"position_indicator"];
    CCMenuItem * fireServiceItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"fire_service"];
    CCMenuItem * interactionTypeItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"interaction_type"];
    CCMenuItem * accessoryItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"accessory"];
    
    // If "Dover" then, no BAR BUTTON
    [self setVisibilityForBarButton:isPredefined];
    [self setVisibilityForAccessory:isPredefined];
    [self setVisibilityForAltusException:isPredefined];
    
    // If "Dover" then, no PI 15" Matisse
    NSString * cop_type = [copTypeItem.selectedThumb.attritubes stringValueForKey:@"data-val"];
    if ([cop_type isEqualToString:@"D"] || [cop_type isEqualToString:@"A"]){
        [positionIndicatorItem setVisibleByAttr:@"data-val" value:@"M15" shown:NO flag:YES];
        CCThumb * thumb = positionIndicatorItem.selectedThumb;
        if (!isPredefined && [[thumb.attritubes stringValueForKey:@"data-val"] isEqualToString:@"M15"]){
            thumb.isSelected = NO;
            [positionIndicatorItem thumbsByAttrKeysAndValuesAndSelect:0 isSelect:YES keysAndValues:@[@"data-val", @"M10"]];
        }
    }else{
        [positionIndicatorItem setVisibleByAttr:@"data-val" value:@"M15" shown:YES flag:YES];
    }
    
    // Apply the Dover default Configuration
    if ([cop_type isEqualToString:@"D"]){
        // Fire Service 200 code
        CCThumb * thumb = fireServiceItem.selectedThumb;
        thumb.isSelected = NO;
        [fireServiceItem thumbsByAttrKeysAndValuesAndSelect:0 isSelect:YES keysAndValues:@[@"data-val", @"S"]];
        
        // Cop Interface - Traditional, < 5 floors
        thumb = interactionTypeItem.selectedThumb;
        thumb.isSelected = NO;
        [interactionTypeItem thumbsByAttrKeysAndValuesAndSelect:0 isSelect:YES keysAndValues:@[@"data-val", @"PB"]];
        [self filterOptionsInteractionType:isPredefined];
        
        NSArray<CCThumb *> *thumbs = accessoryItem.selectedThumbs;
        for (int i = 0; i < thumbs.count; i++){
            thumbs[i].isSelected = NO;
        }
        NSArray * accessories = @[@"A", @"B", @"C", @"F"];
        for (int i = 0; i < accessories.count; i++){
            thumbs = [accessoryItem thumbsByAttrKey:@"data-val" value:accessories[i]];
            for (int j = 0; j < thumbs.count; j++){
                NSString * prefix = [thumbs[j].attritubes stringValueForKey:@"data-prefix"];
                if (![prefix isEqualToString:@"AR"]){
                    thumbs[j].isSelected = YES;
                }
            }
        }
        
        // For Dover, we will show the Key Switches menu
        [accessoryItem setVisibleByAttr:@"data-val" value:@"K" shown:YES flag:YES];
    }else{
        // For non-dover, we will hide the Key Switches menu
        CCThumb * thumb = [[accessoryItem thumbsByAttrKey:@"data-val" value:@"K"] objectAtIndex:0];
        thumb.isSelected = NO;
        thumb.isShown = NO;
    }
}

- (void) filterOptionsInteractionType:(BOOL) isPredefined{
    CCMenuItem * copTypeItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"cop_type"];
    //CCMenuItem * positionIndicatorItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"position_indicator"];
    //CCMenuItem * frontCopSelection = [CCMenuItem menuItemInMenuItems:menuItems withID:@"front_cop_selection"];
    //CCMenuItem * rearCopSelection = [CCMenuItem menuItemInMenuItems:menuItems withID:@"rear_cop_selection"];
    CCMenuItem * fireServiceItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"fire_service"];
    CCMenuItem * interactionTypeItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"interaction_type"];
    CCMenuItem * accessoryItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"accessory"];
    CCMenuItem * touchScreenItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"touchscreen_size"];
    CCMenuItem * numberOfFloorsItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"number_of_floors"];
    
    NSString * interaction_type = [interactionTypeItem.selectedThumb.attritubes stringValueForKey:@"data-val"];
    if ([interaction_type isEqualToString:@"DD"]){
        // Fire Service - no 2000code
        CCThumb * thumb = [[fireServiceItem thumbsByAttrKey:@"data-val" value:@"S"] objectAtIndex:0];
        thumb.isShown = NO;
        if (!isPredefined && thumb.isSelected){
            thumb.isSelected = NO;
            [fireServiceItem thumbsByAttrKeysAndValuesAndSelect:0 isSelect:YES keysAndValues:@[@"data-val", @"C"]];
        }
        
        // No Run/Stop && Pull/Push Accessory
        NSArray<CCThumb*> * thumbs = [accessoryItem thumbsByAttrKey:@"data-prefix" value:@"UB"];
        for (int i = 0; i < thumbs.count; i++){
            CCThumb * thumb = thumbs[i];
            thumb.isSelected = NO;
            thumb.isShown = NO;
        }
    }else{
        [fireServiceItem setVisibleByAttr:@"data-val" value:@"S" shown:YES flag:YES];
        NSArray<CCThumb*> * thumbs = [accessoryItem thumbsByAttrKey:@"data-prefix" value:@"UB"];
        for (int i = 0; i < thumbs.count; i++){
            CCThumb * thumb = thumbs[i];
            thumb.isShown = YES;
        }
    }
    
    // If Traditional or Destination Dispatch, then no TouchScreen Size option
    if ([interaction_type isEqualToString:@"PB"] || [interaction_type isEqualToString:@"DD"]){
        touchScreenItem.isShown = NO;
        
        // on iOS, no needs to implement Direct Show because of tableview reload
        if (!isPredefined) [menuTableView reloadData];
        
        CCThumb * thumb = touchScreenItem.selectedThumb;
        if (thumb != nil) thumb.isSelected = NO;
    }else{
        touchScreenItem.isShown = YES;
        
        // on iOS, no needs to implement Direct Show because of tableview reload
        if (!isPredefined) [menuTableView reloadData];
        
        if (!isPredefined && touchScreenItem.selectedThumb == nil){
            [[touchScreenItem thumbs] objectAtIndex:0].isSelected = YES;
        }
    }
    
    // If Touchscreen or Destination Dispatch, then no Number of Floors options
    if ([interaction_type isEqualToString:@"TS"] || [interaction_type isEqualToString:@"DD"]){
        numberOfFloorsItem.isShown = NO;
        
        // on iOS, no needs to implement Direct Show because of tableview reload
        if (!isPredefined) [menuTableView reloadData];
        
        if (numberOfFloorsItem.selectedThumb != nil)
            numberOfFloorsItem.selectedThumb.isSelected = NO;
    }else{
        numberOfFloorsItem.isShown = YES;
        
        // on iOS, no needs to implement Direct Show because of tableview reload
        if (!isPredefined) [menuTableView reloadData];
        
        if (!isPredefined && numberOfFloorsItem.selectedThumb == nil){
            [[numberOfFloorsItem thumbs] objectAtIndex:0].isSelected = YES;
        }
    }
    
    // If Touch Screen or Destination Dispatch, then automatically Cop Type as "Applied" if previous was "Dover"
    if ([interaction_type isEqualToString:@"TS"] || [interaction_type isEqualToString:@"DD"]){
        CCThumb * thumb = copTypeItem.selectedThumb;
        if (!isPredefined && [[thumb.attritubes stringValueForKey:@"data-val"] isEqualToString:@"D"]){
            thumb.isSelected = NO;
            [copTypeItem thumbsByAttrKeysAndValuesAndSelect:0 isSelect:YES keysAndValues:@[@"data-val", @"A"]];
            
            [self filterOptionsCopType:isPredefined];
        }
    }
    
    [self resetTSImageSetting:[interaction_type isEqualToString:@"TS"]];
    
    [self setVisibilityForBarButton:isPredefined];
    [self setVisibilityForAccessory:isPredefined];
}

- (void) setVisibilityForBarButton:(BOOL) isPredefined{
    CCMenuItem * copTypeItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"cop_type"];
    CCMenuItem * interactionTypeItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"interaction_type"];
    CCMenuItem * numberOfFloorsItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"number_of_floors"];
    CCMenuItem * tactileStyleItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"tactile_style"];
    
    NSString * cop_type = [copTypeItem.selectedThumb.attritubes stringValueForKey:@"data-val"];
    NSString * interaction_type = [interactionTypeItem.selectedThumb.attritubes stringValueForKey:@"data-val"];
    NSString * number_of_floors = @"";
    
    if (numberOfFloorsItem.selectedThumb != nil) number_of_floors = [numberOfFloorsItem.selectedThumb.attritubes stringValueForKey:@"data-val"];
    
    // If Cop type is "Dover" or Interaction type is "Touch Screen" or "Destination Dispatch" then, no BAR Button;
    BOOL hiddenBarButton = NO;
    if ([cop_type isEqualToString:@"D"] || [interaction_type isEqualToString:@"TS"] || [interaction_type isEqualToString:@"DD"]){
        hiddenBarButton = YES;
    }else if ([cop_type isEqualToString:@"A"] && [number_of_floors isEqualToString:@"P3"]){
        // If Cop Type is "Dover" and Number of Floors = 15 then, don't show the Bar Button
        hiddenBarButton = YES;
    }
    
    if (hiddenBarButton){
        [tactileStyleItem setVisibleByAttr:@"data-val" value:@"A" shown:NO flag:YES];
        CCThumb * thumb = tactileStyleItem.selectedThumb;
        if (!isPredefined && thumb != nil && [[thumb.attritubes stringValueForKey:@"data-val"] isEqualToString:@"A"]){
            thumb.isSelected = NO;
            tactileStyleItem.thumbs[0].isSelected = YES;
        }
        [self setVisibilityForPushButton:isPredefined];
    }else{
        [tactileStyleItem setVisibleByAttr:@"data-val" value:@"A" shown:YES flag:YES];
        if (!isPredefined && tactileStyleItem.selectedThumb == nil){
            tactileStyleItem.thumbs[0].isSelected = YES;
        }
    }
}

- (void) setVisibilityForPushButton:(BOOL) isPredefined{
    // Pushbutton submenu should be hidden when 'BAR Button' and 'Dune'
    CCMenuItem * tactileStyleItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"tactile_style"];
    NSString * tactile_style = [tactileStyleItem.selectedThumb.attritubes stringValueForKey:@"data-val"];
    
    CCMenuItem * pushButtonItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"pushbutton"];
    if ([tactile_style isEqualToString:@"A"] || [tactile_style isEqualToString:@"U"]){
        pushButtonItem.isShown = NO;
        
        // on iOS, no needs to implement Direct Show because of tableview reload
        [menuTableView reloadData];
        
        CCThumb * thumb = pushButtonItem.selectedThumb;
        if (thumb != nil){
            thumb.isSelected = NO;
        }
    }else{
        pushButtonItem.isShown = YES;
        CCThumb * thumb = pushButtonItem.selectedThumb;
        if (!isPredefined && thumb == nil){
            [pushButtonItem thumbsByAttrKeysAndValuesAndSelect:0 isSelect:YES keysAndValues:@[@"data-val", @"0"]];
        }
        
        // on iOS, no needs to implement Direct Show because of tableview reload
        [menuTableView reloadData];
    }
}

- (void) setVisibilityForAccessory:(BOOL) isPredefined{
    CCMenuItem * copTypeItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"cop_type"];
    CCMenuItem * interactionTypeItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"interaction_type"];
    CCMenuItem * accessoryItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"accessory"];
    
    NSString * cop_type = [copTypeItem.selectedThumb.attritubes stringValueForKey:@"data-val"];
    NSString * interaction_type = [interactionTypeItem.selectedThumb.attritubes stringValueForKey:@"data-val"];
    [accessoryItem setVisibleByAttr:@"data-val" value:@"D" shown:YES flag:YES];
    [accessoryItem setVisibleByAttr:@"data-val" value:@"E" shown:YES flag:YES];
    [accessoryItem setVisibleByAttr:@"data-val" value:@"G" shown:YES flag:YES];
    
    // If Destination Dispatch, then no Access Control
    if ([interaction_type isEqualToString:@"DD"] || [cop_type isEqualToString:@"D"]){
        [accessoryItem setVisibleByAttr:@"data-val" value:@"D" shown:NO flag:YES];
        CCThumb * thumb = [accessoryItem thumbByAttrKey:@"data-val" value:@"D"];
        if (thumb != nil && thumb.isSelected){
            thumb.isSelected = NO;
        }
    }
    
    // If Cop Type is "Dover", then no Access Control and Service Cabinet and Bottom Engraving
    if ([cop_type isEqualToString:@"D"]){
        [accessoryItem setVisibleByAttr:@"data-val" value:@"G" shown:NO flag:YES];
        CCThumb * thumb = [accessoryItem thumbByAttrKey:@"data-val" value:@"G"];
        if (thumb != nil && thumb.isSelected){
            thumb.isSelected = NO;
        }
    }
}

- (void) setVisibilityForAltusException:(BOOL) isPredefined{
    // Altus only works on "Swing" cop type
    CCMenuItem * copItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"cop_type"];
    NSString * cop_type = [copItem.selectedThumb.attritubes stringValueForKey:@"data-val"];
    
    NSString * opening = [self getOpening];
    CCMenuItem * openingTypeMenu = [CCMenuItem menuItemInMenuItems:menuItems withID:@"opening_type"];
    CCThumb * openingTypeThumb = openingTypeMenu.selectedThumb;
    NSString * opening_door_type = [openingTypeThumb.attritubes stringValueForKey:@"data-opening"];
    
    CCMenuItem * frontCopSelection = [CCMenuItem menuItemInMenuItems:menuItems withID:@"front_cop_selection"];
    CCMenuItem * rearCopSelection = [CCMenuItem menuItemInMenuItems:menuItems withID:@"rear_cop_selection"];
    
    if ([cop_type isEqualToString:@"D"] || [cop_type isEqualToString:@"A"]){
        CCThumb * selected = frontCopSelection.selectedThumb;
        if (!isPredefined && [[selected.attritubes stringValueForKey:@"data-opening"] isEqualToString:opening] && [[selected.attritubes stringValueForKey:@"data-val"] containsString:@"A"]){
            selected.isSelected = NO;
            [frontCopSelection thumbsByAttrKeysAndValuesAndSelect:0 isSelect:YES keysAndValues:@[@"data-opening", opening]];
        }
        [frontCopSelection setVisibleByAttr:@"data-opening" value:opening shown:NO flag:YES key1:@"data-val" containVal:@"A" containFlag:YES];
        
        if ([opening_door_type isEqualToString:@"2"]){
            selected = rearCopSelection.selectedThumb;
            if (!isPredefined && [[selected.attritubes stringValueForKey:@"data-opening"] isEqualToString:opening] && [[selected.attritubes stringValueForKey:@"data-val"] containsString:@"A"]){
                selected.isSelected = NO;
                [rearCopSelection thumbsByAttrKeysAndValuesAndSelect:0 isSelect:YES keysAndValues:@[@"data-opening", opening]];
            }
            [rearCopSelection setVisibleByAttr:@"data-opening" value:opening shown:NO flag:YES key1:@"data-val" containVal:@"A" containFlag:YES];
        }
    }else{
        if (!isPredefined && frontCopSelection.selectedThumb == nil){
            [frontCopSelection thumbsByAttrKeysAndValuesAndSelect:0 isSelect:YES keysAndValues:@[@"data-opening", opening]];
        }
        [frontCopSelection setVisibleByAttr:@"data-opening" value:opening shown:YES flag:YES key1:@"data-val" containVal:@"A" containFlag:YES];
        
        if ([opening_door_type isEqualToString:@"2"]){
            if (!isPredefined && rearCopSelection.selectedThumb == nil){
                [rearCopSelection thumbsByAttrKeysAndValuesAndSelect:0 isSelect:YES keysAndValues:@[@"data-opening", opening]];
            }
            [rearCopSelection setVisibleByAttr:@"data-opening" value:opening shown:YES flag:YES key1:@"data-val" containVal:@"A" containFlag:YES];
        }
    }
    
    [self filterOptionsCopSelection:isPredefined];
}

- (void) updateException:(CCThumb*) thumb exceptions:(NSString*) exceptions {
    if(thumb == nil){
        return;
    }
    BOOL linkField = true;
    CCMenuItem *cabMaterial = [CCMenuItem menuItemInMenuItems:menuItems withID:@"cab_material"];
    if(cabMaterial){
        CCThumb *selected = cabMaterial.selectedThumb;
        if(selected != nil && [[selected.attritubes stringValueForKey:@"data-val"] isEqualToString:@"B"]) {
            linkField = false;
        }
    }
    
    NSString *oException = [exceptions stringByReplacingOccurrencesOfString:@"-" withString:@"_"];
    NSString *field = [NSString stringWithFormat:@"data-%@", exceptions];
    
    CCMenuItem *objTMP = [CCMenuItem menuItemInMenuItems:menuItems withID:oException];
    if (objTMP == nil){
        objTMP = [CCMenuItem menuItemInMenuItems:[SharedData shared].menuEditPanelItems withID:oException];
    }
    
    if(objTMP){
        NSArray * thumbList = nil;
        
        if(linkField){
            //objTMP.showAllThumbs(true);
            thumbList = objTMP.thumbs;
        }else{
            //objTMP.setVisibleByAttr("data-brass", "0", true, false);
            thumbList = [objTMP thumbsByAttrKey:@"data-brass" value:@"0"];
        }
        for(CCThumb *t in thumbList){
            [t.classes addObject:@"dcl-ex-visible"];
            t.isShown = YES;
        }
    }
    
    if (objTMP && [thumb.attritubes stringValueForKey:field].length > 0) {
        NSArray* f = [[thumb.attritubes stringValueForKey:field] componentsSeparatedByString:@":"];
        for (NSString * vF in f) {
            NSArray * thumbList= [objTMP thumbsByAttrKey:@"data-val" value:vF];
            
            for (CCThumb * objF in thumbList) {
                [objF removeClass:@"dcl-ex-visible"];
                objF.isShown = NO;
                if (objF.isSelected) {
                    objF.isSelected = NO;
                    NSArray * tempList = [objTMP thumbsByAttrKey:@"data-val" value:[thumb.attritubes stringValueForKey:[NSString stringWithFormat:@"data-default-%@", exceptions]]];
                    for (CCThumb * temp in tempList) {
                        temp.isSelected = YES;
                    }
                }
            }
        }
    }
    
    //        if(objTMP != null && objTMP.getSelectedThumb() == null){
    //            List<Thumb> visibleThumbs = objTMP.getVisibleThumbs(null);
    //            if(visibleThumbs.size() > 0){
    //                Thumb firstThumb = visibleThumbs.get(0);
    //                firstThumb.select();
    //            }
    //        }
    
    //        if(objTMP.find('a.dcl-selected:visible').length == 0)
    //            $objTMP.find('a.dcl-selected:first').addClass('dcl-selected');
}

- (void) filterOptionsForLandingType:(int) hallLanding {
    BOOL _tempHallMain = isHallMain;
    
    if (hallLanding > -1) _tempHallMain = hallLanding == 1;
    
    CCMenuItem * hallStyleWidthItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"hall_style_width"];
    CCMenuItem * hallStyleHeightItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"hall_style_height"];
    CCMenuItem * hallOptionsItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"hall_options"];
    
    // If Main Egress, then we only show the Extended height
    if (_tempHallMain){
        // Regular
        [hallStyleHeightItem thumbByAttrKey:@"data-val" value:@"B"].isShown = NO;
        // Small
        [hallStyleHeightItem thumbByAttrKey:@"data-val" value:@"D"].isShown = NO;
        
        // Remove the Previous Selection
        [hallStyleWidthItem selectedThumb].isSelected = NO;
        [hallStyleHeightItem selectedThumb].isSelected = NO;
        
        // Set the Extended Height Selected
        [hallStyleWidthItem thumbByAttrKey:@"data-val" value:@"C"].isSelected = YES;
        [hallStyleHeightItem thumbByAttrKey:@"data-val" value:@"C"].isSelected = YES;
        
        // For Options, we only need to show Code Blue, EPO, Access Ksw, Floor Lockout
        NSArray * thumbs0 = [hallOptionsItem thumbsByAttrKey:@"data-main-egress" value:@"0"];
        for (CCThumb * thumb in thumbs0) thumb.isShown = NO;
        
        NSArray * thumbs1 = [hallOptionsItem thumbsByAttrKey:@"data-main-egress" value:@"1"];
        for (CCThumb * thumb in thumbs1) thumb.isShown = YES;
    }else{
        // Regular
        [hallStyleHeightItem thumbByAttrKey:@"data-val" value:@"B"].isShown = YES;
        // Small
        [hallStyleHeightItem thumbByAttrKey:@"data-val" value:@"D"].isShown = YES;
        
        // >>> Temporary For Options, we can show all
        NSArray * thumbs0 = [hallOptionsItem thumbsByAttrKey:@"data-main-egress" value:@"0"];
        for (CCThumb * thumb in thumbs0) thumb.isShown = YES;
        
        NSArray * thumbs1 = [hallOptionsItem thumbsByAttrKey:@"data-main-egress" value:@"1"];
        for (CCThumb * thumb in thumbs1) thumb.isShown = YES;
    }
    
    [self filterOptionsForHallStyleWidth:NO];
    [self filterOptionsForHallStyleHeight:NO];
    [self filterOptionsForHallLanternOrientation:NO];
}

// Called when Hall Style width is changed(clicked)
- (void) filterOptionsForHallStyleWidth:(BOOL) isPredefined{
    // For Intermediate Terminal Only
    
    // if 4" then hide the Tri-Flame
    CCMenuItem * hallStyleWidthItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"hall_style_width"];
    CCMenuItem * hallOptionsItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"hall_options"];
        
    CCThumb * thumb1 = [hallOptionsItem thumbByAttrKey:@"data-val" value:@"1"];
    CCThumb * thumb3 = [hallOptionsItem thumbByAttrKey:@"data-val" value:@"3"];
    
    if ([[[hallStyleWidthItem selectedThumb].attritubes stringValueForKey:@"data-val"] isEqualToString:@"B"]){
        thumb1.isSelected = NO;
        thumb1.isShown = NO;
    }else{
        thumb1.isShown = YES;
    }
    
    if (!isHallMain){
        // if 4" then hide the 2-PI
        if ([[[hallStyleWidthItem selectedThumb].attritubes stringValueForKey:@"data-val"] isEqualToString:@"B"]){
            thumb3.isSelected = NO;
            thumb3.isShown = NO;
        }else{
            thumb3.isShown = YES;
        }
    }
}

// Called when Hall Style height is changed(clicked)
- (void) filterOptionsForHallStyleHeight:(BOOL) isPredefined{
    // For Intermediate Terminal Only
    CCMenuItem * hallStyleHeightItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"hall_style_height"];
    CCMenuItem * hallOptionsItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"hall_options"];
    
    if (!isHallMain){
        if ([[[hallStyleHeightItem selectedThumb].attritubes stringValueForKey:@"data-val"] isEqualToString:@"D"]){
            // if Small, we deselect all options already selected
            NSArray * thumbs = [hallOptionsItem selectedThumbs];
            for (CCThumb * thumb in thumbs){
                thumb.isSelected = NO;
            }
        }
    }else{
        //
        //$("#hall_options").closest('.dcl-block').show();
    }
}

- (void) filterOptionsForHallLanternItems:(BOOL) isPredefined{
    // Only apply when menu thumb is clicked. (Not on loadPredefined)
    if (isPredefined) return;
    
    // If Lantern is now invisible, because no Arrow Type is selected, then auto-select the ADA arrow type, to make the lantern visible
    CCMenuItem * hallLanternArrowTypeItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"hall_lantern_arrow_type"];
    if (hallLanternArrowTypeItem.selectedThumbs != nil && hallLanternArrowTypeItem.selectedThumbs.count > 0) return;
    
    [hallLanternArrowTypeItem thumbByAttrKey:@"data-val" value:@"B"].isSelected = YES;
    [self filterOptionsForHallLanternArrowType:isPredefined];
}

// Called when Hall Lantern Orientation is changed(clicked)
- (void) filterOptionsForHallLanternOrientation:(BOOL) isPredefined{
    CCMenuItem * hallLanternOrientationItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"hall_lantern_orientation"];
    CCMenuItem * hallLanternWidthItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"hall_lantern_width"];
    CCMenuItem * hallLanternHeightItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"hall_lantern_height"];
    if ([[[hallLanternOrientationItem selectedThumb].attritubes stringValueForKey:@"data-val"] isEqualToString:@"C"]){
        // if Vertical, then remove the Extended width
        if ([hallLanternWidthItem thumbByAttrKey:@"data-val" value:@"C"].isSelected){
            [hallLanternWidthItem thumbByAttrKey:@"data-val" value:@"C"].isSelected = NO;
            [hallLanternWidthItem thumbByAttrKey:@"data-val" value:@"B"].isSelected = YES;
        }
        
        [hallLanternWidthItem thumbByAttrKey:@"data-val" value:@"C"].isShown = NO;
        
        // Change the label and image
        hallLanternWidthItem.title = @"Height";
        hallLanternHeightItem.title = @"Width";
        
        // Height
        CCThumb * thumb_WB = [hallLanternWidthItem thumbByAttrKey:@"data-val" value:@"B"];
        [thumb_WB setFileName:@"lantern_heightregular.png"];
        CCThumb * thumb_WC = [hallLanternWidthItem thumbByAttrKey:@"data-val" value:@"C"];
        [thumb_WC setFileName:@"lantern_heightextended.png"];
        
        // Width
        CCThumb * thumb_HB = [hallLanternHeightItem thumbByAttrKey:@"data-val" value:@"B"];
        [thumb_HB setFileName:@"lantern_width4.png"];
        CCThumb * thumb_HC = [hallLanternHeightItem thumbByAttrKey:@"data-val" value:@"C"];
        [thumb_HC setFileName:@"lantern_width6.png"];
    }else{
        [hallLanternWidthItem thumbByAttrKey:@"data-val" value:@"C"].isShown = YES;
        
        // Change the label and image
        hallLanternWidthItem.title = @"Width";
        hallLanternHeightItem.title = @"Height";
        
        // Width
        CCThumb * thumb_WB = [hallLanternWidthItem thumbByAttrKey:@"data-val" value:@"B"];
        [thumb_WB setFileName:@"lantern_hor_width_regular.png"];
        CCThumb * thumb_WC = [hallLanternWidthItem thumbByAttrKey:@"data-val" value:@"C"];
        [thumb_WC setFileName:@"lantern_hor_width_extended.png"];
        
        // Height
        CCThumb * thumb_HB = [hallLanternHeightItem thumbByAttrKey:@"data-val" value:@"B"];
        [thumb_HB setFileName:@"lantern_hor_height4.png"];
        CCThumb * thumb_HC = [hallLanternHeightItem thumbByAttrKey:@"data-val" value:@"C"];
        [thumb_HC setFileName:@"lantern_hor_height6.png"];
    }
    [menuTableView reloadData];
    // For Vertical, no restriction on Hall Lantern Height for Vandal
    [self filterOptionsForHallLanternArrowType:isPredefined];
}

// Called when Hall Lantern Arrow Type is changed(clicked)
- (void) filterOptionsForHallLanternArrowType:(BOOL) isPredefined{
    CCMenuItem * hallLanternArrowTypeItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"hall_lantern_arrow_type"];
    CCMenuItem * hallLanternOrientationItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"hall_lantern_orientation"];
    CCMenuItem * hallLanternHeightItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"hall_lantern_height"];
    
    if ([[[hallLanternArrowTypeItem selectedThumb].attritubes stringValueForKey:@"data-val"] isEqualToString:@"C"] && [[[hallLanternOrientationItem selectedThumb].attritubes stringValueForKey:@"data-val"] isEqualToString:@"B"]){
        // if Vandal and Horizontal then remove then 4" height
        if ([hallLanternHeightItem thumbByAttrKey:@"data-val" value:@"B"].isSelected){
            [hallLanternHeightItem thumbByAttrKey:@"data-val" value:@"B"].isSelected = NO;
            [hallLanternHeightItem thumbByAttrKey:@"data-val" value:@"C"].isSelected = YES;
        }
        
        [hallLanternHeightItem thumbByAttrKey:@"data-val" value:@"B"].isShown = NO;
    }else{
        [hallLanternHeightItem thumbByAttrKey:@"data-val" value:@"B"].isShown = YES;
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (void) doSwitchMenus:(BOOL) isFront{
    if (isCabEditMode){
        menuVisibleItems = [SharedData shared].menuEditPanelItems;
        CCMenuItem * menuItem = menuVisibleItems[0];
        
        for (CCMenuItem * subMenuItem in menuItem.subMenuItems){
            subMenuItem.isExpanded = NO;
        }
        expandedSection = 0;
    }else{
        if (isCabViewMode){
            if (isFront){
                menuVisibleItems = [SharedData shared].menuFrontItems;
            }else{
                menuVisibleItems = [SharedData shared].menuBackItems;
            }
            
            // Quick start
            CCMenuItem * popularMenu = menuVisibleItems[0];
            // Change the file name of image
            int index = !isFront? 2:1;
            for (CCThumb * thumb in [popularMenu thumbs]){
                NSString * fileName = [NSString stringWithFormat:!isFront? @"layout-0%d.jpg":@"cop-0%d.jpg", index++];
                [thumb setFileName:fileName];
            }
        }else{
            menuVisibleItems = [SharedData shared].menuHallItems;
        }
        
        expandedSection = -1;
    }
    
    [menuTableView reloadData];
    dispatch_async(dispatch_get_main_queue(), ^{
        CGRect rect = [menuTableView rectForSection:0];
        [menuTableView scrollRectToVisible:rect animated:YES];
    });
    
    [self displayAttachGraphicsButton];
}

- (NSMutableArray *) getAllHallThumbs {
    NSMutableArray * hallThumbs = [[NSMutableArray alloc] init];
    
    for (int i = 0; i < menuItems.count; i++){
        CCMenuItem *menuItem = menuItems[i];
        if (![menuItem.folder hasPrefix:@"hall_"]) continue;
        
        if (!menuItem.hasSubMenuItems){
            for (CCThumb * thumb in [menuItem thumbs]){
                [hallThumbs addObject:thumb];
            }
        }else{
            for (int j = 0; j < menuItem.subMenuItems.count; j++){
                CCMenuItem * subMenuItem = menuItem.subMenuItems[j];
                for (CCThumb * thumb in [subMenuItem thumbs]){
                    [hallThumbs addObject:thumb];
                }
            }
        }
    }
        
    return hallThumbs;
}

- (void) saveOptionsForLandingType:(BOOL) isInitialSet {
    NSMutableArray * hallThumbs = [self getAllHallThumbs];
    for (CCThumb * thumb in hallThumbs){
        if (isInitialSet){
            thumb.attritubes[@"data-main"] = @"0";
            thumb.attritubes[@"data-typical"] = @"0";
        }else{
            if (isHallMain){
                thumb.attritubes[@"data-main"] = @"0";
            }else{
                thumb.attritubes[@"data-typical"] = @"0";
            }
            
            // for Hall Building, we reset the reverse landing type's data settings
            if ([thumb.parent.dataRel isEqualToString:@"hall_building"]){
                if (isHallMain) thumb.attritubes[@"data-typical"] = @"0";
                else thumb.attritubes[@"data-main"] = @"0";
            }
        }
        
        if (thumb.isSelected){
            if (isInitialSet){
                thumb.attritubes[@"data-main"] = @"1";
                thumb.attritubes[@"data-typical"] = @"1";
            }else{
                if (isHallMain){
                    thumb.attritubes[@"data-main"] = @"1";
                }else{
                    thumb.attritubes[@"data-typical"] = @"1";
                }
            }
            
            // for Hall Building, we reset the reverse landing type's data settings
            if ([thumb.parent.dataRel isEqualToString:@"hall_building"]){
                if (isHallMain) thumb.attritubes[@"data-typical"] = @"1";
                else thumb.attritubes[@"data-main"] = @"1";
            }
        }
    }
}

- (void) restoreOptionsForLandingType:(int) hallLanding {
    BOOL _tempHallMain = isHallMain;
    
    if (hallLanding > -1) _tempHallMain = hallLanding == 1;
        
    NSMutableArray * hallThumbs = [self getAllHallThumbs];
    for (CCThumb * thumb in hallThumbs){
        thumb.isSelected = NO;
        
        if (_tempHallMain && [thumb.attritubes[@"data-main"] isEqualToString:@"1"]) thumb.isSelected = YES;
        if (!_tempHallMain && [thumb.attritubes[@"data-typical"] isEqualToString:@"1"])
            thumb.isSelected = YES;
    }
    
    // Reload the menu view
    expandedSection = -1;
    [menuTableView reloadData];
    dispatch_async(dispatch_get_main_queue(), ^{
        CGRect rect = [menuTableView rectForSection:0];
        [menuTableView scrollRectToVisible:rect animated:YES];
    });
}

#pragma mark - TableView

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return menuVisibleItems.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    if (expandedSection == section) {
        return 1;
    }
    return 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if (isCabEditMode){
        return 0;
    }
    return ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) ? 54 : 44;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    CCMenuItem * item = menuVisibleItems[indexPath.section];

    NSInteger cols = 2;
    if ((!isDisplayingFront && [item.folder isEqualToString:@"wall_material"]) || [item.folder isEqualToString:@"opening_type"] || [item.folder isEqualToString:@"hall_finish"] || [item.folder isEqualToString:@"back_wall"] || [item.folder isEqualToString:@"side_wall"] || [item.folder isEqualToString:@"hall_building"] || [item.folder isEqualToString:@"ending_type"] || [item.folder isEqualToString:@"handrail_type"] || [item.folder isEqualToString:@"ceiling_type"]) {
        cols = 3;
    }
    
    if (isDisplayingFront && [item.folder isEqualToString:@"cop_type"]){
        cols = 3;
    }
    
    if ([item hasSeparators]) {
        CGFloat h = 0;
        for (CCSeparator * separator in item.separators) {
            if (separator.isExpanded) {
                CGFloat gap = (cols == 2) ? MENU_ITEM_HORIZONTAL_GAP : MENU_ITEM_HORIZONTAL_GAP * 2;
                CGFloat width = (tableView.frame.size.width - gap) / cols;
                CGFloat height = [CCThumbCollectionViewCell heightForCellWidth:width];
                
                NSInteger count = [[item visibleThumbs:separator] count];
                NSInteger rows = count % cols == 0 ? count / cols : count / cols + 1;
                
                // height + spaceForLines * rows
                h += (height + 4) * rows + 36;
            } else {
                h += 36;
            }
        }
        return h;
    }
    
    if (![item hasSubMenuItems]) {
        CGFloat gap = (cols == 2) ? MENU_ITEM_HORIZONTAL_GAP : MENU_ITEM_HORIZONTAL_GAP * 2;
        CGFloat width = (tableView.frame.size.width - gap) / cols;
        CGFloat height = [CCThumbCollectionViewCell heightForCellWidth:width];

        NSInteger count = [[item visibleThumbs:nil] count];
        NSInteger rows = count % cols == 0 ? count / cols : count / cols + 1;
        // height + spaceForLines * rows
        return (height + 4) * rows;
    }
    
    CGFloat h = 0;
    for (CCMenuItem * subItem in item.subMenuItems) {
        if (!subItem.isShown) continue;
        
        if (subItem.isExpanded) {
            CGFloat gap = (cols == 2) ? MENU_ITEM_HORIZONTAL_GAP : MENU_ITEM_HORIZONTAL_GAP * 2;
            CGFloat width = (tableView.frame.size.width - gap) / cols;
            CGFloat height = [CCThumbCollectionViewCell heightForCellWidth:width];
            
            NSInteger count = [[subItem visibleThumbs:nil] count];
            NSInteger rows = count % cols == 0 ? count / cols : count / cols + 1;

            // height + spaceForLines * rows
            h += (height + 4) * rows + 36;
        } else {
            h += 36;
        }
        
        if ([subItem.dataRel isEqualToString:@"wall_material"]){
            h += 40;
        }
        
        if ([subItem.graphicControlMenu isEqualToString:@"1"] && [canvasView.selectedPanel.graphicImage length] > 0) {
            h += 120;
        }
    }
    
    if (item.thumbs.count > 0) {
        // handrail has both thumbs and subitems
        CGFloat gap = (cols == 2) ? MENU_ITEM_HORIZONTAL_GAP : MENU_ITEM_HORIZONTAL_GAP * 2;
        CGFloat width = (tableView.frame.size.width - gap) / cols;
        CGFloat height = [CCThumbCollectionViewCell heightForCellWidth:width];
        
        NSInteger count = [[item visibleThumbs:nil] count];
        NSInteger rows = count % cols == 0 ? count / cols : count / cols + 1;
        
        // height + spaceForLines * rows
        h += (height + 4) * rows;
    }
    
    return h;
}

- (nullable UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    MenuSectionHeaderView * header = (MenuSectionHeaderView*)[[[NSBundle mainBundle] loadNibNamed:@"MenuSectionHeaderView" owner:self options:nil] firstObject];
    header.tag = section;
    UITapGestureRecognizer * tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onSectionTapWithGestureRecognizer:)];
    
    [header addGestureRecognizer:tapGesture];
    
    [header setSelected:(section == expandedSection)];
    
    CCMenuItem * item = menuVisibleItems[section];
    
    header.titleLabel.text = item.title;
    header.numberLabel.text = [NSString stringWithFormat:@"%ld",  (long)section + 1];

    return header;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

    CCMenuItem * item = menuVisibleItems[indexPath.section];

    if ([item hasSubMenuItems] || [item hasSeparators]) {
        CCMenuItemWithSubmenuCell * c = (CCMenuItemWithSubmenuCell*)[tableView dequeueReusableCellWithIdentifier:@"CCMenuItemWithSubmenuCell" forIndexPath:indexPath];
        c.delegate = self;
        
        [c populateSubmenusWithMenuItem:item showsGraphicControlMenu:([canvasView.selectedPanel.graphicImage length] != 0) graphicSize: canvasView.selectedPanel.graphicSize horizontalAlignment: canvasView.selectedPanel.graphicHoriAlign verticalAlignment: canvasView.selectedPanel.graphicVertAlign];
        
        return c;
    }
    
    CCMenuItemCell * cell = (CCMenuItemCell*)[tableView dequeueReusableCellWithIdentifier:@"CCMenuItemCell" forIndexPath:indexPath];
    cell.delegate = self;
    [cell populateThumbsWithMenuItem:item];
    
    return cell;
}

- (void) onSectionTapWithGestureRecognizer:(UITapGestureRecognizer*) gesture {
    if (oldSectionHeaderView) {
        [oldSectionHeaderView setSelected:NO];
    }
    
    NSInteger section = gesture.view.tag; // tag = section index
    MenuSectionHeaderView * header = (MenuSectionHeaderView *)gesture.view;
    oldSectionHeaderView = header;
    
    if (section == expandedSection) {
        if (expandedSection > -1) {
            [menuTableView beginUpdates];
            
            [menuTableView deleteRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:0 inSection:expandedSection]] withRowAnimation:UITableViewRowAnimationAutomatic];
            expandedSection = -1;
            
            [menuTableView endUpdates];
            
            [header setSelected:NO];
        }
        
        return;
    }
    
    NSInteger oldSection = expandedSection;
    
    [menuTableView beginUpdates];
    
    expandedSection = section;
    
    if (oldSection > -1) {
        [menuTableView deleteRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:0 inSection:oldSection]] withRowAnimation:UITableViewRowAnimationAutomatic];
    }
    
    [menuTableView insertRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:0 inSection:section]] withRowAnimation:UITableViewRowAnimationAutomatic];
    
//    [menuTableView reloadSections:[NSIndexSet indexSet] withRowAnimation:UITableViewRowAnimationAutomatic];
    
    [menuTableView endUpdates];
    
    [header setSelected:YES];
    [menuTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:section] atScrollPosition:UITableViewScrollPositionTop animated:YES];
}

#pragma mark - CollectionClick
// has separator or submenus

- (void) menuItem: (CCMenuItem*) menuItem subMenuItem:(CCMenuItem*) subMenuItem didSelectThumb:(CCThumb*) thumb inCollectionView:(UICollectionView*) cView {
    // backwall, material finishes, handrail
    
    CCMenuItem * backWallMenuItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"back_wall"];
    CCMenuItem * sideWallMenuItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"back_wall"];
    NSString * prevBackWall = [backWallMenuItem.selectedThumb.attritubes stringValueForKey:@"data-val"];
    NSString * prevSideWall = [sideWallMenuItem.selectedThumb.attritubes stringValueForKey:@"data-val"];
    
    if ([thumb.parent.dataRel isEqualToString:@"customize_materials"] || [thumb.parent.dataRel isEqualToString:@"customize_metals"] || [thumb.parent.dataRel isEqualToString:@"wall_glass_mirror"]){
        
        CCMenuItem * customizeMaterials = [CCMenuItem menuItemInMenuItems:menuVisibleItems withID:@"customize_materials"];
        if (customizeMaterials.selectedThumb) customizeMaterials.selectedThumb.isSelected = NO;
        CCMenuItem * customizeMetals = [CCMenuItem menuItemInMenuItems:menuVisibleItems withID:@"customize_metals"];
        if (customizeMetals.selectedThumb) customizeMetals.selectedThumb.isSelected = NO;
        CCMenuItem * wallGlassMaterials = [CCMenuItem menuItemInMenuItems:menuVisibleItems withID:@"wall_glass_mirror"];
        if (wallGlassMaterials.selectedThumb) wallGlassMaterials.selectedThumb.isSelected = NO;
        
        thumb.isSelected = YES;
        
        if (canvasView.selectedPanel){
            if (!isDisplayingFront){
                canvasView.selectedPanel.material = [thumb.attritubes stringValueForKey:@"data-val"];
                if (![Utils containsString:canvasView.selectedPanel.material inArray:GLASS_MIRRORS]){
                    [self initializeGraphicInfo:canvasView.selectedPanel];
                }
                canvasView.selectedPanel.materialDescription = thumb.setting.name;
            }else{
                NSArray * reflectionsArray = [self getSideReflectionAry];
                NSMutableArray<CCLayoutPanel*> * sidePanels = [NSMutableArray new];
                for (int i = 0; i < canvasView.panels.count; i++){
                    CCLayoutPanel * panel = canvasView.panels[i];
                    if ([panel.type isEqualToString:LAYOUT_TYPE_SIDE]){
                        [sidePanels addObject:panel];
                    }
                }
                NSInteger invertIndex = [reflectionsArray indexOfObject:[NSNumber numberWithInteger:canvasView.selectedPanel.index]];
                sidePanels[invertIndex].material = [thumb.attritubes stringValueForKey:@"data-val"];
            }
            btnRevert.hidden = NO;
            [self displayAttachGraphicsButton];
        }
        
        [menuTableView reloadData];
    }else{
        if ([thumb.parent.optional isEqualToString:@"1"] &&
            thumb.isSelected) {
            thumb.isSelected = NO;
        } else {
            if (thumb.parent.multi == nil){
                thumb.isSelected = YES;
                if ([thumb.parent.dataRel isEqualToString:@"wall_material"]){
                    CCMenuItem * metalItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"wall_metals"];
                    if (metalItem.selectedThumb) metalItem.selectedThumb.isSelected = NO;
                }else if ([thumb.parent.dataRel isEqualToString:@"wall_metals"]){
                    CCMenuItem * materialItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"wall_material"];
                    if (materialItem.selectedThumb) materialItem.selectedThumb.isSelected = NO;
                }
            }else if ([thumb.parent.multi isEqualToString:@"1"]){
                if ([thumb.parent.dataRel isEqualToString:@"hall_options"]){
                    // for hall options
                    thumb.attritubes[@"data-slot"] = @"";
                    
                    if (isHallMain){
                        if ([[thumb.attritubes stringValueForKey:@"data-val"] isEqualToString:@"4"] || [[thumb.attritubes stringValueForKey:@"data-val"] isEqualToString:@"1"]){
                            NSArray<CCThumb *> * thumbs = [thumb.parent selectedThumbs];
                            for (CCThumb *t in thumbs){
                                t.isSelected = NO;
                            }
                        }else{
                            [thumb.parent thumbByAttrKey:@"data-val" value:@"1"].isSelected = NO;
                            [thumb.parent thumbByAttrKey:@"data-val" value:@"4"].isSelected = NO;
                            
                            if ([thumb.parent selectedThumbs].count >= 2){
                                [thumb.parent selectedThumbs][0].isSelected = NO;
                            }
                        }
                    }else{
                        CCMenuItem * hallStyleHeightItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"hall_style_height"];
                        NSString * hall_style_height = [[hallStyleHeightItem selectedThumb].attritubes stringValueForKey:@"data-val"];
                        if ([hall_style_height isEqualToString:@"D"]){
                            [hallStyleHeightItem thumbByAttrKey:@"data-val" value:@"D"].isSelected = NO;
                            [hallStyleHeightItem thumbByAttrKey:@"data-val" value:@"B"].isSelected = YES;
                            hall_style_height = @"B";
                        }
                        
                        if ([hall_style_height isEqualToString:@"B"]){
                            NSArray<CCThumb *> * thumbs = [thumb.parent selectedThumbs];
                            for (CCThumb *t in thumbs){
                                t.isSelected = NO;
                            }
                        }else if ([hall_style_height isEqualToString:@"C"]){
                            // One PI
                            if ([[thumb.attritubes stringValueForKey:@"data-val"] isEqualToString:@"2"]){
                                // remove two PIs selection
                                [thumb.parent thumbByAttrKey:@"data-val" value:@"3"].isSelected = NO;
                            }
                            
                            // Two PI
                            if ([[thumb.attritubes stringValueForKey:@"data-val"] isEqualToString:@"3"]){
                                // remove one PI selection
                                [thumb.parent thumbByAttrKey:@"data-val" value:@"2"].isSelected = NO;
                            }
                            
                            // If already two options are sleected, remove one from the top most
                            if ([thumb.parent selectedThumbs].count >= 2){
                                [thumb.parent selectedThumbs][0].isSelected = NO;
                            }
                        }
                    }
                }
                thumb.isSelected = YES;
            }
                  
            
            [self filterOptions:thumb predefined:NO isBack:YES isLoop:NO];
            
            NSString * curBackWall = [backWallMenuItem.selectedThumb.attritubes stringValueForKey:@"data-val"];
            NSString * curSideWall = [sideWallMenuItem.selectedThumb.attritubes stringValueForKey:@"data-val"];
            if (![prevBackWall isEqualToString:curBackWall]){
                [self initializePanelData:LAYOUT_TYPE_BACK];
            }
            if (![prevSideWall isEqualToString:curSideWall]){
                [self initializePanelData:LAYOUT_TYPE_SIDE];
            }
            
            if ([thumb.parent.dataRel isEqualToString:@"wall_material"] || [thumb.parent.dataRel isEqualToString:@"wall_metals"] || [thumb.parent.dataRel isEqualToString:@"wall_material_optional"]){
                [self initializePanelData:LAYOUT_TYPE_ALL];
            }
            
            if ([thumb.parent.folder isEqualToString:@"hall_style"] || [thumb.parent.folder isEqualToString:@"hall_options"]){
                Hall_Zoom_Index = 2;
            }else if ([thumb.parent.folder isEqualToString:@"hall_lantern_style"] || [thumb.parent.folder isEqualToString:@"hall_lantern_options"]){
                [self resetHallZoomIndex];
            }
            
            CCMenuItem* parent = thumb.parent;
            if ([parent.dataRel isEqualToString:@"cab_material"] || [parent.dataRel isEqualToString:@"wall_material"] || [parent.dataRel isEqualToString:@"wall_metals"]) {
                //[menuTableView reloadSections:[NSIndexSet indexSetWithIndex:expandedSection] withRowAnimation:UITableViewRowAnimationNone];
                [menuTableView reloadData];
            }
        }
        
        [cView reloadData];
    }
    
    [self loadImages:isDisplayingFront shouldClearView:YES];
}

- (void) menuItem:(CCMenuItem *) menuItem didExpandOrCollapseSubMenuItem:(CCMenuItem *)subMenuItem {
    [menuTableView reloadSections:[NSIndexSet indexSetWithIndex:expandedSection] withRowAnimation:UITableViewRowAnimationFade];
}

- (void) menuItemCell:(CCMenuItemCell *)cell didSelectThumb:(CCThumb *)thumb inCollectionView:(UICollectionView *)cView atIndex:(NSInteger)index {
    
    if ([thumb.parent.dataRel isEqualToString:STR_PRE_DEFINED]) {
        // load predefined configs
        SharedData * shared = [SharedData shared];
        CabConfig * config = shared.popularLayouts[index];
        if (config) {
            self.defaultConfig = config;
            self.defaultMode = 0;
            [self loadPredefinedConfig:self.defaultConfig];
            return;
        }
    } else {
        if ([thumb.parent.optional isEqualToString:@"1"] &&
            thumb.isSelected) {
            thumb.isSelected = NO;
        } else {
            if (thumb.parent.multi == nil){
                thumb.isSelected = YES;
            }else if ([thumb.parent.multi isEqualToString:@"1"]){
                // for non "AC" accessories, just group one select
                if (![[thumb.attritubes stringValueForKey:@"data-prefix"] isEqualToString:@"AC"]){
                    NSString * prefix = [thumb.attritubes stringValueForKey:@"data-prefix"];
                    // if FS or CDA layer, then de-select for the same data-prefix item
                    CCMenuItem * accessoryItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"accessory"];
                    NSArray<CCThumb *> * thumbs = [accessoryItem selectedThumbs];
                    for (CCThumb *t in thumbs){
                        if ([[t.attritubes stringValueForKey:@"data-prefix"] isEqualToString: prefix]){
                            t.isSelected = NO;
                        }
                    }
                }
                
                thumb.isSelected = YES;
            }
            
            [self filterOptions:thumb predefined:NO isBack:YES isLoop:NO];
        }
        [cView reloadData];
    }
    // load image
    [self loadImages:isDisplayingFront shouldClearView:YES];
}

- (void)didTapGraphicSize {
    UIAlertController *actionSheet = [UIAlertController alertControllerWithTitle:@"Graphic Size" message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    
    if ([UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPad) {
        actionSheet.popoverPresentationController.sourceView = self.view;
        actionSheet.popoverPresentationController.sourceRect = CGRectMake(self.view.bounds.size.width / 2.0, self.view.bounds.size.height / 2.0, 0, 0);
        actionSheet.popoverPresentationController.permittedArrowDirections = 0;
    }
    
    [actionSheet addAction:[UIAlertAction actionWithTitle:@"Full" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        canvasView.selectedPanel.graphicSize = GRAPHIC_SIZE_FULL;
        [self loadImages:isDisplayingFront shouldClearView:YES];

        [menuTableView reloadData];
    }]];
    [actionSheet addAction:[UIAlertAction actionWithTitle:@"Medium" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        canvasView.selectedPanel.graphicSize = GRAPHIC_SIZE_MEDIUM;
        [self loadImages:isDisplayingFront shouldClearView:YES];

        [menuTableView reloadData];
    }]];
    [actionSheet addAction:[UIAlertAction actionWithTitle:@"Small" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        canvasView.selectedPanel.graphicSize = GRAPHIC_SIZE_SMALL;
        [self loadImages:isDisplayingFront shouldClearView:YES];

        [menuTableView reloadData];
    }]];
    [actionSheet addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    
    [self presentViewController:actionSheet animated:YES completion:nil];
}

- (void)didTapHorizontalAlignment {
    UIAlertController *actionSheet = [UIAlertController alertControllerWithTitle:@"Horizontal Alignment" message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    
    if ([UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPad) {
        actionSheet.popoverPresentationController.sourceView = self.view;
        actionSheet.popoverPresentationController.sourceRect = CGRectMake(self.view.bounds.size.width / 2.0, self.view.bounds.size.height / 2.0, 0, 0);
        actionSheet.popoverPresentationController.permittedArrowDirections = 0;
    }
    
    [actionSheet addAction:[UIAlertAction actionWithTitle:@"Left" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        canvasView.selectedPanel.graphicHoriAlign = GRAPHIC_HALIGN_LEFT;
        [self loadImages:isDisplayingFront shouldClearView:YES];

        [menuTableView reloadData];
    }]];
    [actionSheet addAction:[UIAlertAction actionWithTitle:@"Center" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        canvasView.selectedPanel.graphicHoriAlign = GRAPHIC_HALIGN_CENTER;
        [self loadImages:isDisplayingFront shouldClearView:YES];

        [menuTableView reloadData];
    }]];
    [actionSheet addAction:[UIAlertAction actionWithTitle:@"Right" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        canvasView.selectedPanel.graphicHoriAlign = GRAPHIC_HALIGN_RIGHT;
        [self loadImages:isDisplayingFront shouldClearView:YES];

        [menuTableView reloadData];
    }]];
    [actionSheet addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    
    [self presentViewController:actionSheet animated:YES completion:nil];
}

- (void)didTapVerticalAlignment {
    UIAlertController *actionSheet = [UIAlertController alertControllerWithTitle:@"Vertical Alignment" message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    
    if ([UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPad) {
        actionSheet.popoverPresentationController.sourceView = self.view;
        actionSheet.popoverPresentationController.sourceRect = CGRectMake(self.view.bounds.size.width / 2.0, self.view.bounds.size.height / 2.0, 0, 0);
        actionSheet.popoverPresentationController.permittedArrowDirections = 0;
    }
    
    [actionSheet addAction:[UIAlertAction actionWithTitle:@"Top" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        canvasView.selectedPanel.graphicVertAlign = GRAPHIC_VALIGN_TOP;
        [self loadImages:isDisplayingFront shouldClearView:YES];

        [menuTableView reloadData];
    }]];
    [actionSheet addAction:[UIAlertAction actionWithTitle:@"Center" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        canvasView.selectedPanel.graphicVertAlign = GRAPHIC_VALIGN_CENTER;
        [self loadImages:isDisplayingFront shouldClearView:YES];

        [menuTableView reloadData];
    }]];
    [actionSheet addAction:[UIAlertAction actionWithTitle:@"Bottom" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        canvasView.selectedPanel.graphicVertAlign = GRAPHIC_VALIGN_BOTTOM;
        [self loadImages:isDisplayingFront shouldClearView:YES];

        [menuTableView reloadData];
    }]];
    [actionSheet addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    
    [self presentViewController:actionSheet animated:YES completion:nil];
}

-(CCBaseSetting *) getHallRequestData:(CCMenuItem *)item HallLanding:(NSString *) landing{
    CCBaseSetting * setting = nil;
    if (item.multi != nil && [item.multi isEqualToString:@"1"]){
        // For accessory
        NSMutableArray <CCThumb *> * thumbs = [[NSMutableArray alloc] init];
        for (CCThumb * thumb in item.thumbs){
            if ([landing isEqualToString:@"M"] && [thumb.attritubes[@"data-main"] isEqualToString:@"1"]){
                [thumbs addObject:thumb];
            }else if ([landing isEqualToString:@"T"] && [thumb.attritubes[@"data-typical"] isEqualToString:@"1"]){
                [thumbs addObject:thumb];
            }
        }
        NSString *saveVal = @"";
        NSString *saveName = @"";
        NSString *saveImage = @"";
        setting = [CCBaseSetting new];
        if (thumbs.count > 0){
            setting.name = thumbs[0].setting.name;
            setting.desc = thumbs[0].setting.desc;
            setting.fileName = thumbs[0].setting.fileName;
            setting.filePath = thumbs[0].setting.filePath;
            setting.menuTitle = [NSString stringWithFormat:@"%@-%@", landing, thumbs[0].parent.dataRel];
            setting.description_ss = thumbs[0].setting.menuTitle;
        }
        for (int i = 0; i < thumbs.count; i++){
            CCThumb * thumb = thumbs[i];
            saveVal = [saveVal stringByAppendingFormat:@", %@", thumb.setting.desc];
            saveName = [saveName stringByAppendingFormat:@", %@", thumb.setting.name];
            saveImage = [saveImage stringByAppendingFormat:@", %@", thumb.setting.fileName];
        }
        if (![saveVal isEqualToString:@""]){
            saveVal = [saveVal substringFromIndex:2];
        }
        if (![saveName isEqualToString:@""]){
            saveName = [saveName substringFromIndex:2];
        }
        if (![saveImage isEqualToString:@""]){
            saveImage = [saveImage substringFromIndex:2];
        }
        if (setting != nil){
            setting.name = saveName;
            setting.desc = saveVal;
            setting.fileName = saveImage;
        }
    }else{
        CCThumb * selected = nil;
        for (CCThumb * thumb in item.thumbs){
            if ([landing isEqualToString:@"M"] && [thumb.attritubes[@"data-main"] isEqualToString:@"1"]){
                selected = thumb;
            }else if ([landing isEqualToString:@"T"] && [thumb.attritubes[@"data-typical"] isEqualToString:@"1"]){
                selected = thumb;
            }
        }
        if (selected) {
            setting = [CCBaseSetting new];
            setting.name = selected.setting.name;
            setting.desc = selected.setting.desc;
            setting.filePath = selected.setting.filePath;
            setting.fileName = selected.setting.fileName;
            setting.menuTitle = [NSString stringWithFormat:@"%@-%@", landing, selected.parent.dataRel];
            setting.description_ss = selected.setting.menuTitle;
        }
    }
    return setting;
}

#pragma mark - Buttons

- (CCRequestData*) prepareRequestData {
    preparingReqData = YES;
    CCRequestData * data = [[CCRequestData alloc] init];
    data.issuedDate = [NSDate date];
    
    if (isCabViewMode){
        // images
        if (isDisplayingFront) {
            data.frontImage = currentImage;
            [self loadImages:NO shouldClearView:NO];
            data.backImage = [self getFullImage:0 MinimumLayer:1 MaximumLayer:23 ExcludeLayer:3];
        } else {
            data.backImage = currentImage;
            [self loadImages:YES shouldClearView:NO];
            data.frontImage = [self getFullImage:0 MinimumLayer:1 MaximumLayer:23 ExcludeLayer:3];
        }
    }else{
        [self loadImages:NO shouldClearView:NO];
        data.backImage = [self getFullImage:0 MinimumLayer:1 MaximumLayer:23 ExcludeLayer:3];
        
        [self loadImages:YES shouldClearView:NO];
        data.frontImage = [self getFullImage:0 MinimumLayer:1 MaximumLayer:23 ExcludeLayer:3];

    }
    
    BOOL _tempCabViewMode = isCabViewMode;
    BOOL _tempHallMain = isHallMain;
    
    isCabViewMode = NO;
    isHallMain = YES;
    [self restoreOptionsForLandingType:1];
    [self filterOptionsForLandingType:1];
    [self loadImages:NO shouldClearView:NO];
    data.hallMainImage = [self getFullImage:0 MinimumLayer:24 MaximumLayer:30 ExcludeLayer:0];
    
    isHallMain = NO;
    [self restoreOptionsForLandingType:2];
    [self filterOptionsForLandingType:2];
    [self loadImages:NO shouldClearView:NO];
    data.hallTypicalImage = [self getFullImage:0 MinimumLayer:24 MaximumLayer:30 ExcludeLayer:0];
    
    if (_tempHallMain){
        [self restoreOptionsForLandingType:1];
        [self filterOptionsForLandingType:-1];
    }
    
    isCabViewMode = _tempCabViewMode;
    isHallMain = _tempHallMain;
    
    NSString * material_finish_file = @"";
    
    [data.settings removeAllObjects];
    for (CCMenuItem * item in menuItems) {
        if ([item.dataRel isEqualToString:STR_PRE_DEFINED]) {
            continue;
        }
        
        if ([item.folder hasPrefix:@"hall_"]){
            for (int i = 0; i < 2; i ++){
                NSString * landing = i == 0? @"M":@"T";
                // For hall options, we have data-typical, data-main values
                if (item.hasSubMenuItems){
                    for (CCMenuItem * subItem in item.subMenuItems) {
                        CCBaseSetting * setting = [self getHallRequestData:subItem HallLanding:landing];
                        if (setting) [data.settings addObject:setting];
                    }
                }else{
                    CCBaseSetting * setting = [self getHallRequestData:item HallLanding:landing];
                    if (setting) [data.settings addObject:setting];
                }
            }
        }else{
            if (item.multi != nil && [item.multi isEqualToString:@"1"]){
                // For accessory
                NSArray <CCThumb *> * thumbs = item.selectedThumbs;
                NSString *saveVal = @"";
                NSString *saveName = @"";
                CCBaseSetting * setting = [CCBaseSetting new];
                if (thumbs.count > 0){
                    setting.name = thumbs[0].setting.name;
                    setting.desc = thumbs[0].setting.desc;
                    setting.fileName = thumbs[0].setting.fileName;
                    setting.filePath = thumbs[0].setting.filePath;
                    setting.menuTitle = thumbs[0].setting.menuTitle;
                }
                for (int i = 0; i < thumbs.count; i++){
                    CCThumb * thumb = thumbs[i];
                    saveVal = [saveVal stringByAppendingFormat:@", %@", thumb.setting.desc];
                    saveName = [saveName stringByAppendingFormat:@", %@", thumb.setting.name];
                }
                if (![saveVal isEqualToString:@""]){
                    saveVal = [saveVal substringFromIndex:2];
                }
                if (![saveName isEqualToString:@""]){
                    saveName = [saveName substringFromIndex:2];
                }
                if (setting != nil){
                    setting.name = saveName;
                    setting.desc = saveVal;
                    [data.settings addObject:setting];
                }
            }else{
                CCThumb * selected = item.selectedThumb;
                if (selected) {
                    [data.settings addObject:selected.setting];
                }
                
                if (selected == nil && [item.dataRel isEqualToString:@"ending_type"]){
                    selected = item.unavailableThumb;
                    if (selected != nil){
                        [data.settings addObject:selected.setting];
                    }
                }
                for (CCMenuItem * subItem in item.subMenuItems) {
                    if ([subItem.dataRel isEqualToString:@"wall_material"] || [subItem.dataRel isEqualToString:@"wall_metals"]){
                        if (subItem.selectedThumb){
                            material_finish_file = subItem.selectedThumb.setting.fileName;
                        }
                    }else{
                        CCThumb * selectedSub = subItem.selectedThumb;
                        if (selectedSub)
                        {
                            [data.settings addObject:selectedSub.setting];
                        }
                    }
                }
            }
        }
    }
    
    NSString * material_finishes_description = @"";
    for (int i = 0; i < canvasView.panels.count; i++){
        CCLayoutPanel * panel = canvasView.panels[i];
        NSString * desc = (panel.graphicImage != nil && ![panel.graphicImage isEqualToString:@""])? @"Graphic Glass":panel.materialDescription;
        if (![material_finishes_description containsString:desc]){
            material_finishes_description = [material_finishes_description stringByAppendingFormat:@", %@", desc];
        }
    }
    if (![material_finishes_description isEqualToString:@""]){
        material_finishes_description = [material_finishes_description substringFromIndex:2];
    }
    CCBaseSetting * setting = [CCBaseSetting new];
    setting.name = @"Wall Material Finish";
    setting.desc = material_finishes_description;
    setting.fileName = material_finish_file;
    setting.menuTitle = @"Wall Material Finish";
    [data.settings addObject:setting];
    preparingReqData = NO;
    
    return data;
}

- (IBAction)createPDF:(id)sender {
    CCCreatePDFDialogView * cView = [CCCreatePDFDialogView showOnView:self.view];
    [cView setProjectName:self.defaultConfig.projectName];
    [cView setInitChecks];
    
    NSString * lastEmail = [[NSUserDefaults standardUserDefaults] objectForKey:USER_LAST_EMAIL_KEY];
    if (lastEmail) {
        [cView setEmail:lastEmail];
    } else {
        [cView setEmail:[[NSUserDefaults standardUserDefaults] objectForKey:USER_EMAIL_KEY]];
    }
    
    cView.dialogBlock = ^(NSString * proj, NSString * email, BOOL isCabInterior, BOOL isCOP, BOOL isHallFixtures) {
        [self exitPanelEditor:sender];
        CCRequestData * data = [self prepareRequestData];
        data.projName = proj;
        data.email = email;
        data.isPDFCabInterior = isCabInterior;
        data.isPDFCOP = isCOP;
        data.isPDFHallFixtures = isHallFixtures;
        
        NSUserDefaults * store = [NSUserDefaults standardUserDefaults];
        [store setObject:email forKey:USER_LAST_EMAIL_KEY];
        [store synchronize];

        PDFPreviewViewController * lvc = [[UIStoryboard storyboardWithName:@"Configurator" bundle:nil] instantiateViewControllerWithIdentifier:@"PDFPreviewViewController"];
        lvc.modalPresentationStyle = UIModalPresentationFullScreen;
        lvc.data = data;
        [self presentViewController:lvc animated:YES completion:nil];
    };
}

- (IBAction)requestQuote:(id)sender {
    RequestQuoteViewController * lvc = [[UIStoryboard storyboardWithName:@"Configurator" bundle:nil] instantiateViewControllerWithIdentifier:@"RequestQuoteViewController"];
    
    CCRequestData * data = [self prepareRequestData];
    
    lvc.projName = self.defaultConfig.projectName;
    lvc.customerName = self.defaultConfig.customerName;
    lvc.requestData = data;
    lvc.modalPresentationStyle = UIModalPresentationFullScreen;
    
    [self presentViewController:lvc animated:YES completion:nil];    
}

- (IBAction)switchView:(id)sender {
    if (isCabEditMode){
        [self exitPanelEditor:nil];
    }
    
    isDisplayingFront = !isDisplayingFront;
    
    // if showing frontdoor side, locking the back panel
    [self lockAllBackPanels:isDisplayingFront];
    
    [self resetSideReflectPanelData];
    
    [self doSwitchMenus:isDisplayingFront];
    
    [self loadImages:isDisplayingFront shouldClearView:YES];
    // Alex, 2020/04/01
    [self scrollviewZoomToFullSize];
    
    [self updateSwitchDesc];
}

- (void) hallViewModeProcess {
    if (isCabViewMode){
        [btnHallView setTitle:@"Hall View" forState:UIControlStateNormal];
        btnSwitchTerminal.hidden = YES;
        btnSwitchView.hidden = NO;
        openCloseView.hidden = YES;

        btnMenuHallView.hidden = NO;
        btnMenuCabView.hidden = YES;
        btnMenuSwitchTerminalView.hidden = YES;
        btnMenuSwitch.hidden = NO;
        btnMenuOpenDoorView.hidden = YES;
        btnMenuCloseDoorView.hidden = YES;
    }else{
        [btnHallView setTitle:@"Cab & COP View" forState:UIControlStateNormal];
        btnSwitchTerminal.hidden = NO;
        btnSwitchView.hidden = YES;
        openCloseView.hidden = btnCollapse.hidden;
        
        swhOpenCloseDoors.on = YES;
        leftDoorClosedConstraint.active = YES;
        leftDoorOpenedConstraint.active = NO;
        rightDoorClosedConstraint.active = YES;
        rightDoorOpenedConstraint.active = NO;
        doorClosedConstraint.active = YES;
        doorOpenedConstraint.active = NO;
        
        [contentView layoutSubviews];
        
        btnMenuHallView.hidden = YES;
        btnMenuCabView.hidden = NO;
        btnMenuSwitchTerminalView.hidden = NO;
        btnMenuSwitch.hidden = YES;
        btnMenuOpenDoorView.hidden = NO;
        btnMenuCloseDoorView.hidden = YES;
    }
    
    [self doSwitchMenus:isDisplayingFront];
    
    if (!isCabViewMode){
        [self filterOptionsForLandingType:-1];
    }
    
    [self loadImages:(!isCabViewMode? NO:isDisplayingFront) shouldClearView:YES];
    [self updateSwitchDesc];
}

- (IBAction)hallView:(id)sender {
    if (isCabEditMode){
        [self exitPanelEditor:nil];
    }
    
    isCabViewMode = !isCabViewMode;
    Hall_Zoom_Index = 0;
    [self hallViewModeProcess];
}

- (IBAction)switchTerminal:(id)sender {
    isHallMain = !isHallMain;
    
    [self restoreOptionsForLandingType:-1];
    [self filterOptionsForLandingType:-1];
    [self updateSwitchDesc];
    [self loadImages:NO shouldClearView:YES];
}

- (IBAction)switchDoor:(id)sender {
    [UIView animateWithDuration:0.8f animations:^{
        leftDoorOpenedConstraint.active = !swhOpenCloseDoors.on;
        leftDoorClosedConstraint.active = swhOpenCloseDoors.on;
        rightDoorOpenedConstraint.active = !swhOpenCloseDoors.on;
        rightDoorClosedConstraint.active = swhOpenCloseDoors.on;
        doorOpenedConstraint.active = !swhOpenCloseDoors.on;
        doorClosedConstraint.active = swhOpenCloseDoors.on;
        
        [contentView layoutSubviews];
    } completion:^(BOOL finished){
    }];
    
    if (swhOpenCloseDoors.on) {
        btnMenuOpenDoorView.hidden = NO;
        btnMenuCloseDoorView.hidden = YES;
    } else {
        btnMenuOpenDoorView.hidden = YES;
        btnMenuCloseDoorView.hidden = NO;
    }
}


- (IBAction)closeDoor:(id)sender {
    swhOpenCloseDoors.on = YES;
    [self switchDoor:sender];
}

- (IBAction)openDoor:(id)sender {
    swhOpenCloseDoors.on = NO;
    [self switchDoor:sender];
}

- (NSString *) getHallSaveItemValue:(CCMenuItem *) menuItem{
    NSString * result = @"";
    
    NSArray<CCThumb *> * thumbs = [menuItem thumbs];
    for (int i = 0; i < thumbs.count; i++){
        CCThumb * thumb = thumbs[i];
        result = [result stringByAppendingFormat:@"!%@~%@", [thumb.attritubes stringValueForKey:@"data-main"], [thumb.attritubes stringValueForKey:@"data-typical"]];
    }
    
    if (![result isEqualToString:@""]){
        result = [result substringFromIndex:1];
    }
    
    return result;
}

- (IBAction)saveAs:(id)sender {
    __weak CCSaveConfigDialogView * cView = [CCSaveConfigDialogView showOnView:self.view];
    [cView setProjectName:self.defaultConfig.projectName customerName:self.defaultConfig.customerName];
    
    cView.saveBlock = ^(NSString * proj, NSString * custom) {
        CabConfig* config = [CabConfig new];
        config.projectName = proj;
        config.customerName = custom;
        config.configDate = [NSDate date];

        NSMutableDictionary * items = [NSMutableDictionary new];

        for (CCMenuItem * item in menuItems) {
            if ([item.dataRel isEqualToString:STR_PRE_DEFINED]) {
                continue;
            }
            
            if ([item.folder hasPrefix:@"hall_"]){
                // For hall options, we have data-typical, data-main values
                if (item.hasSubMenuItems){
                    for (CCMenuItem * subItem in item.subMenuItems) {
                        NSString * saveVal = [self getHallSaveItemValue:subItem];
                        [items setObject:saveVal forKey:subItem.dataRel];
                    }
                }else{
                    NSString * saveVal = [self getHallSaveItemValue:item];
                    [items setObject:saveVal forKey:item.dataRel];
                }
            }else{
                if (item.multi != nil && [item.multi isEqualToString:@"1"]){
                    NSArray<CCThumb *> * thumbs = [item selectedThumbs];
                    NSString * saveVal = @"";
                    for (int i = 0; i < thumbs.count; i++){
                        CCThumb * thumb = [thumbs objectAtIndex:i];
                        saveVal = [saveVal stringByAppendingFormat:@"#%@%@", [thumb.attritubes stringValueForKey:@"data-prefix"], [thumb.attritubes stringValueForKey:@"data-val"]];
                    }
                    if (![saveVal isEqualToString:@""]){
                        saveVal = [saveVal substringFromIndex:1];
                    }
                    [items setObject:saveVal forKey:item.dataRel];
                }else{
                    CCThumb * selected = item.selectedThumb;
                    if (selected) {
                        [items setObject:selected.imageName forKey:item.dataRel];
                    }
                    
                    for (CCMenuItem * subItem in item.subMenuItems) {
                        CCThumb * sselected = subItem.selectedThumb;
                        if (sselected) {
                            NSString *imgName =sselected.imageName;
                            if ([imgName containsString:@"-ts"]){
                                imgName = [imgName stringByReplacingOccurrencesOfString:@"-ts" withString:@""];
                            }
                            [items setObject:imgName forKey:subItem.dataRel];
                        }
                    }
                }
            }
        }
        
        config.items = items;
        
        NSMutableArray *panels = [NSMutableArray array];
        for (int i = 0; i < canvasView.panels.count; i++) {
            CCLayoutPanel * panel = canvasView.panels[i];
            [panels addObject:[panel dictionary]];
        }
        config.panels = panels;

        if ([CabConfig insertConfig:config]) {
            self.defaultConfig = config;
            [cView showSuccess];
        }
    };
}

- (IBAction)mainMenu:(id)sender {
    [self.navigationController popToRootViewControllerAnimated:YES];
}
- (IBAction)doMenuCollapse:(id)sender {
    self.mainRatioConstraint.active = NO;
    contentLeadingConstraint.active = NO;
    btnCollapse.hidden = YES;
    btnOpen.hidden = NO;
    stackWidthConstraint.constant = 42;
    menuLeadingConstraint.constant = 0;
    [self scrollviewZoomToFullSize];
    btnMainMenu.hidden = YES;
    btnSaveAs.hidden = YES;
    stackSwitchMenu.hidden = YES;
    
    openCloseView.hidden = YES;
    
    btnRevert.hidden = YES;
    if (isCabEditMode){
        [self exitPanelEditor:nil];
    }
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [self configureHallZoomInZones];
    });
    
}

- (IBAction)doMenuOpen:(id)sender {
    self.mainRatioConstraint.active = YES;
    contentLeadingConstraint.active = YES;
    btnCollapse.hidden = NO;
    btnOpen.hidden = YES;
    btnMainMenu.hidden = NO;
    btnSaveAs.hidden = NO;
    stackSwitchMenu.hidden = NO;
    stackWidthConstraint.constant = 0;
    menuLeadingConstraint.constant = 10;
    [self scrollviewZoomToFullSize];
    
    openCloseView.hidden = isCabViewMode;
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [self configureHallZoomInZones];
    });
}

- (IBAction)editIndividualPanel:(id)sender {
    isCabEditMode = YES;
    exitPanelHeightConstraint.constant = 200;
    editPanelInstructionView.hidden = NO;
    [self doSwitchMenus:NO];
    
    [self getReadyForCustomizeIndividual:YES];
    canvasView.selectedPanel = nil;
    [self displayAttachGraphicsButton];
    menuBottomAreaHeightConstraint.constant = 0;
}

- (IBAction)exitPanelEditor:(id)sender {
    isCabEditMode = NO;
    editPanelInstructionView.hidden = YES;
    menuTableTopConstraint.constant = 8;
    canvasView.selectedPanel = nil;
    [self doSwitchMenus:NO];
    
    [self getReadyForCustomizeIndividual:NO];
    
    [self displayAttachGraphicsButton];
    
    btnRevert.hidden = YES;
    menuBottomAreaHeightConstraint.constant = 54;
}

- (IBAction)onRevert:(id)sender {
    [self resetPanelMaterials:LAYOUT_TYPE_BACK];
    [self resetPanelMaterials:LAYOUT_TYPE_SIDE];
    
    [menuTableView reloadData];
    [self loadImages:isDisplayingFront shouldClearView:YES];
    [self displayAttachGraphicsButton];
    
    btnRevert.hidden = YES;
}

- (IBAction)attachGraphics:(id)sender {
    UIAlertController *actionSheet = [UIAlertController alertControllerWithTitle:@"Attach Graphics" message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    
    if ([UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPad) {
        actionSheet.popoverPresentationController.sourceView = self.view;
        actionSheet.popoverPresentationController.sourceRect = CGRectMake(self.view.bounds.size.width / 2.0, self.view.bounds.size.height / 2.0, 0, 0);
        actionSheet.popoverPresentationController.permittedArrowDirections = 0;
    }
    
    [actionSheet addAction:[UIAlertAction actionWithTitle:@"Camera" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [self openCamera];
    }]];
    [actionSheet addAction:[UIAlertAction actionWithTitle:@"Photo Library" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [self openPhotoLibrary];
    }]];
    [actionSheet addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    
    [self presentViewController:actionSheet animated:YES completion:nil];
}

- (IBAction)onDeleteAttachment:(id)sender {
    if (canvasView.selectedPanel){
        [self initializeGraphicInfo:canvasView.selectedPanel];
        [self displayAttachGraphicsButton];
        [self loadImages:isDisplayingFront shouldClearView:YES];
        [menuTableView reloadData];
    }
}

- (void)openCamera {
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
    imagePicker.delegate = self;
    [self presentViewController:imagePicker animated:YES completion:nil];
}

- (void)openPhotoLibrary {
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    imagePicker.delegate = self;
    [self presentViewController:imagePicker animated:YES completion:nil];
}

#pragma mark ---- scrollView delegate methods ----

- (void)scrollviewZoomToFullSize
{
    //    CGSize scrollViewSize = self.scrollView.bounds.size;
    //
    //    CGFloat w = scrollViewSize.width / self.scrollView.minimumZoomScale;
    //    CGFloat h = scrollViewSize.height / self.scrollView.minimumZoomScale;
    //    CGFloat x = 0;
    //    CGFloat y = 0;
    //
    //    CGRect rectToZoomTo = CGRectMake(x, y, w, h);
    //
    //    [self.scrollView zoomToRect:rectToZoomTo animated:YES];
    [scrollView setZoomScale:1 animated:YES];
}

- (void)scrollViewDoubleTapped:(UITapGestureRecognizer*)recognizer {
    // Get the location within the image view where we tapped
    CGPoint pointInView = [recognizer locationInView:contentView];
    
    // Get a zoom scale that's zoomed in slightly, capped at the maximum zoom scale specified by the scroll view
    CGFloat newZoomScale = scrollView.zoomScale * 1.5f;
    newZoomScale = MIN(newZoomScale, scrollView.maximumZoomScale);
    
    // Figure out the rect we want to zoom to, then zoom to it
    CGSize scrollViewSize = scrollView.bounds.size;
    
    CGFloat w = scrollViewSize.width / newZoomScale;
    CGFloat h = scrollViewSize.height / newZoomScale;
    CGFloat x = pointInView.x - (w / 2.0f);
    CGFloat y = pointInView.y - (h / 2.0f);
    
    CGRect rectToZoomTo = CGRectMake(x, y, w, h);
    
    [scrollView zoomToRect:rectToZoomTo animated:YES];
}

- (void)restoreEditVisibleMenuItems {
    if (isCabEditMode){
        CCMenuItem * editMenuItem = menuVisibleItems[0];
        
        if (![editMenuItem.subMenuItems containsObject:[SharedData shared].wallMaterialEditItem])
            [editMenuItem.subMenuItems insertObject:[SharedData shared].wallMaterialEditItem atIndex:0];
        
        if (![editMenuItem.subMenuItems containsObject:[SharedData shared].wallMetalEditItem])
            [editMenuItem.subMenuItems insertObject:[SharedData shared].wallMetalEditItem atIndex:1];
        
        if (![editMenuItem.subMenuItems containsObject:[SharedData shared].wallGlassEditItem])
            [editMenuItem.subMenuItems insertObject:[SharedData shared].wallGlassEditItem atIndex:2];
    }
}

- (void)handlePanelTapped:(UITapGestureRecognizer*)recognizer {
    if (isCabEditMode){
        CGPoint touchPoint = [recognizer locationInView:scrollView];
        CCLayoutPanel * prevSelectedPanel = canvasView.selectedPanel;
        [canvasView setTouchedPanel:touchPoint ZoomScale:scrollView.zoomScale];
        if (canvasView.selectedPanel){
            [canvasView setPanelsVisibility:NO selection:YES];
            [canvasView setNeedsDisplay];
            
            menuTableTopConstraint.constant = 50;
            exitPanelHeightConstraint.constant = 40;
            
            [self restoreEditVisibleMenuItems];
            CCMenuItem * editMenuItem = menuVisibleItems[0];
            CCMenuItem * backWallMenuItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"back_wall"];
            NSString * backWall = [backWallMenuItem.selectedThumb.attritubes stringValueForKey:@"data-val"];
            // if Maple Leaf and Trinity, then the back-1 (Maple Leaf), and back-2 (Trinity) panels are only mirror/glass configurable
            // Added by Alex, 07/05/2024
            if (([backWall isEqualToString:@"C"] && [canvasView.selectedPanel.type isEqualToString:LAYOUT_TYPE_BACK] && canvasView.selectedPanel.index == 1) || ([backWall isEqualToString:@"A"] && [canvasView.selectedPanel.type isEqualToString:LAYOUT_TYPE_BACK] && canvasView.selectedPanel.index == 2)) {
                [editMenuItem.subMenuItems removeObject:[SharedData shared].wallMaterialEditItem];
                [editMenuItem.subMenuItems removeObject:[SharedData shared].wallMetalEditItem];
            }else{
                // Glasses are not possible under handrail except for the new layouts - Ashbury AL, Dundas AL, Time's Square, St. Mark's Square
                if (canvasView.selectedPanel.belowHandrail && ![Utils containsString:[backWallMenuItem.selectedThumb.attritubes stringValueForKey:@"data-val"] inArray:@[@"1", @"2", @"3", @"4"]]) {
                    [editMenuItem.subMenuItems removeObject:[SharedData shared].wallGlassEditItem];
                }
            }
            
            NSString * material = canvasView.selectedPanel.material;
            CCMenuItem * menuItem = [SharedData shared].menuEditPanelItems[0];
            for (CCMenuItem * subMenuItem in menuItem.subMenuItems){
                subMenuItem.isExpanded = NO;
                for (CCThumb * thumb in subMenuItem.thumbs){
                    thumb.isSelected = NO;
                    if ([thumb.attritubes[@"data-val"] isEqualToString:material]){
                        thumb.isSelected = YES;
                        subMenuItem.isExpanded = YES;
                    }
                }
            }
            
            [menuTableView reloadData];
            
            NSInteger sections = [self numberOfSectionsInTableView:menuTableView];
            for (NSInteger section = 0 ; section < sections ; section ++) {
                NSInteger rows = [self tableView:menuTableView numberOfRowsInSection:section];
                for (NSInteger row = 0 ; row < rows ;  row ++) {
                    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:row inSection:section];
                    UITableViewCell * cell = [self tableView:menuTableView cellForRowAtIndexPath:indexPath];
                    if ([cell isKindOfClass:[CCMenuItemWithSubmenuCell class]]) {
                        [menuTableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionBottom animated:NO];
                        
                        CCMenuItemWithSubmenuCell * cell = (CCMenuItemWithSubmenuCell *)[menuTableView cellForRowAtIndexPath:indexPath];
                        UIView *viewToShow;
                        if ([canvasView.selectedPanel.graphicImage length] == 0) {
                            viewToShow = [cell selectedThumbCell];
                        } else {
                            viewToShow = [cell visibleGraphicControlMenuView];
                        }
                        if (viewToShow != nil) {
                            CGPoint point = CGPointMake(0, viewToShow.bounds.size.height / 2);
                            point = [menuTableView convertPoint:point fromView:viewToShow];
                            if (menuTableView.contentOffset.y > 0 && menuTableView.contentOffset.y + menuTableView.bounds.size.height / 2 > point.y) {
                                [menuTableView setContentOffset:CGPointMake(0, point.y - menuTableView.bounds.size.height / 2)];
                            }
                        }
                    }
                }
            }

            [self displayAttachGraphicsButton];
        }else{
            canvasView.selectedPanel = prevSelectedPanel;
        }
        
        //[self doSwitchMenus:NO];
    }
}

- (void)scrollViewTwoFingerTapped:(UITapGestureRecognizer*)recognizer {
    // Zoom out slightly, capping at the minimum zoom scale specified by the scroll view
    CGFloat newZoomScale = scrollView.zoomScale / 1.5f;
    newZoomScale = MAX(newZoomScale, scrollView.minimumZoomScale);
    [scrollView setZoomScale:newZoomScale animated:YES];
}



-(UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView{
    return contentView;
}

- (BOOL)prefersStatusBarHidden{
    return YES;
}

- (BOOL)isEmptyCops:(NSString *)cop_location{
    return [cop_location isEqualToString:@""] || [cop_location isEqualToString:@"O"] || [cop_location isEqualToString:@"OO"];
}

- (NSString *) getOpening{
    CCMenuItem *openingTypeMenu = [CCMenuItem menuItemInMenuItems:menuItems withID:@"opening_type"];
    if (openingTypeMenu == nil) return @"";
    
    CCThumb *openingTypeThumb = openingTypeMenu.selectedThumb;
    NSString *openingType = [openingTypeThumb.attritubes stringValueForKey:@"data-val"];
    NSString *opening = [openingType stringByTrimmingCharactersInSet:[NSCharacterSet uppercaseLetterCharacterSet]];
    NSString *openingSide = [openingType stringByTrimmingCharactersInSet:[NSCharacterSet decimalDigitCharacterSet]];
    return [opening isEqualToString:@"2"]? @"3":([openingSide isEqualToString:@"R"]? @"2":@"1");
}

- (void) resetTSImageSetting:(BOOL) isTouchScreen{
    CCMenuItem * frontCopSelection = [CCMenuItem menuItemInMenuItems:menuItems withID:@"front_cop_selection"];
    CCMenuItem * rearCopSelection = [CCMenuItem menuItemInMenuItems:menuItems withID:@"rear_cop_selection"];
    
    NSArray<CCThumb*> * front_thumbs = [frontCopSelection thumbs];
    NSArray<CCThumb*> * rear_thumbs = [rearCopSelection thumbs];
    // Replace the cop_location images with "-ts.png" images
    for (int i = 0; i < front_thumbs.count; i++){
        front_thumbs[i].isTSImage = isTouchScreen;
    }
    for (int i = 0; i < rear_thumbs.count; i++){
        rear_thumbs[i].isTSImage = isTouchScreen;
    }
}

- (void) updateSwitchDesc {
    lblSwitchDesc.adjustsFontSizeToFitWidth = YES;
    lblSwitchDesc.minimumScaleFactor = 0.5;
    if (isCabViewMode){
        if (isDisplayingFront){
            lblSwitchDesc.text = @"To make changes to Cab, Switch View to Back.";
        }else{
            lblSwitchDesc.text = @"To make changes to COP, Switch View to Front.";
        }
    }else{
        if (isHallMain){
            [btnSwitchTerminal setTitle:@"Switch to Intermediate Terminal" forState:UIControlStateNormal];
            lblSwitchDesc.text = @"To make changes to Intermediate Terminal, Switch Landing.";
        }else{
            [btnSwitchTerminal setTitle:@"Switch to Terminal" forState:UIControlStateNormal];
            lblSwitchDesc.text = @"To make changes to Terminal, Switch Landing.";
        }
    }
    
    
}

#pragma mark ---- individual panel edit related methods ----
- (NSMutableArray<NSArray*> *) parsePanelArrayData:(NSString *)individuals{
    NSMutableArray * panel_arys = [NSMutableArray new];
    if (individuals != nil && ![individuals isEqualToString:@""]){
        NSArray * panels = [individuals componentsSeparatedByString:@"-"];
        for (int i = 0; i < panels.count; i++){
            if (![panels[i] isEqualToString:@""]){
                NSArray * points = [panels[i] componentsSeparatedByString:@":"];
                NSMutableArray<CCPoint*> * points_ary = [NSMutableArray new];
                for (int j = 0; j < points.count; j++){
                    if (![points[j] isEqualToString:@""]){
                        NSArray * coords = [points[j] componentsSeparatedByString:@","];
                        int x = [coords[0] intValue];
                        int y = [coords[1] intValue];
                        CCPoint * point = [CCPoint pointWithXY:x Y:y];
                        [points_ary addObject:point];
                    }
                }
                [panel_arys addObject:points_ary];
            }
        }
    }
    return panel_arys;
}

- (void) initializePanelData:(NSString *)type{
    if ([type isEqualToString:LAYOUT_TYPE_BACK] || [type isEqualToString:LAYOUT_TYPE_ALL]){
        NSMutableArray<CCLayoutPanel*> * backPanels = [NSMutableArray new];
        
        CCMenuItem * backWallMenu = [CCMenuItem menuItemInMenuItems:menuItems withID:@"back_wall"];
        NSString * backWallIndividuals = backWallMenu.selectedThumb.attritubes[@"data-individuals"];
        NSArray * backPoints = [self parsePanelArrayData:backWallIndividuals];
        NSArray * backGraphicLayouts = [backWallMenu.selectedThumb.attritubes[@"data-graphic-layout"] componentsSeparatedByString:@","];
        for (int i = 0; i < backPoints.count; i++){
            CCLayoutPanel * panel = [[CCLayoutPanel alloc] init];
            panel.type = LAYOUT_TYPE_BACK;
            panel.index = i + 1;
            panel.points = backPoints[i];
            panel.locked = isDisplayingFront;
            panel.graphicLayout = backGraphicLayouts[i];
            [backPanels addObject:panel];
        }
        for (long i = canvasView.panels.count - 1; i >= 0; i--){
            if ([canvasView.panels[i].type isEqualToString:LAYOUT_TYPE_BACK]){
                [canvasView.panels removeObject:canvasView.panels[i]];
            }
        }
        [canvasView.panels addObjectsFromArray:backPanels];
        [self resetPanelMaterials:LAYOUT_TYPE_BACK];
    }
        
    if ([type isEqualToString:LAYOUT_TYPE_SIDE] || [type isEqualToString:LAYOUT_TYPE_ALL]){
        NSMutableArray<CCLayoutPanel*> * sidePanels = [NSMutableArray new];
        
        CCMenuItem * sideWallMenu = [CCMenuItem menuItemInMenuItems:menuItems withID:@"side_wall"];
        NSString * sideWallIndividuals = sideWallMenu.selectedThumb.attritubes[@"data-individuals"];
        NSArray * sidePoints = [self parsePanelArrayData:sideWallIndividuals];
        for (int i = 0; i < sidePoints.count; i++){
            CCLayoutPanel * panel = [[CCLayoutPanel alloc] init];
            panel.type = LAYOUT_TYPE_SIDE;
            panel.index = i + 1;
            panel.points = sidePoints[i];
            [sidePanels addObject:panel];
        }
        for (long i = canvasView.panels.count - 1; i >= 0; i--){
            if ([canvasView.panels[i].type isEqualToString:LAYOUT_TYPE_SIDE]){
                [canvasView.panels removeObject:canvasView.panels[i]];
            }
        }
        [canvasView.panels addObjectsFromArray:sidePanels];
        [self resetPanelMaterials:LAYOUT_TYPE_SIDE];
    }
}

- (void) resetPanelMaterials:(NSString*) type{
    CCMenuItem * materialMenu = [CCMenuItem menuItemInMenuItems:menuItems withID:@"wall_material"];
    NSString *wall_material = materialMenu.selectedThumb.attritubes[@"data-val"];
    NSString *wall_material_description = materialMenu.selectedThumb.setting.name;
    
    if (materialMenu.selectedThumb == nil){
        CCMenuItem * metalMenu = [CCMenuItem menuItemInMenuItems:menuItems withID:@"wall_metals"];
        wall_material = metalMenu.selectedThumb.attritubes[@"data-val"];
        wall_material_description = metalMenu.selectedThumb.setting.name;
    }
    
    NSString *below_handrail_material = @"";
    CCMenuItem * materialOptionalMenu = [CCMenuItem menuItemInMenuItems:menuItems withID:@"wall_material_optional"];
    if (materialOptionalMenu.selectedThumb != nil){
        below_handrail_material = materialOptionalMenu.selectedThumb.attritubes[@"data-val"];
    }
    
    NSArray *default_mirrors = nil;
    int bh_wall_start = -1;
    
    if ([type isEqualToString:LAYOUT_TYPE_BACK]){
        CCMenuItem * backMenuItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"back_wall"];
        default_mirrors = [self getDefaultMirrorsAry:backMenuItem];
        bh_wall_start = [backMenuItem.selectedThumb.attritubes[@"data-bh-wall-start"] intValue];
    }else if ([type isEqualToString:LAYOUT_TYPE_SIDE]){
        CCMenuItem * sideMenuItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"side_wall"];
        default_mirrors = [self getDefaultMirrorsAry:sideMenuItem];
        bh_wall_start = [sideMenuItem.selectedThumb.attritubes[@"data-bh-wall-start"] intValue];
    }
    
    for (int i = 0; i < canvasView.panels.count; i++){
        CCLayoutPanel *panel = canvasView.panels[i];
        if ([panel.type isEqualToString:type]){
            NSString *material = @"";
            NSString *material_description = @"";
            if ([default_mirrors[panel.index - 1] isEqualToString:@"0"]){
                material = wall_material;
                material_description = wall_material_description;
            }else{
                material = default_mirrors[panel.index - 1];
                material_description = @"Mirror";
            }
            
            BOOL below_handrail = bh_wall_start < 0 || (panel.index >= bh_wall_start);
            if (![below_handrail_material isEqualToString:@""] && below_handrail){
                material = below_handrail_material;
            }
            
            [self initializeGraphicInfo:panel];
            panel.material = material;
            panel.materialDescription = material_description;
            panel.belowHandrail = below_handrail;
        }
    }
}

// locking the back panel, so it can't be selected or visible
- (void) lockAllBackPanels:(BOOL) locked{
    for (int i = 0; i < canvasView.panels.count; i++){
        CCLayoutPanel *panel = canvasView.panels[i];
        if ([panel.type isEqualToString:LAYOUT_TYPE_BACK]){
            panel.locked = locked;
        }
    }
}

- (void) resetSideReflectPanelData{
    CCMenuItem * sideMenuItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"side_wall"];
    NSString *side_wall_ref_individuals = sideMenuItem.selectedThumb.attritubes[@"data-ref-individuals"];
    if (side_wall_ref_individuals == nil || [side_wall_ref_individuals isEqualToString:@""]) return;
    NSArray *side_ref_points = [self parsePanelArrayData:side_wall_ref_individuals];
    NSArray *side_reflection_arrays = [self getSideReflectionAry];
    
    NSString *side_wall_individuals = sideMenuItem.selectedThumb.attritubes[@"data-individuals"];
    NSArray *side_points = [self parsePanelArrayData:side_wall_individuals];
    
    NSMutableArray<CCLayoutPanel*> *sidePanels = [NSMutableArray new];
    for (int i = 0; i < canvasView.panels.count; i++){
        CCLayoutPanel *panel = canvasView.panels[i];
        if ([panel.type isEqualToString:LAYOUT_TYPE_SIDE]){
            [sidePanels addObject:panel];
        }
    }
    
    for (int i = 0; i < sidePanels.count; i++){
        if (isDisplayingFront){
            NSInteger idx = [side_reflection_arrays[i] intValue] - 1;
            sidePanels[idx].points = side_ref_points[idx];
        }else{
            sidePanels[i].points = side_points[i];
        }
    }
}

- (void) getReadyForCustomizeIndividual:(BOOL) showAllIndividuals{
    if (isCabEditMode){
        if (canvasView.panels.count <= 0){
            [self initializePanelData:LAYOUT_TYPE_ALL];
        }
        if (showAllIndividuals){
            for (int i = 0; i < canvasView.panels.count; i++){
                canvasView.panels[i].visible = true;
                canvasView.panels[i].filled = true;
            }
        }
        [canvasView setNeedsDisplay];
    }else{
        for (int i = 0; i < canvasView.panels.count; i++){
            canvasView.panels[i].visible = false;
        }
        [canvasView setNeedsDisplay];
    }
}

- (NSArray *) getSideReflectionAry{
    CCMenuItem * sideWallMenu = [CCMenuItem menuItemInMenuItems:menuItems withID:@"side_wall"];
    NSString * reflections = sideWallMenu.selectedThumb.attritubes[@"data-reflections"];
    NSMutableArray * reflections_ary = [NSMutableArray  new];
    if (![reflections isEqualToString:@""]){
        NSArray * ary = [reflections componentsSeparatedByString:@","];
        for (NSString * val in ary){
            NSInteger integerVal = [val intValue];
            [reflections_ary addObject:@(integerVal)];
        }
    }
    return reflections_ary;
}

- (NSArray *) getDefaultMirrorsAry:(CCMenuItem *)menuItem{
    NSString * mirrors = menuItem.selectedThumb.attritubes[@"data-mirrors"];
    NSArray * mirrors_array = [NSArray new];
    if (![mirrors isEqualToString:@""]){
        mirrors_array = [mirrors componentsSeparatedByString:@","];
    }
    return mirrors_array;
}

- (void)initializeGraphicInfo:(CCLayoutPanel *)panel {
    panel.graphicWidth = 0;
    panel.graphicHeight = 0;
    panel.graphicSize = @"";
    panel.graphicImage = @"";
    panel.graphicHoriAlign = @"";
    panel.graphicVertAlign = @"";
}

- (void)displayAttachGraphicsButton {
    if (canvasView.selectedPanel && [canvasView.selectedPanel.type isEqualToString:LAYOUT_TYPE_BACK] && [Utils containsString:canvasView.selectedPanel.material inArray:GLASS_MIRRORS]){
        if (canvasView.selectedPanel.graphicImage == nil || [canvasView.selectedPanel.graphicImage isEqualToString:@""]){
            btnAttachGraphics.hidden = NO;
            self.btnDeleteAttachGraphic.hidden = YES;
        }else{
            btnAttachGraphics.hidden = YES;
            self.btnDeleteAttachGraphic.hidden = NO;
            CGSize size = mainView.frame.size;
            CGRect frame = [CCAttachedGraphic bounds:canvasView.selectedPanel.points];
            [self.btnDeleteAttachGraphic setCenter:CGPointMake((frame.origin.x + frame.size.width) * size.width / IMAGE_MAX_SIZE, frame.origin.y * size.height / IMAGE_MAX_SIZE)];
            
            // Make visible graphic control menu area, and set the default option values
        }
    }else{
        btnAttachGraphics.hidden = YES;
        self.btnDeleteAttachGraphic.hidden = YES;
        // Make invisible graphic control menu area
    }
}

- (void) setDefaultGraphicLayoutOptions {
    if (canvasView.selectedPanel){
        if ([canvasView.selectedPanel.graphicLayout isEqualToString:GRAPHIC_LAYOUT_FULL]){
            canvasView.selectedPanel.graphicSize = GRAPHIC_SIZE_MEDIUM;
        }else if ([canvasView.selectedPanel.graphicLayout isEqualToString:GRAPHIC_LAYOUT_HLONG]){
            canvasView.selectedPanel.graphicSize = GRAPHIC_SIZE_MEDIUM;
        }else if ([canvasView.selectedPanel.graphicLayout isEqualToString:GRAPHIC_LAYOUT_VLONG]){
            canvasView.selectedPanel.graphicSize = GRAPHIC_SIZE_MEDIUM;
        }else if ([canvasView.selectedPanel.graphicLayout isEqualToString:GRAPHIC_LAYOUT_SMALL]){
            canvasView.selectedPanel.graphicSize = GRAPHIC_SIZE_SMALL;
        }
        
        canvasView.selectedPanel.graphicHoriAlign = GRAPHIC_HALIGN_CENTER;
        canvasView.selectedPanel.graphicVertAlign = GRAPHIC_VALIGN_CENTER;
    }
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [picker dismissViewControllerAnimated:YES completion:nil];
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(nonnull NSDictionary<UIImagePickerControllerInfoKey,id> *)info {
    [picker dismissViewControllerAnimated:YES completion:nil];
    
    UIImage * image = info[UIImagePickerControllerOriginalImage];
    
    NSString *fileName = [NSString stringWithFormat:@"%f.png", [[NSDate date] timeIntervalSince1970]];
    NSString *filePath = [imagesPath stringByAppendingPathComponent:fileName];
    
    [UIImagePNGRepresentation(image) writeToFile:filePath atomically:YES];
    
    canvasView.selectedPanel.graphicImage = fileName;
    [self setDefaultGraphicLayoutOptions];
    [self loadImages:isDisplayingFront shouldClearView:YES];
    
    [menuTableView reloadData];
    
    NSInteger sections = [self numberOfSectionsInTableView:menuTableView];
    for (NSInteger section = 0 ; section < sections ; section ++) {
        NSInteger rows = [self tableView:menuTableView numberOfRowsInSection:section];
        for (NSInteger row = 0 ; row < rows ;  row ++) {
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:row inSection:section];
            UITableViewCell * cell = [self tableView:menuTableView cellForRowAtIndexPath:indexPath];
            if ([cell isKindOfClass:[CCMenuItemWithSubmenuCell class]]) {
                [menuTableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionBottom animated:NO];
                
                CCMenuItemWithSubmenuCell * cell = (CCMenuItemWithSubmenuCell *)[menuTableView cellForRowAtIndexPath:indexPath];
                UIView *menu = [cell visibleGraphicControlMenuView];
                if (menu != nil) {
                    CGPoint point = CGPointMake(0, menu.bounds.size.height / 2);
                    point = [menuTableView convertPoint:point fromView:menu];
                    if (menuTableView.contentOffset.y > 0 && menuTableView.contentOffset.y + menuTableView.bounds.size.height / 2 > point.y) {
                        [menuTableView setContentOffset:CGPointMake(0, point.y - menuTableView.bounds.size.height / 2)];
                    }
                }
            }
        }
    }

    btnRevert.hidden = NO;

    [self displayAttachGraphicsButton];
}

#pragma mark ---- hall zoom related methods ----

- (IBAction)hallZoomInS:(id)sender {
    btnHallZoomOut.hidden = NO;
    Hall_Zoom_Index = 2;
    [self scrollviewZoomToFullSize];
    [self loadImages:NO shouldClearView:YES];
}

- (IBAction)hallZoomInL:(id)sender {
    btnHallZoomOut.hidden = NO;
    [self resetHallZoomIndex];
    [self scrollviewZoomToFullSize];
    [self loadImages:NO shouldClearView:YES];
}

- (IBAction)hallZoomOut:(id)sender {
    Hall_Zoom_Index = 0;
    btnHallZoomOut.hidden = YES;
    [self scrollviewZoomToFullSize];
    [self loadImages:NO shouldClearView:YES];
}

- (void) configureHallZoomInZones {
    if (!isCabViewMode){
        // Calculate Hall Station zone area depends on hall station height
        CCMenuItem * hallStyleHeightItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"hall_style_height"];
        NSString * hall_style_height = [[hallStyleHeightItem selectedThumb].attritubes stringValueForKey:@"data-val"];
        int hs_x = 0, hs_y = 0, hs_w = 0, hs_h = 0;
        if ([hall_style_height isEqualToString:@"B"]){ // Regular
            hs_x = 270;
            hs_y = 830;
            hs_w = 218;
            hs_h = 402;
        }else if ([hall_style_height isEqualToString:@"C"]){ // Extended
            hs_x = 236;
            hs_y = 657;
            hs_w = 280;
            hs_h = 592;
        }else if ([hall_style_height isEqualToString:@"D"]){ // Small
            hs_x = 266;
            hs_y = 962;
            hs_w = 220;
            hs_h = 280;
        }
        
        CGFloat canvas_width = canvasView.frame.size.width;
        CGFloat canvas_height = canvasView.frame.size.height;
        hallZoomInSBtnLeadingConstraint.constant = (hs_x + hs_w) * canvas_width / 2048 - 25;
        hallZoomInSBtnTopConstraint.constant = hs_y * canvas_height / 2048 - 25;
        
        // hall_station_zone configurations here,
        hallZoomSZoneBtnLeadingConstraint.constant = hs_x * canvas_width / 2048;
        hallZoomSZoneBtnTopConstraint.constant = hs_y * canvas_height / 2048;
        hallZoomSZoneBtnWidthConstraint.constant = hs_w * canvas_width / 2048;
        hallZoomSZoneBtnHeightConstraint.constant = hs_h * canvas_height / 2048;
        
        // Calculate Hall Lantern zon area depends on hall lantern orientation and width/height
        CCMenuItem * hallLanternOrientationItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"hall_lantern_orientation"];
        NSString * hall_lantern_orientation = [[hallLanternOrientationItem selectedThumb].attritubes stringValueForKey:@"data-val"];
        CCMenuItem * hallLanternWidthItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"hall_lantern_width"];
        NSString * hall_lantern_width = [[hallLanternWidthItem selectedThumb].attritubes stringValueForKey:@"data-val"];
        
        int hl_x = 0, hl_y = 0, hl_w = 0, hl_h = 0;
        if ([hall_lantern_orientation isEqualToString:@"B"]){   // Horizontal
            if ([hall_lantern_width isEqualToString:@"B"]){     // Regular
                hl_x = 804;
                hl_y = 92;
                hl_w = 434;
                hl_h = 198;
            }else if ([hall_lantern_width isEqualToString:@"C"]){   // Extended
                hl_x = 718;
                hl_y = 102;
                hl_w = 612;
                hl_h = 181;
            }
        }else if ([hall_lantern_orientation isEqualToString:@"C"]){     // Vertical
            hl_x = 250;
            hl_y = 358;
            hl_w = 251;
            hl_h = 343;
        }
        hallZoomInLBtnLeadingConstraint.constant = (hl_x + hl_w) * canvas_width / 2048 - 20;
        hallZoomInLBtnTopConstraint.constant = hl_y * canvas_height / 2048 - 20;
        
        // hall_lantern_zone configuration here,
        hallZoomLZoneBtnLeadingConstraint.constant = hl_x * canvas_width / 2048;
        hallZoomLZoneBtnTopConstraint.constant = hl_y * canvas_height / 2048;
        hallZoomLZoneBtnWidthConstraint.constant = hl_w * canvas_width / 2048;
        hallZoomLZoneBtnHeightConstraint.constant = hl_h * canvas_height / 2048;
        
        btnHallZoomInS.hidden = NO;
        btnHallZoomSZone.hidden = NO;
        
        CCMenuItem * hallLanternArrowTypeItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"hall_lantern_arrow_type"];
        CCMenuItem * hallLanternPIItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"hall_lantern_pi"];
        NSString * hallLanternArrowType = [hallLanternArrowTypeItem selectedThumb]? [[hallLanternArrowTypeItem selectedThumb].attritubes stringValueForKey:@"data-val"]:@"";
        NSString * hallLanternPI = [hallLanternPIItem selectedThumb]? [[hallLanternPIItem selectedThumb].attritubes stringValueForKey:@"data-val"]:@"";
        if (![hallLanternArrowType isEqualToString:@""] || ![hallLanternPI isEqualToString:@"A"]){
            btnHallZoomInL.hidden = NO;
            btnHallZoomLZone.hidden = NO;
        }else{
            btnHallZoomInL.hidden = YES;
            btnHallZoomLZone.hidden = YES;
        }
        
        if (!btnHallZoomOut.hidden){
            openCloseView.hidden = YES;
            btnHallZoomInS.hidden = YES;
            btnHallZoomSZone.hidden = YES;
            btnHallZoomInL.hidden = YES;
            btnHallZoomLZone.hidden = YES;
        }else{
            openCloseView.hidden = NO;
        }
    }else{
        btnHallZoomInS.hidden = YES;
        btnHallZoomSZone.hidden = YES;
        btnHallZoomInL.hidden = YES;
        btnHallZoomLZone.hidden = YES;
        btnHallZoomOut.hidden = YES;
    }
}

- (void) resetHallZoomIndex {
    CCMenuItem * hallLanternOrientationItem = [CCMenuItem menuItemInMenuItems:menuItems withID:@"hall_lantern_orientation"];
    NSString * hall_lantern_orientation = [[hallLanternOrientationItem selectedThumb].attritubes stringValueForKey:@"data-val"];
    if ([hall_lantern_orientation isEqualToString:@"B"]){       // Horizontal
        Hall_Zoom_Index = 1;
    }else if ([hall_lantern_orientation isEqualToString:@"C"]){ // Vertical
        Hall_Zoom_Index = 3;
    }
}

- (void) AppendHallZoomImage:(NSString*) imageName zOrder:(NSInteger)z {
    BOOL hallZoomMode = !btnHallZoomOut.hidden;
    
    if (hallZoomMode && Hall_Zoom_Index > 0){
        z += 10;
        if (z == 35){           // Hall Building Wall Image
            [self appendImage:[imageName stringByAppendingFormat:@"-%d", Hall_Zoom_Index] zOrder:z];
        }else if ((z == 36 && Hall_Zoom_Index == 2) || (z > 36 && (Hall_Zoom_Index == 1 || Hall_Zoom_Index == 3))){
            // if Hall Station Zone, only Hall Station Images, if Hall Lantern Zone, only Hall Lantern Images only
            [self appendImage:[imageName stringByAppendingFormat:@"-%@", @"Z"] zOrder:z];
        }
    }
}
@end
