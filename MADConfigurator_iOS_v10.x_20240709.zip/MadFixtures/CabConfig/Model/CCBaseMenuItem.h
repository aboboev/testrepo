//
//  CCBaseMenuItem.h
//  MadCabConfigurator
//
//  Created by Alex on 1/15/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CCBaseMenuItem : NSObject

@property (nonatomic, strong) NSString * title;
@property (nonatomic, strong) NSString * drop;
@property (nonatomic) BOOL isShown;
// For UI
@property (nonatomic) BOOL isExpanded;

@end
