//
//  CCBaseSetting.h
//  MadCabConfigurator
//
//  Created by Alex on 1/15/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CCBaseSetting : NSObject

@property (nonatomic, strong) NSString * menuTitle;
@property (nonatomic, strong) NSString * filePath;
@property (nonatomic, strong) NSString * fileName;
@property (nonatomic, strong) NSString * name;
@property (nonatomic, strong) NSString * desc;

@property (nonatomic, strong) NSString * description_ss;
@property (nonatomic, strong) NSString * description_brass;

- (NSString*) getDescFromMany:(BOOL)isSS;

@end
