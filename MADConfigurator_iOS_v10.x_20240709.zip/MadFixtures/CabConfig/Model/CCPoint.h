//
//  CCPoint.h
//  MadFixtures
//
//  Created by Alex on 2/3/24.
//  Copyright © 2024 Mad Elevator. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CCPoint : NSObject
{
    
}
+ (instancetype) pointWithXY: (NSInteger) x Y:(NSInteger) y;
@property (nonatomic, assign) NSInteger x;
@property (nonatomic, assign) NSInteger y;

- (id)initWithDictionary:(NSDictionary *)dictionary;

-(NSDictionary *)dictionary;
+(NSArray *)dictionaryArrayWithPoints:(NSArray<CCPoint*>*)points;

@end
