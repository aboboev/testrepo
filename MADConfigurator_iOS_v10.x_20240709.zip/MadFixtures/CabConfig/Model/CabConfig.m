//
//  CabConfig.m
//  MadCabConfigurator
//
//  Created by Alex on 1/14/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import "CabConfig.h"
#import "AppDelegate.h"
#import "CDConfig+CoreDataClass.h"
#import "CDConfig+CoreDataProperties.h"

#define CONFIG_ENTITY       @"CDConfig"

#define CONFIG_PROJECT_NAME_KEY         @"projectName"
#define CONFIG_CUSTOMER_NAME_KEY         @"customerName"
#define CONFIG_DATE_KEY         @"configDate"
#define CONFIG_ITEMS_KEY         @"items"
#define CONFIG_PANELS_KEY         @"panels"

@interface CabConfig()
{
    
}
@end

@implementation CabConfig

+ (CabConfig *) configFromCDObject:(CDConfig*) c {
    CabConfig * config = [[CabConfig alloc] init];
    
    config.configDate = c.configDate;
    config.projectName = c.projectName;
    config.customerName = c.customerName;

    NSMutableDictionary * items = [NSMutableDictionary new];
    
    NSArray * itemsKeyValues = [c.items componentsSeparatedByString:@","];
    for (NSInteger index = 0; index < itemsKeyValues.count; index += 2) {
        NSString * key = itemsKeyValues[index];
        NSString * val = itemsKeyValues[index + 1];
        items[key] = val;
    }
    
    config.items = items;
    
    if (c.panels != nil) {
        config.panels = [NSJSONSerialization JSONObjectWithData:[c.panels dataUsingEncoding:NSUTF8StringEncoding] options:0 error:nil];
    }
    
    return config;
}
//
//+ (NSDictionary *) dictionaryFromConfig:(CabConfig*) config {
//    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
//    dic[CONFIG_ID_KEY] = config.ID;
//    dic[CONFIG_DATE_KEY] = config.configDate;
//    dic[CONFIG_PROJECT_NAME_KEY] = config.projectName;
//    dic[CONFIG_CUSTOMER_NAME_KEY] = config.customerName;
//    dic[CONFIG_ITEMS_KEY] = config.items;
//    
//    return dic;
//}

+ (NSArray*) getConfigsWithSort:(CabConfigSort) sort ascending:(BOOL) ascending {
    NSManagedObjectContext *context = AppDelegate.sharedDelegate.managedObjectContext;
    
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] initWithEntityName:CONFIG_ENTITY];
    
    if (sort == CabConfigSortDate)
    {
        NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:CONFIG_DATE_KEY ascending:ascending];
        fetchRequest.sortDescriptors = @[sortDescriptor];
    } else if (sort == CabConfigSortProject) {
        NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:CONFIG_PROJECT_NAME_KEY ascending:ascending];
        fetchRequest.sortDescriptors = @[sortDescriptor];
    } else if (sort == CabConfigSortCustomer) {
        NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:CONFIG_CUSTOMER_NAME_KEY ascending:ascending];
        fetchRequest.sortDescriptors = @[sortDescriptor];
    }
    
    NSError *requestError = nil;
    NSArray *projects = [context executeFetchRequest:fetchRequest error:&requestError];
    
    NSMutableArray * configs = [NSMutableArray new];
    for (CDConfig * config in projects) {
        CabConfig * c = [CabConfig configFromCDObject:config];
        [configs addObject:c];
    }
    
    return configs;
}

+ (BOOL) insertConfig:(CabConfig*) config {
    NSManagedObjectContext *context = [AppDelegate sharedDelegate].managedObjectContext;
    
    CDConfig * c = [NSEntityDescription insertNewObjectForEntityForName:CONFIG_ENTITY inManagedObjectContext:context];
    c.projectName = config.projectName;
    c.customerName = config.customerName;
    c.configDate = config.configDate;
    
    NSString * items = @"";
    for (NSString * key in config.items.allKeys) {
        NSString * val = config.items[key];
        items = [items stringByAppendingFormat:@"%@,%@,", key, val];
    }
    items = [items substringToIndex:items.length - 1];
    c.items = items;
    
    if ([config.panels count] > 0) {
        NSData *jsonData = [NSJSONSerialization dataWithJSONObject:config.panels options:NSJSONWritingPrettyPrinted error:nil];
        NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        
        c.panels = jsonString;
    }
    
    return [[AppDelegate sharedDelegate] saveContext];
}

+ (BOOL) removeConfig:(CabConfig*) config {
    NSManagedObjectContext *context = [AppDelegate sharedDelegate].managedObjectContext;

    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] initWithEntityName:CONFIG_ENTITY];
    NSArray *configs = [context executeFetchRequest:fetchRequest error:nil];
    
    CDConfig * matched = nil;
    for (CDConfig * c in configs) {
        if ([c.projectName isEqualToString:config.projectName] && [c.customerName isEqualToString:config.customerName] && [c.configDate isEqualToDate:config.configDate]) {
            // same
            matched = c;
            break;
        }
    }
    if (!matched) {
        return NO;
    }
    
    [context deleteObject:matched];
    return YES;
}

//+ (NSArray*) getConfigsWithFilter:(CabConfigFilter) filter ascending:(BOOL) ascending {
//    
//    if (![[NSFileManager defaultManager] fileExistsAtPath:CONFIGS_PLIST_PATH]) {
//        // create file
//        [[NSFileManager defaultManager] createFileAtPath:CONFIGS_PLIST_PATH contents:nil attributes:nil];
//        
//        return [NSArray new];
//    }
//    
//    NSData *plistData = [NSData dataWithContentsOfFile:CONFIGS_PLIST_PATH];
//    NSError *error;
//    NSPropertyListFormat format;
//    
//    NSArray * configs = [NSPropertyListSerialization propertyListWithData:plistData options:NSPropertyListMutableContainers format:&format error:&error];
//    
//    if (error == nil && configs) {
//        NSMutableArray * result = [NSMutableArray new];
//        for (NSDictionary * dic in configs) {
//            [result addObject:[CabConfig configFromDictionary:dic]];
//        }
//        
//        if (filter == CabConfigFilterDate) {
//            [result sortUsingComparator:^NSComparisonResult(id  _Nonnull obj1, id  _Nonnull obj2) {
//                NSDate * date1 = obj1[CONFIG_DATE_KEY];
//                NSDate * date2 = obj2[CONFIG_DATE_KEY];
//                
//                return (ascending) ? [date1 compare:date2] : [date2 compare:date1];
//            }];
//        } else if (filter == CabConfigFilterProject) {
//            [result sortUsingComparator:^NSComparisonResult(id  _Nonnull obj1, id  _Nonnull obj2) {
//                NSDate * date1 = obj1[CONFIG_PROJECT_NAME_KEY];
//                NSDate * date2 = obj2[CONFIG_PROJECT_NAME_KEY];
//                
//                return (ascending) ? [date1 compare:date2] : [date2 compare:date1];
//            }];
//        } else if (filter == CabConfigFilterCustomer) {
//            [result sortUsingComparator:^NSComparisonResult(id  _Nonnull obj1, id  _Nonnull obj2) {
//                NSDate * date1 = obj1[CONFIG_CUSTOMER_NAME_KEY];
//                NSDate * date2 = obj2[CONFIG_CUSTOMER_NAME_KEY];
//                
//                return (ascending) ? [date1 compare:date2] : [date2 compare:date1];
//            }];
//        }
//        
//        return result;
//    }
//
//    return [NSArray new];
//}
//
//+ (BOOL) saveConfig:(CabConfig*) config {
//    if (![[NSFileManager defaultManager] fileExistsAtPath:CONFIGS_PLIST_PATH]) {
//        // create file
//        [[NSFileManager defaultManager] createFileAtPath:CONFIGS_PLIST_PATH contents:nil attributes:nil];
//    }
//    NSDictionary * dictionary = [CabConfig dictionaryFromConfig:config];
//    
//    if ([NSPropertyListSerialization propertyList:dictionary isValidForFormat:NSPropertyListXMLFormat_v1_0]) {
//        NSLog(@"OK");
//    }
//    
//    NSOutputStream * stream = [NSOutputStream outputStreamToFileAtPath:CONFIGS_PLIST_PATH append:YES];
//    NSLog(@"%@", CONFIGS_PLIST_PATH);
//    
//    NSError * error;
//    NSInteger bytes = [NSPropertyListSerialization writePropertyList:dictionary toStream:stream format:NSPropertyListXMLFormat_v1_0 options:0 error:&error];
//    
//    return (bytes >0);
//}
//
//+ (BOOL) saveConfigs:(NSArray<CabConfig*>*) configs {
//    if (![[NSFileManager defaultManager] fileExistsAtPath:CONFIGS_PLIST_PATH]) {
//        // create file
//        [[NSFileManager defaultManager] createFileAtPath:CONFIGS_PLIST_PATH contents:nil attributes:nil];
//    }
//    
//    NSMutableArray * array = [[NSMutableArray alloc] init];
//    for (CabConfig * c in configs) {
//        [array addObject:[CabConfig dictionaryFromConfig:c]];
//    }
//    
//    NSOutputStream * stream = [NSOutputStream outputStreamToFileAtPath:CONFIGS_PLIST_PATH append:NO];
//    
//    NSInteger bytes = [NSPropertyListSerialization writePropertyList:array toStream:stream format:NSPropertyListXMLFormat_v1_0 options:0 error:nil];
//    
//    return (bytes >0);
//}


@end
