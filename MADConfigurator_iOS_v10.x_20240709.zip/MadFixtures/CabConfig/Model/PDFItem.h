//
//  PDFItem.h
//  MadFixtures
//
//  Created by Alex on 12/24/20.
//  Copyright © 2020 Mad Elevator. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PDFItem : NSObject
{
    
}

@property (nonatomic, assign) NSInteger number;
@property (nonatomic, strong) NSString * title;
@property (nonatomic, strong) NSString * image1;
@property (nonatomic, strong) NSString * image2;
@property (nonatomic, strong) NSString * content;

@end
