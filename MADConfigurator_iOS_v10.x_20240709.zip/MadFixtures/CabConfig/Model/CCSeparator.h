//
//  CCSeparator.h
//  MadCabConfigurator
//
//  Created by Alex on 1/14/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CCBaseMenuItem.h"

@class CCMenuItem;
@interface CCSeparator : CCBaseMenuItem {
    
}

@property (nonatomic, strong) CCMenuItem * parent;

+ (instancetype) separatorWithName: (NSString*) name parent:(CCMenuItem*) parent;
- (BOOL) equals: (CCSeparator *) separator;


@end
