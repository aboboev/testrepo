//
//  CabConfig.h
//  MadCabConfigurator
//
//  Created by Alex on 1/14/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum : NSUInteger {
    CabConfigSortDate,
    CabConfigSortProject,
    CabConfigSortCustomer
} CabConfigSort;

@interface CabConfig : NSObject
{

}

@property (nonatomic, assign) NSInteger ID;

@property (nonatomic, strong) NSString *dataRel;
@property (nonatomic, strong) NSString *dataTitle;
@property (nonatomic, strong) NSString *dataPreview;

@property (nonatomic, strong) NSDictionary *items;
@property (nonatomic, strong) NSString *projectName;
@property (nonatomic, strong) NSString *customerName;
@property (nonatomic, strong) NSDate *configDate;

@property (nonatomic, strong) NSArray *panels;

+ (NSArray*) getConfigsWithSort:(CabConfigSort) sort ascending:(BOOL) ascending;
+ (BOOL) insertConfig:(CabConfig*) config;
+ (BOOL) removeConfig:(CabConfig*) config;

@end
