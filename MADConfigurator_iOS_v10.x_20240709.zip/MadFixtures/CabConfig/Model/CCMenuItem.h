//
//  CCMenuItem.h
//  MadCabConfigurator
//
//  Created by Alex on 1/14/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CCBaseMenuItem.h"

@class CCThumb;
@class CCMenuItem;
@class CCSeparator;
@interface CCMenuItem : CCBaseMenuItem
{
    
}

@property (nonatomic, strong) NSString *dataRel;
@property (nonatomic, strong) NSString *ID;
@property (nonatomic, strong) NSString *folder;
@property (nonatomic, strong) NSString *optional;
@property (nonatomic, strong) NSString *sub;
@property (nonatomic, strong) NSString *multi;
@property (nonatomic, strong) NSString *graphicControlMenu;

@property (nonatomic, strong) NSMutableArray <CCThumb*>* thumbs;
@property (nonatomic, strong) NSMutableArray <CCMenuItem*>* subMenuItems;
@property (nonatomic, strong) NSMutableArray <CCSeparator*>* separators;

@property (nonatomic, strong) CCMenuItem *parent;

+ (CCMenuItem *) menuItemInMenuItems: (NSArray *) items withFolder:(NSString *) folder;
- (NSMutableArray*)visibleThumbs:(CCSeparator*) separator;
- (NSMutableArray*)visibleThumbsIncludingSubitems;

- (CCThumb*) selectedThumb;
- (CCThumb*) unavailableThumb;
- (NSArray<CCThumb *>*) selectedThumbs;

+ (CCMenuItem *) menuItemInMenuItems:(NSArray *)items withID:(NSString *)ID;
- (NSArray<CCThumb *>*) thumbsByIDsArray:(NSString *)IDs;
- (CCThumb * ) thumbByFileName:(NSString *) filename;
- (CCThumb * ) selectedThumbByAttr:(NSString *) key value:(NSString *) value key:(BOOL) keyFlag flag:(BOOL) selectedFlag;
- (NSArray<CCThumb *>*) thumbsByAttrKey:(NSString *) key value:(NSString *) value;
- (CCThumb * ) thumbByAttrKey:(NSString *) key value:(NSString *) value;
- (NSArray<CCThumb *>*) thumbsByAttrKeysAndValues:(NSArray *) keysAndValues;
- (void) thumbsByAttrKeysAndValuesAndSelect:(NSInteger) selectNum isSelect:(BOOL) isSelect keysAndValues:(NSArray *)keysAndValues;

- (void) showAllThumbs:(BOOL) shown;
- (void) showAllUnavailableThumbs:(BOOL) shown;
- (void) deselectAllThumbs;

- (NSInteger) unavailableThumbsCount;
- (void) setVisibleByAttr:(NSString *) key value:(NSString * ) value shown:(BOOL)shown flag:(BOOL) flag;
- (void) setVisibleByAttr:(NSString *) key value:(NSString * ) value shown:(BOOL)shown flag:(BOOL) flag key1:(NSString * ) key1 containVal:(NSString *)containVal containFlag:(BOOL)containFlag;
- (void) setVisibleByAttrAndClass:(NSString *) key value:(NSString * ) value class:(NSString*) className shown:(BOOL)shown;

+ (void) showThumbsByAttr:(NSArray *) menuItems key:(NSString *) key value:(NSString * ) value shown:(BOOL)shown;
+ (void) showThumbsByClassAndAttr:(NSArray *) menuItems key:(NSString *) key value:(NSString * ) value class:(NSString*) className shown:(BOOL)shown;

- (NSArray*) thumbsByClasses:(NSArray*) classNames;

// extensions
- (BOOL) hasSubMenuItems;
- (BOOL) hasSeparators;

@end

