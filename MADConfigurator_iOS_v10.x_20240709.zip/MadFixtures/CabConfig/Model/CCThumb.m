//
//  CCThumb.m
//  MadCabConfigurator
//
//  Created by Alex on 1/14/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import "CCThumb.h"
#import "CCBaseSetting.h"
#import "CCMenuItem.h"

@implementation CCThumb

- (instancetype) init {
    self = [super init];
    _isAvailable = YES;
    _isShown = YES;
    _isSelected = NO;
    _isTSImage = NO;
    _setting = [CCBaseSetting new];
    _attritubes = [[NSMutableDictionary alloc] init];
    return self;
}

- (NSString*) name {
    return _setting.name;
}

- (NSString*) imageName {
    return _setting.fileName;
}

- (CCBaseSetting*) getSetting {
    _setting.menuTitle = self.parent.title;
    
    return _setting;
}

- (void) setFileName:(NSString*) fileName {
    _setting.fileName = fileName;
    if ([fileName containsString:@"-Look.png"]) {
        _isAvailable = NO;
    }
}

- (void) removeClass:(NSString*) className {
    [_classes removeObject:className];
}
- (BOOL) hasClass:(NSString * ) className {
    return [_classes containsObject:className];
}

- (void) setIsSelected:(BOOL)isSelected {
    if (isSelected) {
        if (self.parent.multi == nil){
            CCThumb * oldSelected = self.parent.selectedThumb;
            if (oldSelected) {
                oldSelected.isSelected = NO;
            }
        }
        
        _isSelected = YES;
        _isShown = YES;
    } else {
        _isSelected = NO;
    }
}

- (void) setIsTSImage:(BOOL)isTSImage{
    if (isTSImage){
        if ([_attritubes[@"data-tsimage"] isEqualToString:@"1"]){
            NSString *replaced = [NSString stringWithFormat:@"%@-ts%@", [self.imageName substringToIndex:self.imageName.length - 4], [self.imageName substringFromIndex:self.imageName.length - 4]];
            [self setFileName:replaced];
        }
    }else{
        if ([_attritubes[@"data-tsimage"] isEqualToString:@"1"]){
            NSString *replaced = [self.imageName stringByReplacingOccurrencesOfString:@"-ts" withString:@""];
            [self setFileName:replaced];
        }
    }
}
@end
