//
//  CCPoint.m
//  MadFixtures
//
//  Created by Alex on 2/3/24.
//  Copyright © 2024 Mad Elevator. All rights reserved.
//
#import "CCPoint.h"

@implementation CCPoint

- (instancetype) init {
    self = [super init];
    self.x = -1;
    self.y = -1;
    return self;
}

+ (instancetype) pointWithXY:(NSInteger)x Y:(NSInteger)y{
    CCPoint * point = [CCPoint new];
    point.x = x;
    point.y = y;
    return point;
}

- (id)initWithDictionary:(NSDictionary *)dictionary {
    self = [self init];
    
    self.x = [[dictionary objectForKey:@"x"] integerValue];
    self.y = [[dictionary objectForKey:@"y"] integerValue];
    
    return self;
}

-(NSDictionary *)dictionary {
    return [NSDictionary dictionaryWithObjectsAndKeys:@(self.x), @"x", @(self.y), @"y", nil];
}

+(NSArray *)dictionaryArrayWithPoints:(NSArray<CCPoint*>*)points {
    NSMutableArray *array = [NSMutableArray array];
    for (CCPoint *point in points) {
        [array addObject:[point dictionary]];
    }
    return array;
}

@end
