//
//  SharedData.m
//  MadCabConfigurator
//
//  Created by Alex on 1/7/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import "SharedData.h"
#import "CabConfig.h"
#import "CCMenuItem.h"
#import "CCThumb.h"
#import "CCSeparator.h"
#import "CCBaseSetting.h"

#import "TreeNode.h"
#import "XMLParser.h"

#import "Constants.h"

static SharedData * shared = nil;

@interface SharedData() {

}
@end

@implementation SharedData

+ (instancetype) shared {
    if (shared == nil) {
        shared = [[SharedData alloc] init];
    }
    
    return shared;
}

- (void) initialize {
    [self loadPreModels];
    [self loadCabinet];
}

- (void) loadCabinet {
    if (_menuItems != nil) {
        [_menuItems removeAllObjects];
        _menuItems = nil;
    }
    _menuItems = [NSMutableArray new];
    
    //set predefined models
    CCMenuItem * popularItem = [CCMenuItem new];
    popularItem.dataRel = STR_PRE_DEFINED;
    popularItem.title = STR_POPULAR_LAYOUTS;
    popularItem.folder = POPULAR_IMG_URL; // in iOS it's no matter;
    
    int index = 0;
    for (CabConfig * config in _popularLayouts) {
        CCThumb * thumb = [CCThumb new];
        thumb.setting.name = config.dataTitle;
        [thumb setFileName:config.dataPreview];
        thumb.setting.filePath = [NSString stringWithFormat:@"%@%@", popularItem.folder, config.dataPreview];
        thumb.attritubes[@"data-val"] = [NSString stringWithFormat:@"%d", index++];
        thumb.parent = popularItem;
        
        [popularItem.thumbs addObject:thumb];
    }
    [_menuItems addObject:popularItem];
    
    NSURL *purl = [NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"cabinet" ofType:@"xml"]];
    
    TreeNode * xmlDoc = [[XMLParser sharedInstance] parseXMLFile:purl];
    
    if(xmlDoc != nil){
        NSArray * sections = xmlDoc.children;
        for (TreeNode * section in sections) {
            CCMenuItem * item = [CCMenuItem new];
            item.dataRel = section.attributes[@"data-rel"];
            
            // We remove Finish Below Handrail menu for now, 2024/01/31, Alex
            if ([item.dataRel isEqualToString:@"wall_material_optional"]) {
                continue;
            }
            
            item.ID = [section childElementByName:@"id"].leafvalue;
            item.title = [section childElementByName:@"title"].leafvalue;
            item.folder = [section childElementByName:@"folder"].leafvalue;
            item.optional = [section childElementByName:@"optional"].leafvalue;
            item.multi = [section childElementByName:@"multiple"].leafvalue;
            item.sub = [section childElementByName:@"sub"].leafvalue;
            item.drop = [section childElementByName:@"drop"].leafvalue;
            item.graphicControlMenu = [section childElementByName:@"graphic_control_menu"].leafvalue;

            if ([item.dataRel isEqualToString:@"handrail_type"] ||
                [item.dataRel isEqualToString:@"wall_material_optional"]) {
                CCThumb * thumb = [CCThumb new];
                [thumb setFileName:NONE_THUMB];
                thumb.setting.filePath = [NSString stringWithFormat:@"%@%@/%@", MENU_THUMB_IMG_URL, item.folder, NONE_THUMB];
                thumb.isAvailable = NO;
                thumb.isSelected = YES;
//                thumb.parent = item;
                [item.thumbs addObject:thumb];
            }
            
            TreeNode * thumbTag = [section childElementByName:@"thumbs"];
//            TreeNode * firstThumbItem = [thumbTag.children firstObject];
            NSArray * allThumbItems = thumbTag.children; // items
            
            for (TreeNode * thumbItem in allThumbItems) {
                NSString * value = thumbItem.attributes[@"value"];
                if ([value isEqualToString:STR_SEPARATOR]) {
                    // add separator to item.separators
                    TreeNode * nameTag = [thumbItem.children firstObject];
                    CCSeparator * separator = [CCSeparator separatorWithName:nameTag.leafvalue parent:item];
                    
                    [item.separators addObject:separator];
                } else {
                    CCThumb * thumb = [CCThumb new];
                    thumb.parent = item;
                    NSString * thumbName = [thumbItem childElementByName:@"name"].leafvalue;
                    thumb.setting.name = thumbName;
                    [thumb setFileName:[thumbItem childElementByName:@"file"].leafvalue];
                    thumb.setting.desc = [thumbItem childElementByName:@"description"].leafvalue;
                    thumb.setting.description_ss = [thumbItem childElementByName:@"description_ss"].leafvalue;
                    thumb.setting.description_brass = [thumbItem childElementByName:@"description_brass"].leafvalue;
                    
                    NSString * show = thumbItem.attributes[@"show"];
                    thumb.isShown = ![show isEqualToString:@"0"];
                    
                    BOOL exception = false;
                    thumb.attritubes[@"data-floor"] = thumbItem.attributes[@"floor"];
                    thumb.attritubes[@"data-floor-d"] = thumbItem.attributes[@"floor-d"];
                    thumb.attritubes[@"data-opening"] = thumbItem.attributes[@"opening"];
                    
                    NSString *sideWall = thumbItem.attributes[@"side-wall"];
                    if (sideWall) {
                        thumb.attritubes[@"data-side-wall"] = sideWall;
                        if (sideWall.length > 0) {
                            exception = YES;
                        }
                    }
                    
                    
                    NSString *wallMaterial = thumbItem.attributes[@"wall-material"];
                    if (wallMaterial) {
                        thumb.attritubes[@"data-wall-material"] = wallMaterial;
                        if (wallMaterial.length > 0) {
                            exception = YES;
                        }
                    }
                    
                    thumb.attritubes[@"data-handrail-type"] = thumbItem.attributes[@"handrail-type"];
                    
                    NSString *cabMaterial = thumbItem.attributes[@"cab-material"];
                    if (cabMaterial) {
                        thumb.attritubes[@"data-cab-material"] = cabMaterial;
                        if (cabMaterial.length > 0) {
                            exception = YES;
                        }
                    }
                    
                    NSString *bumperRail = thumbItem.attributes[@"bumper-rail"];
                    if (bumperRail) {
                        thumb.attritubes[@"data-bumper-rail"] = bumperRail;
                        if (bumperRail.length > 0) {
                            exception = YES;
                        }
                    }
                    
                    thumb.attritubes[@"data-default-side-wall"] = thumbItem.attributes[@"default-side-wall"];
                    thumb.attritubes[@"data-default-wall-material"] = thumbItem.attributes[@"default-wall-material"];
                    thumb.attritubes[@"data-default-cab-material"] = thumbItem.attributes[@"default-cab-material"];
                    
                    thumb.attritubes[@"data-reflections"] = thumbItem.attributes[@"reflections"];
                    thumb.attritubes[@"data-individuals"] = thumbItem.attributes[@"individuals"];
                    thumb.attritubes[@"data-ref-individuals"] = thumbItem.attributes[@"ref-individuals"];
                    thumb.attritubes[@"data-mirrors"] = thumbItem.attributes[@"mirrors"];
                    thumb.attritubes[@"data-bh-wall-start"] = thumbItem.attributes[@"bh_wall_start"];
                    thumb.attritubes[@"data-graphic-layout"] = thumbItem.attributes[@"graphic_layout"];
                    
                    thumb.attritubes[@"data-ecr"] = thumbItem.attributes[@"ecr"];
                    thumb.attritubes[@"data-brass"] = thumbItem.attributes[@"brass"];
                    thumb.attritubes[@"data-reflection"] = thumbItem.attributes[@"reflection"];
                    thumb.attritubes[@"data-val"] = thumbItem.attributes[@"value"];

                    thumb.attritubes[@"data-prefix"] = thumbItem.attributes[@"prefix"];
                    thumb.attritubes[@"data-refval"] = thumbItem.attributes[@"refval"];
                    thumb.attritubes[@"data-tsimage"] = thumbItem.attributes[@"tsimage"];
                    
                    thumb.attritubes[@"data-main-egress"] = thumbItem.attributes[@"main-egress"];
                    
                    
                    if(exception){
                        thumb.attritubes[@"data-exceptions"] = @"1";
                    }
                                        
                    //thumb.setFilePath(GlobalConstants.MENU_THUMB_IMG_URL + item.getFolder() + "/" +thumb.getFileName());
                    
                    if(item.separators.count > 0){
                        thumb.separator = item.separators.lastObject;
                    }
                    
                    [item.thumbs addObject:thumb];
                }
            }
            
            if ([item.sub isEqualToString:@"1"]) {
                CCMenuItem * parent = [CCMenuItem menuItemInMenuItems:_menuItems withFolder:item.folder];
                if (parent == nil) {
                    parent = [CCMenuItem new];
                    if ([item.folder isEqualToString:@"wall_material"]) {
                        parent.title = @"Material Finishes";
                    }else if ([item.folder isEqualToString:@"handrail_type"]){
                        parent.title = @"Handrail";
                    }else if ([item.folder isEqualToString:@"cop_location"]) {
                        parent.title = @"COP Location";
                    }else if ([item.folder isEqualToString:@"position_indicator"]) {
                        parent.title = @"Position Indicator";
                    }else if ([item.folder isEqualToString:@"cop_interface"]) {
                        parent.title = @"COP Interface";
                    }else if ([item.folder isEqualToString:@"pushbutton"]) {
                        parent.title = @"Pushbutton";
                    }else if ([item.folder isEqualToString:@"hall_style"]) {
                        parent.title = @"Hall Station Style";
                    }else if ([item.folder isEqualToString:@"hall_options"]) {
                        parent.title = @"Hall Station Options";
                    }else if ([item.folder isEqualToString:@"hall_lantern_style"]) {
                        parent.title = @"Lantern Style";
                    }else if ([item.folder isEqualToString:@"hall_lantern_options"]) {
                        parent.title = @"Lantern Options";
                    }
                    
                    parent.folder = item.folder;
                    [_menuItems addObject:parent];
                }
                item.parent = parent;
                [parent.subMenuItems addObject:item];
            } else {
                [_menuItems addObject:item];
            }
            
        }
    }
    
    if (_menuFrontItems != nil) {
        [_menuFrontItems removeAllObjects];
        _menuFrontItems = nil;
    }
    _menuFrontItems = [NSMutableArray new];

    // Quick start
    [_menuFrontItems addObject:_menuItems[0]];
    
    // door opening type
    [_menuFrontItems addObject:_menuItems[3]];
    
    // material finishes
    CCMenuItem * item = _menuItems[5];
    [_menuFrontItems addObject:item.subMenuItems[0]];
    
    // Last 6 menu items are Hall menus
    for (int i = 9; i < _menuItems.count - 6; i++){
        [_menuFrontItems addObject:_menuItems[i]];
    }
    
    if (_menuBackItems != nil) {
        [_menuBackItems removeAllObjects];
        _menuBackItems = nil;
    }
    _menuBackItems = [NSMutableArray new];
        
    if (_menuEditPanelItems != nil) {
        [_menuEditPanelItems removeAllObjects];
        _menuEditPanelItems = nil;
    }
    _menuEditPanelItems = [NSMutableArray new];
    
    for (int i = 0; i < 9; i++){
        if (i == 5){
        // if Material Finishes Menu
        // We remove edit panel last 3 menus, that ID starting with CW prefix
            CCMenuItem * menuEditItem = [CCMenuItem new];
            menuEditItem.folder = @"wall_material";
            menuEditItem.dataRel = @"wall_material";
            if (menuEditItem.subMenuItems != nil){
                [menuEditItem.subMenuItems removeAllObjects];
                menuEditItem.subMenuItems = nil;
            }
            menuEditItem.subMenuItems = [NSMutableArray new];
            
            CCMenuItem * menuItem = _menuItems[i];
            for (CCMenuItem * subMenuItem in menuItem.subMenuItems){
                if ([subMenuItem.ID hasPrefix:@"CW"]){
                    [menuEditItem.subMenuItems addObject:subMenuItem];
                }
                if ([subMenuItem.ID isEqualToString:@"CWGM"]){
                    _wallGlassEditItem = subMenuItem;
                }
                if ([subMenuItem.ID isEqualToString:@"CWM"]){
                    _wallMaterialEditItem = subMenuItem;
                }
                if ([subMenuItem.ID isEqualToString:@"CWMT"]){
                    _wallMetalEditItem = subMenuItem;
                }
            }
            [menuItem.subMenuItems removeObjectsInArray:menuEditItem.subMenuItems];
            
            [_menuEditPanelItems addObject:menuEditItem];
        }
        [_menuBackItems addObject:_menuItems[i]];
    }
    
    if (_menuHallItems != nil) {
        [_menuHallItems removeAllObjects];
        _menuHallItems = nil;
    }
    _menuHallItems = [NSMutableArray new];
    
    for (int i = 0; i < _menuItems.count; i++){
        CCMenuItem *menuItem = _menuItems[i];
        if ([menuItem.folder hasPrefix:@"hall_"]){
            [_menuHallItems addObject:menuItem];
        }
    }
}

- (void) loadPreModels {
    if (_popularLayouts != nil) {
        [_popularLayouts removeAllObjects];
        _popularLayouts = nil;
    }
    _popularLayouts = [[NSMutableArray alloc] init];
    
    NSURL *purl = [NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"predefined" ofType:@"xml"]];

    TreeNode * root = [[XMLParser sharedInstance] parseXMLFile:purl];
    for (TreeNode * child in root.children) {
        if (![child.key isEqualToString:@"image"]) {
            continue;
        }
        
        CabConfig * config = [[CabConfig alloc] init];
        config.dataRel = child.attributes[@"data-rel"];
        config.dataTitle = child.attributes[@"data-title"];
        config.dataPreview = child.attributes[@"data-preview"];
        NSArray * nodes = child.children;

        NSMutableDictionary * items = [[NSMutableDictionary alloc] init];

        for (TreeNode * node in nodes) {
            if (node.key != nil && node.leafvalue != nil) {
                [items setObject:node.leafvalue forKey:node.key];
            }
        }
        config.items = items;
        [_popularLayouts addObject:config];
    }
}

- (CabConfig * ) popularLayoutWithDataRel:(NSString*) dataRel {
    for (CabConfig * config in _popularLayouts) {
        if ([config.dataRel isEqualToString:dataRel]) {
            return config;
        }
    }
    return nil;
}

@end
