//
//  CDConfig+CoreDataClass.h
//  MadCabConfigurator
//
//  Created by Alex on 2/16/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface CDConfig : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "CDConfig+CoreDataProperties.h"
