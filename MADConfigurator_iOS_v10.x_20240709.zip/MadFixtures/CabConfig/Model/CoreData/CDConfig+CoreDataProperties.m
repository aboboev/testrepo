//
//  CDConfig+CoreDataProperties.m
//  MadCabConfigurator
//
//  Created by Alex on 2/16/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import "CDConfig+CoreDataProperties.h"

@implementation CDConfig (CoreDataProperties)

+ (NSFetchRequest<CDConfig *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"CDConfig"];
}

@dynamic projectName;
@dynamic customerName;
@dynamic items;
@dynamic configDate;
@dynamic panels;

@end
