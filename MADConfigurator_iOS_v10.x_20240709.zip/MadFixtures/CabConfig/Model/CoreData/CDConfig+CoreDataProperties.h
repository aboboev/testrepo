//
//  CDConfig+CoreDataProperties.h
//  MadCabConfigurator
//
//  Created by Alex on 2/16/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import "CDConfig+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface CDConfig (CoreDataProperties)

+ (NSFetchRequest<CDConfig *> *)fetchRequest;

@property (nullable, nonatomic, copy) NSString *projectName;
@property (nullable, nonatomic, copy) NSString *customerName;
@property (nullable, nonatomic, copy) NSString *items;
@property (nullable, nonatomic, copy) NSDate *configDate;
@property (nullable, nonatomic, copy) NSString *panels;

@end

NS_ASSUME_NONNULL_END
