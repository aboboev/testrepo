//
//  CDConfig+CoreDataClass.m
//  MadCabConfigurator
//
//  Created by Alex on 2/16/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import "CDConfig+CoreDataClass.h"

@implementation CDConfig

@end
