//
//  CCLayer.m
//  MadCabConfigurator
//
//  Created by Alex on 2/24/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import "CCLayer.h"

@implementation CCLayer

- (instancetype) init {
    self = [super init];
    self.zOrder = -1;
    self.imageNames = [NSMutableArray new];
    self.attachedGraphics = [NSMutableArray new];
    return self;
}

- (void) clearLayer {
    self.zOrder = -1;
    [self.imageNames removeAllObjects];
    [self.attachedGraphics removeAllObjects];
}

- (void) addImageName:(NSString*) imageName {
    if (![self.imageNames containsObject:imageName]) {
        [self.imageNames addObject:imageName];
    }
}

- (void) attachGraphic:(NSString *) fileName graphicSize:(NSString *)graphicSize horizontalAlignment:(NSString *)horizontalAlignment verticalAlignment:(NSString *)verticalAlignment points:(NSMutableArray<CCPoint *> *)points {
    for (CCAttachedGraphic *attachedGraphic in self.attachedGraphics) {
        if ([attachedGraphic.fileName isEqualToString:fileName]) {
            return;
        }
    }
    
    CCAttachedGraphic *attachedGraphic = [[CCAttachedGraphic alloc] init];
    attachedGraphic.fileName = fileName;
    attachedGraphic.graphicSize = graphicSize;
    attachedGraphic.horizontalAlignment = horizontalAlignment;
    attachedGraphic.verticalAlignment = verticalAlignment;
    attachedGraphic.points = points;
    
    [self.attachedGraphics addObject:attachedGraphic];
}

@end
