//
//  CCLayer.h
//  MadCabConfigurator
//
//  Created by Alex on 2/24/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CCAttachedGraphic.h"

@interface CCLayer : NSObject
{
    
}

@property (nonatomic, assign) NSInteger zOrder;
@property (nonatomic, strong) NSMutableArray<NSString*>* imageNames;
@property (nonatomic, strong) NSMutableArray<CCAttachedGraphic*>* attachedGraphics;

- (void) clearLayer;
- (void) addImageName:(NSString*) imageName;
- (void) attachGraphic:(NSString *) fileName graphicSize:(NSString *)graphicSize horizontalAlignment:(NSString *)horizontalAlignment verticalAlignment:(NSString *)verticalAlignment points:(NSMutableArray<CCPoint*>*) points;

@end
