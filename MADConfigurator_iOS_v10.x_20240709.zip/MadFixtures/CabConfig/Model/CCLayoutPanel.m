//
//  CCLayoutPanel.m
//  MadFixtures
//
//  Created by Alex on 2/2/24.
//  Copyright © 2024 Mad Elevator. All rights reserved.
//

#import "CCLayoutPanel.h"
#import "Constants.h"

@implementation CCLayoutPanel

- (instancetype) init {
    self = [super init];
    
    self.type = @"";
    self.index = -1;
    self.points = [NSMutableArray new];
    self.visible = NO;
    self.filled = NO;
    self.material = @"";
    self.materialDescription = @"";
    self.belowHandrail = NO;
    self.locked = NO;
    self.graphicImage = @"";
    self.graphicWidth = 0;
    self.graphicHeight = 0;
    self.graphicSize = @"";
    self.graphicHoriAlign = @"";
    self.graphicVertAlign = @"";
    self.graphicLayout = @"";
    
    return self;
}

- (id)initWithDictionary:(NSDictionary *)dictionary {
    self = [self init];
    
    self.type = [dictionary objectForKey:@"type"];
    self.index = [[dictionary objectForKey:@"index"] integerValue];
    
    self.points = [NSMutableArray array];
    NSArray *points = [dictionary objectForKey:@"points"];
    if (points != nil) {
        for (NSDictionary *pointDictionary in points) {
            [self.points addObject:[[CCPoint alloc] initWithDictionary:pointDictionary]];
        }
    }
    
    self.visible = NO;
    self.filled = NO;
    self.material = [dictionary objectForKey:@"material"];
    self.materialDescription = [dictionary objectForKey:@"materialDescription"];
    self.belowHandrail = [[dictionary objectForKey:@"belowHandrail"] boolValue];
    self.locked = [[dictionary objectForKey:@"locked"] boolValue];
    self.graphicImage = [dictionary objectForKey:@"graphicImage"];
    self.graphicWidth = [[dictionary objectForKey:@"graphicWidth"] integerValue];
    self.graphicHeight = [[dictionary objectForKey:@"graphicHeight"] integerValue];
    self.graphicSize = [dictionary objectForKey:@"graphicSize"];
    self.graphicHoriAlign = [dictionary objectForKey:@"graphicHoriAlign"];
    self.graphicVertAlign = [dictionary objectForKey:@"graphicVertAlign"];
    self.graphicLayout = [dictionary objectForKey:@"graphicLayout"];
    
    return self;
}

-(NSDictionary *)dictionary {
    return [NSDictionary dictionaryWithObjectsAndKeys:self.type, @"type", @(self.index), @"index", [CCPoint dictionaryArrayWithPoints:self.points], @"points", @(self.visible), @"visible", @(self.filled), @"filled", self.material, @"material", self.materialDescription, @"materialDescription", @(self.belowHandrail), @"belowHandrail", @(self.locked), @"locked", self.graphicImage, @"graphicImage", @(self.graphicWidth), @"graphicWidth", @(self.graphicHeight), @"graphicHeight", self.graphicSize, @"graphicSize", self.graphicHoriAlign, @"graphicHoriAlign", self.graphicVertAlign, @"graphicVertAlign", self.graphicLayout, @"graphicLayout", nil];
}

@end
