//
//  CCRequestData.h
//  MadCabConfigurator
//
//  Created by Alex on 2/17/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface CCRequestData : NSObject
{
    
}

@property (nonatomic, strong) NSString * projName;
@property (nonatomic, strong) NSString * email;
@property (nonatomic, strong) NSDate * issuedDate;

@property (nonatomic, strong) NSMutableArray * settings;

@property (nonatomic, strong) UIImage * frontImage;
@property (nonatomic, strong) UIImage * backImage;
@property (nonatomic, strong) UIImage * hallMainImage;
@property (nonatomic, strong) UIImage * hallTypicalImage;

@property (nonatomic, strong) NSString * name;
@property (nonatomic, strong) NSString * company;
@property (nonatomic, strong) NSString * phone;
@property (nonatomic, strong) NSString * address;
@property (nonatomic, strong) NSString * width;
@property (nonatomic, strong) NSString * depth;
@property (nonatomic, strong) NSString * height;
@property (nonatomic, strong) NSString * controller;
@property (nonatomic, strong) NSString * controllerType;
@property (nonatomic, strong) NSString * capacity;
@property (nonatomic, strong) NSString * numOfElevs;
@property (nonatomic, strong) NSString * numOfRisers;
@property (nonatomic, strong) NSString * numOfOpenings;
@property (nonatomic, strong) NSString * notes;
@property (nonatomic, strong) NSString * providerQuoteFor;

@property (nonatomic, assign) BOOL isPDFCabInterior;
@property (nonatomic, assign) BOOL isPDFCOP;
@property (nonatomic, assign) BOOL isPDFHallFixtures;

@end
