//
//  CCSeparator.m
//  MadCabConfigurator
//
//  Created by Alex on 1/14/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import "CCSeparator.h"

@implementation CCSeparator

+ (instancetype) separatorWithName: (NSString*) name parent:(CCMenuItem*) parent {
    CCSeparator * s = [CCSeparator new];
    s.parent = parent;
    s.title = name;
    s.drop = @"1";
    return s;
}

- (BOOL) equals: (CCSeparator *) other {
    if(self.title == nil || other == nil){
        return false;
    }
    return [self.title isEqualToString:other.title];
}

@end
