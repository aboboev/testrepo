//
//  CCAttachedGraphic.m
//  MadFixtures
//
//  Created by Alex on 3/13/24.
//  Copyright © 2024 Mad Elevator. All rights reserved.
//

#import "CCAttachedGraphic.h"

@implementation CCAttachedGraphic

- (CGRect)bounds {
    return [CCAttachedGraphic bounds:self.points];
}

+ (CGRect)bounds:(NSMutableArray<CCPoint*>*) points {
    if (points == nil || points.count == 0) return CGRectZero;
    
    CGRect result = CGRectMake(points[0].x, points[0].y, 0, 0);
    for (CCPoint* point in points) {
        if (point.x < result.origin.x) {
            result.size.width += result.origin.x - point.x;
            result.origin.x = point.x;
        } else if (point.x > result.origin.x + result.size.width) {
            result.size.width = point.x - result.origin.x;
        }
        if (point.y < result.origin.y) {
            result.size.height += result.origin.y - point.y;
            result.origin.y = point.y;
        } else if (point.y > result.origin.y + result.size.height) {
            result.size.height = point.y - result.origin.y;
        }
    }
    return CGRectMake(result.origin.x / 2, result.origin.y / 2, result.size.width / 2, result.size.height / 2);
}

@end
