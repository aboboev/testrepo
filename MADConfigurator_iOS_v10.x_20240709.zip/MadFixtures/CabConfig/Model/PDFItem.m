//
//  PDFItem.m
//  MadFixtures
//
//  Created by Alex on 12/24/20.
//  Copyright © 2020 Mad Elevator. All rights reserved.
//

#import "PDFItem.h"

@implementation PDFItem

- (instancetype) init {
    self = [super init];
    self.number = 0;
    self.title = @"";
    self.image1 = @"";
    self.image2 = @"";
    self.content = @"";
    return self;
}

@end

