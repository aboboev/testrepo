//
//  CCMenuItem.m
//  MadCabConfigurator
//
//  Created by Alex on 1/14/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import "CCMenuItem.h"
#import "CCThumb.h"
#import "CCSeparator.h"
#import "NSDictionary+Extra.h"
#import "Constants.h"
#import "Utils.h"

@implementation CCMenuItem

- (instancetype) init {
    self = [super init];
    
    if (self != nil){
        self.thumbs = [NSMutableArray new];
        self.separators = [NSMutableArray new];
        self.subMenuItems = [NSMutableArray new];
        self.isShown = YES;
    }
    
    return self;
}

- (BOOL) hasSubMenuItems {
    return _subMenuItems.count;
}

- (BOOL) hasSeparators {
    return _separators.count;
}

+ (CCMenuItem *) menuItemInMenuItems: (NSArray *) items withFolder:(NSString *) folder {
    CCMenuItem * found = nil;
    for (CCMenuItem * i in items) {
        if ([i.folder isEqualToString:folder]) {
            found = i;
            break;
        }
    }
    
    return found;
}

+ (CCMenuItem *) menuItemInMenuItems:(NSArray *)items withID:(NSString *)ID {
    if ([ID isEqualToString:@"accessories"]){
        ID = @"accessory";
    }
    
    for (CCMenuItem * i in items) {
        if ([i.dataRel isEqualToString:ID]) {
            return i;
        }
        for (CCMenuItem * s in i.subMenuItems) {
            if ([s.dataRel isEqualToString:ID]) {
                return s;
            }
        }
    }
    
    return nil;
}

- (NSArray<CCThumb *>*) thumbsByIDsArray:(NSString *)IDs{
    NSMutableArray * thumbsArray = [[NSMutableArray alloc] init];
    if ([IDs isEqualToString:@""]){
        return thumbsArray;
    }
    NSArray * ary = [IDs componentsSeparatedByString:@","];
    
    NSString * firstVal = ary[0];
    for (CCThumb * thumb in self.thumbs) {
        if (firstVal.length == 1){
            if (![[thumb.attritubes stringValueForKey:@"data-prefix"] isEqualToString:@"AR"] &&
                [Utils containsString:[thumb.attritubes stringValueForKey:@"data-val"] inArray:ary]){
                [thumbsArray addObject:thumb];
            }
        }else{
            NSString * str = [NSString stringWithFormat:@"%@%@", [thumb.attritubes stringValueForKey:@"data-prefix"], [thumb.attritubes stringValueForKey:@"data-val"]];
            if ([Utils containsString:str inArray:ary]){
                [thumbsArray addObject:thumb];
            }
        }
    }
    
    return thumbsArray;
}

- (NSMutableArray*)visibleThumbs:(CCSeparator*) separator {
    NSMutableArray * result = [[NSMutableArray alloc] init];
    for (CCThumb * thumb in self.thumbs) {
        if (thumb.isShown && (thumb.separator == nil || [thumb.separator equals:separator])) {
            [result addObject:thumb];
        }
    }
    return result;
}

- (NSMutableArray*)visibleThumbsIncludingSubitems {
    NSMutableArray * result = [[NSMutableArray alloc] init];
    for (CCThumb * thumb in self.thumbs) {
        if (thumb.isShown) {
            [result addObject:thumb];
        }
    }
    
    for (CCMenuItem * subItem in self.subMenuItems) {
        for (CCThumb * thumb in subItem.thumbs) {
            if (thumb.isShown) {
                [result addObject:thumb];
            }
        }
    }
    
    return result;
}

- (CCThumb*) selectedThumb {
    
    for (CCThumb * thumb in self.thumbs) {
        if (thumb.isSelected && thumb.isAvailable) {
            return thumb;
        }
    }
    
    return nil;
}

- (CCThumb*) unavailableThumb {
    
    for (CCThumb * thumb in self.thumbs) {
        if (!thumb.isAvailable && thumb.isShown) {
            return thumb;
        }
    }
    
    return nil;
}

- (NSArray<CCThumb *>*) selectedThumbs{
    NSMutableArray * thmbs = [[NSMutableArray alloc] init];
    
    for (CCThumb * thumb in self.thumbs) {
        if (thumb.isSelected && thumb.isAvailable) {
            [thmbs addObject:thumb];
        }
    }
    
    return thmbs;
}

- (CCThumb*) selectedThumbByAttr {
    
    for (CCThumb * thumb in self.thumbs) {
        if (thumb.isSelected && thumb.isAvailable) {
            return thumb;
        }
    }
    
    return nil;
}

- (void) deselectAllThumbs {
    for (CCThumb * thumb in _thumbs) {
        if ([thumb.imageName isEqualToString:NONE_THUMB]) {
            thumb.isSelected = YES;
        } else {
            thumb.isSelected = NO;
        }
    }
}

- (void) showAllThumbs:(BOOL) shown {
    for (CCThumb * thumb in _thumbs) {
        if (shown && thumb.isAvailable) {
            thumb.isShown = YES;
        } else {
            thumb.isShown = NO;
        }
    }
}

-(void) showAllUnavailableThumbs:(BOOL) shown{
    for (CCThumb * thumb in _thumbs) {
        if (!thumb.isAvailable) {
            thumb.isShown = shown;
        }
    }
}

- (NSInteger) unavailableThumbsCount {
    NSInteger count = 0;
    for (CCThumb * thumb in _thumbs) {
        if (!thumb.isAvailable) {
            count++;
        }
    }
    return count;
}

- (CCThumb * ) thumbByFileName:(NSString *) filename {
    for (CCThumb * thumb in _thumbs) {
        if ([thumb.imageName isEqualToString:filename]) {
            return thumb;
        }
    }
    return nil;
}

- (CCThumb *) selectedThumbByAttr:(NSString *)key value:(NSString *)value key:(BOOL)keyFlag flag:(BOOL)selectedFlag {
    for (CCThumb * thumb in _thumbs) {
        if ([[thumb.attritubes stringValueForKey:key] isEqualToString:value] == keyFlag && thumb.isSelected == selectedFlag) {
            return thumb;
        }
    }
    return nil;
}

- (NSArray<CCThumb *>*) thumbsByAttrKey:(NSString *) key value:(NSString *) value {
    NSMutableArray * result = [NSMutableArray new];
    for (CCThumb * thumb in _thumbs) {
        if ([[thumb.attritubes stringValueForKey:key] isEqualToString:value]) {
            [result addObject:thumb];
        }
    }
    
    return result;
}

- (CCThumb *) thumbByAttrKey:(NSString *) key value:(NSString *) value {
    //NSMutableArray * result = [NSMutableArray new];
    for (CCThumb * thumb in _thumbs) {
        if ([[thumb.attritubes stringValueForKey:key] isEqualToString:value]) {
            return thumb;
        }
    }
    
    return nil;
}

- (NSArray<CCThumb *>*) thumbsByAttrKeysAndValues:(NSArray *) keysAndValues {
    if (keysAndValues.count < 2 || keysAndValues.count % 2 != 0) {
        return [NSArray new];
    }
    NSMutableArray * list = [NSMutableArray new];
    for (CCThumb * thumb in _thumbs) {
        BOOL flag = YES;
        for (int i = 0; i < keysAndValues.count; i += 2) {
            if (![[thumb.attritubes stringValueForKey:keysAndValues[i]] isEqualToString:keysAndValues[i+1]]) {
                flag = NO;
            }
        }
        if (flag) {
            [list addObject:thumb];
        }
    }
    
    return list;
}

- (void) thumbsByAttrKeysAndValuesAndSelect:(NSInteger) selectNum isSelect:(BOOL) isSelect keysAndValues:(NSArray *)keysAndValues{
    if (keysAndValues.count < 2 || keysAndValues.count % 2 != 0) {
        return;
    }
    NSMutableArray * list = [NSMutableArray new];
    for (CCThumb * thumb in _thumbs) {
        BOOL flag = YES;
        for (int i = 0; i < keysAndValues.count; i += 2) {
            if (![[thumb.attritubes stringValueForKey:keysAndValues[i]] isEqualToString:keysAndValues[i+1]]) {
                flag = NO;
            }
        }
        if (flag) {
            [list addObject:thumb];
        }
    }
    
    if (list.count > 0){
        ((CCThumb *)[list objectAtIndex:selectNum]).isSelected = isSelect;
    }
}

- (void) setVisibleByAttr:(NSString *) key value:(NSString * ) value shown:(BOOL)shown flag:(BOOL) flag {
    for (CCThumb * thumb in _thumbs) {
        if ([[thumb.attritubes stringValueForKey:key] isEqualToString:value] == flag) {
            thumb.isShown = shown;
        }
    }
}

- (void) setVisibleByAttr:(NSString *) key value:(NSString * ) value shown:(BOOL)shown flag:(BOOL) flag key1:(NSString * ) key1 containVal:(NSString *)containVal containFlag:(BOOL)containFlag{
    for (CCThumb * thumb in _thumbs) {
        if ([[thumb.attritubes stringValueForKey:key] isEqualToString:value] == flag && [[thumb.attritubes stringValueForKey:key1] containsString:containVal] == containFlag) {
            thumb.isShown = shown;
        }
    }
}

- (void) setVisibleByAttrAndClass:(NSString *) key value:(NSString * ) value class:(NSString*) className shown:(BOOL)shown {
    for (CCThumb * thumb in _thumbs) {
        if ([[thumb.attritubes stringValueForKey:key] isEqualToString:value] && [thumb hasClass:className]) {
            thumb.isShown = shown;
        }
    }
}

+ (void) showThumbsByAttr:(NSArray *) menuItems key:(NSString *) key value:(NSString * ) value shown:(BOOL)shown {
    for (CCMenuItem * item in menuItems) {
        [item setVisibleByAttr:key value:value shown:shown flag:YES];
        for (CCMenuItem * subItem in item.subMenuItems) {
            [subItem setVisibleByAttr:key value:value shown:shown flag:YES];
        }
    }
}

+ (void) showThumbsByClassAndAttr:(NSArray *) menuItems key:(NSString *) key value:(NSString * ) value class:(NSString*) className shown:(BOOL)shown {
    
    for (CCMenuItem * item in menuItems) {
        [item setVisibleByAttrAndClass:key value:value class:className shown:shown];
        
        for (CCMenuItem * subItem in item.subMenuItems) {
            [subItem setVisibleByAttrAndClass:key value:value class:className shown:shown];
        }
    }
}

- (NSArray*) thumbsByClasses:(NSArray*) classNames {
    NSInteger count = classNames.count;
    if (count == 0) return [NSArray new];
    
    NSMutableArray * list = [NSMutableArray new];
    
    for (CCThumb * thumb in self.thumbs) {
        BOOL flag = NO;
        for (NSString * string in classNames) {
            if ([thumb hasClass:string]) {
                flag = YES;
                break;
            }
        }
        
        if (flag) {
            [list addObject:thumb];
        }
    }
    
    return list;
}

@end
