//
//  CCLayoutPanel.h
//  MadFixtures
//
//  Created by Alex on 2/2/24.
//  Copyright © 2024 Mad Elevator. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CCPoint.h"

@interface CCLayoutPanel : NSObject
{
    
}

@property (nonatomic, strong) NSString* type;
@property (nonatomic, assign) NSInteger index;
@property (nonatomic, strong) NSMutableArray<CCPoint*>* points;
@property (nonatomic, assign) BOOL visible;
@property (nonatomic, assign) BOOL filled;
@property (nonatomic, strong) NSString* material;
@property (nonatomic, strong) NSString* materialDescription;
@property (nonatomic, assign) BOOL belowHandrail;
@property (nonatomic, assign) BOOL locked;
@property (nonatomic, strong) NSString* graphicImage;
@property (nonatomic, assign) NSInteger graphicWidth;
@property (nonatomic, assign) NSInteger graphicHeight;
@property (nonatomic, strong) NSString* graphicSize;
@property (nonatomic, strong) NSString* graphicHoriAlign;
@property (nonatomic, strong) NSString* graphicVertAlign;
@property (nonatomic, strong) NSString* graphicLayout;

-(NSDictionary *)dictionary;
-(id)initWithDictionary:(NSDictionary *)dictionary;

@end
