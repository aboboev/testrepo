//
//  SharedData.h
//  MadCabConfigurator
//
//  Created by Alex on 1/7/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@class CabConfig;
@class CCMenuItem;
@interface SharedData : NSObject

// main components
@property (nonatomic, strong) NSMutableArray<CCMenuItem*>* menuItems;
@property (nonatomic, strong) NSMutableArray<CCMenuItem*>* menuFrontItems;
@property (nonatomic, strong) NSMutableArray<CCMenuItem*>* menuBackItems;
@property (nonatomic, strong) NSMutableArray<CCMenuItem*>* menuHallItems;
@property (nonatomic, strong) NSMutableArray<CCMenuItem*>* menuEditPanelItems;
@property (nonatomic, strong) CCMenuItem* wallMaterialEditItem;
@property (nonatomic, strong) CCMenuItem* wallMetalEditItem;
@property (nonatomic, strong) CCMenuItem* wallGlassEditItem;

// popular layouts
@property (nonatomic, strong) NSMutableArray<CabConfig*>* popularLayouts;

+ (instancetype) shared;
- (void) initialize;

//- (CabConfig * ) popularLayoutWithDataRel:(NSString*) dataRel;

@end
