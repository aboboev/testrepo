//
//  CCAttachedGraphic.h
//  MadFixtures
//
//  Created by Alex on 3/13/24.
//  Copyright © 2024 Mad Elevator. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CCPoint.h"

NS_ASSUME_NONNULL_BEGIN

@interface CCAttachedGraphic : NSObject

@property (nonatomic, strong) NSString* fileName;
@property (nonatomic, strong) NSString* graphicSize;
@property (nonatomic, strong) NSString* horizontalAlignment;
@property (nonatomic, strong) NSString* verticalAlignment;
@property (nonatomic, strong) NSMutableArray<CCPoint*>* points;

- (CGRect)bounds;
+ (CGRect)bounds:(NSMutableArray<CCPoint*>*) points;

@end

NS_ASSUME_NONNULL_END
