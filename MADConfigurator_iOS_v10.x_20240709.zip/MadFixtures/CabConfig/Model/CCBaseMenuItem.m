//
//  CCBaseMenuItem.m
//  MadCabConfigurator
//
//  Created by Alex on 1/15/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import "CCBaseMenuItem.h"

@implementation CCBaseMenuItem

@end
