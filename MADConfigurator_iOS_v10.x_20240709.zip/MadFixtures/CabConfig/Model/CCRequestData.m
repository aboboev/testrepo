//
//  CCRequestData.m
//  MadCabConfigurator
//
//  Created by Alex on 2/17/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import "CCRequestData.h"

@implementation CCRequestData

- (instancetype) init {
    self = [super init];
    self.settings = [NSMutableArray new];
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
