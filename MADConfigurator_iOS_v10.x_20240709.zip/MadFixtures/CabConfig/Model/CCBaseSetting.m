//
//  CCBaseSetting.m
//  MadCabConfigurator
//
//  Created by Alex on 1/15/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import "CCBaseSetting.h"

@implementation CCBaseSetting

- (NSString*) getDescFromMany:(BOOL)isSS {
    if (_desc.length > 0) {
        return _desc;
    }
    if (isSS) {
        return _description_ss;
    }
    
    return _description_brass;
}

@end
