//
//  CCThumb.h
//  MadCabConfigurator
//
//  Created by Alex on 1/14/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@class CCMenuItem;
@class CCBaseSetting;
@class CCSeparator;

@interface CCThumb : NSObject

@property (nonatomic, strong) NSMutableDictionary * attritubes;
@property (nonatomic, strong) NSMutableArray<NSString*> * classes;

@property (nonatomic) BOOL isSelected;
@property (nonatomic) BOOL isShown;
@property (nonatomic) BOOL isAvailable;
@property (nonatomic) BOOL isTSImage;

@property (nonatomic, strong) CCMenuItem * parent;
@property (nonatomic, strong, getter=getSetting) CCBaseSetting * setting;
@property (nonatomic, strong) CCSeparator * separator;

- (NSString*) name;
- (NSString*) imageName;

- (CCBaseSetting*) getSetting; // getter
- (void) setFileName:(NSString*) fileName;

- (void) removeClass:(NSString*) className;
- (BOOL) hasClass:(NSString * ) className;

// custom setters
- (void) setIsSelected:(BOOL)isSelected;

@end
