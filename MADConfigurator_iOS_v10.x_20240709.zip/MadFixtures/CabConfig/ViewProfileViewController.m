//
//  ViewProfileViewController.m
//  MadCabConfigurator
//
//  Created by Alex on 2/26/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import "ViewProfileViewController.h"
#import "CCInputScreenBottomBar.h"
#import "CCInputScreenTopBar.h"
#import "AppDelegate.h"
#import "Constants.h"

@interface ViewProfileViewController ()
{
    BOOL didAddBars;
}
@end

@implementation ViewProfileViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    didAddBars = NO;
    
    [self.tableView setKeyboardDismissMode:UIScrollViewKeyboardDismissModeOnDrag];
    [self setInputAccessoryViews];
    [self fillInputs];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    
    if (!didAddBars) {
        [self addHeaderAndFooter];
        didAddBars = YES;
    }
}

- (void) fillInputs {
    NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
    
    NSString * name = [defaults objectForKey:USER_NAME_KEY];
    if (name) {
        nameTextField.text = name;
    }
    NSString * email = [defaults objectForKey:USER_EMAIL_KEY];
    if (email) {
        emailTextField.text = email;
    }
    NSString * company = [defaults objectForKey:USER_COMPANY_KEY];
    if (company) {
        companyTextField.text = company;
    }
    NSString * phone = [defaults objectForKey:USER_PHONE_KEY];
    if (phone) {
        phoneTextField.text = phone;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) setInputAccessoryViews {
    CCInputScreenBottomBar* bottomBar = [CCInputScreenBottomBar view];
    [bottomBar setSubmitButtonTitle:@"Save"];

    nameTextField.inputAccessoryView = bottomBar;
    emailTextField.inputAccessoryView = bottomBar;
    companyTextField.inputAccessoryView = bottomBar;
    phoneTextField.inputAccessoryView = bottomBar;
    
    __weak ViewProfileViewController* wself = self;
    bottomBar.backBlock = ^(void) {
        [self.view endEditing:YES];
        [CCInputScreenBottomBar removeBottomBar];
        [CCInputScreenTopBar removeTopBar];

        [wself dismissViewControllerAnimated:YES completion:nil];
    };
    
    bottomBar.submitBlock = ^(void) {
        [wself submitAndRemove];
    };
}

- (void) addHeaderAndFooter {
    CCInputScreenBottomBar* bottomBar = [CCInputScreenBottomBar showOnView:[(AppDelegate*)[UIApplication sharedApplication].delegate window]];
    
    #pragma clang diagnostic ignored "-Wdeprecated-declarations"
    CGFloat topMargin = self.topLayoutGuide.length;
    CCInputScreenTopBar * topView = [CCInputScreenTopBar showOnView:[(AppDelegate*)[UIApplication sharedApplication].delegate window] topGuide:topMargin];
    [topView setTitle:@"VIEW PROFILE"];
    
    self.tableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
    self.tableView.contentInset = UIEdgeInsetsMake(0, 0, 0, 0);
    
    CGRect frame = self.tableView.frame;
    frame.origin.y += topMargin;
    frame.size.height -= topMargin;
    self.tableView.frame = frame;
    
    __weak ViewProfileViewController* wself = self;
    
    [bottomBar setSubmitButtonTitle:@"Save"];
    bottomBar.submitBlock = ^(void) {
        [wself submitAndRemove];
    };
    bottomBar.backBlock = ^(void) {
        [self.view endEditing:YES];
        [CCInputScreenBottomBar removeBottomBar];
        [CCInputScreenTopBar removeTopBar];
        [wself dismissViewControllerAnimated:YES completion:nil];
    };
}

- (void) submitAndRemove {
    NSString * name = nameTextField.text;
    NSString * email = emailTextField.text;
    NSString * company = companyTextField.text;
    NSString * phone = phoneTextField.text;
    
    UITextField * errorField = nil;
    NSString * error = nil;
    
    if (name.length == 0) {
        errorField = nameTextField;
        error = @"Please input your Name!";
    } else if (email.length == 0) {
        errorField = emailTextField;
        error = @"Please input your Email!";
    } else if (company.length == 0) {
        errorField = companyTextField;
        error = @"Please input your Company!";
    } else if (phone.length == 0) {
        errorField = phoneTextField;
        error = @"Please input your Phone!";
    }

    if (error && errorField) {
        UIAlertController *menu = [UIAlertController alertControllerWithTitle:nil message:error preferredStyle:UIAlertControllerStyleAlert];
        [menu addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
            [errorField becomeFirstResponder];
        }]];
        [self presentViewController:menu animated:YES completion:nil];
        return;
    }
    
    // save
    NSUserDefaults * store = [NSUserDefaults standardUserDefaults];
    [store setObject:name forKey:USER_NAME_KEY];
    [store setObject:email forKey:USER_EMAIL_KEY];
    [store setObject:company forKey:USER_COMPANY_KEY];
    [store setObject:phone forKey:USER_PHONE_KEY];
    [store synchronize];
    
    [CCInputScreenTopBar removeTopBar];
    [CCInputScreenBottomBar removeBottomBar];

    [self dismissViewControllerAnimated:YES completion:nil];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (BOOL)prefersStatusBarHidden{
    return YES;
}

#pragma mark ---- Orientation ----
- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskPortrait;
}

- (BOOL)shouldAutorotate {
    return NO;
}

@end
