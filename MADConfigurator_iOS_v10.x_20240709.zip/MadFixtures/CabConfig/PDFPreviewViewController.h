//
//  PDFPreviewViewController.h
//  MadCabConfigurator
//
//  Created by Alex on 2/16/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MessageUI/MFMailComposeViewController.h>

@class CCRequestData;
@interface PDFPreviewViewController : UIViewController <MFMailComposeViewControllerDelegate>
{
    IBOutlet UIScrollView * scrollView;
    
    IBOutlet UIView * frontContainer;
    IBOutlet UIView * backContainer;
    IBOutlet UIView * hallMainContainer;
    IBOutlet UIView * hallTypicalContainer;
    
    
    IBOutletCollection(UIButton) NSArray * buttons;
    
    IBOutlet UILabel * leftTitleLabel;
    IBOutlet UILabel * rightTitleLabel;
    IBOutlet UIView * topButtonsView;
    IBOutlet UIView * bottomBarView;
    
    IBOutlet UILabel * frontProjectLabel;
    IBOutlet UILabel * frontDateLabel;
    IBOutlet UILabel * backProjectLabel;
    IBOutlet UILabel * backDateLabel;
    IBOutlet UILabel * hallMainProjectLabel;
    IBOutlet UILabel * hallMainDateLabel;
    IBOutlet UILabel * hallTypicalProjectLabel;
    IBOutlet UILabel * hallTypicalDateLabel;
    
    IBOutlet UIImageView * frontImageView;
    IBOutlet UIImageView * backImageView;
    IBOutlet UIImageView * hallMainImageView;
    IBOutlet UIImageView * hallTypicalImageView;
    
    IBOutlet UIStackView * componentFrontStackView;
    IBOutlet UIStackView * componentBackStackView;
    IBOutlet UIStackView * componentHallMainStackView;
    IBOutlet UIStackView * componentHallTypicalStackView;
    
    IBOutlet UILabel * contactFrontLabel;
    IBOutlet UILabel * contactBackLabel;
    IBOutlet UILabel * contactHallMainLabel;
    IBOutlet UILabel * contactHallTypicalLabel;
    
    IBOutlet NSLayoutConstraint * scrollViewBottomConstraint;
    
    IBOutletCollection(UILabel) NSArray * infoLabels;
    IBOutletCollection(UILabel) NSArray * valueLabels;
    __weak IBOutlet UILabel *frontHeaderTitle;
    __weak IBOutlet UILabel *frontHeaderDesc;
    __weak IBOutlet UILabel *backHeaderTitle;
    __weak IBOutlet UILabel *backHeaderDesc;
    __weak IBOutlet UILabel *hallMainHeaderTitle;
    __weak IBOutlet UILabel *hallMainHeaderDesc;
    __weak IBOutlet UILabel *hallTypicalHeaderTitle;
    __weak IBOutlet UILabel *hallTypicalHeaderDesc;
}

@property (nonatomic, strong) CCRequestData * data;
@property (nonatomic, assign) BOOL fromRFQ;

- (IBAction)back:(id)sender;
- (IBAction)submit:(id)sender;

@end
