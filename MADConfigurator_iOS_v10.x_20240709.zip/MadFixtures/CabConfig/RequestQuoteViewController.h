//
//  RequestQuoteViewController.h
//  MadCabConfigurator
//
//  Created by Alex on 1/22/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MadFixtures-Swift.h"

@class CCRequestData;
@interface RequestQuoteViewController : UITableViewController <BEMCheckBoxDelegate>
{
    IBOutlet UITextField * nameTextField;
    IBOutlet UITextField * emailTextField;
    IBOutlet UITextField * companyTextField;
    IBOutlet UITextField * phoneTextField;
    IBOutlet UITextField * projectTextField;
    IBOutlet UITextField * addressTextField;
    IBOutlet UITextField * widthTextField;
    IBOutlet UITextField * heightTextField;
    IBOutlet UITextField * depthTextField;
    IBOutlet UITextField * capacityTextField;
    IBOutlet UITextField * elevatorNumTextField;
    IBOutlet UITextField * risersNumTextField;
    IBOutlet UITextField * openingsNumTextField;
    IBOutlet UITextField * controllerTextField;
    IBOutlet UITextField * controllerTypeTextField;
    IBOutlet UITextView * notesTextView;
    IBOutlet BEMCheckBox * chkCabInterior;
    IBOutlet BEMCheckBox * chkShell;
    IBOutlet BEMCheckBox * chkFixtures;
    IBOutlet BEMCheckBox * chkCOP;
}

@property (nonatomic, strong) NSString * projName;
@property (nonatomic, strong) NSString * customerName;
@property (nonatomic, strong) CCRequestData * requestData;

- (IBAction)onControllerTypeInput:(id)sender;
- (IBAction)onCapacityInput:(id)sender;

@end
