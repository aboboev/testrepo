//
//  SavedConfigsViewController.h
//  MadCabConfigurator
//
//  Created by Alex on 1/23/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SavedConfigsViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>
{
    IBOutlet UITableView * configsTableView;
    IBOutlet UILabel * sortLabel;
    IBOutlet UIButton * backButton;
    IBOutlet UIButton * newButton;
    IBOutlet UIButton * sortButton;
}

- (IBAction)back:(id)sender;
- (IBAction)newConfig:(id)sender;
- (IBAction)sort:(id)sender;

@end
