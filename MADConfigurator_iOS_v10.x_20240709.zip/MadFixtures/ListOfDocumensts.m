//
//  ListOfDocumensts.m
//  MadFixtures
//
//  Created by Antonio Pena on 12-03-19.
//  Copyright (c) 2012 Kioaxis. All rights reserved.
//

#import "ListOfDocumensts.h"
#import "DocDetail.h"
#import "DisplayDocument.h"

#define SectionHeaderHeight 40

@interface ListOfDocumensts ()

@end


@implementation ListOfDocumensts





- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}


- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if ([self tableView:tableView titleForHeaderInSection:section] != nil) {
        return SectionHeaderHeight;
    }
    else {
        // If no section header title, no section header needed
        return 0;
    }
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    NSString *sectionTitle = [self tableView:tableView titleForHeaderInSection:section];
    if (sectionTitle == nil) {
        return nil;
    }
    
    // Create label with section title
    UILabel *label = [[UILabel alloc] init];
    label.frame = CGRectMake(20, 6, 300, 30);
    label.backgroundColor = [UIColor clearColor];
    label.textColor = [UIColor whiteColor];
    label.shadowColor = [UIColor grayColor];
    label.shadowOffset = CGSizeMake(-1.0, 1.0);
    label.font = [UIFont boldSystemFontOfSize:22];
    label.text = sectionTitle;
    
    // Create header view and add label as a subview
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, SectionHeaderHeight)];
    
    [view addSubview:label];
    
    return view;
}


- (void)viewDidLoad
{
    [super viewDidLoad];

    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
 
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    
    
    
    //[self.tableView setBackgroundColor:[UIColor blackColor]];
    
    
    //self.tableView.opaque = NO;
    
    //self.tableView.backgroundColor=[UIColor blackColor];
    
    //UIImage *img = [UIImage imageNamed:@"documentlist.jpg"];
    //[self.tableView setBackgroundColor:[UIColor colorWithPatternImage:img]];
    
    
    self.tableView.backgroundColor = [UIColor clearColor];
    self.tableView.opaque = NO;
    self.tableView.backgroundView = nil;
   
    UIImage *img = [UIImage imageNamed:@"documentlist.jpg"];
    [self.tableView setBackgroundColor:[UIColor colorWithPatternImage:img]];
    
    
    // create the list;
    docs = [NSMutableArray array];

    brochures = [NSMutableArray array];    
    technical = [NSMutableArray array];
    
    
    DocDetail *doc = [[DocDetail alloc] init];
    
    doc.title =@"Select Project Brochure";
    doc.subtitle =@"Brochure";
    doc.filename =@"Select_Project_Brochure";
    
    [brochures addObject:doc];
    
    
    doc = [[DocDetail alloc] init];
    
    doc.title =@"Touch-To-Go Touchscreen";
    doc.subtitle =@"Brochure";
    doc.filename =@"TTG_Sales_Booklet";
    
    [brochures addObject:doc];
    
    
    doc = [[DocDetail alloc] init];
    
    doc.title =@"BS Series Pushbutton";
    doc.subtitle =@"Technical Documentation";
    doc.filename =@"BS_SERIES";
    
    [technical addObject:doc];
    
    
    doc = [[DocDetail alloc] init];
    
    doc.title =@"BP Series Pushbutton";
    doc.subtitle =@"Technical Documentation";
    doc.filename =@"BP_SERIES";
    
    [technical addObject:doc];
    
    
    doc = [[DocDetail alloc] init];
    
    doc.title =@"BL Series Pushbutton";
    doc.subtitle =@"Technical Documentation";
    doc.filename =@"BL_Series";
    
    [technical addObject:doc];
    
    
    doc = [[DocDetail alloc] init];
    
    doc.title =@"BD Series Pushbutton";
    doc.subtitle =@"Technical Documentation";
    doc.filename =@"BD_Series";
    
    [technical addObject:doc];
    
    
    doc = [[DocDetail alloc] init];
    
    doc.title =@"DUNE Series Pushbutton";
    doc.subtitle =@"Technical Documentation";
    doc.filename =@"DUNE_Series";
    
    [technical addObject:doc]; 

    
    doc = [[DocDetail alloc] init];
    
    doc.title =@"Colossus Pushbutton";
    doc.subtitle =@"Technical Documentation";
    doc.filename =@"Colossus_Series";
    
    [technical addObject:doc]; 
    
    
    doc = [[DocDetail alloc] init];
    
    doc.title =@"Marquee Digital Signage";
    doc.subtitle =@"Technical Documentation";
    doc.filename =@"MARQUEE";
    
    [technical addObject:doc]; 

    
    doc = [[DocDetail alloc] init];
    
    doc.title =@"Matisse 2-Way Video";
    doc.subtitle =@"Technical Documentation";
    doc.filename =@"MATISSE_2WC";
    
    [technical addObject:doc];
    
    
    doc = [[DocDetail alloc] init];
    
    doc.title =@"Touch-To-Go Panel Prep Guide";
    doc.subtitle =@"Technical Documentation";
    doc.filename =@"TTG_Panel_Preparation_Guide";
    
    [technical addObject:doc];
    
    
    [docs addObject:brochures];
    [docs addObject:technical];
    
}

- (BOOL)shouldAutorotate
{
    return YES;
}


- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender

{
    
    if ([[segue identifier] isEqualToString:@"DisplayTheDocument"]) {
        
        NSIndexPath *selectedRowIndex = [self.tableView indexPathForSelectedRow];
        NSArray *array = [docs objectAtIndex:selectedRowIndex.section];
        
        // Configure the cell...
        DocDetail *doc = [array objectAtIndex:selectedRowIndex.row];
        
        
        DisplayDocument *view = [segue destinationViewController];
        
        view.headingName = doc.title;
        view.fileName = doc.filename;
        view.modalPresentationStyle = UIModalPresentationFullScreen;
    }
}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
//#warning Potentially incomplete method implementation.
    // Return the number of sections.
    return [docs count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
//#warning Incomplete method implementation.
    // Return the number of rows in the section.
//    return [docs count];
    
    

        //Number of rows it should expect should be based on the section
        NSArray *array = [docs objectAtIndex:section];

        return [array count];
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    
    if(section == 0)
        return @"Brochures";
    else
        return @"Technical Documentation";
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"DocumentCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    
    NSArray *array = [docs objectAtIndex:indexPath.section];
    
     // Configure the cell...
    DocDetail *doc = [array objectAtIndex:indexPath.row];
    
    cell.textLabel.text = doc.title;//[documentList objectAtIndex:indexPath.row];
	cell.detailTextLabel.text = doc.subtitle;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;

    
    if(indexPath.row % 2 == 0)
    {
       // cell.backgroundColor = [UIColor grayColor];
        
        UIImage *img = [UIImage imageNamed:@"doclistred.png"];
        cell.backgroundColor  = [UIColor colorWithPatternImage:img];

    }
    else
    {
        //cell.backgroundColor = [UIColor darkGrayColor];
        
        UIImage *img = [UIImage imageNamed:@"doclistblue.png"];
        cell.backgroundColor  = [UIColor colorWithPatternImage:img];

        
    }
    
    cell.alpha = 0.2;
    
    return cell;
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Navigation logic may go here. Create and push another view controller.
    /*
     <#DetailViewController#> *detailViewController = [[<#DetailViewController#> alloc] initWithNibName:@"<#Nib name#>" bundle:nil];
     // ...
     // Pass the selected object to the new view controller.
     [self.navigationController pushViewController:detailViewController animated:YES];
     */
}


- (BOOL)prefersStatusBarHidden
{
    return YES;
}

@end
