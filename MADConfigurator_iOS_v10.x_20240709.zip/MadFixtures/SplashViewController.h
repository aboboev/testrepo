//
//  SplashViewController.h
//  MadFixtures
//
//  Created by Alex on 5/30/18.
//  Copyright © 2018 Mad Elevator. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SplashViewController : UIViewController

@end
