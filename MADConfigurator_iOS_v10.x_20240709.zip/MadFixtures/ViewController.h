//
//  ViewController.h
//  MadFixtures
//
//  Created by Antonio Pena on 12-01-14.
//  Copyright (c) 2012 Kioaxis. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (nonatomic, strong) IBOutletCollection(UIButton) NSArray *buttons;

@property (nonatomic, weak) IBOutlet UIView *helpView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *firstButtonHeightConstraint;

- (IBAction)goCabConfig:(id)sender;
- (IBAction)openHelp:(id)sender;
- (IBAction)closeHelp:(id)sender;

@end
