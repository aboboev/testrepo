//
//  CopViewController.h
//  MadFixtures
//
//  Created by Antonio Pena on 2014-04-23.
//  Copyright (c) 2014 Kioaxis. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "V8HorizontalPickerView.h"
#import <MessageUI/MFMailComposeViewController.h>

typedef enum {
    DOOR_SingleSideOpening,
    DOOR_CenterOpening,
    DoorTypeOptions
} DoorType;


typedef enum {
    COP_Swing,
    COP_Applied,
    CopTypeOptions
} CopType;

typedef enum {
    F_Stainless,
    F_Brass,
    FinishTypeOptions
} FinishType;

typedef enum {
    E_None,
    E_NoSmoking,
    E_NoSmokingCapacity,
    E_Capacity,
    EngravingsTypeOptions
} EngravingsType;

typedef enum {
    PI_None,
    PI_RedMH222,
    PI_BlueMH222,
    PI_Giotto43,
    PI_Giotto7,
    PI_Matisse7,
    PI_Matisse10,
    PositionIndicatorOptions
} PositionIndicatorType;



typedef enum {
    L_MainCop,
    L_AuxCop,
    L_MainAuxCop,
    LocationTypeOptions,
} LocationType;

typedef enum {
    FS_None,
    FS_Cabinet,
    FS_Code,
    FireServiceOptions
} FireServiceType;

typedef enum {
    SS_None,
    SS_CodeBlue,
    SpecialServiceOptions
} SpecialServiceType;


typedef enum {
    PB_SmSquare,
    PB_JuliusSurround,
    PB_Ceaser,
    PB_Dune,
    PB_PinBrail,
    PB_Slimline,
    PB_FmJulius,
    PB_FmRound,
    PB_FmSquare,
    PB_BlackCeasar,
    PushButtonOptions
} PushButtonType;

typedef enum {
    O_FrontOnly,
    O_FrontRear,
    OpeningOptions
} OpeningType;

typedef enum {
    AC_None,
    AC_CardReaderProvision,
    AccessControlOptions
} AccessControlType;



typedef enum {
    SC_None,
    SC_Blank,
    SC_CertificateWindow,
    SC_Engravings,
    ServiceCabinetOptions
} ServiceCabinetType;

typedef enum {
    TS_None,
    TS_22,
    TS_19w,
    TS_19s,
    TS_17,
    TouchscreenOptions
} TouchscreenType;

typedef enum {
    COORD_A_SINGLE,
    COORD_A_CENTER,
    COORD_B_SINGLE,
    COORD_B_CENTER
} CoordType;

typedef enum {
    CB_DoorType,
    CB_Coptype,
    CB_Finish,
    CB_Engraving,
    //CB_EngravingLoc,
    CB_PositionIndicator,
    //CB_PositionIndicatorLoc,
    CB_EmergencyLight,
    //CB_EmergencyLightLoc,
    CB_Autodialer,
    //CB_AutodialerLoc,
    CB_FireService,
    //CB_FireServiceLoc,
    CB_OtherService,
    CB_Touchscreen,
    //CB_TouchscreenLoc,
    CB_Pushbutton,
    //CB_PushbuttonNumOpenings,
    CB_RearOpening,
    CB_AccessControl,
    //CB_AccessControlLoc,
    CB_ServiceCabinet,
    //CB_ServiceCabinetLoc
} ConfigButtonType;







@interface CopViewController : UIViewController <UIPickerViewDelegate, MFMailComposeViewControllerDelegate, UITableViewDelegate, V8HorizontalPickerViewDelegate, V8HorizontalPickerViewDataSource,  UIScrollViewDelegate>
{


    IBOutlet UIImageView *imgBg;
    
    IBOutlet UIImageView *imgM2;
    IBOutlet UIImageView *imgM3;
    IBOutlet UIImageView *imgM4;
    IBOutlet UIImageView *imgM5;
    IBOutlet UIImageView *imgM6;
    IBOutlet UIImageView *imgM7;
    IBOutlet UIImageView *imgM8;
    IBOutlet UIImageView *imgM9;
    IBOutlet UIImageView *imgM10;
    IBOutlet UIImageView *imgM11;

    

    IBOutlet UIImageView *imgA2;
    IBOutlet UIImageView *imgA3;
    IBOutlet UIImageView *imgA4;
    IBOutlet UIImageView *imgA5;
    IBOutlet UIImageView *imgA6;
    IBOutlet UIImageView *imgA7;
    IBOutlet UIImageView *imgA8;
    IBOutlet UIImageView *imgA9;
    IBOutlet UIImageView *imgA10;
    IBOutlet UIImageView *imgA11;
    
    IBOutlet UIView *viewConfiguration;

    
    IBOutlet UIButton *btnHome;
    IBOutlet UIButton *btnEmail;
    IBOutlet UIButton *btnConfirguration;
    
    
    IBOutlet UIView *viewUserInterface;
    
    IBOutlet UIImageView *imgUiBg;
    
    
    // the table view stuff
    IBOutlet UITableView *tblOptionsCOP;
    
}


@property (nonatomic, strong) IBOutlet V8HorizontalPickerView *hPickerView;
@property (nonatomic, strong) IBOutlet V8HorizontalPickerView *hPickerViewExtra;


@property(nonatomic, retain)IBOutlet UIImageView *imgBg;

@property(nonatomic, retain)IBOutlet UIImageView *imgM2;
@property(nonatomic, retain)IBOutlet UIImageView *imgM3;
@property(nonatomic, retain)IBOutlet UIImageView *imgM4;
@property(nonatomic, retain)IBOutlet UIImageView *imgM5;
@property(nonatomic, retain)IBOutlet UIImageView *imgM6;
@property(nonatomic, retain)IBOutlet UIImageView *imgM7;
@property(nonatomic, retain)IBOutlet UIImageView *imgM8;
@property(nonatomic, retain)IBOutlet UIImageView *imgM9;
@property(nonatomic, retain)IBOutlet UIImageView *imgM10;
@property(nonatomic, retain)IBOutlet UIImageView *imgM11;



@property(nonatomic, retain)IBOutlet UIImageView *imgA2;
@property(nonatomic, retain)IBOutlet UIImageView *imgA3;
@property(nonatomic, retain)IBOutlet UIImageView *imgA4;
@property(nonatomic, retain)IBOutlet UIImageView *imgA5;
@property(nonatomic, retain)IBOutlet UIImageView *imgA6;
@property(nonatomic, retain)IBOutlet UIImageView *imgA7;
@property(nonatomic, retain)IBOutlet UIImageView *imgA8;
@property(nonatomic, retain)IBOutlet UIImageView *imgA9;
@property(nonatomic, retain)IBOutlet UIImageView *imgA10;
@property(nonatomic, retain)IBOutlet UIImageView *imgA11;



@property(nonatomic, retain)IBOutlet UIView *viewConfiguration;
@property(nonatomic, retain)IBOutlet UIScrollView *viewConfigurationScroll;




@property(nonatomic, retain)IBOutlet UIButton *btnHome;
@property(nonatomic, retain)IBOutlet UIButton *btnEmail;
@property(nonatomic, retain)IBOutlet UIButton *btnConfirguration;


@property(nonatomic, retain)IBOutlet UIImageView *imgUiBg;
@property(nonatomic, retain)IBOutlet UIView *viewUserInterface;

@property(nonatomic, retain)IBOutlet UITableView *tblOptionsCOP;


@property (nonatomic, strong) IBOutlet UIScrollView *scrollView;
@property (nonatomic, strong) IBOutlet UIView *containerView;


@property (nonatomic, weak) IBOutlet NSLayoutConstraint *varConstraint;
@property (nonatomic, weak) IBOutlet UILabel *rotateLabel;

@end
