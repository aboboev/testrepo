//
//  DisplayDocument.m
//  MadFixtures
//
//  Created by Antonio Pena on 12-03-17.
//  Copyright (c) 2012 Kioaxis. All rights reserved.
//

#import "DisplayDocument.h"

@interface DisplayDocument ()

@end

@implementation DisplayDocument

@synthesize headingName, fileName;



-(IBAction)sendEmail {
    
    MFMailComposeViewController *composer = [[MFMailComposeViewController alloc] init];
    
    [composer setMailComposeDelegate:self];
    
    if ([MFMailComposeViewController canSendMail]) {
        
        //[composer setToRecipients:[NSArray arrayWithObjects:@"info@madelevator.com", nil]];
        
         [composer setCcRecipients:[NSArray arrayWithObjects:@"info@madelevator.com", nil]];
        
        [composer setSubject:@"MAD Elevator - Documentation"];

        
        NSString *TheMsg = [NSString stringWithFormat:@"\n\nPlease find attached requested documentation. \n\n      %@  \n\nPlease let you MAD Sales Rep know if you have any questions.\n\n\nThe MAD Elevator Team\n1-866-967-8500\ninfo@madelevator.com\n\n Sent from MAD Fixtures App",headingName];
        
        
        [composer setMessageBody:TheMsg isHTML:NO];
        
        
        // Attach a pdf to the email
        NSString * pdfPath = [[NSBundle mainBundle] pathForResource:fileName ofType:@"pdf"];
        NSData * data = [NSData dataWithContentsOfFile:pdfPath];
       // NSMutableData *data = [NSMutableData dataWithContentsOfFile:pdfPath];
        
        [composer addAttachmentData:data mimeType:@"application/pdf" fileName:[NSString stringWithFormat:@"%@.pdf", fileName]];
        
        
        //UIImage *photoImage = [UIImage imageNamed:photo]; 
        //NSData *photoData = UIImageJPEGRepresentation(photoImage, 1); 
        //[composer addAttachmentData:photoData mimeType:@"image/jpeg" fileName:photo]; 
        
        
        
        [composer setModalTransitionStyle:UIModalTransitionStyleCrossDissolve];
        
        
        [self presentViewController:composer animated:YES completion:nil];
        
        //[self presentModalViewController:composer animated:YES];
        
        
        //[composer release];
        
    }
    
    //else
    
    //[composer release];
    
}

-(void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error {
    
    if (error) {
        UIAlertController * alert = [UIAlertController
                                     alertControllerWithTitle:@"Error Occured"
                                     message:[NSString stringWithFormat:@"error - %@", [error description]]
                                     preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction* dismissButton = [UIAlertAction
                                        actionWithTitle:@"dismiss"
                                        style:UIAlertActionStyleDefault
                                        handler:^(UIAlertAction * action) {
                                            //Handle your yes please button action here
                                            [alert dismissViewControllerAnimated:YES completion:nil];
                                        }];
        [alert addAction:dismissButton];
        [self presentViewController:alert animated:YES completion:nil];
        
        //[self dismissModalViewControllerAnimated:YES];
        [self dismissViewControllerAnimated:YES completion:nil];
        
    }
    
    else {
        
       // [self dismissModalViewControllerAnimated:YES];
        [self dismissViewControllerAnimated:YES completion:nil];
        
    }
    
} 



- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    self.title = headingName;  //@"Document Name Here";
    
    
    NSURL *url = [NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:fileName ofType:@"pdf"]];
    
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    webView.scalesPageToFit = YES;
	webView.autoresizingMask = (UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight);
	
    
    [webView loadRequest:request];
    
    [webView addSubview:activityInd];
    
    timer = [NSTimer scheduledTimerWithTimeInterval:(1.0/2.0)
             
                                             target:self
             
                                           selector:@selector(loading)
             
                                           userInfo:nil
             
                                            repeats:YES];
    
    
}

-(void)loading {  
    
    if (!webView.loading)
        
        [activityInd stopAnimating];
        
    else
        
        [activityInd startAnimating];
    
}

- (BOOL)shouldAutorotate
{
    return (YES);
}



- (BOOL)prefersStatusBarHidden
{
    return YES;
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    UIViewController *vc = [segue destinationViewController];
    vc.modalPresentationStyle = UIModalPresentationFullScreen;
}

@end
