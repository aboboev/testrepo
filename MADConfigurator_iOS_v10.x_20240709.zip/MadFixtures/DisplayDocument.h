//
//  DisplayDocument.h
//  MadFixtures
//
//  Created by Antonio Pena on 12-03-17.
//  Copyright (c) 2012 Kioaxis. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MessageUI/MFMailComposeViewController.h>

@interface DisplayDocument : UIViewController<UIWebViewDelegate, MFMailComposeViewControllerDelegate>{
    #pragma clang diagnostic ignored "-Wdeprecated-declarations"
    IBOutlet UIWebView *webView;
    IBOutlet UIActivityIndicatorView *activityInd;
    NSTimer *timer;
}

@property (nonatomic, strong) NSString *headingName;
@property (nonatomic, strong) NSString *fileName;

-(IBAction)sendEmail;

@end
