//
//  XMLParser.m
//  MadCabConfigurator
//
//  Created by Alex on 1/14/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import "XMLParser.h"
#import "TreeNode.h"

@implementation XMLParser

static XMLParser *sharedInstance = nil;
// Use just one parser instance at any time
+(XMLParser *) sharedInstance
{
    if(!sharedInstance) {
        sharedInstance = [[self alloc] init];
    }
    return sharedInstance;
}

// Public parser returns the tree root
- (TreeNode *)parseXMLFile: (NSURL *) url
{
    stack = [[NSMutableArray alloc] init];
    root = [[TreeNode alloc] init];
    root.parent = nil;
    root.leafvalue = nil;
    root.attributes = nil;
    root.children = [[NSMutableArray alloc] init];
    [stack addObject:root];
    
    NSXMLParser *parser = [[NSXMLParser alloc] initWithContentsOfURL:url];
    [parser setDelegate:self];
    [parser parse];
    // pop down to real root
    return [[root children] lastObject];
}

// Descend to a new element
- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(nullable NSString *)namespaceURI qualifiedName:(nullable NSString *)qName attributes:(NSDictionary<NSString *, NSString *> *)attributeDict {
    
    if (qName) elementName = qName;
    TreeNode *leaf = [[TreeNode alloc] init];
    leaf.parent = [stack lastObject];
    [(NSMutableArray *)[[stack lastObject] children] addObject:leaf];
    leaf.key = [NSString stringWithString:elementName];
    leaf.leafvalue = NULL;
    leaf.children = [[NSMutableArray alloc] init];
    leaf.attributes = attributeDict;
    
    [stack addObject:leaf];
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(nullable NSString *)namespaceURI qualifiedName:(nullable NSString *)qName {
    [stack removeLastObject];
}

// Reached a leaf
- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
    NSString * leaf = [[stack lastObject] leafvalue];
    if (leaf == nil) {
        [[stack lastObject] setLeafvalue:[NSString stringWithString:string]];
    } else {
        leaf = [leaf stringByAppendingString:string];
        [[stack lastObject] setLeafvalue:leaf];
    }
}

@end
