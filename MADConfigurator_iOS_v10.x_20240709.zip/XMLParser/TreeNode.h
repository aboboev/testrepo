//
//  TreeNode.h
//  MadCabConfigurator
//
//  Created by Alex on 1/14/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TreeNode : NSObject
{
    
}

@property (nonatomic, strong) TreeNode * parent;
@property (nonatomic, strong) NSMutableArray * children;
@property (nonatomic, strong) NSString * key;
@property (nonatomic, strong) NSString * leafvalue;
@property (nonatomic, strong) NSDictionary * attributes;

- (TreeNode *) childElementByName:(NSString*) name;

@end
