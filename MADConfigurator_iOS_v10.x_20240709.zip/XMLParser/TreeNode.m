//
//  TreeNode.m
//  MadCabConfigurator
//
//  Created by Alex on 1/14/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import "TreeNode.h"

@implementation TreeNode

- (TreeNode *) childElementByName:(NSString*) name {
    TreeNode * child = nil;
    
    for (TreeNode * node in self.children) {
        if ([node.key isEqualToString:name]) {
            child = node;
            break;
        }
    }
    
    return child;
}

@end
