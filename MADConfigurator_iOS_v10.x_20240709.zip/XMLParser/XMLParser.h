//
//  XMLParser.h
//  MadCabConfigurator
//
//  Created by Alex on 1/14/20.
//  Copyright © 2020 MAD Elevator Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@class TreeNode;
@interface XMLParser : NSObject <NSXMLParserDelegate>
{
    NSMutableArray * stack;
    TreeNode * root;
}

+(XMLParser *) sharedInstance;
- (TreeNode *)parseXMLFile: (NSURL *) url;

@end
